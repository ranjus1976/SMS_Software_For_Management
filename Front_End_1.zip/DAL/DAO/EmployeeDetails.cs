﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SMSapplication.DAL.DAO
{
    public class EmployeeDetails
    {
        private int employeeID;
        private string employeeName;
        private string empAddress;
        private string empDOB;
        private int empDesignationID;
        private string empDesignation;
        private int empDepartmentID;
        private string empDepartmentName;
        private string empOfficialCellNo;
        private int empGroupID;
        private string empGroupName;
        private string empActivate;

        public EmployeeDetails()
        {
            
        }

        public EmployeeDetails(string employeeNameEdit, string empAddressEdit, string empDOBEdit, int empDesignationIDEdit, string empDesignationEdit, int empDepartmentIDEdit, string empDepartmentNameEdit, string empOfficialCellNoEdit, int empGroupIDEdit, string empGroupNameEdit, string empActivateEdit)
        {
            this.EmployeeName = employeeNameEdit;
            this.EmpAddress = empAddressEdit;
            this.EmpDob = empDOBEdit;
            this.EmpDesignationId = empDepartmentIDEdit;
            this.EmpDesignation = empDesignationEdit;
            this.EmpDepartmentId = empDepartmentIDEdit;
            this.EmpDepartmentName = empDepartmentNameEdit;
            this.EmpOfficialCellNo = empOfficialCellNoEdit;
            this.EmpGroupId = empGroupIDEdit;
            this.EmpGroupName = empGroupNameEdit;
            this.EmpActivate = empActivateEdit;
        }

        public int EmployeeId
        {
            get { return employeeID; }
            set { employeeID = value; }
        }

        public string EmployeeName
        {
            get { return employeeName; }
            set { employeeName = value; }
        }

        public string EmpAddress
        {
            get { return empAddress; }
            set { empAddress = value; }
        }

        public string EmpDob
        {
            get { return empDOB; }
            set { empDOB = value; }
        }

        public int EmpDesignationId
        {
            get { return empDesignationID; }
            set { empDesignationID = value; }
        }

        public string EmpDesignation
        {
            get { return empDesignation; }
            set { empDesignation = value; }
        }

        public int EmpDepartmentId
        {
            get { return empDepartmentID; }
            set { empDepartmentID = value; }
        }

        public string EmpDepartmentName
        {
            get { return empDepartmentName; }
            set { empDepartmentName = value; }
        }

        public string EmpOfficialCellNo
        {
            get { return empOfficialCellNo; }
            set { empOfficialCellNo = value; }
        }

        public int EmpGroupId
        {
            get { return empGroupID; }
            set { empGroupID = value; }
        }

        public string EmpGroupName
        {
            get { return empGroupName; }
            set { empGroupName = value; }
        }

        public string EmpActivate
        {
            get { return empActivate; }
            set { empActivate = value; }
        }
    }
}
