﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SMSapplication.DAL.DAO
{
    class UserRoleDetails
    {
        private string userRoleID;
        private string userRole;

        public UserRoleDetails()
        {

        }

        public UserRoleDetails(string userRoleEdit)
        {
            this.UserRole = userRoleEdit;
        }

        public string UserRole
        {
            get { return userRole; }
            set { userRole = value; }
        }

        public string UserRoleId
        {
            get { return userRoleID; }
            set { userRoleID = value; }
        }
    }
}
