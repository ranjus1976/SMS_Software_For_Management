﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SMSapplication.DAL.DAO
{
    class GroupDetails
    {
        private string groupName;
        private string location;
        private string groupActivate;

        public GroupDetails()
        {
            
        }

        public GroupDetails(string groupNameEdit, string locationEdit, string groupActivateEdit)
        {
            this.GroupName = groupNameEdit;
            this.Location = locationEdit;
            this.GroupActivate = groupNameEdit;
        }

        public string GroupName
        {
            get { return groupName; }
            set { groupName = value; }
        }

        public string Location
        {
            get { return location; }
            set { location = value; }
        }

        public string GroupActivate
        {
            get { return groupActivate; }
            set { groupActivate = value; }
        }
    }
}
