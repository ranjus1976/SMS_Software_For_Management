﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.Data.Common;

namespace SMSapplication.DAL.DAO
{
    class GlobalClass
    {
        #region Variable Declaratio

        string passPhrase = "Pas5pr@se";            // can be any string
        string saltValue = "s@1tValue";            // can be any string
        string hashAlgorithm = "SHA1";            // can be "MD5"
        int passwordIterations = 2;              // can be any number
        string initVector = "@1B2c3D4e5F6g7H8"; // must be 16 bytes
        int keySize = 256;                     // can be 192 or 128

        #endregion

        private static DbProviderFactory dbProviderFactory;
        private static DbConnection dbConnection;

        private static string loginUserName;
        private static string userIDForEditUserDetails;
        private static string groupIDForUpdateGroup;
        public static string smsText;
        private static string deptIDForUpdateDepartment;
        private static string designationIDforUpdateDesignation;
        private static string empIDforUpdateEmployee;
        private static int selectOption;
        private static string groupSelectedFromGroupSetup;
        private static string groupIDForGroupSetup;
        private static string groupSetupIDForUpdateGroupSetup;
        private static string marketIdForUpdate;
        private static string productIDForUpdateProduct;
        private static decimal currCostPrice;
        private static decimal currSalePrice;
        private static string productCode;

        private static string fromDateForSalesTarget;
        private static string toDateForSalesTarget;
        private static string groupNameForSalesTarget;
        private static string empDesignationForSalesTarget;
        private static string empNameForSalesTarget;
        private static string empIdForSalesTarget;
        private static string empMobileNoForSalesTarget;
        private static decimal orderAmountForSalesTarget;

        private static string productIdForSalesTarget;
        private static string productCodeForSalesTarget;
        private static string productNameForSalesTarget;
        private static decimal productSalesPriceForSalesTarget;
        private static int salesTargetIDForUpdateSalesTarget;

        private static string productCodeForSpecialSalesTarget;
        private static string productIdForSpecialSalesTarget;
        private static string productNameForSpecialSalesTarget;
        private static decimal productSalesPriceForSpecialSalesTarget;
        private static decimal productCostPriceForSpecialSalesTarget;

        private static string serverName;
        private static string databaseName;
        private static string userName;
        private static string password;

        private static string tabNameForProductListUI;

        //04 apr 2016
        private static string empIDForSales;
        private static string empNameForSales;
        private static string empDesignationForSales;
        private static string empCellNoForSales;
        private static string empGroupNameForSales;
        private static string empMarketCodeForSales;
        private static string empMarketNameForSales;

        private static string proIdForSales;
        private static string proCodeForSales;
        private static string proNameForSales;
        private static decimal proCostPriceForSales;
        private static decimal proSalePriceForSales;
        private static int proQuantityForSales;
        private static decimal proSaleAmountForSales;

        private static string smsDetails;
        private static string smsCutting;
        private static string marketCodeOfEmpForSales;

        private static int salesTargetDataGridViewValue;
        private static string salesDate;
        private static string salesMonth;
        private static string salesDay;
        private static string salesYear;

        private static int divisionIdForUpdateDivision;
        private static string divisionNameForUpdateDivision;
        private static int groupIdForUpdateDivision;
        private static string groupNameForUpdateDivision;
        private static string empNameForUpdateDivision;
        private static string empDesiForUpdateDivision;
        private static string empActivateForUpdateDivision;

        private static string divisionNameToLoadDivision;

        private static string marketCodeForUpdateMarketSetup;

        private static int enableDisableFormValueForReloadDivisionGrid;

        private static string divisionNameOfEmployeeForSalesTarget;

        private static string passwordCheckForUserUpdate;

        //26 July
        private static string previousTeamName;
        private static string previousEmpNameFromTeam;
        private static string previousDivisionName;
        private static string previousEmployeeNameForDivision;
        private static string previousTeamNameForDivision;
        private static int previousTeamIDForDivision;
        // end 26 July

        // 03 Aug 2016
        private static int regionIDForUpdateRegion;
        private static string previousRegionName;
        private static string previousEmployeeNameForRegion;
        private static string previousDivisionNameForRegion;
        private static int previousDivisionIDForRegion;
        // end of 03 Aug 2016

        // 15 Aug 2016
        private static int zoneIdForUpdateZone;
        private static string previousZoneName;
        private static string previousEmployeeNameForZone;
        private static string previousRegionNameForZone;
        private static int previousRegionIDForZone;
        // end 15 Aug 2016

        //27 Aug 2016
        private static int areaIDForUpdateArea;
        private static string previousAreaName;
        private static string previousEmployeeNameForArea;
        private static string previousZoneNameForArea;
        private static int previousZoneIDForArea;
        // End 27 Aug 2016
        
        public string Encrypt(string plainText)
        {
            // Convert strings into byte arrays.
            // Let us assume that strings only contain ASCII codes.
            // If strings include Unicode characters, use Unicode, UTF7, or UTF8 
            // encoding.
            byte[] initVectorBytes = Encoding.ASCII.GetBytes(initVector);
            byte[] saltValueBytes = Encoding.ASCII.GetBytes(saltValue);

            // Convert our plaintext into a byte array.
            // Let us assume that plaintext contains UTF8-encoded characters.
            byte[] plainTextBytes = Encoding.UTF8.GetBytes(plainText);

            // First, we must create a password, from which the key will be derived.
            // This password will be generated from the specified passphrase and 
            // salt value. The password will be created using the specified hash 
            // algorithm. Password creation can be done in several iterations.
            PasswordDeriveBytes password = new PasswordDeriveBytes(
                                                            passPhrase,
                                                            saltValueBytes,
                                                            hashAlgorithm,
                                                            passwordIterations);
            //PasswordRecovery pss = new PasswordRecovery();
            //pss.

            // Use the password to generate pseudo-random bytes for the encryption
            // key. Specify the size of the key in bytes (instead of bits).
            byte[] keyBytes = password.GetBytes(keySize / 8);

            // Create uninitialized Rijndael encryption object.
            RijndaelManaged symmetricKey = new RijndaelManaged();

            // It is reasonable to set encryption mode to Cipher Block Chaining
            // (CBC). Use default options for other symmetric key parameters.
            symmetricKey.Mode = CipherMode.CBC;

            // Generate encryptor from the existing key bytes and initialization 
            // vector. Key size will be defined based on the number of the key 
            // bytes.
            ICryptoTransform encryptor = symmetricKey.CreateEncryptor(
                                                             keyBytes,
                                                             initVectorBytes);

            // Define memory stream which will be used to hold encrypted data.
            MemoryStream memoryStream = new MemoryStream();

            // Define cryptographic stream (always use Write mode for encryption).
            CryptoStream cryptoStream = new CryptoStream(memoryStream,
                                                         encryptor,
                                                         CryptoStreamMode.Write);
            // Start encrypting.
            cryptoStream.Write(plainTextBytes, 0, plainTextBytes.Length);

            // Finish encrypting.
            cryptoStream.FlushFinalBlock();

            // Convert our encrypted data from a memory stream into a byte array.
            byte[] cipherTextBytes = memoryStream.ToArray();

            // Close both streams.
            memoryStream.Close();
            cryptoStream.Close();

            // Convert encrypted data into a base64-encoded string.
            string cipherText = Convert.ToBase64String(cipherTextBytes);

            // Return encrypted string.
            return cipherText;
        }

        public string Decrypt(string cipherText)
        {
            // Convert strings defining encryption key characteristics into byte
            // arrays. Let us assume that strings only contain ASCII codes.
            // If strings include Unicode characters, use Unicode, UTF7, or UTF8
            // encoding.
            byte[] initVectorBytes = Encoding.ASCII.GetBytes(initVector);
            byte[] saltValueBytes = Encoding.ASCII.GetBytes(saltValue);

            // Convert our ciphertext into a byte array.
            byte[] cipherTextBytes = Convert.FromBase64String(cipherText);

            // First, we must create a password, from which the key will be 
            // derived. This password will be generated from the specified 
            // passphrase and salt value. The password will be created using
            // the specified hash algorithm. Password creation can be done in
            // several iterations.
            PasswordDeriveBytes password = new PasswordDeriveBytes(
                                                            passPhrase,
                                                            saltValueBytes,
                                                            hashAlgorithm,
                                                            passwordIterations);

            // Use the password to generate pseudo-random bytes for the encryption
            // key. Specify the size of the key in bytes (instead of bits).
            byte[] keyBytes = password.GetBytes(keySize / 8);

            // Create uninitialized Rijndael encryption object.
            RijndaelManaged symmetricKey = new RijndaelManaged();

            // It is reasonable to set encryption mode to Cipher Block Chaining
            // (CBC). Use default options for other symmetric key parameters.
            symmetricKey.Mode = CipherMode.CBC;

            // Generate decryptor from the existing key bytes and initialization 
            // vector. Key size will be defined based on the number of the key 
            // bytes.
            ICryptoTransform decryptor = symmetricKey.CreateDecryptor(
                                                             keyBytes,
                                                             initVectorBytes);

            // Define memory stream which will be used to hold encrypted data.
            MemoryStream memoryStream = new MemoryStream(cipherTextBytes);

            // Define cryptographic stream (always use Read mode for encryption).
            CryptoStream cryptoStream = new CryptoStream(memoryStream,
                                                          decryptor,
                                                          CryptoStreamMode.Read);

            // Since at this point we don't know what the size of decrypted data
            // will be, allocate the buffer long enough to hold ciphertext;
            // plaintext is never longer than ciphertext.
            byte[] plainTextBytes = new byte[cipherTextBytes.Length];

            // Start decrypting.
            int decryptedByteCount = cryptoStream.Read(plainTextBytes,
                                                       0,
                                                       plainTextBytes.Length);

            // Close both streams.
            memoryStream.Close();
            cryptoStream.Close();

            // Convert decrypted data into a string. 
            // Let us assume that the original plaintext string was UTF8-encoded.
            string plainText = Encoding.UTF8.GetString(plainTextBytes,
                                                       0,
                                                       decryptedByteCount);

            // Return decrypted string.   
            return plainText;
        }

        public static string LoginUserName
        {
            get { return loginUserName; }
            set { loginUserName = value; }
        }

        public static string UserIdForEditUserDetails
        {
            get { return userIDForEditUserDetails; }
            set { userIDForEditUserDetails = value; }
        }

        public static string GroupIdForUpdateGroup
        {
            get { return groupIDForUpdateGroup; }
            set { groupIDForUpdateGroup = value; }
        }

        public static string SmsText
        {
            get { return smsText; }
            set { smsText = value; }
        }

        public static string DeptIdForUpdateDepartment
        {
            get { return deptIDForUpdateDepartment; }
            set { deptIDForUpdateDepartment = value; }
        }

        public static string DesignationIDforUpdateDesignation
        {
            get { return designationIDforUpdateDesignation; }
            set { designationIDforUpdateDesignation = value; }
        }

        public static string EmpIDforUpdateEmployee
        {
            get { return empIDforUpdateEmployee; }
            set { empIDforUpdateEmployee = value; }
        }

        public static int SelectOption
        {
            get { return selectOption; }
            set { selectOption = value; }
        }

        public static string GroupSelectedFromGroupSetup
        {
            get { return groupSelectedFromGroupSetup; }
            set { groupSelectedFromGroupSetup = value; }
        }

        public static string GroupIdForGroupSetup
        {
            get { return groupIDForGroupSetup; }
            set { groupIDForGroupSetup = value; }
        }

        public static string GroupSetupIdForUpdateGroupSetup
        {
            get { return groupSetupIDForUpdateGroupSetup; }
            set { groupSetupIDForUpdateGroupSetup = value; }
        }

        public static string MarketIdForUpdate
        {
            get { return marketIdForUpdate; }
            set { marketIdForUpdate = value; }
        }

        public static string ProductIdForUpdateProduct
        {
            get { return productIDForUpdateProduct; }
            set { productIDForUpdateProduct = value; }
        }

        public static decimal CurrCostPrice
        {
            get { return currCostPrice; }
            set { currCostPrice = value; }
        }

        public static decimal CurrSalePrice
        {
            get { return currSalePrice; }
            set { currSalePrice = value; }
        }

        public static string ProductCode
        {
            get { return productCode; }
            set { productCode = value; }
        }

        public static string ProductIdForSalesTarget
        {
            get { return productIdForSalesTarget; }
            set { productIdForSalesTarget = value; }
        }

        public static string ProductCodeForSalesTarget
        {
            get { return productCodeForSalesTarget; }
            set { productCodeForSalesTarget = value; }
        }

        public static string ProductNameForSalesTarget
        {
            get { return productNameForSalesTarget; }
            set { productNameForSalesTarget = value; }
        }

        public static decimal ProductSalesPriceForSalesTarget
        {
            get { return productSalesPriceForSalesTarget; }
            set { productSalesPriceForSalesTarget = value; }
        }

        public static int SalesTargetIdForUpdateSalesTarget
        {
            get { return salesTargetIDForUpdateSalesTarget; }
            set { salesTargetIDForUpdateSalesTarget = value; }
        }

        public static string ServerName
        {
            get { return serverName; }
            set { serverName = value; }
        }

        public static string DatabaseName
        {
            get { return databaseName; }
            set { databaseName = value; }
        }

        public static string UserName
        {
            get { return userName; }
            set { userName = value; }
        }

        public static string Password
        {
            get { return password; }
            set { password = value; }
        }

        public static string ProductCodeForSpecialSalesTarget
        {
            get { return productCodeForSpecialSalesTarget; }
            set { productCodeForSpecialSalesTarget = value; }
        }

        public static string ProductIdForSpecialSalesTarget
        {
            get { return productIdForSpecialSalesTarget; }
            set { productIdForSpecialSalesTarget = value; }
        }

        public static string ProductNameForSpecialSalesTarget
        {
            get { return productNameForSpecialSalesTarget; }
            set { productNameForSpecialSalesTarget = value; }
        }

        public static decimal ProductSalesPriceForSpecialSalesTarget
        {
            get { return productSalesPriceForSpecialSalesTarget; }
            set { productSalesPriceForSpecialSalesTarget = value; }
        }

        public static decimal ProductCostPriceForSpecialSalesTarget
        {
            get { return productCostPriceForSpecialSalesTarget; }
            set { productCostPriceForSpecialSalesTarget = value; }
        }

        public static string TabNameForProductListUi
        {
            get { return tabNameForProductListUI; }
            set { tabNameForProductListUI = value; }
        }

        public static string EmpIdForSales
        {
            get { return empIDForSales; }
            set { empIDForSales = value; }
        }

        public static string EmpDesignationForSales
        {
            get { return empDesignationForSales; }
            set { empDesignationForSales = value; }
        }

        public static string EmpNameForSales
        {
            get { return empNameForSales; }
            set { empNameForSales = value; }
        }

        public static string EmpCellNoForSales
        {
            get { return empCellNoForSales; }
            set { empCellNoForSales = value; }
        }

        public static string EmpGroupNameForSales
        {
            get { return empGroupNameForSales; }
            set { empGroupNameForSales = value; }
        }

        public static string EmpMarketCodeForSales
        {
            get { return empMarketCodeForSales; }
            set { empMarketCodeForSales = value; }
        }

        public static string EmpMarketNameForSales
        {
            get { return empMarketNameForSales; }
            set { empMarketNameForSales = value; }
        }

        public static string ProIdForSales
        {
            get { return proIdForSales; }
            set { proIdForSales = value; }
        }

        public static string ProCodeForSales
        {
            get { return proCodeForSales; }
            set { proCodeForSales = value; }
        }

        public static string ProNameForSales
        {
            get { return proNameForSales; }
            set { proNameForSales = value; }
        }

        public static decimal ProCostPriceForSales
        {
            get { return proCostPriceForSales; }
            set { proCostPriceForSales = value; }
        }

        public static decimal ProSalePriceForSales
        {
            get { return proSalePriceForSales; }
            set { proSalePriceForSales = value; }
        }

        public static int ProQuantityForSales
        {
            get { return proQuantityForSales; }
            set { proQuantityForSales = value; }
        }

        public static decimal ProSaleAmountForSales
        {
            get { return proSaleAmountForSales; }
            set { proSaleAmountForSales = value; }
        }

        public static string SmsDetails
        {
            get { return smsDetails; }
            set { smsDetails = value; }
        }

        public static string SmsCutting
        {
            get { return smsCutting; }
            set { smsCutting = value; }
        }

        public static string FromDateForSalesTarget
        {
            get { return fromDateForSalesTarget; }
            set { fromDateForSalesTarget = value; }
        }

        public static string ToDateForSalesTarget
        {
            get { return toDateForSalesTarget; }
            set { toDateForSalesTarget = value; }
        }

        public static string GroupNameForSalesTarget
        {
            get { return groupNameForSalesTarget; }
            set { groupNameForSalesTarget = value; }
        }

        public static string EmpDesignationForSalesTarget
        {
            get { return empDesignationForSalesTarget; }
            set { empDesignationForSalesTarget = value; }
        }

        public static string EmpNameForSalesTarget
        {
            get { return empNameForSalesTarget; }
            set { empNameForSalesTarget = value; }
        }

        public static string EmpIdForSalesTarget
        {
            get { return empIdForSalesTarget; }
            set { empIdForSalesTarget = value; }
        }

        public static string EmpMobileNoForSalesTarget
        {
            get { return empMobileNoForSalesTarget; }
            set { empMobileNoForSalesTarget = value; }
        }

        public static decimal OrderAmountForSalesTarget
        {
            get { return orderAmountForSalesTarget; }
            set { orderAmountForSalesTarget = value; }
        }

        public static int SalesTargetDataGridViewValue
        {
            get { return salesTargetDataGridViewValue; }
            set { salesTargetDataGridViewValue = value; }
        }

        public static string MarketCodeOfEmpForSales
        {
            get { return marketCodeOfEmpForSales; }
            set { marketCodeOfEmpForSales = value; }
        }

        public static string SalesDate
        {
            get { return salesDate; }
            set { salesDate = value; }
        }

        public static string SalesMonth
        {
            get { return salesMonth; }
            set { salesMonth = value; }
        }

        public static string SalesDay
        {
            get { return salesDay; }
            set { salesDay = value; }
        }

        public static string SalesYear
        {
            get { return salesYear; }
            set { salesYear = value; }
        }

        public static int DivisionIdForUpdateDivision
        {
            get { return divisionIdForUpdateDivision; }
            set { divisionIdForUpdateDivision = value; }
        }

        public static string DivisionNameForUpdateDivision
        {
            get { return divisionNameForUpdateDivision; }
            set { divisionNameForUpdateDivision = value; }
        }

        public static int GroupIdForUpdateDivision
        {
            get { return groupIdForUpdateDivision; }
            set { groupIdForUpdateDivision = value; }
        }

        public static string GroupNameForUpdateDivision
        {
            get { return groupNameForUpdateDivision; }
            set { groupNameForUpdateDivision = value; }
        }

        public static string EmpNameForUpdateDivision
        {
            get { return empNameForUpdateDivision; }
            set { empNameForUpdateDivision = value; }
        }

        public static string EmpDesiForUpdateDivision
        {
            get { return empDesiForUpdateDivision; }
            set { empDesiForUpdateDivision = value; }
        }

        public static string EmpActivateForUpdateDivision
        {
            get { return empActivateForUpdateDivision; }
            set { empActivateForUpdateDivision = value; }
        }

        public static string DivisionNameToLoadDivision
        {
            get { return divisionNameToLoadDivision; }
            set { divisionNameToLoadDivision = value; }
        }

        public static string MarketCodeForUpdateMarketSetup
        {
            get { return marketCodeForUpdateMarketSetup; }
            set { marketCodeForUpdateMarketSetup = value; }
        }

        public static int EnableDisableFormValueForReloadDivisionGrid
        {
            get { return enableDisableFormValueForReloadDivisionGrid; }
            set { enableDisableFormValueForReloadDivisionGrid = value; }
        }

        public static string DivisionNameOfEmployeeForSalesTarget
        {
            get { return divisionNameOfEmployeeForSalesTarget; }
            set { divisionNameOfEmployeeForSalesTarget = value; }
        }

        public static string PasswordCheckForUserUpdate
        {
            get { return passwordCheckForUserUpdate; }
            set { passwordCheckForUserUpdate = value; }
        }

        public static string PreviousTeamName
        {
            get { return previousTeamName; }
            set { previousTeamName = value; }
        }

        public static string PreviousEmpNameFromTeam
        {
            get { return previousEmpNameFromTeam; }
            set { previousEmpNameFromTeam = value; }
        }

        public static string PreviousDivisionName
        {
            get { return previousDivisionName; }
            set { previousDivisionName = value; }
        }

        public static string PreviousEmployeeNameForDivision
        {
            get { return previousEmployeeNameForDivision; }
            set { previousEmployeeNameForDivision = value; }
        }

        public static int RegionIdForUpdateRegion
        {
            get { return regionIDForUpdateRegion; }
            set { regionIDForUpdateRegion = value; }
        }

        public static string PreviousRegionName
        {
            get { return previousRegionName; }
            set { previousRegionName = value; }
        }

        public static string PreviousEmployeeNameForRegion
        {
            get { return previousEmployeeNameForRegion; }
            set { previousEmployeeNameForRegion = value; }
        }

        public static string PreviousTeamNameForDivision
        {
            get { return previousTeamNameForDivision; }
            set { previousTeamNameForDivision = value; }
        }

        public static int PreviousTeamIdForDivision
        {
            get { return previousTeamIDForDivision; }
            set { previousTeamIDForDivision = value; }
        }

        public static string PreviousDivisionNameForRegion
        {
            get { return previousDivisionNameForRegion; }
            set { previousDivisionNameForRegion = value; }
        }

        public static int PreviousDivisionIdForRegion
        {
            get { return previousDivisionIDForRegion; }
            set { previousDivisionIDForRegion = value; }
        }

        public static int ZoneIdForUpdateZone
        {
            get { return zoneIdForUpdateZone; }
            set { zoneIdForUpdateZone = value; }
        }

        public static string PreviousZoneName
        {
            get { return previousZoneName; }
            set { previousZoneName = value; }
        }

        public static string PreviousEmployeeNameForZone
        {
            get { return previousEmployeeNameForZone; }
            set { previousEmployeeNameForZone = value; }
        }

        public static string PreviousRegionNameForZone
        {
            get { return previousRegionNameForZone; }
            set { previousRegionNameForZone = value; }
        }

        public static int PreviousRegionIdForZone
        {
            get { return previousRegionIDForZone; }
            set { previousRegionIDForZone = value; }
        }

        public static int AreaIdForUpdateArea
        {
            get { return areaIDForUpdateArea; }
            set { areaIDForUpdateArea = value; }
        }

        public static string PreviousAreaName
        {
            get { return previousAreaName; }
            set { previousAreaName = value; }
        }

        public static string PreviousEmployeeNameForArea
        {
            get { return previousEmployeeNameForArea; }
            set { previousEmployeeNameForArea = value; }
        }

        public static string PreviousZoneNameForArea
        {
            get { return previousZoneNameForArea; }
            set { previousZoneNameForArea = value; }
        }

        public static int PreviousZoneIdForArea
        {
            get { return previousZoneIDForArea; }
            set { previousZoneIDForArea = value; }
        }
    }
}
