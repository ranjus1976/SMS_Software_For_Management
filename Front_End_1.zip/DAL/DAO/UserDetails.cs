﻿using System;
using System.Collections.Generic;
using System.Text;


namespace SMSapplication.DAL.DAO
{
    public class UserDetails
    {
        private string userName;
        private string password;
        private int userRoleId;
        private string userRole;
        private string userActivate;

        public UserDetails()
        {

        }

        public UserDetails(string userNameEdit, string passwordEdit, int userRoleIdEdit, string userRoleEdit, string userActivateEdit)
        {
            this.UserName = userNameEdit;
            this.Password = passwordEdit;
            this.UserRoleId = userRoleIdEdit;
            this.UserRole = userRoleEdit;
            this.UserActivate = userActivateEdit;
        }

        public string UserName
        {
            get { return userName; }
            set { userName = value; }
        }

        public string Password
        {
            get { return password; }
            set { password = value; }
        }

        public int UserRoleId
        {
            get { return userRoleId; }
            set { userRoleId = value; }
        }

        public string UserRole
        {
            get { return userRole; }
            set { userRole = value; }
        }

        public string UserActivate
        {
            get { return userActivate; }
            set { userActivate = value; }
        }
    }
}
