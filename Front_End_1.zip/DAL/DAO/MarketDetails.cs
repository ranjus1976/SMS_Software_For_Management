﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SMSapplication.DAL.DAO
{
    public class MarketDetails
    {
        private int marketID;
        private string marketCode;
        private string marketName;
        private int totalNoOfParty;
        private int target;
        private int monthlyNoOfVisit;
        private string active;

        public MarketDetails()
        {
            
        }

        public MarketDetails(string marketCodeEdit, string marketNameEdit, int totalNoOfPartyEdit, int targetEdit,
            int monthlyNoOfVisitEdit, string activeEdit)
        {
            this.MarketCode = marketCodeEdit;
            this.MarketName = marketNameEdit;
            this.TotalNoOfParty = totalNoOfPartyEdit;
            this.Target = targetEdit;
            this.MonthlyNoOfVisit = monthlyNoOfVisitEdit;
            this.Active = activeEdit;
        }

        public int MarketId
        {
            get { return marketID; }
            set { marketID = value; }
        }

        public string MarketCode
        {
            get { return marketCode; }
            set { marketCode = value; }
        }

        public string MarketName
        {
            get { return marketName; }
            set { marketName = value; }
        }

        public int TotalNoOfParty
        {
            get { return totalNoOfParty; }
            set { totalNoOfParty = value; }
        }

        public int Target
        {
            get { return target; }
            set { target = value; }
        }

        public int MonthlyNoOfVisit
        {
            get { return monthlyNoOfVisit; }
            set { monthlyNoOfVisit = value; }
        }

        public string Active
        {
            get { return active; }
            set { active = value; }
        }
    }
}
