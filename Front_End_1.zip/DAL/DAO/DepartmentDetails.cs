﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SMSapplication.DAL.DAO
{
    public class DepartmentDetails
    {
        private int departmrntID;
        private string departmentName;
        private string departmentNameDetails;
        private string departmentActive;

        public DepartmentDetails()
        {
            
        }

        public DepartmentDetails(string departmentNameEdit, string departmentNameDetailsEdit,
            string departmentActiveEdit)
        {
            this.DepartmentName = departmentNameEdit;
            this.DepartmentNameDetails = departmentNameDetailsEdit;
            this.DepartmentActive = departmentActiveEdit;
        }

        public int DepartmrntId
        {
            get { return departmrntID; }
            set { departmrntID = value; }
        }

        public string DepartmentName
        {
            get { return departmentName; }
            set { departmentName = value; }
        }

        public string DepartmentNameDetails
        {
            get { return departmentNameDetails; }
            set { departmentNameDetails = value; }
        }

        public string DepartmentActive
        {
            get { return departmentActive; }
            set { departmentActive = value; }
        }
    }
}
