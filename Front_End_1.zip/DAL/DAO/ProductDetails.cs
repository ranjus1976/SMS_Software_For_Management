﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SMSapplication.DAL.DAO
{
    public class ProductDetails
    {
        private int productID;
        private string productCode;
        private string productName;
        private string packSize;
        private decimal unitCostPrice;
        private decimal unitSalePrice;

        public ProductDetails()
        {
            
        }

        public ProductDetails(string productCodeEdit, string productNameEdit, string packSizeEdit, decimal unitCostPriceEdit, decimal unitSalePriceEdit)
        {
            this.ProductCode = productCodeEdit;
            this.ProductName = productNameEdit;
            this.PackSize = packSizeEdit;
            this.UnitCostPrice = unitCostPriceEdit;
            this.UnitSalePrice = unitSalePriceEdit;
        }

        public int ProductId
        {
            get { return productID; }
            set { productID = value; }
        }

        public string ProductCode
        {
            get { return productCode; }
            set { productCode = value; }
        }

        public string ProductName
        {
            get { return productName; }
            set { productName = value; }
        }

        public string PackSize
        {
            get { return packSize; }
            set { packSize = value; }
        }

        public decimal UnitCostPrice
        {
            get { return unitCostPrice; }
            set { unitCostPrice = value; }
        }

        public decimal UnitSalePrice
        {
            get { return unitSalePrice; }
            set { unitSalePrice = value; }
        }
    }
}
