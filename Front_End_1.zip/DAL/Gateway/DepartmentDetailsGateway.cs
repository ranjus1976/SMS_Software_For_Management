﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Windows.Forms;
using SMSapplication.DAL.DAO;
using SMSapplication.UI;

namespace SMSapplication.DAL.Gateway
{
    public class DepartmentDetailsGateway
    {
        private SqlDataAdapter da = new SqlDataAdapter();
        private SqlDataReader dr;
        private SqlCommand cmd;
        private DataSet ds = new DataSet();
        public DataSet objDSDepartment = new DataSet();

        public DataTable ShowAllDepartment()
        {
            DBConnection.OpenSqlConnection();
            cmd = new SqlCommand("select * from tbl_Department", DBConnection.SqlConnectionObject);
            da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DBConnection.CloseSqlConnection();
            return dt;
        }

        public DataTable LoadAllActiveDepartment()
        {
            DBConnection.OpenSqlConnection();
            cmd = new SqlCommand("select * from tbl_Department where Active = 'Yes'", DBConnection.SqlConnectionObject);
            da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DBConnection.CloseSqlConnection();
            return dt;
        }
    }
}
