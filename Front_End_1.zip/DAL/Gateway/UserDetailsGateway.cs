﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Windows.Forms;
using SMSapplication.DAL.DAO;
using SMSapplication.UI;

namespace SMSapplication.DAL.Gateway
{
    public class UserDetailsGateway
    {
        private SqlDataAdapter da = new SqlDataAdapter();
        private SqlDataReader dr;
        private SqlCommand cmd;
        private SqlCommand cmdDelete;
        private DataSet ds = new DataSet();
        public DataSet objdsUser = new DataSet();
        private string sql = null;
        public int flag;
        private string userName;
        private string password;
        private int userRoleId;
        public static string userRole;
        public static string userActive;
        // new by Tanvir
        //public string getPassfromDB;
        public string decryptDBPass;
        public string getPassFromTxtPass;

        GlobalClass objGlobalClass = new GlobalClass();

        public bool UserLogIn(UserDetails objuserlogin)
        {
            DBConnection.OpenSqlConnection();
            sql = "select * from tbl_User_Details where User_Name='" + objuserlogin.UserName + "'";
            cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
            da.SelectCommand = cmd;
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                dr = cmd.ExecuteReader();
                dr.Read();
                userName = dr[1].ToString();
                password = dr[2].ToString();
                userRoleId = Convert.ToInt32(dr[3]);
                userRole = dr[4].ToString();
                userActive = dr[5].ToString();
                da.Dispose();
                cmd.Dispose();
                DBConnection.CloseSqlConnection();

                decryptDBPass = objGlobalClass.Decrypt(password);

                //if (userName == objuserlogin.UserName && password == objuserlogin.Password && userActive == "Yes")
                //{
                //    flag = 1;
                //}

                if (userName == objuserlogin.UserName && decryptDBPass == objuserlogin.Password && userActive == "Yes")
                {
                    flag = 1;
                }
                else
                {
                    MessageBox.Show("Please provide correct information.");
                    da.Dispose();
                    cmd.Dispose();
                    DBConnection.CloseSqlConnection();
                    flag = 0;
                }
            }
            else
            {
                MessageBox.Show("User Name & Password dose not Match!.");
                da.Dispose();
                cmd.Dispose();
                DBConnection.CloseSqlConnection();
                flag = 0;
            }
            if (flag == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public DataTable combobox_UserType_Display()
        {
            DBConnection.OpenSqlConnection();
            cmd = new SqlCommand("select * from tbl_User_Role", DBConnection.SqlConnectionObject);
            da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DBConnection.CloseSqlConnection();
            return dt;
        }

        public DataTable ShowAllUser()
        {
            DBConnection.OpenSqlConnection();
            cmd = new SqlCommand("select * from tbl_User_Details", DBConnection.SqlConnectionObject);
            da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DBConnection.CloseSqlConnection();
            return dt;
        }

        public DataTable GetActiveUser()
        {
            DBConnection.OpenSqlConnection();
            cmdDelete = new SqlCommand("delete tbl_Temp_User_Details", DBConnection.SqlConnectionObject);
            cmdDelete.ExecuteNonQuery();
            cmd = new SqlCommand("insert into tbl_Temp_User_Details (User_Name,Password,User_Role_ID,User_Role,Active)" +
                                     "select User_Name,Password,User_Role_ID,User_Role,Active from tbl_User_Details where Active = 'Yes'", DBConnection.SqlConnectionObject);
            da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DBConnection.CloseSqlConnection();
            return dt;
        }

        public DataTable GetNonActiveUser()
        {
            DBConnection.OpenSqlConnection();
            cmdDelete = new SqlCommand("delete tbl_Temp_User_Details", DBConnection.SqlConnectionObject);
            cmdDelete.ExecuteNonQuery();
            cmd = new SqlCommand("insert into tbl_Temp_User_Details (User_Name,Password,User_Role_ID,User_Role,Active)" +
                                     "select User_Name,Password,User_Role_ID,User_Role,Active from tbl_User_Details where Active = 'No'", DBConnection.SqlConnectionObject);
            da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DBConnection.CloseSqlConnection();
            return dt;
        }

        public DataTable GetAllUser()
        {
            DBConnection.OpenSqlConnection();
            cmdDelete = new SqlCommand("delete tbl_Temp_User_Details", DBConnection.SqlConnectionObject);
            cmdDelete.ExecuteNonQuery();
            cmd = new SqlCommand("insert into tbl_Temp_User_Details (User_Name,Password,User_Role_ID,User_Role,Active)" +
                                     "select User_Name,Password,User_Role_ID,User_Role,Active from tbl_User_Details", DBConnection.SqlConnectionObject);
            da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DBConnection.CloseSqlConnection();
            return dt;
        }

        public void DeleteTempData()
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("delete tbl_Temp_User_Details", DBConnection.SqlConnectionObject);
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        public DataTable GetTempData()
        {
            DBConnection.OpenSqlConnection();
            cmd = new SqlCommand("select * from tbl_Temp_User_Details", DBConnection.SqlConnectionObject);
            da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DBConnection.CloseSqlConnection();
            return dt;
        }
    }
}
