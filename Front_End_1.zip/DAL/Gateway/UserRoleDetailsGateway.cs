﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Windows.Forms;
using SMSapplication.DAL.DAO;
using SMSapplication.UI;


namespace SMSapplication.DAL.Gateway
{
    public class UserRoleDetailsGateway
    {
        private SqlDataAdapter da = new SqlDataAdapter();
        private SqlCommand cmd;
        private SqlDataReader dr;
        private string userRoleID;
        public string GetUserRoleID(string userRoleName)
        {
            DBConnection.OpenSqlConnection();
            string CommandText = "select * from tbl_User_Role where User_Role='" + userRoleName + "'";
            cmd = new SqlCommand(CommandText, DBConnection.SqlConnectionObject);
            //da = new SqlDataAdapter(cmd);
            da.SelectCommand = cmd;
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                dr = cmd.ExecuteReader();
                dr.Read();
                userRoleID = dr[0].ToString();
                cmd.Dispose();
                DBConnection.CloseSqlConnection();
            }
            return userRoleID;
        }
    }
}
