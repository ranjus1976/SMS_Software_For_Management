﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Windows.Forms;
using SMSapplication.DAL.DAO;
using SMSapplication.UI;


namespace SMSapplication.DAL.Gateway
{
    public class GroupDetailsGateway
    {
        private SqlDataAdapter da = new SqlDataAdapter();
        private SqlDataReader dr;
        private SqlCommand cmd;
        private DataSet ds = new DataSet();
        public DataSet objdsUser = new DataSet();
        private string sql = null;
        public int flag;
        private string userName;
        private string password;
        private int userRoleId;
        public static string userRole;
        public static string userActive;

        public DataTable ShowAllGroup()
        {
            DBConnection.OpenSqlConnection();
            cmd = new SqlCommand("select * from tbl_Group", DBConnection.SqlConnectionObject);
            da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DBConnection.CloseSqlConnection();
            return dt;
        }

        public DataTable LoadActiveGroup()
        {
            DBConnection.OpenSqlConnection();
            cmd = new SqlCommand("select * from tbl_Group where Active = 'Yes'", DBConnection.SqlConnectionObject);
            da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DBConnection.CloseSqlConnection();
            return dt;
        }

        public DataTable LoadSelectGroupForGroupSetup()
        {
            DBConnection.OpenSqlConnection();
            cmd = new SqlCommand("select * from tbl_Group where Active = 'Yes' and Group_Name != 'All Group'", DBConnection.SqlConnectionObject);
            da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DBConnection.CloseSqlConnection();
            return dt;
        }
    }
}
