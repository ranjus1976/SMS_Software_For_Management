﻿using System;
using System.Collections.Generic;
//using System.Linq;
using System.IO;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;
using SMSapplication.DAL.DAO;

namespace SMSapplication.DAL
{
    public class DBConnection
    {
        static string connectionString = "";
        static SqlConnection sqlConnectionObject;
        static StreamReader objStreamReader;
        private static string strSQL;
        private static string serverName;
        private static string databaseName;
        private static string userName;
        private static string password;
   
        public static SqlConnection SqlConnectionObject
        {
            get { return DBConnection.sqlConnectionObject; }
        }

        private static string GetSQLString()
        {
            try
            {
                string startupPath = Application.StartupPath.ToString();
                string fileName = "ServerSetting\\Server.txt";
                string path = startupPath + "\\" + fileName;
                objStreamReader = new StreamReader(path);
                strSQL = objStreamReader.ReadLine();
                //if (strSQL.Contains(";"))
                //{
                //    int index = strSQL.IndexOf(";");
                //    serverName = strSQL.Substring(0, index);
                //    var parts = serverName.Split('=');
                //    serverName = parts[1].ToString();
                //}

                var newParts = strSQL.Split(';');
                serverName = newParts[0].ToString();
                var serverNamePart = serverName.Split('=');
                serverName = serverNamePart[1].ToString();
                GlobalClass.ServerName = serverName.ToString();

                databaseName = newParts[1].ToString();
                var dbNamePart = databaseName.Split('=');
                databaseName = dbNamePart[1].ToString();
                GlobalClass.DatabaseName = databaseName.ToString();

                userName = newParts[2].ToString();
                var userNamePart = userName.Split('=');
                userName = userNamePart[1].ToString();
                GlobalClass.UserName = userName.ToString();

                password = newParts[3].ToString();
                var passwordPart = password.Split('=');
                password = passwordPart[1].ToString();
                GlobalClass.Password = password.ToString();

                
                //serverName = strSQL.Substring()
                objStreamReader.Close();
            }
            
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "No connection to Database........");
            }
            return strSQL;
        }

        static DBConnection()
        {
            //closed on 11/03/2016 for test
            //connectionString = @"Data Source=RANJU-PC\SQL2005;Initial Catalog=SMS_Server_DB;user id=sa;password=123456;Integrated Security=true;";
            //sqlConnectionObject = new SqlConnection(connectionString);
            //end of closed on 11/03/2016 for test
            connectionString = GetSQLString();
            sqlConnectionObject = new SqlConnection(connectionString);
        }

        public static void OpenSqlConnection()
        {
            if (sqlConnectionObject.State == ConnectionState.Open)
            {
                sqlConnectionObject.Close();
            }
            sqlConnectionObject.Open();
        }

        public static void CloseSqlConnection()
        {
            sqlConnectionObject.Close();
        }
    }
}
