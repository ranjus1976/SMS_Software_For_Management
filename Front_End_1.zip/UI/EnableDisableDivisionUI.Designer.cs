﻿namespace SMSapplication.UI
{
    partial class EnableDisableDivisionUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EnableDisableDivisionUI));
            this.label1 = new System.Windows.Forms.Label();
            this.btnCancelEnableOrDisable = new System.Windows.Forms.Button();
            this.btnEnableOrDisable = new System.Windows.Forms.Button();
            this.radioButtonDisableDivision = new System.Windows.Forms.RadioButton();
            this.radioButtonEnableDivision = new System.Windows.Forms.RadioButton();
            this.cmbSelectDivisionForEnableOrDisable = new System.Windows.Forms.ComboBox();
            this.lblSelectDivision = new System.Windows.Forms.Label();
            this.lblSelectGroup = new System.Windows.Forms.Label();
            this.cmbSelectGroupForEnableDisableDivision = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(45, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(252, 24);
            this.label1.TabIndex = 11;
            this.label1.Text = "Please Select a Option.....";
            // 
            // btnCancelEnableOrDisable
            // 
            this.btnCancelEnableOrDisable.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelEnableOrDisable.Location = new System.Drawing.Point(218, 144);
            this.btnCancelEnableOrDisable.Name = "btnCancelEnableOrDisable";
            this.btnCancelEnableOrDisable.Size = new System.Drawing.Size(89, 28);
            this.btnCancelEnableOrDisable.TabIndex = 10;
            this.btnCancelEnableOrDisable.Text = "&Cancel";
            this.btnCancelEnableOrDisable.UseVisualStyleBackColor = true;
            this.btnCancelEnableOrDisable.Click += new System.EventHandler(this.btnCancelEnableOrDisable_Click);
            // 
            // btnEnableOrDisable
            // 
            this.btnEnableOrDisable.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEnableOrDisable.Location = new System.Drawing.Point(123, 144);
            this.btnEnableOrDisable.Name = "btnEnableOrDisable";
            this.btnEnableOrDisable.Size = new System.Drawing.Size(89, 28);
            this.btnEnableOrDisable.TabIndex = 9;
            this.btnEnableOrDisable.Text = "&Ok";
            this.btnEnableOrDisable.UseVisualStyleBackColor = true;
            this.btnEnableOrDisable.Click += new System.EventHandler(this.btnEnableOrDisable_Click);
            // 
            // radioButtonDisableDivision
            // 
            this.radioButtonDisableDivision.AutoSize = true;
            this.radioButtonDisableDivision.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonDisableDivision.Location = new System.Drawing.Point(167, 45);
            this.radioButtonDisableDivision.Name = "radioButtonDisableDivision";
            this.radioButtonDisableDivision.Size = new System.Drawing.Size(140, 20);
            this.radioButtonDisableDivision.TabIndex = 8;
            this.radioButtonDisableDivision.TabStop = true;
            this.radioButtonDisableDivision.Text = "Disable Division";
            this.radioButtonDisableDivision.UseVisualStyleBackColor = true;
            this.radioButtonDisableDivision.CheckedChanged += new System.EventHandler(this.radioButtonDisableDivision_CheckedChanged);
            this.radioButtonDisableDivision.Click += new System.EventHandler(this.radioButtonDisableDivision_Click);
            // 
            // radioButtonEnableDivision
            // 
            this.radioButtonEnableDivision.AutoSize = true;
            this.radioButtonEnableDivision.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonEnableDivision.Location = new System.Drawing.Point(12, 45);
            this.radioButtonEnableDivision.Name = "radioButtonEnableDivision";
            this.radioButtonEnableDivision.Size = new System.Drawing.Size(135, 20);
            this.radioButtonEnableDivision.TabIndex = 7;
            this.radioButtonEnableDivision.TabStop = true;
            this.radioButtonEnableDivision.Text = "Enable Division";
            this.radioButtonEnableDivision.UseVisualStyleBackColor = true;
            this.radioButtonEnableDivision.CheckedChanged += new System.EventHandler(this.radioButtonEnableDivision_CheckedChanged);
            this.radioButtonEnableDivision.Click += new System.EventHandler(this.radioButtonEnableDivision_Click);
            // 
            // cmbSelectDivisionForEnableOrDisable
            // 
            this.cmbSelectDivisionForEnableOrDisable.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSelectDivisionForEnableOrDisable.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectDivisionForEnableOrDisable.FormattingEnabled = true;
            this.cmbSelectDivisionForEnableOrDisable.Location = new System.Drawing.Point(167, 76);
            this.cmbSelectDivisionForEnableOrDisable.Name = "cmbSelectDivisionForEnableOrDisable";
            this.cmbSelectDivisionForEnableOrDisable.Size = new System.Drawing.Size(140, 21);
            this.cmbSelectDivisionForEnableOrDisable.Sorted = true;
            this.cmbSelectDivisionForEnableOrDisable.TabIndex = 123;
            this.cmbSelectDivisionForEnableOrDisable.Text = "Select Division";
            this.cmbSelectDivisionForEnableOrDisable.TextChanged += new System.EventHandler(this.cmbSelectDivisionForEnableOrDisable_TextChanged);
            // 
            // lblSelectDivision
            // 
            this.lblSelectDivision.AutoSize = true;
            this.lblSelectDivision.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectDivision.Location = new System.Drawing.Point(27, 75);
            this.lblSelectDivision.Name = "lblSelectDivision";
            this.lblSelectDivision.Size = new System.Drawing.Size(120, 18);
            this.lblSelectDivision.TabIndex = 124;
            this.lblSelectDivision.Text = "Select Division";
            // 
            // lblSelectGroup
            // 
            this.lblSelectGroup.AutoSize = true;
            this.lblSelectGroup.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectGroup.Location = new System.Drawing.Point(27, 105);
            this.lblSelectGroup.Name = "lblSelectGroup";
            this.lblSelectGroup.Size = new System.Drawing.Size(107, 18);
            this.lblSelectGroup.TabIndex = 126;
            this.lblSelectGroup.Text = "Select Group";
            // 
            // cmbSelectGroupForEnableDisableDivision
            // 
            this.cmbSelectGroupForEnableDisableDivision.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSelectGroupForEnableDisableDivision.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectGroupForEnableDisableDivision.FormattingEnabled = true;
            this.cmbSelectGroupForEnableDisableDivision.Location = new System.Drawing.Point(167, 106);
            this.cmbSelectGroupForEnableDisableDivision.Name = "cmbSelectGroupForEnableDisableDivision";
            this.cmbSelectGroupForEnableDisableDivision.Size = new System.Drawing.Size(140, 21);
            this.cmbSelectGroupForEnableDisableDivision.Sorted = true;
            this.cmbSelectGroupForEnableDisableDivision.TabIndex = 125;
            this.cmbSelectGroupForEnableDisableDivision.Text = "Select Group";
            // 
            // EnableDisableDivisionUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(331, 197);
            this.Controls.Add(this.lblSelectGroup);
            this.Controls.Add(this.cmbSelectGroupForEnableDisableDivision);
            this.Controls.Add(this.lblSelectDivision);
            this.Controls.Add(this.cmbSelectDivisionForEnableOrDisable);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnCancelEnableOrDisable);
            this.Controls.Add(this.btnEnableOrDisable);
            this.Controls.Add(this.radioButtonDisableDivision);
            this.Controls.Add(this.radioButtonEnableDivision);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "EnableDisableDivisionUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Enable / Disable Division";
            this.Load += new System.EventHandler(this.EnableDisableDivisionUI_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnCancelEnableOrDisable;
        private System.Windows.Forms.Button btnEnableOrDisable;
        private System.Windows.Forms.RadioButton radioButtonDisableDivision;
        private System.Windows.Forms.RadioButton radioButtonEnableDivision;
        private System.Windows.Forms.ComboBox cmbSelectDivisionForEnableOrDisable;
        private System.Windows.Forms.Label lblSelectDivision;
        private System.Windows.Forms.Label lblSelectGroup;
        private System.Windows.Forms.ComboBox cmbSelectGroupForEnableDisableDivision;
    }
}