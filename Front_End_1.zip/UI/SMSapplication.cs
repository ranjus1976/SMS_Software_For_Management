/*
 * Created by: Syeda Anila Nusrat. 
 * Date: 1st August 2009
 * Time: 2:54 PM 
 * Modified by Tanvir Islam
 * Date: Feb 2016
 */
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.IO.Ports;
using System.Reflection;
using System.Windows.Forms;
using Microsoft.SqlServer.Server;
using SMSapplication.BLL;
using SMSapplication.DAL;
using SMSapplication.DAL.DAO;
using SMSapplication.DAL.Gateway;
using SMSapplication.UI;

using System.ComponentModel;
using System.Drawing;
using System.Text;
//using Microsoft.SqlServer.Management.Smo;
//using Microsoft.SqlServer.Management.Common;
//using SQLDMO;
using Application = System.Windows.Forms.Application;
using Message = System.Web.Services.Description.Message;

namespace SMSapplication
{
    public partial class SMSapplication : Form
    {
        #region Constructor

        public SMSapplication()
        {
            InitializeComponent();
            reset_Focus_Timer.Enabled = false;
            Auto_Read_Timer.Enabled = false;
            txtEndTime.Text = Convert.ToString(now.ToShortTimeString().Substring(0,2));
            txtEndTime.Text = txtEndTime.Text.Replace(':', ' ');
        }
        #endregion

        #region Private Variables
        SerialPort port = new SerialPort();
        clsSMS objclsSMS = new clsSMS();
        ShortMessageCollection objShortMessageCollection = new ShortMessageCollection();
        UserDetailsManager objUserDetailsManager = new UserDetailsManager();
        UserRoleDetailsManager objUserRoleDetailsManager = new UserRoleDetailsManager();
        GroupDetailsManager objGroupDetailsManager = new GroupDetailsManager();
        SMSDetailsManager objSmsDetailsManager = new SMSDetailsManager();
        EmployeeDetailsManager objEmployeeDetailsManager = new EmployeeDetailsManager();
        DepartmentDetails objDepartmentDetails = new DepartmentDetails();
        DepartmentDetailsManager objDepartmentDetailsManager = new DepartmentDetailsManager();
        DepartmentDetailsGateway objDepartmentDetailsGateway = new DepartmentDetailsGateway();
        DesignationDetailsManager objDesignationDetailsManager = new DesignationDetailsManager();
        GroupSetupManager objGroupSetupManager = new GroupSetupManager();
        MarketDetailsManager objMarketDetailsManager = new MarketDetailsManager();
        ProductDetailsManager objProductDetailsManager = new ProductDetailsManager();
        ProductDetails objProductDetails = new ProductDetails();
        GroupDetailsGateway objGroupDetailsGateway = new GroupDetailsGateway();
        SalesTargerDetailsManager objSalesTargerDetailsManager = new SalesTargerDetailsManager();
        SalesDetailsManager objSalesDetailsManager = new SalesDetailsManager();
        DivisionDetailsManager objDivisionDetailsManager = new DivisionDetailsManager();
        //DataGridViewCheckBoxColumn checkBoxColumnEmpSelected = new DataGridViewCheckBoxColumn();
        
        //for Db Backup

        public string serverList;
        public int serverCount;
        public DateTime CurrentDateTime = DateTime.Now;
        public string getDate;
        public string getTime;
        public string uniqueBackUpName;
        public string sqlServerName;
        public string dbBackupPath;
        public string dbBackipFolderName;
        public string backUpFileName;
        
        //SqlCommand cmd = new SqlCommand();
        //End of Db Backup
        
        GlobalClass objGlobalClass = new GlobalClass();
        
        private DateTime currenTime = DateTime.Now;
        private System.Threading.Timer timer;

        public int flag;
        public int checkSMSReceivedDBLogFlag;
        public int checkSMSAutoSendDBLogFlag;
        //public string getProductCodeFromProductListUIForSalesTarget;
        public DateTime now = DateTime.Now;
        

        //private readonly TimeSpan StartTime = new TimeSpan(5, 0, 0);
        //private readonly TimeSpan EndTime = new TimeSpan(6, 0, 0);
        
        #endregion

        #region Private Methods

        #region Write StatusBar
        private void WriteStatusBar(string status)
        {
            try
            {
                statusBar1.Text = "Message: " + status;
            }
            catch (Exception ex)
            {
                
            }
        }
        #endregion
        
        #endregion

        #region Private Events

        private void SMSapplication_Load(object sender, EventArgs e)
        {
            try
            {
                if (GlobalClass.SelectOption == 1)
                {
                    #region Display all available COM Ports
                    string[] ports = SerialPort.GetPortNames();
                    //string[] ports = 
                    
                    // Add all port names to the combo box:
                    foreach (string port in ports)
                    {
                        this.cboPortName.Items.Add(port);
                    }
                    #endregion

                    //Remove tab pages
                    this.tabSMSapplication.TabPages.Remove(tbSendSMS);
                    this.tabSMSapplication.TabPages.Remove(tbReadSMS);
                    this.tabSMSapplication.TabPages.Remove(tbDeleteSMS);
                    this.tabSMSapplication.TabPages.Remove(tbUserCreate);
                    this.tabSMSapplication.TabPages.Remove(tbDepartment);
                    this.tabSMSapplication.TabPages.Remove(tbDesignation);
                    this.tabSMSapplication.TabPages.Remove(tbGroup);
                    this.tabSMSapplication.TabPages.Remove(tbEmployee);
                    this.tabSMSapplication.TabPages.Remove(tbDivision);
                    this.tabSMSapplication.TabPages.Remove(tbMarket);
                    this.tabSMSapplication.TabPages.Remove(tbMarketSetup);
                    this.tabSMSapplication.TabPages.Remove(tbProduct);
                    this.tabSMSapplication.TabPages.Remove(tbProductPriceUpdateLog);
                    this.tabSMSapplication.TabPages.Remove(tbSalesTarget);
                    this.tabSMSapplication.TabPages.Remove(tbSpecialItemSaleTarget);
                    this.tabSMSapplication.TabPages.Remove(tbSalesDetails);
                    this.tabSMSapplication.TabPages.Remove(tbReports);
                    
                    if (btnOK.Enabled == false)
                    {
                        btnOK.Enabled = true;
                    }

                    if (btnDBBackup.Enabled == false)
                    {
                        btnDBBackup.Enabled = true;
                    }

                    this.btnDisconnect.Enabled = false;

                    //02 Mar 2016 by Tanvir
                    GlobalClass.SmsText = "Please send your report. Ignore this SMS if you already send the report. Thank You.";
                    //MessageBox.Show(GlobalClass.SmsText);
                }
                else if (GlobalClass.SelectOption == 2)
                {
                    //Remove tab pages
                    this.tabSMSapplication.TabPages.Remove(tbSendSMS);
                    this.tabSMSapplication.TabPages.Remove(tbReadSMS);
                    this.tabSMSapplication.TabPages.Remove(tbDeleteSMS);
                    this.tabSMSapplication.TabPages.Remove(tbUserCreate);
                    this.tabSMSapplication.TabPages.Remove(tbDepartment);
                    this.tabSMSapplication.TabPages.Remove(tbDesignation);
                    this.tabSMSapplication.TabPages.Remove(tbGroup);
                    this.tabSMSapplication.TabPages.Remove(tbEmployee);
                    this.tabSMSapplication.TabPages.Remove(tbDivision);
                    this.tabSMSapplication.TabPages.Remove(tbMarket);
                    this.tabSMSapplication.TabPages.Remove(tbMarketSetup);
                    this.tabSMSapplication.TabPages.Remove(tbProduct);
                    this.tabSMSapplication.TabPages.Remove(tbPortSettings);
                    this.tabSMSapplication.TabPages.Remove(tbProductPriceUpdateLog);
                    this.tabSMSapplication.TabPages.Remove(tbSalesTarget);
                    this.tabSMSapplication.TabPages.Remove(tbSpecialItemSaleTarget);
                    this.tabSMSapplication.TabPages.Remove(tbSalesDetails);
                    this.tabSMSapplication.TabPages.Remove(tbReports);

                    if (btnOK.Enabled == true)
                    {
                        btnOK.Enabled = false;
                    }

                    if (btnDBBackup.Enabled == false)
                    {
                        btnDBBackup.Enabled = true;
                    }

                    this.btnDisconnect.Enabled = false;

                    if (reset_Focus_Timer.Enabled == true)
                    {
                        reset_Focus_Timer.Enabled = false;
                        //MessageBox.Show("Timer Started......");
                    }

                    if (Auto_Read_Timer.Enabled == true)
                    {
                        Auto_Read_Timer.Enabled = false;
                    }

                    txtStartTime.Enabled = false;
                    txtEndTime.Enabled = false;
                    checkBoxSMSRead.Enabled = false;
                    checkBoxSMSSend.Enabled = false;

                    //New 08/03/2016
                    //closed 03 Mar 2016
                    this.tabSMSapplication.TabPages.Add(tbUserCreate);
                    this.tabSMSapplication.TabPages.Add(tbDepartment);
                    this.tabSMSapplication.TabPages.Add(tbDesignation);
                    this.tabSMSapplication.TabPages.Add(tbGroup);
                    this.tabSMSapplication.TabPages.Add(tbEmployee);
                    this.tabSMSapplication.TabPages.Add(tbDivision);
                    this.tabSMSapplication.TabPages.Add(tbMarket);
                    this.tabSMSapplication.TabPages.Add(tbMarketSetup);
                    this.tabSMSapplication.TabPages.Add(tbProduct);
                    this.tabSMSapplication.TabPages.Add(tbProductPriceUpdateLog);
                    this.tabSMSapplication.TabPages.Add(tbSalesTarget);
                    //this.tabSMSapplication.TabPages.Add(tbSpecialItemSaleTarget);
                    this.tabSMSapplication.TabPages.Add(tbSalesDetails);
                    this.tabSMSapplication.TabPages.Add(tbReports);
                    //end closed 03 Mar 2016

                    this.btnDisconnect.Enabled = false;
                    this.btnOK.Enabled = false;

                    //load ComboBox's
                    //closed 03 Mar 2016
                    cmbUserRole.DataSource = objUserDetailsManager.com_UserType_Display();
                    cmbUserRole.DisplayMember = "User_Role";
                    cmbUserRole.ValueMember = "User_Role";
                    cmbUserRole.Text = "Select User Role";
                    //end closed 03 Mar 2016

                    //closed 03 Mar 2016
                    this.txtRoleID.Text = objUserRoleDetailsManager.GetUserRoleID(cmbUserRole.Text);
                    //end closed 03 Mar 2016

                    //load UserList
                    //closed 03 Mar 2016
                    dataGridViewUserDetails.DataSource = objUserDetailsManager.AllUserDetails();
                    dataGridViewUserDetails.Columns[0].Visible = false;
                    dataGridViewUserDetails.Columns[3].Visible = false;
                    //dataGridViewUserDetails.Columns[6].Visible = false;
                    //end closed 03 Mar 2016

                    //load Group List
                    //closed 03 Mar 2016
                    dataGridViewGroupDetails.DataSource = objGroupDetailsManager.AllGroupDetails();
                    dataGridViewGroupDetails.Columns[0].Visible = false;

                    btnSaveUser.Enabled = false;
                    btnSaveGroup.Enabled = false;
                    btnSaveDepartment.Enabled = false;
                    btnSaveDesignation.Enabled = false;
                    btnSaveEmployee.Enabled = false;
                    btnSaveMarket.Enabled = false;
                    //end closed 03 Mar 2016

                    // load Department Grid View List
                    dataGridViewDepartmentDetails.DataSource = objDepartmentDetailsManager.AllDepartmentDetails();
                    dataGridViewDepartmentDetails.Columns[0].Visible = false;

                    //load Designagnation
                    dataGridViewDesignationList.DataSource = objDesignationDetailsManager.ShowAllDesignation();
                    dataGridViewDesignationList.Columns[0].Visible = false;

                    dataGridViewEmployeeList.DataSource = objEmployeeDetailsManager.ShowAllEmployee();
                    dataGridViewEmployeeList.Columns[0].Visible = false;
                    dataGridViewEmployeeList.Columns[4].Visible = false;
                    dataGridViewEmployeeList.Columns[6].Visible = false;
                    dataGridViewEmployeeList.Columns[9].Visible = false;
                    dataGridViewEmployeeList.Columns[12].Visible = false;
                    dataGridViewEmployeeList.Columns[13].Visible = false;
                    dataGridViewEmployeeList.Columns[14].Visible = false;
                    //dataGridViewEmployeeList.Columns[15].Visible = false;
                    /*
                    cmbUserRole.DataSource = objUserDetailsManager.com_UserType_Display();
                    cmbUserRole.DisplayMember = "User_Role";
                    cmbUserRole.ValueMember = "User_Role";
                    */

                    cmbEmployeeDesignation.DataSource = objDesignationDetailsManager.LoadDesignationCombo();
                    cmbEmployeeDesignation.DisplayMember = "Designation";
                    cmbEmployeeDesignation.ValueMember = "Designation";
                    cmbEmployeeDesignation.Text = "Select Designation";

                    cmbEmployeeDepartment.DataSource = objDepartmentDetailsManager.LoadDepartmentCombo();
                    cmbEmployeeDepartment.DisplayMember = "Department_Name";
                    cmbEmployeeDepartment.ValueMember = "Department_Name";
                    cmbEmployeeDepartment.Text = "Select Department";

                    cmbEmployeeGroup.DataSource = objGroupDetailsManager.LoadGroupCombo();
                    cmbEmployeeGroup.DisplayMember = "Group_Name";
                    cmbEmployeeGroup.ValueMember = "Group_Name";
                    cmbEmployeeGroup.Text = "Select Team";

                    //closed on 17 May 2016
                    //cmbSelectGroupForMarket.DataSource = objGroupDetailsManager.LoadSelectGroupCombo();
                    //cmbSelectGroupForMarket.DisplayMember = "Group_Name";
                    //cmbSelectGroupForMarket.ValueMember = "Group_Name";
                    //end closed on 17 May 2016

                    //new on 18 May 2016
                    //cmbSelectGroupForMarketSetup.DataSource = objGroupDetailsManager.LoadSelectGroupCombo();
                    //cmbSelectGroupForMarketSetup.DisplayMember = "Group_Name";
                    //cmbSelectGroupForMarketSetup.ValueMember = "Group_Name";

                    //cmbSelectDevisionForMarketSetup.DataSource = objDivisionDetailsManager.LoadSelectDivision();
                    //cmbSelectDevisionForMarketSetup.DisplayMember = "Division_Name";
                    //cmbSelectDevisionForMarketSetup.ValueMember = "Division_Name";
                    //cmbSelectDevisionForMarketSetup.Text = "Select Division";

                    //cmbSelectMarketForMarketSetup.DataSource = objMarketDetailsManager.LoadAllMarket();
                    //cmbSelectMarketForMarketSetup.DisplayMember = "Market_Code";
                    //cmbSelectMarketForMarketSetup.ValueMember = "Market_Code";
                    //cmbSelectMarketForMarketSetup.Text = "Select Market";

                    dataGridViewMarketSetup.DataSource = objMarketDetailsManager.AllMarketDetails();
                    dataGridViewMarketSetup.Columns[0].Visible = false;
                    dataGridViewMarketSetup.Columns[3].Visible = false;
                    dataGridViewMarketSetup.Columns[4].Visible = false;
                    dataGridViewMarketSetup.Columns[5].Visible = false;
                    dataGridViewMarketSetup.Columns[7].Visible = false;
                    //dataGridViewMarketSetup.Columns[8].Visible = false;
                    //dataGridViewMarketSetup.Columns[9].Visible = false;
                    //dataGridViewMarketSetup.Columns[10].Visible = false;
                    dataGridViewMarketSetup.Columns[11].Visible = false;
                    //dataGridViewMarketSetup.Columns[12].Visible = false;
                    //dataGridViewMarketSetup.Columns[13].Visible = false;
                    //dataGridViewMarketSetup.Columns[14].Visible = false;
                    //end new on 18 May 2016

                    //Group Setup
                    //cmbSelectGroup.DataSource = objGroupDetailsManager.LoadSelectGroupCombo();
                    //cmbSelectGroup.DisplayMember = "Group_Name";
                    //cmbSelectGroup.ValueMember = "Group_Name";
                    //LoadGroupSetupCombo();
                    //End of Group Setup

                    // load market grid
                    dataGridViewMarket.DataSource = objMarketDetailsManager.AllMarketDetails();
                    dataGridViewMarket.Columns[0].Visible = false;
                    dataGridViewMarket.Columns[7].Visible = false;
                    dataGridViewMarket.Columns[8].Visible = false;
                    dataGridViewMarket.Columns[9].Visible = false;
                    dataGridViewMarket.Columns[10].Visible = false;
                    dataGridViewMarket.Columns[11].Visible = false;
                    //dataGridViewMarket.Columns[13].Visible = false;
                    // end of load market grid

                    //load product
                    dataGridViewProduct.DataSource = objProductDetailsManager.ShowAllProduct();
                    // end of load product

                    //load product price update log
                    dgvProductPriceUpdateLog.DataSource = objProductDetailsManager.ShowUpdateLogForAllProduct();
                    dgvProductPriceUpdateLog.Columns[0].Visible = false;
                    //end of load product price update log
                    if (reset_Focus_Timer.Enabled == true)
                    {
                        reset_Focus_Timer.Enabled = false;
                        //MessageBox.Show("Timer Started......");
                    }

                    if (Auto_Read_Timer.Enabled == true)
                    {
                        Auto_Read_Timer.Enabled = false;
                    }

                    txtStartTime.Enabled = false;
                    txtEndTime.Enabled = false;
                    checkBoxSMSRead.Enabled = false;
                    checkBoxSMSSend.Enabled = false;

                    lblStartTime.Visible = false;
                    lblEndTime.Visible = false;
                    txtStartTime.Visible = false;
                    txtEndTime.Visible = false;
                    checkBoxSMSRead.Visible = false;
                    checkBoxSMSSend.Visible = false;

                    txtEmployeeDesignationID.Text =
                        objDesignationDetailsManager.GetDesignationID(cmbEmployeeDesignation.Text);

                    txtEmployeeDepartmentID.Text =
                        objDepartmentDetailsManager.GetDepartmentID(cmbEmployeeDepartment.Text);

                    txtEmployeeGroupID.Text = objGroupDetailsManager.GetGroupID(cmbEmployeeGroup.Text);

                    //end new 08/03/2016
                    
                    //new 09/03/2016
                    //Group Setup 

                    checkActiveDesignationForGroupSetup();
                    //dataGridViewMarket.DataSource = objGroupSetupManager.LoadAllGroupSetup();
                    //dataGridViewMarket.Columns[4].Visible = false;
                    //End Group Setup
                    //end of new 09/03/2016

                    //Load Sales target Start
                    dataGridViewSalesTarget.DataSource = objSalesTargerDetailsManager.ShowAllSalesTarget();
                    dataGridViewSalesTarget.Columns[0].Visible = false;
                    dataGridViewSalesTarget.Columns[3].Visible = false;
                    dataGridViewSalesTarget.Columns[9].Visible = false;
                    //Load Sales target End

                    //load special item sale target
                    dgvSpecialItemSalesTarget.DataSource = objSalesTargerDetailsManager.ShowAllSpecialItemSalesTarget();
                    dgvSpecialItemSalesTarget.Columns[0].Visible = false;
                    dgvSpecialItemSalesTarget.Columns[3].Visible = false;
                    dgvSpecialItemSalesTarget.Columns[11].Visible = false;
                    //end load special item sale target

                    //load sales details
                    dgvSalesDetails.Refresh();
                    dgvSalesDetails.DataSource = objSalesDetailsManager.ShowAllSales();
                    dgvSalesDetails.Columns[0].Visible = false;
                    dgvSalesDetails.Columns[2].Visible = false;
                    dgvSalesDetails.Columns[9].Visible = false;
                    dgvSalesDetails.Columns[1].DefaultCellStyle.Format = "MM/dd/yyyy";
                    //end load sales details
                }

            }
            catch(Exception ex)
            {
                ErrorLog(ex.Message);
            }
        }
        private void btnOK_Click(object sender, EventArgs e)
        {
            try
            {
                if (GlobalClass.SelectOption == 1)
                {
                    //Open communication port 
                    this.port = objclsSMS.OpenPort(this.cboPortName.Text, Convert.ToInt32(this.cboBaudRate.Text), Convert.ToInt32(this.cboDataBits.Text), Convert.ToInt32(this.txtReadTimeOut.Text), Convert.ToInt32(this.txtWriteTimeOut.Text));

                    if (this.port != null)
                    {
                        this.gboPortSettings.Enabled = false;

                        //MessageBox.Show("Modem is connected at PORT " + this.cboPortName.Text);
                        this.statusBar1.Text = "Modem is connected at PORT " + this.cboPortName.Text;

                        //Add tab pages
                        this.tabSMSapplication.TabPages.Add(tbSendSMS);
                        this.tabSMSapplication.TabPages.Add(tbReadSMS);
                        this.tabSMSapplication.TabPages.Add(tbDeleteSMS);


                        this.lblConnectionStatus.Text = "Connected at " + this.cboPortName.Text;
                        this.btnDisconnect.Enabled = true;
                        this.btnOK.Enabled = false;

                        if (reset_Focus_Timer.Enabled == false)
                        {
                            reset_Focus_Timer.Enabled = true;
                            //MessageBox.Show("Timer Started......");
                        }

                        if (Auto_Read_Timer.Enabled == false)
                        {
                            Auto_Read_Timer.Enabled = true;
                        }
                        
                    }
                    else
                    {
                        //MessageBox.Show("Invalid port settings");
                        this.statusBar1.Text = "Invalid port settings";
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLog(ex.Message);
            }

        }
        private void btnDisconnect_Click(object sender, EventArgs e)
        {
            try
            {
                this.gboPortSettings.Enabled = true;
                objclsSMS.ClosePort(this.port);

                //Remove tab pages
                this.tabSMSapplication.TabPages.Remove(tbSendSMS);
                this.tabSMSapplication.TabPages.Remove(tbReadSMS);
                this.tabSMSapplication.TabPages.Remove(tbDeleteSMS);
                this.tabSMSapplication.TabPages.Remove(tbUserCreate);
                this.tabSMSapplication.TabPages.Remove(tbGroup);
                this.tabSMSapplication.TabPages.Remove(tbDepartment);
                this.tabSMSapplication.TabPages.Remove(tbDesignation);
                this.tabSMSapplication.TabPages.Remove(tbEmployee);
                this.tabSMSapplication.TabPages.Remove(tbMarket);
                this.tabSMSapplication.TabPages.Remove(tbProduct);
                this.lblConnectionStatus.Text = "Not Connected";
                this.btnDisconnect.Enabled = false;
                this.btnOK.Enabled = true;
                
                Application.Restart();
                LoginUI objLoginUi = new LoginUI();
                //objLoginUi.ShowDialog();
            }
            catch (Exception ex)
            {
                ErrorLog(ex.Message);
            }
        }
        private void btnSendSMS_Click(object sender, EventArgs e)
        {

            //.............................................. Send SMS ....................................................
            try
            {
                if (objclsSMS.sendMsg(this.port, this.txtSIM.Text, this.txtMessage.Text))
                {
                    //MessageBox.Show("Message has sent successfully");
                    
                    //closed by Tanvir for check purpose on 02-Mar-2016
                    //txtSIM.Clear();
                    //txtMessage.Clear();
                    
                    objclsSMS.KillProcess();
                    //this.BringToFront();
                    this.statusBar1.Text = "Message has sent successfully";
                    //this.statusBar1.Focus();

                    //closed by Tanvir (Not need)
                    //objclsSMS.ClosePort(port);
                    //this.port.Close();
                    //this.port.Open();
                }
                else
                {
                    //MessageBox.Show("Failed to send message");
                    this.statusBar1.Text = "Failed to send message";
                }
                
                
            }
            catch (Exception ex)
            {
                ErrorLog(ex.Message);
                //this.statusBar1.Focus();
            }

            //if (statusBar1.Text == "Message has sent successfully" || statusBar1.Text == "Message: Response received is incomplete.")
            //{
            //    reset_Focus_Timer.Start();

            //}
        }
        private void btnReadSMS_Click(object sender, EventArgs e)
        {
            try
            {
                if (lvwMessages.Items.Count >= 0)
                {
                    lvwMessages.Items.Clear();
                }
                //count SMS 
                int uCountSMS = objclsSMS.CountSMSmessages(this.port);
                if (uCountSMS > 0)
                {

                    #region Command
                    string strCommand = "AT+CMGL=\"ALL\"";
                    //closed by Tanvir (Not need)
                    //string strCommand = "AT+CMGL=ALL";

                    if (this.rbReadAll.Checked)
                    {
                        strCommand = "AT+CMGL=\"ALL\"";
                        //closed by Tanvir (Not need)
                        //strCommand = "AT+CMGL=ALL";
                    }
                    else if (this.rbReadUnRead.Checked)
                    {
                        strCommand = "AT+CMGL=\"REC UNREAD\"";
                        //closed by Tanvir (Not need)
                        //strCommand = "AT+CMGL=REC UNREAD";
                    }
                    else if (this.rbReadStoreSent.Checked)
                    {
                        strCommand = "AT+CMGL=\"STO SENT\"";
                        //closed by Tanvir (Not need)
                        //strCommand = "AT+CMGL=STO SENT";
                    }
                    else if (this.rbReadStoreUnSent.Checked)
                    {
                        strCommand = "AT+CMGL=\"STO UNSENT\"";
                        //closed by Tanvir (Not need)
                        //strCommand = "AT+CMGL=STO UNSENT";
                    }
                    #endregion

                    // If SMS exist then read SMS
                    #region Read SMS
                    //.............................................. Read all SMS ....................................................
                    //closed by Tanvir (Not need)
                    //lvwMessages.Clear();

                    objShortMessageCollection = objclsSMS.ReadSMS(this.port, strCommand);
                    //closed by Tanvir (Not need)
                    //objShortMessageCollection = objclsSMS.ReadSMS(this.port);
                    foreach (ShortMessage msg in objShortMessageCollection)
                    {

                        //ListViewItem item = new ListViewItem(new string[] { msg.Sent, msg.Sender, msg.Message });
                        ListViewItem item = new ListViewItem(new string[] { msg.Index, msg.Sent, msg.Sender, msg.Message });
                        //DateTime msgSent = Format msg.Sent.ToString"dd/MM/yyyy HH:mm:ss");
                        //msg.Sent = Forma msg.Sent.ToString("dd/MM/yyyy HH:mm:ss");
                        //string msgSent = string.Format("dd/MM/yyyy HH:mm:ss", msg.Sent);
                        //string msgSent = msg.Sent.Substring(1,17);
                        //msg.Sent = msgSent;
                        item.Tag = msg;
                        lvwMessages.Items.Add(item);
                        //lvwMessages.Columns[0].ListView.Visible = false;
                        //lvwMessages.Columns[1].ToString("MM/dd/yyyy HH:mm:ss");
                        //.ToString("MM/dd/yyyy HH:mm:ss")

                    }
                    
                    #endregion
                }
                else
                {
                    lvwMessages.Clear();
                    //MessageBox.Show("There is no message in SIM");
                    this.statusBar1.Text = "There is no message in SIM";
                }
            }
            catch (Exception ex)
            {
                ErrorLog(ex.Message);
            }
        }
        private void btnDeleteSMS_Click(object sender, EventArgs e)
        {
            try
            {
                //Count SMS 
                int uCountSMS = objclsSMS.CountSMSmessages(this.port);
                if (uCountSMS > 0)
                {
                    DialogResult dr = MessageBox.Show("Are u sure u want to delete the SMS?", "Delete confirmation", MessageBoxButtons.YesNo);

                    if (dr.ToString() == "Yes")
                    {
                        #region Delete SMS

                        if (this.rbDeleteAllSMS.Checked)
                        {                           
                            //...............................................Delete all SMS ....................................................

                            #region Delete all SMS
                            string strCommand = "AT+CMGD=1,4";
                            if (objclsSMS.DeleteMsg(this.port, strCommand))
                            {
                                //MessageBox.Show("Messages has deleted successfuly ");
                                this.statusBar1.Text = "Messages has deleted successfuly";
                            }
                            else
                            {
                                //MessageBox.Show("Failed to delete messages ");
                                this.statusBar1.Text = "Failed to delete messages";
                            }
                            #endregion
                            
                        }
                        else if (this.rbDeleteReadSMS.Checked)
                        {                          
                            //...............................................Delete Read SMS ....................................................

                            #region Delete Read SMS
                            string strCommand = "AT+CMGD=1,3";
                            if (objclsSMS.DeleteMsg(this.port, strCommand))
                            {
                                //MessageBox.Show("Messages has deleted successfuly");
                                this.statusBar1.Text = "Messages has deleted successfuly";
                            }
                            else
                            {
                                //MessageBox.Show("Failed to delete messages ");
                                this.statusBar1.Text = "Failed to delete messages";
                            }
                            #endregion

                        }

                        #endregion
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLog(ex.Message);
            }

        }
        private void btnCountSMS_Click(object sender, EventArgs e)
        {
            try
            {
                //Count SMS
                int uCountSMS = objclsSMS.CountSMSmessages(this.port);
                this.txtCountSMS.Text = uCountSMS.ToString();
            }
            catch (Exception ex)
            {
                ErrorLog(ex.Message);
            }
        }

        #endregion

        #region Error Log
        public void ErrorLog(string Message)
        {
            StreamWriter sw = null;

            try
            {
                WriteStatusBar(Message);

                string sLogFormat = DateTime.Now.ToShortDateString().ToString() + " " + DateTime.Now.ToLongTimeString().ToString() + " ==> ";
                //string sPathName = @"E:\";
                string sPathName = @"SMSapplicationErrorLog_";

                string sYear = DateTime.Now.Year.ToString();
                string sMonth = DateTime.Now.Month.ToString();
                string sDay = DateTime.Now.Day.ToString();

                string sErrorTime = sDay + "-" + sMonth + "-" + sYear;

                sw = new StreamWriter(sPathName + sErrorTime + ".txt", true);

                sw.WriteLine(sLogFormat + Message);
                sw.Flush();

            }
            catch (Exception ex)
            {
                //ErrorLog(ex.ToString());
            }
            finally
            {
                if (sw != null)
                {
                    sw.Dispose();
                    sw.Close();
                }
            }
            
        }
        #endregion

        public void checkActiveDesignationForGroupSetup()
        {
            try
            {
                string DO;
                string GM;
                string DGM;
                string DM;
                string SM;
                string ASM;
                string TSM;
                string SR;

                objDesignationDetailsManager.ShowAllDesignation();
                DO = Convert.ToString(objDesignationDetailsManager.ShowAllDesignation().Rows[0][3].ToString());
                GM = Convert.ToString(objDesignationDetailsManager.ShowAllDesignation().Rows[1][3].ToString());
                DGM = Convert.ToString(objDesignationDetailsManager.ShowAllDesignation().Rows[2][3].ToString());
                DM = Convert.ToString(objDesignationDetailsManager.ShowAllDesignation().Rows[3][3].ToString());
                SM = Convert.ToString(objDesignationDetailsManager.ShowAllDesignation().Rows[4][3].ToString());
                ASM = Convert.ToString(objDesignationDetailsManager.ShowAllDesignation().Rows[5][3].ToString());
                TSM = Convert.ToString(objDesignationDetailsManager.ShowAllDesignation().Rows[6][3].ToString());
                SR = Convert.ToString(objDesignationDetailsManager.ShowAllDesignation().Rows[7][3].ToString());

                if (DO == "Yes")
                {
                    txtNumberOfDO.Text = "1";
                    txtNumberOfDO.Enabled = true;
                }
                else
                {
                    txtNumberOfDO.Text = "0";
                    txtNumberOfDO.Enabled = false;
                }

                if (GM == "Yes")
                {
                    txtNumberOfGM.Text = "1";
                    txtNumberOfGM.Enabled = true;
                }
                else
                {
                    txtNumberOfGM.Text = "0";
                    txtNumberOfGM.Enabled = false;
                }

                if (DGM == "Yes")
                {
                    txtNumberOfDGM.Text = "1";
                    txtNumberOfDGM.Enabled = true;
                }
                else
                {
                    txtNumberOfDGM.Text = "0";
                    txtNumberOfDGM.Enabled = false;
                }

                if (DM == "Yes")
                {
                    txtNumberOfDM.Text = "2";
                    txtNumberOfDM.Enabled = true;
                }
                else
                {
                    txtNumberOfDM.Text = "0";
                    txtNumberOfDM.Enabled = false;
                }

                if (SM == "Yes")
                {
                    txtNumberOfSM.Text = "4";
                    txtNumberOfSM.Enabled = true;
                }
                else
                {
                    txtNumberOfSM.Text = "0";
                    txtNumberOfSM.Enabled = false;
                }

                if (ASM == "Yes")
                {
                    txtNumberOfASM.Text = "4";
                    txtNumberOfASM.Enabled = true;
                }
                else
                {
                    txtNumberOfASM.Text = "0";
                    txtNumberOfASM.Enabled = false;
                }

                if (TSM == "Yes")
                {
                    txtNumberOfTSM.Text = "12";
                    txtNumberOfTSM.Enabled = true;
                }
                else
                {
                    txtNumberOfTSM.Text = "0";
                    txtNumberOfTSM.Enabled = false;
                }

                if (SR == "Yes")
                {
                    txtNumberOfSR.Text = "72";
                    txtNumberOfSR.Enabled = true;
                }
                else
                {
                    txtNumberOfSR.Text = "0";
                    txtNumberOfSR.Enabled = false;
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            //string DO;
            //string GM;
            //string DGM;
            //string DM;
            //string SM;
            //string ASM;
            //string TSM;
            //string SR;

            //objDesignationDetailsManager.ShowAllDesignation();
            //DO = Convert.ToString(objDesignationDetailsManager.ShowAllDesignation().Rows[0][3].ToString());
            //GM = Convert.ToString(objDesignationDetailsManager.ShowAllDesignation().Rows[1][3].ToString());
            //DGM = Convert.ToString(objDesignationDetailsManager.ShowAllDesignation().Rows[2][3].ToString());
            //DM = Convert.ToString(objDesignationDetailsManager.ShowAllDesignation().Rows[3][3].ToString());
            //SM = Convert.ToString(objDesignationDetailsManager.ShowAllDesignation().Rows[4][3].ToString());
            //ASM = Convert.ToString(objDesignationDetailsManager.ShowAllDesignation().Rows[5][3].ToString());
            //TSM = Convert.ToString(objDesignationDetailsManager.ShowAllDesignation().Rows[6][3].ToString());
            //SR = Convert.ToString(objDesignationDetailsManager.ShowAllDesignation().Rows[7][3].ToString());

            //if (DO == "Yes")
            //{
            //    txtNumberOfDO.Text = "1"; 
            //    txtNumberOfDO.Enabled = true;
            //}
            //else
            //{
            //    txtNumberOfDO.Text = "0";
            //    txtNumberOfDO.Enabled = false;
            //}

            //if (GM == "Yes")
            //{
            //    txtNumberOfGM.Text = "1";
            //    txtNumberOfGM.Enabled = true;
            //}
            //else
            //{
            //    txtNumberOfGM.Text = "0";
            //    txtNumberOfGM.Enabled = false;
            //}

            //if (DGM == "Yes")
            //{
            //    txtNumberOfDGM.Text = "1";
            //    txtNumberOfDGM.Enabled = true;
            //}
            //else
            //{
            //    txtNumberOfDGM.Text = "0";
            //    txtNumberOfDGM.Enabled = false;
            //}

            //if (DM == "Yes")
            //{
            //    txtNumberOfDM.Text = "2";
            //    txtNumberOfDM.Enabled = true;
            //}
            //else
            //{
            //    txtNumberOfDM.Text = "0";
            //    txtNumberOfDM.Enabled = false;
            //}

            //if (SM == "Yes")
            //{
            //    txtNumberOfSM.Text = "4";
            //    txtNumberOfSM.Enabled = true;
            //}
            //else
            //{
            //    txtNumberOfSM.Text = "0";
            //    txtNumberOfSM.Enabled = false;
            //}

            //if (ASM == "Yes")
            //{
            //    txtNumberOfASM.Text = "4";
            //    txtNumberOfASM.Enabled = true;
            //}
            //else
            //{
            //    txtNumberOfASM.Text = "0";
            //    txtNumberOfASM.Enabled = false;
            //}

            //if (TSM == "Yes")
            //{
            //    txtNumberOfTSM.Text = "12";
            //    txtNumberOfTSM.Enabled = true;
            //}
            //else
            //{
            //    txtNumberOfTSM.Text = "0";
            //    txtNumberOfTSM.Enabled = false;
            //}

            //if (SR == "Yes")
            //{
            //    txtNumberOfSR.Text = "72";
            //    txtNumberOfSR.Enabled = true;
            //}
            //else
            //{
            //    txtNumberOfSR.Text = "0";
            //    txtNumberOfSR.Enabled = false;
            //}
        }

        private void reset_Focus_Timer_Tick(object sender, EventArgs e)
        {
            
            //this.Activate();
            ////reset_Focus_Timer.Enabled = false;
            ////this.statusBar1.Focus();
            ////MessageBox.Show("Timer is started");
            //DateTime time = DateTime.Now.ToLocalTime();
            //if (Convert.ToString(time) == "12:35 AM")
            //{
            //    btnSendSMS.PerformClick();
            //}
            //SendAutoSMS(sender, e);
            //MessageBox.Show("Timer is started");
            //MessageBox.Show(currenTime.ToShortTimeString());
            //if (txtTimeCheck.Text == currenTime.ToShortTimeString())
            //{
            //    reset_Focus_Timer.Enabled = false;
            //    MessageBox.Show("Timer is stopped");
            //}
            try
            {
                bool valOfShouldRun = false;
                valOfShouldRun = ShouldRunNow();
                if (valOfShouldRun == true)
                {
                    PerformClick();
                }
                else
                {
                    //MessageBox.Show("Timer stopping.....");
                    reset_Focus_Timer.Stop();
                    reset_Focus_Timer.Enabled = false;
                }
            }
            catch
            {
                MessageBox.Show("Error occurred Timer");
            }
            
        }

        private void PerformClick()
        {
            //btnSendSMS.PerformClick();

            //05 Mar 2016 by Tanvir
            try
            {
                checkSMSReceivedLog();
                //btnSendSMS_Click(null, null);
                //reset_Focus_Timer.Enabled = false;
            }
            catch
            {
                MessageBox.Show("Error occurred in PerformClick Function");
            }
            //End 05 Mar 2016 by Tanvir
        }

        public void checkSMSReceivedLog()
        {
            try
            {
                List<EmployeeDetails> listOfEmployee = objEmployeeDetailsManager.GetEmployeeDetails();
                if (listOfEmployee.Count > 0)
                {
                    for (int i = 0; i < listOfEmployee.Count; i++)
                    {
                        //if (checkSMSReceivedLogInDB(listOfEmployee[i].EmpOfficialCellNo.ToString()) == true)
                        //{

                        //}
                        //else
                        this.txtSIM.Text = listOfEmployee[i].EmpOfficialCellNo.ToString();
                        this.txtMessage.Text = GlobalClass.SmsText.ToString();

                        //string cellNo = "";
                        //string SMS = "";

                        //cellNo = listOfEmployee[i].EmpOfficialCellNo.ToString();
                        //SMS = GlobalClass.SmsText.ToString();
                        if (checkSMSReceivedLogInDB(listOfEmployee[i].EmpOfficialCellNo.ToString()) == false)
                        {
                            //objclsSMS.sendMsg(this.port, cellNo, SMS);
                            //objclsSMS.KillProcess();
                            //this.BringToFront();
                            if (checkSMSAutoSendLog(listOfEmployee[i].EmpOfficialCellNo.ToString()) == false)
                            {
                                btnSendSMS_Click(null, null);
                                objSmsDetailsManager.insertAutoSendLog(DateTime.Now.ToShortDateString(), listOfEmployee[i].EmpOfficialCellNo.ToString());
                                //this.statusBar1.Text = "Message has sent successfully";
                                //MessageBox.Show("Message Sent to '" + listOfEmployee[i].EmpOfficialCellNo.ToString() + "'");                                
                            }

                            //closed on 06/03/2015 by Tanvir
                            //else
                            //{
                            //    //MessageBox.Show("Message already Sent to '" + listOfEmployee[i].EmpOfficialCellNo.ToString() + "'");                                
                            //}
                            //end of closed by Tanvir 06/03/2015 
                        }
                    }
                    reset_Focus_Timer.Stop();
                    reset_Focus_Timer.Enabled = false;
                    //MessageBox.Show("Timer Stopped");
                }
            }
            catch
            {
                MessageBox.Show("Error occurred in checkSMSReceivedLog Function");
            }

        }

        public bool checkSMSReceivedLogInDB(string empOfficialCell)
        {
            try
            {
                string receivedDate = DateTime.Now.ToShortDateString();
                SMSDetailsManager objSmsDetailsManager = new SMSDetailsManager();
                checkSMSReceivedDBLogFlag = objSmsDetailsManager.checkSMSReceivedDBLog(receivedDate,empOfficialCell);
            }
            catch
            {
                MessageBox.Show("Error occurred in checkSMSReceivedLogInDB Function");
            }
            if (checkSMSReceivedDBLogFlag == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
            
        }

        public bool checkSMSAutoSendLog(string empOfficialCellNo)
        {
            try
            {
                string sendDate = DateTime.Now.ToShortDateString();
                SMSDetailsManager objSmsDetailsManager = new SMSDetailsManager();
                checkSMSAutoSendDBLogFlag = objSmsDetailsManager.checkAutoSendLogDB(sendDate, empOfficialCellNo);
            }
            catch
            {
                MessageBox.Show("Error occurred in checkSMSAutoSendLog Function");
                throw;
            }
            if (checkSMSAutoSendDBLogFlag == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private bool ShouldRunNow()
        {
            try
            {
                //DateTime now = DateTime.Now;
                //txtEndTime.Text = Convert.ToString(now.ToShortTimeString());
                int end_Time = Convert.ToInt32(txtStartTime.Text);
                int hour = Convert.ToInt32(now.ToShortTimeString().Substring(0, 2).Replace(':', ' '));
                //MessageBox.Show(hour.ToString());
                //new code 06/03/2016
                if (hour == end_Time)
                {
                    flag = 1;
                    //MessageBox.Show(flag.ToString());
                }
                else
                {
                    flag = 0;
                }
                //end of new code 06/03/2016
                
            }
            catch
            {
                MessageBox.Show("Error occured in ShouldRun Function");
            }

            if (flag == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private void btnExitApplication_Click(object sender, EventArgs e)
        {
            try
            {
                //if (MessageBox.Show("Do you add another record?", "Add another record!", MessageBoxButtons.YesNo) == DialogResult.Yes)
                if (MessageBox.Show("Do you want to Exit?", "Exit Application!", MessageBoxButtons.YesNo) ==
                    DialogResult.Yes)
                {
                    this.tabSMSapplication.TabPages.Remove(tbSendSMS);
                    this.tabSMSapplication.TabPages.Remove(tbReadSMS);
                    this.tabSMSapplication.TabPages.Remove(tbDeleteSMS);
                    this.tabSMSapplication.TabPages.Remove(tbUserCreate);
                    this.tabSMSapplication.TabPages.Remove(tbGroup);
                    this.tabSMSapplication.TabPages.Remove(tbDepartment);
                    this.tabSMSapplication.TabPages.Remove(tbDesignation);
                    this.tabSMSapplication.TabPages.Remove(tbEmployee);
                    this.tabSMSapplication.TabPages.Remove(tbMarket);
                    this.tabSMSapplication.TabPages.Remove(tbProduct);
                    this.tabSMSapplication.TabPages.Remove(tbProductPriceUpdateLog);
                    this.tabSMSapplication.TabPages.Remove(tbSalesTarget);
                    this.tabSMSapplication.TabPages.Remove(tbSpecialItemSaleTarget);
                    this.tabSMSapplication.TabPages.Remove(tbSalesDetails);
                    this.tabSMSapplication.TabPages.Remove(tbReports);
                    this.lblConnectionStatus.Text = "Not Connected";
                    this.btnDisconnect.Enabled = false;
                    this.btnOK.Enabled = true;
                    Application.Exit();
                }
                //else
                //{
                //    this.tabSMSapplication.TabPages.Remove(tbSendSMS);
                //    this.tabSMSapplication.TabPages.Remove(tbReadSMS);
                //    this.tabSMSapplication.TabPages.Remove(tbDeleteSMS);
                //    this.tabSMSapplication.TabPages.Remove(tbUserCreate);
                //    this.tabSMSapplication.TabPages.Remove(tbGroup);
                //    this.tabSMSapplication.TabPages.Remove(tbDepartment);
                //    this.tabSMSapplication.TabPages.Remove(tbDesignation);
                //    this.tabSMSapplication.TabPages.Remove(tbEmployee);
                //    this.tabSMSapplication.TabPages.Remove(tbMarket);
                //    this.tabSMSapplication.TabPages.Remove(tbProduct);
                //    this.tabSMSapplication.TabPages.Remove(tbProductPriceUpdateLog);
                //    this.lblConnectionStatus.Text = "Not Connected";
                //    this.btnDisconnect.Enabled = false;
                //    this.btnOK.Enabled = true;
                //    //this.Close();
                //    Application.Restart();
                //}
            }
            catch (Exception ex)
            {
                ErrorLog(ex.Message);
            }
        }

        private void cmbUserRole_SelectedIndexChanged(object sender, EventArgs e)
        {
            //this.txtRoleID.Text = objUserRoleDetailsManager.GetUserRoleID(cmbUserRole.Text.ToString());
            //string cmbText = cmbUserRole.Text;
            this.txtRoleID.Text = objUserRoleDetailsManager.GetUserRoleID(cmbUserRole.Text);
        }

        private void cmbUserRole_SelectedValueChanged(object sender, EventArgs e)
        {
            //string cmbText = cmbUserRole.SelectedText.ToString();
            //this.txtRoleID.Text = objUserRoleDetailsManager.GetUserRoleID(cmbText);
            //string cmbText = cmbUserRole.Text;
            this.txtRoleID.Text = objUserRoleDetailsManager.GetUserRoleID(cmbUserRole.Text);
        }

        private void cmbActive_Click(object sender, EventArgs e)
        {
            //MessageBox.Show(cmbUserRole.ValueMember.ToString());
            //MessageBox.Show(cmbUserRole.DisplayMember.ToString());
            //MessageBox.Show(cmbUserRole.Text);
            string cmbText = cmbUserRole.Text;
            txtRoleID.Text = objUserRoleDetailsManager.GetUserRoleID(cmbText);
        }

        private void dataGridViewUserDetails_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (btnSaveUser.Enabled == false)
            {
                btnSaveUser.Enabled = true;
            }
            btnSaveUser.Text = "Update User";
            GlobalClass.UserIdForEditUserDetails = dataGridViewUserDetails.CurrentRow.Cells[0].Value.ToString();
            txtUserName.Text = dataGridViewUserDetails.CurrentRow.Cells[1].Value.ToString();
            txtPassword.Text = dataGridViewUserDetails.CurrentRow.Cells[2].Value.ToString();
            cmbUserRole.Text = dataGridViewUserDetails.CurrentRow.Cells[4].Value.ToString();
            txtRoleID.Text = dataGridViewUserDetails.CurrentRow.Cells[3].Value.ToString();
            cmbActive.Text = dataGridViewUserDetails.CurrentRow.Cells[5].Value.ToString();
        }

        private void btnAddUser_Click(object sender, EventArgs e)
        {
            if(txtUserName.Enabled == false)
            {
                txtUserName.Enabled = true;
            }

            if (txtPassword.Enabled == false)
            {
                txtPassword.Enabled = true;
            }

            if (cmbUserRole.Enabled == false)
            {
                cmbUserRole.Enabled = true;
            }

            if (cmbActive.Enabled == false)
            {
                cmbActive.Enabled = true;
            }

            if (btnSaveUser.Enabled == false)
            {
                btnSaveUser.Enabled = true;
            }
            
            if (btnSaveUser.Text == "Update User")
            {
                btnSaveUser.Text = "Save User";
            }
            ClearCreateUserTab();
            txtUserName.Focus();
        }

        private void btnSaveUser_Click(object sender, EventArgs e)
        {
            string userName;
            string password;
            string passwordDecrypt;
            int userRoleID;
            string userRoleName;
            string activate;
            int userID;

            if (txtUserName.Text == "")
            {
                MessageBox.Show("User Name can't be blank");
                txtUserName.Focus();
            }
            else if (txtPassword.Text == "")
            {
                MessageBox.Show("Password can't be blank");
                txtPassword.Focus();
            }
            else if (cmbUserRole.Text == "")
            {
                MessageBox.Show("User Role can't be blank");
                cmbUserRole.Focus();
            }
            else if (cmbActive.Text == "")
            {
                MessageBox.Show("User Activation can't be blank");
                cmbActive.Focus();
            }
            else
            {
                if (btnSaveUser.Text == "Save User")
                {
                    userName = txtUserName.Text;
                    password = objGlobalClass.Encrypt(txtPassword.Text);
                    userRoleID = Convert.ToInt32(txtRoleID.Text);
                    userRoleName = cmbUserRole.Text;
                    activate = cmbActive.Text;
                    
                    objUserDetailsManager.InsertNewUser(userName, password, userRoleID, userRoleName, activate);
                    dataGridViewUserDetails.DataSource = objUserDetailsManager.AllUserDetails();
                    dataGridViewUserDetails.Columns[0].Visible = false;
                    dataGridViewUserDetails.Columns[3].Visible = false;
                    //dataGridViewUserDetails.Columns[6].Visible = false;
                    btnSaveUser.Enabled = false;
                    MessageBox.Show("User Added Succesfully");
                }
                if (btnSaveUser.Text == "Update User")
                {
                    userName = txtUserName.Text;
                    passwordDecrypt = objGlobalClass.Decrypt(txtPassword.Text);
                    password = objGlobalClass.Encrypt(passwordDecrypt);
                    userRoleID = Convert.ToInt32(txtRoleID.Text);
                    userRoleName = cmbUserRole.Text;
                    activate = cmbActive.Text;
                    
                    userID = Convert.ToInt32(GlobalClass.UserIdForEditUserDetails);
                    objUserDetailsManager.UpdateUser(userID, userName, password, userRoleID, userRoleName, activate);
                    dataGridViewUserDetails.DataSource = objUserDetailsManager.AllUserDetails();
                    dataGridViewUserDetails.Columns[0].Visible = false;
                    dataGridViewUserDetails.Columns[3].Visible = false;
                    //dataGridViewUserDetails.Columns[6].Visible = false;
                    btnSaveUser.Text = "Save User";
                    btnSaveUser.Enabled = false;
                    MessageBox.Show("User Updated Succesfully");
                }

                ClearCreateUserTab();

                if (btnSaveUser.Enabled == true)
                {
                    btnSaveUser.Enabled = false;
                }

                if (txtUserName.Enabled == true)
                {
                    txtUserName.Enabled = false;
                }

                if (txtPassword.Enabled == true)
                {
                    txtPassword.Enabled = false;
                }

                if (cmbUserRole.Enabled == true)
                {
                    cmbUserRole.Enabled = false;
                }

                if (cmbActive.Enabled == true)
                {
                    cmbActive.Enabled = false;
                }

                if (btnSaveUser.Text == "Update User")
                {
                    btnSaveUser.Text = "Save User";
                }
            }
        }

        public void loadTempSalesTarget()
        {
            dgvSalesTargetDetails.DataSource = objSalesTargerDetailsManager.ShowTempSalesTarget();
            dgvSalesTargetDetails.Columns[0].Visible = false;
            dgvSalesTargetDetails.Columns[3].Visible = false;
            dgvSalesTargetDetails.Columns[9].Visible = false;
        }

        public void ClearCreateUserTab()
        {
            txtUserName.Text = "";
            txtPassword.Text = "";
            cmbUserRole.Text = "Select User Role";
            txtRoleID.Text = "";
            cmbActive.Text = "Select Active";
        }

        private void btnAddGroup_Click(object sender, EventArgs e)
        {
            if (btnSaveGroup.Enabled == false)
            {
                btnSaveGroup.Enabled = true;
            }

            if (txtGroupName.Enabled == false)
            {
                txtGroupName.Enabled = true;
            }
            if (txtLocation.Enabled == false)
            {
                txtLocation.Enabled = true;
            }
            if (cmbGroupActive.Enabled == false)
            {
                cmbGroupActive.Enabled = true;
            }
            if (btnAddGroup.Enabled == false)
            {
                btnAddGroup.Enabled = true;
            }
            if (btnSaveGroup.Text == "Update Group")
            {
                btnSaveGroup.Text = "Save Group";
            }
            
            ClearGroupTab();
            txtGroupName.Focus();
        }

        public void ClearGroupTab()
        {
            txtGroupName.Text = "";
            txtLocation.Text = "";
            cmbGroupActive.Text = "Select Active";
        }

        private void btnSaveGroup_Click(object sender, EventArgs e)
        {
            string groupName;
            string location;
            string activateGroup;
            int groupID;

            int MD;
            int DMD;
            int DO;
            int GM;
            int DGM;
            int DM;
            int SM;
            int ASM;
            int TSM;
            int SR;

            groupName = txtGroupName.Text;
            location = txtLocation.Text;
            activateGroup = cmbGroupActive.Text;

            MD = Convert.ToInt32(txtNumberOfMD.Text);
            DMD = Convert.ToInt32(txtNumberOfDMD.Text);
            DO = Convert.ToInt32(txtNumberOfDO.Text);
            GM = Convert.ToInt32(txtNumberOfGM.Text);
            DGM = Convert.ToInt32(txtNumberOfDGM.Text);
            DM = Convert.ToInt32(txtNumberOfDM.Text);
            SM = Convert.ToInt32(txtNumberOfSM.Text);
            ASM = Convert.ToInt32(txtNumberOfASM.Text);
            TSM = Convert.ToInt32(txtNumberOfTSM.Text);
            SR = Convert.ToInt32(txtNumberOfSR.Text);
            
            if (btnSaveGroup.Text == "Save Group")
            {
                objGroupDetailsManager.InsertNewGroup(groupName, location, activateGroup, MD, DMD,DO, GM,DGM, DM, SM, ASM, TSM, SR);
                dataGridViewGroupDetails.DataSource = objGroupDetailsManager.AllGroupDetails();
                dataGridViewGroupDetails.Columns[0].Visible = false;
                btnSaveGroup.Enabled = false;
                MessageBox.Show("Group Added Succesfully");
                cmbEmployeeGroup.DataSource = objGroupDetailsManager.LoadGroupCombo();
                cmbEmployeeGroup.DisplayMember = "Group_Name";
                cmbEmployeeGroup.ValueMember = "Group_Name";
                ////cmbSelectGroup.DataSource = objGroupDetailsManager.LoadSelectGroupCombo();
                ////cmbSelectGroup.DisplayMember = "Group_Name";
                ////cmbSelectGroup.ValueMember = "Group_Name";
            }

            if (btnSaveGroup.Text == "Update Group")
            {
                groupID = Convert.ToInt32(GlobalClass.GroupIdForUpdateGroup);
                objGroupDetailsManager.UpdateGroup(groupID, groupName, location, activateGroup, MD, DMD, DO, GM, DGM, DM, SM, ASM, TSM, SR);
                //update Employee Information
                objEmployeeDetailsManager.UpdateGroupActiveLogInEmpInfo(groupID,activateGroup);
                //end of update Employee Information
                dataGridViewGroupDetails.DataSource = objGroupDetailsManager.AllGroupDetails();
                dataGridViewGroupDetails.Columns[0].Visible = false;
                dataGridViewGroupDetails.Refresh();
                btnSaveGroup.Text = "Save Group";
                btnSaveGroup.Enabled =false;
                MessageBox.Show("Group Updated Succesfully");
                
                cmbEmployeeGroup.DataSource = objGroupDetailsManager.LoadGroupCombo();
                cmbEmployeeGroup.DisplayMember = "Group_Name";
                cmbEmployeeGroup.ValueMember = "Group_Name";

                //reload employee grid 12/03/2016
                dataGridViewEmployeeList.DataSource = objEmployeeDetailsManager.ShowAllEmployee();
                dataGridViewEmployeeList.Columns[0].Visible = false;
                dataGridViewEmployeeList.Columns[4].Visible = false;
                dataGridViewEmployeeList.Columns[6].Visible = false;
                dataGridViewEmployeeList.Columns[9].Visible = false;
                dataGridViewEmployeeList.Columns[12].Visible = false;
                dataGridViewEmployeeList.Columns[13].Visible = false;
                dataGridViewEmployeeList.Columns[14].Visible = false;
                //dataGridViewEmployeeList.Columns[15].Visible = false;
                // end of reload emp grid 12/03/2016


                //cmbSelectGroup.DataSource = objGroupDetailsManager.LoadSelectGroupCombo();
                //cmbSelectGroup.DisplayMember = "Group_Name";
                //cmbSelectGroup.ValueMember = "Group_Name";

                //LoadGroupSetupCombo();
            }
            ClearGroupTab();

            if (txtGroupName.Enabled == true)
            {
                txtGroupName.Enabled = false;
            }
            if (txtLocation.Enabled == true)
            {
                txtLocation.Enabled = false;
            }
            if (cmbGroupActive.Enabled == true)
            {
                cmbGroupActive.Enabled = false;
            }
            if (btnSaveGroup.Enabled == true)
            {
                btnSaveGroup.Enabled = false;
            }
            if (btnAddGroup.Enabled == false)
            {
                btnAddGroup.Enabled = true;
            }
            if (btnSaveGroup.Text == "Update Group")
            {
                btnSaveGroup.Text = "Save Group";
            }
       }

        private void dataGridViewGroupDetails_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            //if (btnSaveGroup.Enabled == false)
            //{
            //    btnSaveGroup.Enabled = true;
            //}
            //btnSaveGroup.Text = "Update Group";
            //GlobalClass.GroupIdForUpdateGroup = dataGridViewGroupDetails.CurrentRow.Cells[0].Value.ToString();
            //txtGroupName.Text = dataGridViewGroupDetails.CurrentRow.Cells[1].Value.ToString();
            //txtLocation.Text = dataGridViewGroupDetails.CurrentRow.Cells[2].Value.ToString();
            //cmbGroupActive.Text = dataGridViewGroupDetails.CurrentRow.Cells[3].Value.ToString();
        }

        private void btnSMSMoveToDB_Click(object sender, EventArgs e)
        {
            string indexSerial;
            string dateTime;
            string smsReceivedFrom;
            string smsDetails;
            string empName;
            int countSms = lvwMessages.Items.Count;
            int x = 0;

            //if (lvwMessages.Items.Count > 0)
            //{
            //    //do
            //    //{
            //    //    ListViewItem item = lvwMessages.SelectedItems[x];
            //    //    dateTime = item.Text;
            //    //    smsReceivedFrom = item.SubItems[0].Text;
            //    //    smsDetails = item.SubItems[1].Text;
            //    //    x = x + 1;
            //    //} while ();
            //    //dateTime
            //    if (countSms > x)
            //    {
            //        ListViewItem item = lvwMessages.SelectedItems[0];
            //        indexSerial = item.Text;
            //        dateTime = item.SubItems[0].Text;MessageBox.Show(a);
            //        smsReceivedFrom = item.SubItems[1].Text;
            //        smsDetails = item.SubItems[2].Text;
            //        MessageBox.Show(dateTime);
            //        MessageBox.Show(smsReceivedFrom);
            //        MessageBox.Show(smsDetails);
            //        x = x + 1;
            //    }

            //}

            ////foreach (ListViewItem itemRow in this.lvwMessages.Items)
            ////{
            ////    for (int i = 0; i < itemRow.SubItems.Count; i++)
            ////    {
            ////        indexSerial = itemRow.Text;
            ////        dateTime = itemRow.SubItems[0].Text;
            ////        smsReceivedFrom = itemRow.SubItems[1].Text;
            ////        smsDetails = itemRow.SubItems[2].Text;
                    
            ////    }
            ////}
            try
            {
                foreach (ListViewItem itm in lvwMessages.Items)
                {
                    indexSerial = itm.Text;
                    /*first column of the particular item*/
                    dateTime = itm.SubItems[1].Text; /*second column of the particular item*/
                    smsReceivedFrom = itm.SubItems[2].Text;
                    smsDetails = itm.SubItems[3].Text;

                    empName = objEmployeeDetailsManager.GetEmployeeName(smsReceivedFrom);

                    if (empName != null)
                    {
                        objSmsDetailsManager.InsertSMSDetails(empName, dateTime, smsReceivedFrom, smsDetails);
             
                        int uCountSMS = objclsSMS.CountSMSmessages(this.port);
                        if (uCountSMS > 0)
                        {
                            //DialogResult dr = MessageBox.Show("Are u sure u want to delete the SMS?", "Delete confirmation", MessageBoxButtons.YesNo);

                            //if (dr.ToString() == "Yes")
                            //{

                            #region Delete SMS

                            //if (this.rbDeleteAllSMS.Checked)
                            //{
                            //...............................................Delete all SMS ....................................................

                            #region Delete all SMS

                            string strCommand = "AT+CMGD=1,4";
                            if (objclsSMS.DeleteMsg(this.port, strCommand))
                            {
                                //MessageBox.Show("Messages has deleted successfuly ");
                                this.statusBar1.Text = "Messages has deleted successfuly";
                            }
                            else
                            {
                                //MessageBox.Show("Failed to delete messages ");
                                this.statusBar1.Text = "Failed to delete messages";
                            }

                            #endregion

                            //}
                            //else if (this.rbDeleteReadSMS.Checked)
                            //{
                            //...............................................Delete Read SMS ....................................................

                            //    #region Delete Read SMS
                            //    string strCommand = "AT+CMGD=1,3";
                            //    if (objclsSMS.DeleteMsg(this.port, strCommand))
                            //    {
                            //        //MessageBox.Show("Messages has deleted successfuly");
                            //        this.statusBar1.Text = "Messages has deleted successfuly";
                            //    }
                            //    else
                            //    {
                            //        //MessageBox.Show("Failed to delete messages ");
                            //        this.statusBar1.Text = "Failed to delete messages";
                            //    }
                            //    #endregion

                            //}

                            #endregion

                            //}
                        }

                     }
                    else if (empName == null)
                    {
                        #region Delete SMS

                        //if (this.rbDeleteAllSMS.Checked)
                        //{
                        //...............................................Delete all SMS ....................................................

                        #region Delete all SMS

                        string strCommand = "AT+CMGD=1,4";
                        if (objclsSMS.DeleteMsg(this.port, strCommand))
                        {
                            //MessageBox.Show("Messages has deleted successfuly ");
                            this.statusBar1.Text = "Messages has deleted successfuly";
                        }
                        else
                        {
                            //MessageBox.Show("Failed to delete messages ");
                            this.statusBar1.Text = "Failed to delete messages";
                        }

                        #endregion

                        //}
                        //else if (this.rbDeleteReadSMS.Checked)
                        //{
                        //...............................................Delete Read SMS ....................................................

                        //    #region Delete Read SMS
                        //    string strCommand = "AT+CMGD=1,3";
                        //    if (objclsSMS.DeleteMsg(this.port, strCommand))
                        //    {
                        //        //MessageBox.Show("Messages has deleted successfuly");
                        //        this.statusBar1.Text = "Messages has deleted successfuly";
                        //    }
                        //    else
                        //    {
                        //        //MessageBox.Show("Failed to delete messages ");
                        //        this.statusBar1.Text = "Failed to delete messages";
                        //    }
                        //    #endregion

                        //}

                        #endregion
                    }

                }
            }
                //Count SMS 

            catch (Exception ex)
            {
                ErrorLog(ex.Message);
            }

        }

        private ArrayList getItemsFromListViewControl()
        {
            ArrayList lviItemsArrayList = new ArrayList();

            foreach (ListViewItem itemRow in this.lvwMessages.Items)
            {
                //lviItemsArrayList.Add(itemRow.Text); <-- Already included in SubItems so ... = )

                for (int i = 0; i < itemRow.SubItems.Count; i++)
                {
                    lviItemsArrayList.Add(itemRow.SubItems[i].Text);
                    // Do something useful here, for example the line above.
                }
            }
            return lviItemsArrayList;
        }

        private void SendAutoSMS(object sender, EventArgs e)
        {
            if (currenTime.ToShortTimeString() == "1:13 AM")
            {
                btnSendSMS_Click(null, null);
                //MessageBox.Show("SMS send");
                reset_Focus_Timer.Enabled = false;
            }
        }

        private void checkBoxSMSRead_Click(object sender, EventArgs e)
        {
            if (checkBoxSMSRead.Checked == true)
            {
                Auto_Read_Timer.Stop();
                Auto_Read_Timer.Enabled = false;
                MessageBox.Show("Auto Read Timer Stopped .....");
            }

            if (checkBoxSMSRead.Checked == false)
            {
                Auto_Read_Timer.Enabled = true;
                Auto_Read_Timer.Start();
                MessageBox.Show("Auto Read Timer Started .....");
            }
        }

        private void checkBoxSMSSend_Click(object sender, EventArgs e)
        {
            if (checkBoxSMSSend.Checked == true)
            {
                reset_Focus_Timer.Stop();
                reset_Focus_Timer.Enabled = false;
                MessageBox.Show("Auto Send Timer Stopped .....");
            }

            if (checkBoxSMSSend.Checked == false)
            {
                reset_Focus_Timer.Enabled = true;
                reset_Focus_Timer.Start();
                MessageBox.Show("Auto Send Timer Started .....");
            }
        }

        private void btnAddDepartment_Click(object sender, EventArgs e)
        {
            if (btnSaveDepartment.Enabled == false)
            {
                btnSaveDepartment.Enabled = true;
            }

            if (btnSaveDepartment.Text == "Update Department")
            {
                btnSaveDepartment.Text = "Save Department";
            }
            if (txtDepartment.Enabled == false)
            {
                txtDepartment.Enabled = true;
            }
            if (cmbActiveDepartment.Enabled == false)
            {
                cmbActiveDepartment.Enabled = true;
            }
            ClearDepartmentTab();
            txtDepartment.Focus();
        }

        public void ClearDepartmentTab()
        {
            txtDepartment.Text = "";
            cmbActiveDepartment.Text = "Select Active";
        }

        private void btnAddDesignation_Click(object sender, EventArgs e)
        {
            if (btnSaveDesignation.Enabled == false)
            {
                btnSaveDesignation.Enabled = true;
            }

            if (btnSaveDesignation.Text == "Update Designation")
            {
                btnSaveDesignation.Text = "Save Designation";
            }

            if (txtDesignation.Enabled == false)
            {
                txtDesignation.Enabled = true;
            }

            if (txtDesignationDetails.Enabled == false)
            {
                txtDesignationDetails.Enabled = true;
            }

            if (cmbActiveDesignation.Enabled == false)
            {
                cmbActiveDesignation.Enabled = true;
            }
            ClearDesignationTab();
            txtDesignation.Focus();
        }

        public void ClearDesignationTab()
        {
            txtDesignation.Text = "";
            txtDesignationDetails.Text = "";
            cmbActiveDesignation.Text = "Select Active";
        }

        private void btnSaveDepartment_Click(object sender, EventArgs e)
        {
            string deptName;
            string activateDepartment;
            int deptID;

            deptName = txtDepartment.Text;
            activateDepartment = cmbActiveDepartment.Text;

            if (btnSaveDepartment.Text == "Save Department")
            {
                objDepartmentDetailsManager.InsertNewDepartment(deptName,activateDepartment);
                dataGridViewDepartmentDetails.Refresh();
                dataGridViewDepartmentDetails.DataSource = objDepartmentDetailsManager.AllDepartmentDetails();
                dataGridViewDepartmentDetails.Columns[0].Visible = false;
                btnSaveDepartment.Enabled = false;
                MessageBox.Show("Department Added Succesfully");
                cmbEmployeeDepartment.DataSource = objDepartmentDetailsManager.LoadDepartmentCombo();
                cmbEmployeeDepartment.DisplayMember = "Department_Name";
                cmbEmployeeDepartment.ValueMember = "Department_Name";
            }
            else if (btnSaveDepartment.Text == "Update Department")
            {
                deptID = Convert.ToInt32(GlobalClass.DeptIdForUpdateDepartment);
                objDepartmentDetailsManager.UpdateDepartment(deptID,deptName,activateDepartment);
                objEmployeeDetailsManager.UpdateDepartmentActiveLogInEmpInfo(deptID, activateDepartment);
                dataGridViewDepartmentDetails.Refresh();
                dataGridViewDepartmentDetails.DataSource = objDepartmentDetailsManager.AllDepartmentDetails();
                dataGridViewDepartmentDetails.Columns[0].Visible = false;
                btnSaveDepartment.Text = "Save Department";
                btnSaveDepartment.Enabled = false;
                MessageBox.Show("Department Updated Succesfully");
                cmbEmployeeDepartment.DataSource = objDepartmentDetailsManager.LoadDepartmentCombo();
                cmbEmployeeDepartment.DisplayMember = "Department_Name";
                cmbEmployeeDepartment.ValueMember = "Department_Name";

                //LoadGroupSetupCombo();
            }
            ClearDepartmentTab();

            if (txtDepartment.Enabled == true)
            {
                txtDepartment.Enabled = false;
            }
            if (cmbActiveDepartment.Enabled == true)
            {
                cmbActiveDepartment.Enabled = false;
            }
            if (btnSaveDepartment.Enabled == true)
            {
                btnSaveDepartment.Enabled = false;
            }
            if (btnAddDepartment.Enabled == false)
            {
                btnAddDepartment.Enabled = true;
            }
            if (btnSaveDepartment.Text == "Update Department")
            {
                btnSaveDepartment.Text = "Save Department";
            }
        }

        private void dataGridViewDepartmentDetails_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (btnSaveDepartment.Enabled == false)
            {
                btnSaveDepartment.Enabled = true;
            }
            btnSaveDepartment.Text = "Update Department";
            GlobalClass.DeptIdForUpdateDepartment = dataGridViewDepartmentDetails.CurrentRow.Cells[0].Value.ToString();
            txtDepartment.Text = dataGridViewDepartmentDetails.CurrentRow.Cells[1].Value.ToString();
            cmbActiveDepartment.Text = dataGridViewDepartmentDetails.CurrentRow.Cells[2].Value.ToString();
        }

        private void dataGridViewUserDetails_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (btnSaveUser.Enabled == false)
            {
                btnSaveUser.Enabled = true;
            }
            
            if (txtUserName.Enabled == false)
            {
                txtUserName.Enabled = true;
            }

            if (txtPassword.Enabled == false)
            {
                txtPassword.Enabled = true;
            }

            if (cmbUserRole.Enabled == false)
            {
                cmbUserRole.Enabled = true;
            }

            if (cmbActive.Enabled == false)
            {
                cmbActive.Enabled = true;
            }

            btnSaveUser.Text = "Update User";
            GlobalClass.UserIdForEditUserDetails = dataGridViewUserDetails.CurrentRow.Cells[0].Value.ToString();
            txtUserName.Text = dataGridViewUserDetails.CurrentRow.Cells[1].Value.ToString();
            txtPassword.Text = dataGridViewUserDetails.CurrentRow.Cells[2].Value.ToString();
            cmbUserRole.Text = dataGridViewUserDetails.CurrentRow.Cells[4].Value.ToString();
            txtRoleID.Text = dataGridViewUserDetails.CurrentRow.Cells[3].Value.ToString();
            cmbActive.Text = dataGridViewUserDetails.CurrentRow.Cells[5].Value.ToString();
        }

        private void dataGridViewGroupDetails_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (btnSaveGroup.Enabled == false)
            {
                btnSaveGroup.Enabled = true;
            }
            btnSaveGroup.Text = "Update Group";
            GlobalClass.GroupIdForUpdateGroup = dataGridViewGroupDetails.CurrentRow.Cells[0].Value.ToString();
            txtGroupName.Text = dataGridViewGroupDetails.CurrentRow.Cells[1].Value.ToString();
            txtLocation.Text = dataGridViewGroupDetails.CurrentRow.Cells[2].Value.ToString();
            cmbGroupActive.Text = dataGridViewGroupDetails.CurrentRow.Cells[3].Value.ToString();

            if (btnSaveGroup.Enabled == false)
            {
                btnSaveGroup.Enabled = true;
            }

            if (txtGroupName.Enabled == false)
            {
                txtGroupName.Enabled = true;
            }
            if (txtLocation.Enabled == false)
            {
                txtLocation.Enabled = true;
            }
            if (cmbGroupActive.Enabled == false)
            {
                cmbGroupActive.Enabled = true;
            }
            if (btnAddGroup.Enabled == false)
            {
                btnAddGroup.Enabled = true;
            }
            if (btnSaveGroup.Text == "Save Group")
            {
                btnSaveGroup.Text = "Update Group";
            }
        }

        private void btnSaveDesignation_Click(object sender, EventArgs e)
        {
            string designation;
            string designationDetails;
            string activeDesignation;
            int designationID;

            designation = txtDesignation.Text;
            designationDetails = txtDesignationDetails.Text;
            activeDesignation = cmbActiveDesignation.Text;

            if (btnSaveDesignation.Text == "Save Designation")
            {
                objDesignationDetailsManager.InsertDesignation(designation, designationDetails, activeDesignation);
                dataGridViewDesignationList.Refresh();
                dataGridViewDesignationList.DataSource = objDesignationDetailsManager.ShowAllDesignation();
                dataGridViewDesignationList.Columns[0].Visible = false;
                btnSaveDesignation.Enabled = false;
                MessageBox.Show("Designation Added Succesfully");
                cmbEmployeeDesignation.DataSource = objDesignationDetailsManager.LoadDesignationCombo();
                cmbEmployeeDesignation.DisplayMember = "Designation";
                cmbEmployeeDesignation.ValueMember = "Designation";
            }
            else if (btnSaveDesignation.Text == "Update Designation")
            {
                designationID = Convert.ToInt32(GlobalClass.DesignationIDforUpdateDesignation);
                objDesignationDetailsManager.UpdateDesignation(designationID, designation, designationDetails, activeDesignation);
                objEmployeeDetailsManager.UpdateDesignationActiveLogInEmpInfo(designationID, activeDesignation);
                dataGridViewDesignationList.Refresh();
                dataGridViewDesignationList.DataSource = objDesignationDetailsManager.ShowAllDesignation();
                dataGridViewDesignationList.Columns[0].Visible = false;
                btnSaveDesignation.Text = "Save Designation";
                btnSaveDesignation.Enabled = false;
                MessageBox.Show("Designation Updated Succesfully");
                cmbEmployeeDesignation.DataSource = objDesignationDetailsManager.LoadDesignationCombo();
                cmbEmployeeDesignation.DisplayMember = "Designation";
                cmbEmployeeDesignation.ValueMember = "Designation";

                checkActiveDesignationForGroupSetup();

                //reload employee grid 12/03/2016
                dataGridViewEmployeeList.DataSource = objEmployeeDetailsManager.ShowAllEmployee();
                dataGridViewEmployeeList.Columns[0].Visible = false;
                dataGridViewEmployeeList.Columns[4].Visible = false;
                dataGridViewEmployeeList.Columns[6].Visible = false;
                dataGridViewEmployeeList.Columns[9].Visible = false;
                dataGridViewEmployeeList.Columns[12].Visible = false;
                dataGridViewEmployeeList.Columns[13].Visible = false;
                dataGridViewEmployeeList.Columns[14].Visible = false;
                //dataGridViewEmployeeList.Columns[15].Visible = false;
                // end of reload emp grid 12/03/2016

                //LoadGroupSetupCombo();
            }
            ClearDesignationTab();

            if (txtDesignation.Enabled == true)
            {
                txtDesignation.Enabled = false;
            }
            if (txtDesignationDetails.Enabled == true)
            {
                txtDesignationDetails.Enabled = false;
            }
            if (cmbActiveDesignation.Enabled == true)
            {
                cmbActiveDesignation.Enabled = false;
            }
            if (btnSaveDesignation.Enabled == true)
            {
                btnSaveDesignation.Enabled = false;
            }
            if (btnAddDesignation.Enabled == false)
            {
                btnAddDesignation.Enabled = true;
            }
            if (btnSaveDesignation.Text == "Update Designation")
            {
                btnSaveDesignation.Text = "Save Designation";
            }
        }

        private void dataGridViewDesignationList_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (btnSaveDesignation.Enabled == false)
            {
                btnSaveDesignation.Enabled = true;
            }
            btnSaveDesignation.Text = "Update Designation";
            GlobalClass.DesignationIDforUpdateDesignation = dataGridViewDesignationList.CurrentRow.Cells[0].Value.ToString();
            txtDesignation.Text = dataGridViewDesignationList.CurrentRow.Cells[1].Value.ToString();
            txtDesignationDetails.Text = dataGridViewDesignationList.CurrentRow.Cells[2].Value.ToString();
            cmbActiveDesignation.Text = dataGridViewDesignationList.CurrentRow.Cells[3].Value.ToString();

            if (btnSaveDesignation.Enabled == false)
            {
                btnSaveDesignation.Enabled = true;
            }

            if (btnSaveDesignation.Text == "Save Designation")
            {
                btnSaveDesignation.Text = "Update Designation";
            }

            if (txtDesignation.Enabled == false)
            {
                txtDesignation.Enabled = true;
            }

            if (txtDesignationDetails.Enabled == false)
            {
                txtDesignationDetails.Enabled = true;
            }

            if (cmbActiveDesignation.Enabled == false)
            {
                cmbActiveDesignation.Enabled = true;
            }
        }

        private void Auto_Read_Timer_Tick(object sender, EventArgs e)
        {
            try
            {
                btnReadSMS_Click(null, null);
                if (lvwMessages.Items.Count > 0)
                {
                    btnSMSMoveToDB_Click(null, null);
                    //MessageBox.Show("SMS Received....");
                }
            }
            catch
            {
                MessageBox.Show("Error in READ Section");
            }
            
        }

        private void dataGridViewDepartmentDetails_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (btnSaveDepartment.Enabled == false)
            {
                btnSaveDepartment.Enabled = true;
            }

            btnSaveDepartment.Text = "Update Department";
            GlobalClass.DeptIdForUpdateDepartment = dataGridViewDepartmentDetails.CurrentRow.Cells[0].Value.ToString();
            txtDepartment.Text = dataGridViewDepartmentDetails.CurrentRow.Cells[1].Value.ToString();
            cmbActiveDepartment.Text = dataGridViewDepartmentDetails.CurrentRow.Cells[2].Value.ToString();

            if (txtDepartment.Enabled == false)
            {
                txtDepartment.Enabled = true;
            }
            if (cmbActiveDepartment.Enabled == false)
            {
                cmbActiveDepartment.Enabled = true;
            }

        }

        private void cmbEmployeeDesignation_SelectedIndexChanged(object sender, EventArgs e)
        {
            //this.txtRoleID.Text = objUserRoleDetailsManager.GetUserRoleID(cmbUserRole.Text);
            this.txtEmployeeDesignationID.Text =
                objDesignationDetailsManager.GetDesignationID(cmbEmployeeDesignation.Text);
        }

        private void cmbEmployeeDesignation_SelectedValueChanged(object sender, EventArgs e)
        {
            this.txtEmployeeDesignationID.Text =
                objDesignationDetailsManager.GetDesignationID(cmbEmployeeDesignation.Text);
        }

        private void cmbEmployeeDepartment_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.txtEmployeeDepartmentID.Text =
                objDepartmentDetailsManager.GetDepartmentID(cmbEmployeeDepartment.Text);
        }

        private void cmbEmployeeDepartment_SelectedValueChanged(object sender, EventArgs e)
        {
            this.txtEmployeeDepartmentID.Text =
                objDepartmentDetailsManager.GetDepartmentID(cmbEmployeeDepartment.Text);
        }

        private void cmbEmployeeGroup_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.txtEmployeeGroupID.Text = objGroupDetailsManager.GetGroupID(cmbEmployeeGroup.Text);
        }

        private void cmbEmployeeGroup_SelectedValueChanged(object sender, EventArgs e)
        {
            this.txtEmployeeGroupID.Text = objGroupDetailsManager.GetGroupID(cmbEmployeeGroup.Text);
        }

        private void btnSaveEmployee_Click(object sender, EventArgs e)
        {
            string empName;
            string empAddress;
            string empDOB;
            string empDesination;
            int empDesignationID;
            string empDepartment;
            int empDeptID;
            string empOffCellNo;
            string empGroup;
            int empGroupID;
            string empActive;
            int empID;
            string empDesiActive;
            string empDeptActive;
            string empGroupActive;
            int empMarketID;
            string empMarketCode;
            string empNameOfMarket;
            string empQuitDate;

            empName = txtEmployeeName.Text;
            empAddress = txtAddress.Text;
            //empDOB = dTPDateOfBirth.Text;
            empDOB = txtDOB.Text;
            empDesination = cmbEmployeeDesignation.Text;
            empDesignationID = Convert.ToInt32(txtEmployeeDesignationID.Text);
            empDepartment = cmbEmployeeDepartment.Text;
            empDeptID = Convert.ToInt32(txtEmployeeDepartmentID.Text);
            empOffCellNo = txtOfficialCellNo.Text;
            empGroup = cmbEmployeeGroup.Text;
            empGroupID = Convert.ToInt32(txtEmployeeGroupID.Text);
            empActive = cmbEmployeeActive.Text;
            
            //if (txtEmpMarketID.Text == "")
            //{
            //    empMarketID = 0;
            //    empMarketCode = txtEmpMarketCode.Text;
            //    empNameOfMarket = cmbEmpMarketName.Text;
            //}
            //else
            //{
            //    empMarketID = Convert.ToInt32(txtEmpMarketID.Text);
            //    empMarketCode = txtEmpMarketCode.Text;
            //    empNameOfMarket = cmbEmpMarketName.Text;
            //}

            empQuitDate = txtQuitDate.Text;

            empDesiActive = objDesignationDetailsManager.GetDesignationActiveDetails(empDesignationID);
            empDeptActive = objDepartmentDetailsManager.GetDepartmentActiveDetails(empDeptID);
            empGroupActive = objGroupDetailsManager.GetGroupActiveDetails(empGroupID);
            
            if (btnSaveEmployee.Text == "Save Employee")
            {
                objEmployeeDetailsManager.InsertEmployeePrev(empName, empAddress, empDOB, empDesignationID, empDesination, empDeptID, empDepartment, empOffCellNo, empGroupID, empGroup, empActive, empDesiActive, empDeptActive, empGroupActive, empQuitDate);

                dataGridViewEmployeeList.Refresh();
                dataGridViewEmployeeList.DataSource = objEmployeeDetailsManager.ShowAllEmployee();
                dataGridViewEmployeeList.Columns[0].Visible = false;
                dataGridViewEmployeeList.Columns[4].Visible = false;
                dataGridViewEmployeeList.Columns[6].Visible = false;
                dataGridViewEmployeeList.Columns[9].Visible = false;
                dataGridViewEmployeeList.Columns[12].Visible = false;
                dataGridViewEmployeeList.Columns[13].Visible = false;
                dataGridViewEmployeeList.Columns[14].Visible = false;
                //dataGridViewEmployeeList.Columns[15].Visible = false;
                btnAddEmployee.Enabled = true;
                btnSaveEmployee.Enabled = false;
                MessageBox.Show("Employee Added Succesfully");
                //cmbSelectDO.DataSource = objGroupSetupManager.LoadDO();
                //if (objGroupSetupManager.LoadDO().Rows.Count > 0)
                //{
                //    cmbSelectDO.DisplayMember = "Employee_Name";
                //    cmbSelectDO.ValueMember = "Employee_Name";
                //}
                //else
                //{
                //    cmbSelectDO.Enabled = false;
                //}
                //cmbSelectGroup.DataSource = objGroupDetailsManager.LoadSelectGroupCombo();
                //cmbSelectGroup.DisplayMember = "Group_Name";
                //cmbSelectGroup.ValueMember = "Group_Name";

                //LoadGroupSetupCombo();
            }
            else if (btnSaveEmployee.Text == "Update Employee")
            {
                empID = Convert.ToInt32(GlobalClass.EmpIDforUpdateEmployee);
                objEmployeeDetailsManager.UpdateEmployeePrev(empID, empName, empAddress, empDOB, empDesignationID, empDesination, empDeptID, empDepartment, empOffCellNo, empGroupID, empGroup, empActive, empQuitDate); // empDesiActive, empDeptActive, empGroupActive, //, empDesiActive, empDeptActive, empGroupActive, empMarketID, empMarketCode, empNameOfMarket

                dataGridViewEmployeeList.Refresh();
                dataGridViewEmployeeList.DataSource = objEmployeeDetailsManager.ShowAllEmployee();
                dataGridViewEmployeeList.Columns[0].Visible = false;
                dataGridViewEmployeeList.Columns[4].Visible = false;
                dataGridViewEmployeeList.Columns[6].Visible = false;
                dataGridViewEmployeeList.Columns[9].Visible = false;
                dataGridViewEmployeeList.Columns[12].Visible = false;
                dataGridViewEmployeeList.Columns[13].Visible = false;
                dataGridViewEmployeeList.Columns[14].Visible = false;
                //dataGridViewEmployeeList.Columns[15].Visible = false;
                btnSaveEmployee.Text = "Save Employee";
                btnAddEmployee.Enabled = true;
                btnSaveEmployee.Enabled = false;
                MessageBox.Show("Employee Updated Succesfully");
                
                //cmbSelectDO.DataSource = objGroupSetupManager.LoadDO();
                //if (objGroupSetupManager.LoadDO().Rows.Count > 0)
                //{
                //    cmbSelectDO.DisplayMember = "Employee_Name";
                //    cmbSelectDO.ValueMember = "Employee_Name";
                //}
                //else
                //{
                //    cmbSelectDO.Enabled = false;
                //}
                //cmbSelectGroup.DataSource = objGroupDetailsManager.LoadSelectGroupCombo();
                //cmbSelectGroup.DisplayMember = "Group_Name";
                //cmbSelectGroup.ValueMember = "Group_Name";

                //LoadGroupSetupCombo();
            }
            ClearEmployeeTab();

            if (txtEmployeeName.Enabled == true)
            {
                txtEmployeeName.Enabled = false;
            }

            if (txtAddress.Enabled == true)
            {
                txtAddress.Enabled = false;
            }

            if (txtDOB.Enabled == true)
            {
                txtDOB.Enabled = false;
            }

            if (dTPDateOfBirth.Enabled == true)
            {
                dTPDateOfBirth.Enabled = false;
            }

            if (cmbEmployeeDesignation.Enabled == true)
            {
                cmbEmployeeDesignation.Enabled = false;
            }

            if (cmbEmployeeDepartment.Enabled == true)
            {
                cmbEmployeeDepartment.Enabled = false;
            }

            if (txtOfficialCellNo.Enabled == true)
            {
                txtOfficialCellNo.Enabled = false;
            }

            if (cmbEmployeeGroup.Enabled == true)
            {
                cmbEmployeeGroup.Enabled = false;
            }

            if (cmbEmployeeActive.Enabled == true)
            {
                cmbEmployeeActive.Enabled = false;
            }

            if (txtQuitDate.Enabled == true)
            {
                txtQuitDate.Enabled = false;
            }

            if (dTPQuitDate.Enabled == true)
            {
                dTPQuitDate.Enabled = false;
            }

            if (btnSaveEmployee.Text == "Update Employee")
            {
                btnSaveEmployee.Text = "Save Employee";
            }

            if (btnSaveEmployee.Enabled == true)
            {
                btnSaveEmployee.Enabled = false;
            }

            if (btnAddEmployee.Enabled == false)
            {
                btnAddEmployee.Enabled = true;
            }
        }

        private void btnAddEmployee_Click(object sender, EventArgs e)
        {
            if (btnSaveEmployee.Enabled == false)
            {
                btnSaveEmployee.Enabled = true;
            }

            if (btnSaveEmployee.Text == "Update Department")
            {
                btnSaveEmployee.Text = "Save Department";
            }

            if (txtEmployeeName.Enabled == false)
            {
                txtEmployeeName.Enabled = true;
            }

            if (txtAddress.Enabled == false)
            {
                txtAddress.Enabled = true;
            }

            if (txtDOB.Enabled == false)
            {
                txtDOB.Enabled = true;
            }

            if (dTPDateOfBirth.Enabled == false)
            {
                dTPDateOfBirth.Enabled = true;
            }

            if (cmbEmployeeDesignation.Enabled == false)
            {
                cmbEmployeeDesignation.Enabled = true;
            }

            if (cmbEmployeeDepartment.Enabled == false)
            {
                cmbEmployeeDepartment.Enabled = true;
            }

            if (txtOfficialCellNo.Enabled == false)
            {
                txtOfficialCellNo.Enabled = true;
            }

            if (cmbEmployeeGroup.Enabled == false)
            {
                cmbEmployeeGroup.Enabled = true;
            }

            if (cmbEmployeeActive.Enabled == false)
            {
                cmbEmployeeActive.Enabled = true;
            }

            if (txtQuitDate.Enabled == false)
            {
                txtQuitDate.Enabled = true;
            }

            //if (dTPQuitDate.Enabled == false)
            //{
            //    dTPQuitDate.Enabled = true;
            //}

            //if (btnAddEmployee.Enabled == false)
            //{
            //    btnAddEmployee.Enabled = true;
            //}
            
            ClearEmployeeTab();
            txtEmployeeName.Focus();   
        }

        public void ClearEmployeeTab()
        {
            txtEmployeeName.Text = "";
            txtAddress.Text = "";
            txtDOB.Text = "";
            //dTPDateOfBirth.Text = "";
            cmbEmployeeDesignation.Text = "Select Designation";
            txtEmployeeDesignationID.Text = "";
            cmbEmployeeDepartment.Text = "Select Department";
            txtEmployeeDepartmentID.Text = "";
            txtOfficialCellNo.Text = "";
            cmbEmployeeGroup.Text = "Select Team";
            txtEmployeeGroupID.Text = "";
            cmbEmployeeActive.Text = "Select Active";
            //cmbEmpMarketName.Text = "";
            //txtEmpMarketID.Text = "";
            //txtEmpMarketCode.Text = "";
            txtQuitDate.Text = "";
            txtQuitDate.Enabled = false;
            dTPQuitDate.Enabled = false;
            //cmbEmpMarketName.Enabled = false;
        }

        private void dataGridViewEmployeeList_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            string dobOfEmp;
            //string quitDate;
            if (btnSaveEmployee.Enabled == false)
            {
                btnSaveEmployee.Enabled = true;
            }
            btnSaveEmployee.Text = "Update Employee";
            GlobalClass.EmpIDforUpdateEmployee = dataGridViewEmployeeList.CurrentRow.Cells[0].Value.ToString();
            txtEmployeeName.Text = dataGridViewEmployeeList.CurrentRow.Cells[1].Value.ToString();
            txtAddress.Text = dataGridViewEmployeeList.CurrentRow.Cells[2].Value.ToString();
            //dobOfEmp = String.Format("MM/dd/yyyy", dataGridViewEmployeeList.CurrentRow.Cells[3].Value.ToString());

            dobOfEmp = dataGridViewEmployeeList.CurrentRow.Cells[3].Value.ToString();
            txtDOB.Text = dobOfEmp.Replace("12:00:00 AM", "");
            txtDOB.Text = txtDOB.Text.Trim();

            //txtDOB.Text = dobOfEmp.Substring(0, 10).Trim();
            //Convert.ToDateTime(txtDOB.Text) =  dataGridViewEmployeeList.CurrentRow.Cells[3].Value.ToString();
            //dTPDateOfBirth.Text = dataGridViewEmployeeList.CurrentRow.Cells[3].Value.ToString();
            txtEmployeeDesignationID.Text = dataGridViewEmployeeList.CurrentRow.Cells[4].Value.ToString();
            cmbEmployeeDesignation.Text = dataGridViewEmployeeList.CurrentRow.Cells[5].Value.ToString();
            txtEmployeeDepartmentID.Text = dataGridViewEmployeeList.CurrentRow.Cells[6].Value.ToString();
            cmbEmployeeDepartment.Text = dataGridViewEmployeeList.CurrentRow.Cells[7].Value.ToString();
            txtOfficialCellNo.Text = dataGridViewEmployeeList.CurrentRow.Cells[8].Value.ToString();
            txtEmployeeGroupID.Text = dataGridViewEmployeeList.CurrentRow.Cells[9].Value.ToString();
            cmbEmployeeGroup.Text = dataGridViewEmployeeList.CurrentRow.Cells[10].Value.ToString();
            cmbEmployeeActive.Text = dataGridViewEmployeeList.CurrentRow.Cells[11].Value.ToString();
            //txtEmpMarketID.Text = dataGridViewEmployeeList.CurrentRow.Cells[15].Value.ToString();
            //txtEmpMarketCode.Text = dataGridViewEmployeeList.CurrentRow.Cells[16].Value.ToString();
            //cmbEmpMarketName.Text = dataGridViewEmployeeList.CurrentRow.Cells[17].Value.ToString();
            
            //quitDate = dataGridViewEmployeeList.CurrentRow.Cells[18].Value.ToString();
            
            //if(quitDate != "")
            //{
            //    txtQuitDate.Text = quitDate.Substring(0, 10).Trim();
            //}
            //else
            //{
            //    txtQuitDate.Text = dataGridViewEmployeeList.CurrentRow.Cells[18].Value.ToString();    
            //}


            if (btnSaveEmployee.Enabled == false)
            {
                btnSaveEmployee.Enabled = true;
            }

            if (btnSaveEmployee.Text == "Save Department")
            {
                btnSaveEmployee.Text = "Update Department";
            }

            if (txtEmployeeName.Enabled == false)
            {
                txtEmployeeName.Enabled = true;
            }

            if (txtAddress.Enabled == false)
            {
                txtAddress.Enabled = true;
            }

            if (txtDOB.Enabled == false)
            {
                txtDOB.Enabled = true;
            }

            if (dTPDateOfBirth.Enabled == false)
            {
                dTPDateOfBirth.Enabled = true;
            }

            if (cmbEmployeeDesignation.Enabled == false)
            {
                cmbEmployeeDesignation.Enabled = true;
            }

            if (cmbEmployeeDepartment.Enabled == false)
            {
                cmbEmployeeDepartment.Enabled = true;
            }

            if (txtOfficialCellNo.Enabled == false)
            {
                txtOfficialCellNo.Enabled = true;
            }

            if (cmbEmployeeGroup.Enabled == false)
            {
                cmbEmployeeGroup.Enabled = true;
            }

            if (cmbEmployeeActive.Enabled == false)
            {
                cmbEmployeeActive.Enabled = true;
            }

            if (txtQuitDate.Enabled == false)
            {
                txtQuitDate.Enabled = true;
            }

            if (dTPQuitDate.Enabled == false)
            {
                dTPQuitDate.Enabled = true;
            }

            if (btnAddEmployee.Enabled == false)
            {
                btnAddEmployee.Enabled = true;
            }

            if (cmbEmployeeActive.Text == "No")
            {
                if (txtQuitDate.Enabled == false)
                {
                    txtQuitDate.Enabled = true;
                }
                if (dTPQuitDate.Enabled == false)
                {
                    dTPQuitDate.Enabled = true;
                }
                
                txtQuitDate.Text = dataGridViewEmployeeList.CurrentRow.Cells[15].Value.ToString();
                txtQuitDate.Text = txtQuitDate.Text.Replace("12:00:00 AM", "");
                txtQuitDate.Text = txtQuitDate.Text.Trim();
            }

            if (cmbEmployeeActive.Text == "Yes")
            {
                txtQuitDate.Text = ""; 

                if (txtQuitDate.Enabled == true)
                {
                    txtQuitDate.Enabled = false;
                }
                
                if (dTPQuitDate.Enabled == true)
                {
                    dTPQuitDate.Enabled = false;
                }
            }

            txtEmployeeName.Focus();
        }

        private void btnAddMarket_Click(object sender, EventArgs e)
        {
            ClearMarketTab();
            if (txtMarketCode.Enabled == false)
            {
                txtMarketCode.Enabled = true;
            }

            if (txtMarketName.Enabled == false)
            {
                txtMarketName.Enabled = true;
            }

            if (txtTarget.Enabled == false)
            {
                txtTarget.Enabled = true;
            }

            if (txtTotalNoOfParty.Enabled == false)
            {
                txtTotalNoOfParty.Enabled = true;
            }

            if (txtMonthlyNoOfVisit.Enabled == false)
            {
                txtMonthlyNoOfVisit.Enabled = true;
            }

            if (cmbSelectDivisionForMarket.Enabled == false)
            {
                cmbSelectDivisionForMarket.Enabled = true;
            }

            //closed on 17 May 2016
            //if (cmbSelectGroupForMarket.Enabled == false)
            //{
            //    cmbSelectGroupForMarket.Enabled = true;
            //}

            //if (cmbSelectEmpForMarket.Enabled == false)
            //{
            //    cmbSelectEmpForMarket.Enabled = true;
            //}
            //end closed on 17 May 2016
            
            if (cmbMarketActive.Enabled == false)
            {
                cmbMarketActive.Enabled = true;
            }

            if (btnSaveMarket.Enabled == false)
            {
                btnSaveMarket.Enabled = true;
            }

            if (btnAddMarket.Enabled == false)
            {
                btnAddMarket.Enabled = true;
            }

            txtMarketCode.Focus();
        }

        public void ClearMarketTab()
        {
            if (btnSaveMarket.Enabled == false)
            {
                btnSaveMarket.Enabled = true;
            }
            txtMarketCode.Text = "";
            txtMarketName.Text = "";
            txtTotalNoOfParty.Text = "";
            txtTarget.Text = "";
            txtMonthlyNoOfVisit.Text = "";

            //closed on 17 May 2016

            //cmbSelectGroupForMarket.Text = "";
            //txtGroupIDForMarket.Text = "";
            //cmbSelectEmpForMarket.Text = "";
            //txtEmpIDForMarket.Text = "";
            //txtEmpDesignationForMarket.Text = "";
            //txtEmpCellNoForMarket.Text = "";

            //end closed on 17 May 2016

            cmbMarketActive.Text = "Select Active";

            //closed on 17 May 2016
            //txtMarketCode.Focus();
            //end closed on 17 May 2016
        }
         
        private void btnSaveMarket_Click(object sender, EventArgs e)
        {
            int marketID;
            string marketCode;
            string marketName;
            int noOfParty;
            int target;
            int monthlyNoOfVisit;
            int groupID;
            string groupName;
            string divisionName;
            string marketActive;

            //closed on 17 May 2016
            //int empIdForMarket;
            //string empNameForMarket;
            //string officialCellNO;
            //string empDesignationForMarket;
            //int groupIdForMarket;
            //string groupNameForMarket;
            //end closed on 17 May 2016

            marketCode = txtMarketCode.Text;
            marketName = txtMarketName.Text;
            noOfParty = Convert.ToInt32(txtTotalNoOfParty.Text);
            target = Convert.ToInt32(txtTarget.Text);
            monthlyNoOfVisit = Convert.ToInt32(txtMonthlyNoOfVisit.Text);
            groupID = Convert.ToInt16(txtTeamIDForMarket.Text);
            groupName = txtTeamNameForMarket.Text;
            divisionName = cmbSelectDivisionForMarket.Text;
            marketActive = cmbMarketActive.Text;
            //closed on 17 May 2016
            ////empIdForMarket =  Convert.ToInt32(txtEmpIDForMarket.Text) ;
            ////empNameForMarket = cmbSelectEmpForMarket.Text;
            ////officialCellNO = txtEmpCellNoForMarket.Text;
            ////groupIdForMarket = Convert.ToInt32(txtGroupIDForMarket.Text);
            ////groupNameForMarket = cmbSelectGroupForMarket.Text;
            ////empDesignationForMarket = txtEmpDesignationForMarket.Text;
            //end closed on 17 May 2016

            if(btnSaveMarket.Text == "Save Market")
            {
                //closed on 17 May 2016
                //objMarketDetailsManager.InsertMarket(marketCode, marketName, noOfParty, target, monthlyNoOfVisit,
                //marketActive, empIdForMarket, empNameForMarket, officialCellNO, empDesignationForMarket, groupIdForMarket, groupNameForMarket);
                //end closed on 17 May 2016

                //new on 17 May 2016
                objMarketDetailsManager.InsertMarket(marketCode, marketName, noOfParty, target, monthlyNoOfVisit, groupID, groupName, divisionName, marketActive);
                //end of new on 17 May 2016

                //closed 31 May 2016
                //dataGridViewMarket.DataSource = objMarketDetailsManager.AllMarketDetails();
                //dataGridViewMarket.Columns[0].Visible = false;
                //dataGridViewMarket.Columns[7].Visible = false;
                //dataGridViewMarket.Columns[11].Visible = false;
                //dataGridViewMarket.Columns[13].Visible = false;
                //end closed 31 May 2016

                dataGridViewMarket.DataSource = objMarketDetailsManager.AllMarketDetails();
                dataGridViewMarket.Columns[0].Visible = false;
                dataGridViewMarket.Columns[7].Visible = false;
                dataGridViewMarket.Columns[8].Visible = false;
                dataGridViewMarket.Columns[9].Visible = false;
                dataGridViewMarket.Columns[10].Visible = false;
                dataGridViewMarket.Columns[11].Visible = false;
                //dataGridViewMarket.Columns[13].Visible = false;
                btnSaveMarket.Text = "Save Market";
                btnAddMarket.Enabled = true;
                MessageBox.Show("Market Added Succesfully");
            }
            else if (btnSaveMarket.Text == "Update Market")
            {
                marketID = Convert.ToInt32(GlobalClass.MarketIdForUpdate.ToString());

                //closed on 17 May 2016
                //objMarketDetailsManager.UpdateMarket(marketID, marketCode, marketName, noOfParty, target,
                //monthlyNoOfVisit, marketActive, empIdForMarket, empNameForMarket, officialCellNO, empDesignationForMarket, groupIdForMarket, groupNameForMarket);
                //end closed on 17 May 2016
                
                //new on 17 May 2016
                objMarketDetailsManager.UpdateMarket(marketID, marketCode, marketName, noOfParty, target, monthlyNoOfVisit, groupID, groupName, divisionName, marketActive);
                //end of new on 17 May 2016

                //closed 31 May 2016
                //dataGridViewMarket.DataSource = objMarketDetailsManager.AllMarketDetails();
                //dataGridViewMarket.Columns[0].Visible = false;
                //dataGridViewMarket.Columns[7].Visible = false;
                //dataGridViewMarket.Columns[11].Visible = false;
                //dataGridViewMarket.Columns[13].Visible = false;
                //end closed 31 May 2016

                dataGridViewMarket.DataSource = objMarketDetailsManager.AllMarketDetails();
                dataGridViewMarket.Columns[0].Visible = false;
                dataGridViewMarket.Columns[7].Visible = false;
                dataGridViewMarket.Columns[8].Visible = false;
                dataGridViewMarket.Columns[9].Visible = false;
                dataGridViewMarket.Columns[10].Visible = false;
                dataGridViewMarket.Columns[11].Visible = false;
                //dataGridViewMarket.Columns[13].Visible = false;
                MessageBox.Show("Market Update Successfully.");
            }
            ClearMarketTab();

            if (txtMarketCode.Enabled == true)
            {
                txtMarketCode.Enabled = false;
            }

            if (txtMarketName.Enabled == true)
            {
                txtMarketName.Enabled = false;
            }

            if (txtTotalNoOfParty.Enabled == true)
            {
                txtTotalNoOfParty.Enabled = false;
            }

            if (txtTarget.Enabled == true)
            {
                txtTarget.Enabled = false;
            }

            if (txtMonthlyNoOfVisit.Enabled == true)
            {
                txtMonthlyNoOfVisit.Enabled = false;
            }

            //closed on 17 May 2016
            //if (cmbSelectGroupForMarket.Enabled == true)
            //{
            //    cmbSelectGroupForMarket.Enabled = false;
            //}

            //if (cmbSelectEmpForMarket.Enabled == true)
            //{
            //    cmbSelectEmpForMarket.Enabled = false;
            //}

            //end closed on 17 May 2016

            if (cmbMarketActive.Enabled == true)
            {
                cmbMarketActive.Enabled = false;
            }

            if (btnSaveMarket.Text == "Update Market")
            {
                btnSaveMarket.Text = "Save Market";
            }

            if (btnSaveMarket.Enabled == true)
            {
                btnSaveMarket.Enabled = false;
            }

            if (btnAddMarket.Enabled == false)
            {
                btnAddMarket.Enabled = true;
            }

            if (cmbSelectDivisionForMarket.Enabled == true)
            {
                cmbSelectDivisionForMarket.Enabled = false;
            }

            cmbSelectDivisionForMarket.Text = "Select Division";
            txtTeamIDForMarket.Text = "";
            txtTeamNameForMarket.Text = "";
        }

        //private void dataGridViewMarket_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        //{
        //    if (btnSaveMarket.Enabled == false)
        //    {
        //        btnSaveMarket.Enabled = true;
        //    }
        //    btnSaveMarket.Text = "Update Designation";
        //    GlobalClass.MarketIdForUpdate = dataGridViewMarket.CurrentRow.Cells[0].Value.ToString();
        //    //GlobalClass.DesignationIDforUpdateDesignation = dataGridViewDesignationList.CurrentRow.Cells[0].Value.ToString();
        //    txtMarketCode.Text = dataGridViewMarket.CurrentRow.Cells[1].Value.ToString();
        //    txtMarketName.Text = dataGridViewMarket.CurrentRow.Cells[2].Value.ToString();
        //    txtTotalNoOfParty.Text = dataGridViewMarket.CurrentRow.Cells[3].Value.ToString();
        //    txtTarget.Text = dataGridViewMarket.CurrentRow.Cells[4].Value.ToString();
        //    txtMonthlyNoOfVisit.Text = dataGridViewMarket.CurrentRow.Cells[5].Value.ToString();
        //    cmbMarketActive.Text = dataGridViewMarket.CurrentRow.Cells[6].Value.ToString();

        //}

        private void dataGridViewMarket_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (btnSaveMarket.Enabled == false)
            {
                btnSaveMarket.Enabled = true;
            }
            btnSaveMarket.Text = "Update Market";
            
            GlobalClass.MarketIdForUpdate = dataGridViewMarket.CurrentRow.Cells[0].Value.ToString();
            //GlobalClass.DesignationIDforUpdateDesignation = dataGridViewDesignationList.CurrentRow.Cells[0].Value.ToString();
            txtMarketCode.Text = dataGridViewMarket.CurrentRow.Cells[1].Value.ToString();
            txtMarketName.Text = dataGridViewMarket.CurrentRow.Cells[2].Value.ToString();
            txtTotalNoOfParty.Text = dataGridViewMarket.CurrentRow.Cells[3].Value.ToString();
            txtTarget.Text = dataGridViewMarket.CurrentRow.Cells[4].Value.ToString();
            txtMonthlyNoOfVisit.Text = dataGridViewMarket.CurrentRow.Cells[5].Value.ToString();
            if (dataGridViewMarket.CurrentRow.Cells[13].Value.ToString() != "")
            {
                cmbSelectDivisionForMarket.Text = dataGridViewMarket.CurrentRow.Cells[13].Value.ToString();
            }
            cmbMarketActive.Text = dataGridViewMarket.CurrentRow.Cells[6].Value.ToString();

            //closed on 17 May 2016
            //txtEmpIDForMarket.Text = dataGridViewMarket.CurrentRow.Cells[7].Value.ToString();
            //cmbSelectEmpForMarket.Text = dataGridViewMarket.CurrentRow.Cells[8].Value.ToString();
            //txtEmpCellNoForMarket.Text = dataGridViewMarket.CurrentRow.Cells[9].Value.ToString();
            //txtEmpDesignationForMarket.Text = dataGridViewMarket.CurrentRow.Cells[10].Value.ToString();
            //txtGroupIDForMarket.Text = dataGridViewMarket.CurrentRow.Cells[11].Value.ToString();
            //cmbSelectGroupForMarket.Text = dataGridViewMarket.CurrentRow.Cells[12].Value.ToString();
            //end closed on 17 May 2016
            
            if (txtMarketCode.Enabled == false)
            {
                txtMarketCode.Enabled = true;
            }

            if (txtMarketName.Enabled == false)
            {
                txtMarketName.Enabled = true;
            }

            if (txtTarget.Enabled == false)
            {
                txtTarget.Enabled = true;
            }

            if (txtTotalNoOfParty.Enabled == false)
            {
                txtTotalNoOfParty.Enabled = true;
            }

            if (txtMonthlyNoOfVisit.Enabled == false)
            {
                txtMonthlyNoOfVisit.Enabled = true;
            }

            //closed on 17 May 2016
            //if (cmbSelectGroupForMarket.Enabled == false)
            //{
            //    cmbSelectGroupForMarket.Enabled = true;
            //}

            //if (cmbSelectEmpForMarket.Enabled == false)
            //{
            //    cmbSelectEmpForMarket.Enabled = true;
            //}
            //end closed on 17 May 2016

            if (cmbMarketActive.Enabled == false)
            {
                cmbMarketActive.Enabled = true;
            }

            if (btnSaveMarket.Enabled == false)
            {
                btnSaveMarket.Enabled = true;
            }

            if (btnAddMarket.Enabled == false)
            {
                btnAddMarket.Enabled = true;
            }

            if (cmbSelectDivisionForMarket.Enabled == false)
            {
                cmbSelectDivisionForMarket.Enabled = true;
            }
        }

        private void cmbEmployeeDesignation_Leave(object sender, EventArgs e)
        {
            //if (cmbEmployeeDesignation.Text == "SR")
            //{
            //    if (cmbEmpMarketName.Enabled == false)
            //    {
            //        cmbEmpMarketName.Enabled = true;
            //    }
            //}
        }

        private void cmbEmployeeDepartment_Click(object sender, EventArgs e)
        {
            //if (cmbEmployeeDesignation.Text == "SR")
            //{
            //    if (cmbEmpMarketName.Enabled == false)
            //    {
            //        cmbEmpMarketName.Enabled = true;
            //    }
            //}
        }

        private void cmbEmployeeActive_Leave(object sender, EventArgs e)
        {
            //if (cmbEmployeeActive.Text == "No")
            //{
            //    if (txtQuitDate.Enabled == false)
            //    {
            //        txtQuitDate.Enabled = true;
            //        txtQuitDate.Focus();
            //    }
            //    if (dTPQuitDate.Enabled == false)
            //    {
            //        dTPQuitDate.Enabled = true;

            //    }
            //}

            //if (cmbEmployeeActive.Text == "Yes")
            //{
            //    if (txtQuitDate.Text != "")
            //    {
            //        txtQuitDate.Text = "";
            //        txtQuitDate.Enabled = false;
            //        dTPQuitDate.Enabled = false;
            //    }

            //    if (dTPQuitDate.Enabled == true)
            //    {
            //        txtQuitDate.Text = "";
            //        txtQuitDate.Enabled = false;
            //        dTPQuitDate.Enabled = false;
            //    }

            //}
        }

        //private void dTPDateOfBirth_CloseUp(object sender, EventArgs e)
        //{
        //    txtDOB.Text = dTPDateOfBirth.Text.ToString();
        //}

        //private void dTPQuitDate_CloseUp(object sender, EventArgs e)
        //{
        //    txtQuitDate.Text = dTPQuitDate.Text.ToString();
        //}

        //private void cmbEmployeeActive_SelectionChangeCommitted(object sender, EventArgs e)
        //{
        //    if (cmbEmployeeActive.Text == "No")
        //    {
        //        txtQuitDate.Enabled = true;
        //        dTPQuitDate.Enabled = true;
        //        txtQuitDate.Focus();
        //    }
        //    else if (cmbEmployeeActive.Text == "Yes")
        //    {
        //        txtQuitDate.Enabled = false;
        //        dTPQuitDate.Enabled = false;
        //        //txtQuitDate.Focus();
        //    }
        //}

        //private void cmbEmployeeActive_SelectedValueChanged(object sender, EventArgs e)
        //{
        //    if (cmbEmployeeActive.Text == "No")
        //    {
        //        txtQuitDate.Enabled = true;
        //        dTPQuitDate.Enabled = true;
        //        txtQuitDate.Focus();
        //    }
        //    else if (cmbEmployeeActive.Text == "Yes")
        //    {
        //        txtQuitDate.Enabled = false;
        //        dTPQuitDate.Enabled = false;
        //        //txtQuitDate.Focus();
        //    }
        //}

        private void cmbEmployeeActive_SelectedValueChanged_1(object sender, EventArgs e)
        {
            if (cmbEmployeeActive.Text == "No")
            {
                txtQuitDate.Enabled = true;
                dTPQuitDate.Enabled = true;
                txtQuitDate.Focus();
            }
            else if (cmbEmployeeActive.Text == "Yes")
            {
                txtQuitDate.Text = "";
                txtQuitDate.Enabled = false;
                dTPQuitDate.Enabled = false;
                //txtQuitDate.Focus();
            }
        }

        private void dTPQuitDate_CloseUp_1(object sender, EventArgs e)
        {
            txtQuitDate.Text = dTPQuitDate.Text.ToString();
        }

        private void dTPDateOfBirth_CloseUp_1(object sender, EventArgs e)
        {
            txtDOB.Text = dTPDateOfBirth.Text.ToString();
        }

        private void cmbSelectGroupForMarket_Leave(object sender, EventArgs e)
        {
            //if (cmbSelectEmpForMarket.Items.Count <= 0)
            //{
            //    MessageBox.Show("Selected Group dosen't have any active SR! Please select another Group.");
            //    //cmbSelectGroupForMarket.Focus();
            //    if (txtEmpDesignationForMarket.Text != "" || txtEmpIDForMarket.Text != "" || txtEmpCellNoForMarket.Text != "")
            //    {
            //        txtEmpDesignationForMarket.Text = "";
            //        txtEmpIDForMarket.Text = "";
            //        txtEmpCellNoForMarket.Text = "";
            //    }
            //}
        }

        //closed on 17 May 2016
        //private void cmbSelectGroupForMarket_SelectedValueChanged(object sender, EventArgs e)
        //{
        //    string selectedGroup = cmbSelectGroupForMarket.Text;
        //    cmbSelectEmpForMarket.Refresh();
        //    cmbSelectEmpForMarket.Text = "";
        //    cmbSelectEmpForMarket.DataSource = objEmployeeDetailsManager.LoadEmployeeBySelectedGroup(selectedGroup);
        //    cmbSelectEmpForMarket.DisplayMember = "Employee_Name";
        //    cmbSelectEmpForMarket.ValueMember = "Employee_Name";
        //    txtGroupIDForMarket.Text = objGroupDetailsManager.GetGroupID(selectedGroup);
        //    cmbSelectEmpForMarket.Focus();
        //}
        //end closed on 17 May 2016

        private void cmbSelectEmpForMarket_SelectedValueChanged(object sender, EventArgs e)
        {
            //string empNameSelectForMarket = cmbSelectEmpForMarket.Text;
            //DataTable dt = new DataTable();
            //dt = objEmployeeDetailsManager.GetEmployeeDetailsForMarket(empNameSelectForMarket);
            //if (dt.Rows.Count > 0)
            //{
            //    txtEmpDesignationForMarket.Text = dt.Rows[0][5].ToString();
            //    txtEmpIDForMarket.Text = dt.Rows[0][0].ToString();
            //    txtEmpCellNoForMarket.Text = dt.Rows[0][8].ToString();
            //    cmbMarketActive.Focus();
            //}
        }

        //closed on 17 May 2016
        //private void cmbSelectEmpForMarket_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    string empNameSelectForMarket = cmbSelectEmpForMarket.Text;
        //    DataTable dt = new DataTable();
        //    dt = objEmployeeDetailsManager.GetEmployeeDetailsForMarket(empNameSelectForMarket);
        //    if (dt.Rows.Count > 0)
        //    {
        //        txtEmpDesignationForMarket.Text = dt.Rows[0][5].ToString();
        //        txtEmpIDForMarket.Text = dt.Rows[0][0].ToString();
        //        txtEmpCellNoForMarket.Text = dt.Rows[0][8].ToString();
        //        cmbMarketActive.Focus();
        //    }
        //    else
        //    {
        //        txtEmpDesignationForMarket.Text = "";
        //        txtEmpIDForMarket.Text = "";
        //        txtEmpCellNoForMarket.Text = "";
        //    }

        //}
        //end closed on 17 May 2016

        public void tabSMSapplication_Click(object sender, EventArgs e)
        //private void tabSMSapplication_Click(object sender, EventArgs e)
        {
            try
            {

                if (tabSMSapplication.SelectedTab.Text == "User")
                {
                    //ClearCreateUserTab();

                    //if (btnSaveUser.Enabled == true)
                    //{
                    //    btnSaveUser.Enabled = false;
                    //}

                    //if (txtUserName.Enabled == true)
                    //{
                    //    txtUserName.Enabled = false;
                    //}

                    //if (txtPassword.Enabled == true)
                    //{
                    //    txtPassword.Enabled = false;
                    //}

                    //if (cmbUserRole.Enabled == true)
                    //{
                    //    cmbUserRole.Enabled = false;
                    //}

                    //if (cmbActive.Enabled == true)
                    //{
                    //    cmbActive.Enabled = false;
                    //}

                    //if (btnSaveUser.Text == "Update User")
                    //{
                    //    btnSaveUser.Text = "Save User";
                    //}
                    //dataGridViewUserDetails.DataSource = objUserDetailsManager.AllUserDetails();
                    //dataGridViewUserDetails.Columns[0].Visible = false;
                    //dataGridViewUserDetails.Columns[3].Visible = false;
                    ////dataGridViewUserDetails.Columns[6].Visible = false;

                    //btnAddUser.Focus();

                    RefreshUser();
                }

                if (tabSMSapplication.SelectedTab.Text == "Department")
                {
                    //ClearDepartmentTab();

                    //if (txtDepartment.Enabled == true)
                    //{
                    //    txtDepartment.Enabled = false;
                    //}
                    //if (cmbActiveDepartment.Enabled == true)
                    //{
                    //    cmbActiveDepartment.Enabled = false;
                    //}
                    //if (btnSaveDepartment.Enabled == true)
                    //{
                    //    btnSaveDepartment.Enabled = false;
                    //}
                    //if (btnAddDepartment.Enabled == false)
                    //{
                    //    btnAddDepartment.Enabled = true;
                    //}
                    //if (btnSaveDepartment.Text == "Update Department")
                    //{
                    //    btnSaveDepartment.Text = "Save Department";
                    //}
                    //dataGridViewDepartmentDetails.DataSource = objDepartmentDetailsManager.AllDepartmentDetails();
                    //dataGridViewDepartmentDetails.Columns[0].Visible = false;

                    //btnAddDepartment.Focus();

                    RefreshDept();
                }

                if (tabSMSapplication.SelectedTab.Text == "Designation")
                {
                    //ClearDesignationTab();

                    //if (txtDesignation.Enabled == true)
                    //{
                    //    txtDesignation.Enabled = false;
                    //}
                    //if (txtDesignationDetails.Enabled == true)
                    //{
                    //    txtDesignationDetails.Enabled = false;
                    //}
                    //if (cmbActiveDesignation.Enabled == true)
                    //{
                    //    cmbActiveDesignation.Enabled = false;
                    //}
                    //if (btnSaveDesignation.Enabled == true)
                    //{
                    //    btnSaveDesignation.Enabled = false;
                    //}
                    //if (btnAddDesignation.Enabled == false)
                    //{
                    //    btnAddDesignation.Enabled = true;
                    //}
                    //if (btnSaveDesignation.Text == "Update Designation")
                    //{
                    //    btnSaveDesignation.Text = "Save Designation";
                    //}
                    //dataGridViewDesignationList.DataSource = objDesignationDetailsManager.ShowAllDesignation();
                    //dataGridViewDesignationList.Columns[0].Visible = false;

                    //btnAddDesignation.Focus();

                    RefreshDesi();
                }

                if (tabSMSapplication.SelectedTab.Text == "Team")
                {
                    //ClearGroupTab();

                    //if (txtGroupName.Enabled == true)
                    //{
                    //    txtGroupName.Enabled = false;
                    //}
                    //if (txtLocation.Enabled == true)
                    //{
                    //    txtLocation.Enabled = false;
                    //}
                    //if (cmbGroupActive.Enabled == true)
                    //{
                    //    cmbGroupActive.Enabled = false;
                    //}
                    //if (btnSaveGroup.Enabled == true)
                    //{
                    //    btnSaveGroup.Enabled = false;
                    //}
                    //if (btnAddGroup.Enabled == false)
                    //{
                    //    btnAddGroup.Enabled = true;
                    //}
                    //if (btnSaveGroup.Text == "Update Group")
                    //{
                    //    btnSaveGroup.Text = "Save Group";
                    //}

                    //dataGridViewGroupDetails.DataSource = objGroupDetailsManager.AllGroupDetails();
                    //dataGridViewGroupDetails.Columns[0].Visible = false;

                    //btnAddGroup.Focus();

                    RefreshTeam();
                }

                if (tabSMSapplication.SelectedTab.Text == "Employee")
                {
                    //ClearEmployeeTab();

                    //if (txtEmployeeName.Enabled == true)
                    //{
                    //    txtEmployeeName.Enabled = false;
                    //}

                    //if (txtAddress.Enabled == true)
                    //{
                    //    txtAddress.Enabled = false;
                    //}

                    //if (txtDOB.Enabled == true)
                    //{
                    //    txtDOB.Enabled = false;
                    //}

                    //if (dTPDateOfBirth.Enabled == true)
                    //{
                    //    dTPDateOfBirth.Enabled = false;
                    //}

                    //if (cmbEmployeeDesignation.Enabled == true)
                    //{
                    //    cmbEmployeeDesignation.Enabled = false;
                    //}

                    //if (cmbEmployeeDepartment.Enabled == true)
                    //{
                    //    cmbEmployeeDepartment.Enabled = false;
                    //}

                    //if (txtOfficialCellNo.Enabled == true)
                    //{
                    //    txtOfficialCellNo.Enabled = false;
                    //}

                    //if (cmbEmployeeGroup.Enabled == true)
                    //{
                    //    cmbEmployeeGroup.Enabled = false;
                    //}

                    //if (cmbEmployeeActive.Enabled == true)
                    //{
                    //    cmbEmployeeActive.Enabled = false;
                    //}

                    //if (txtQuitDate.Enabled == true)
                    //{
                    //    txtQuitDate.Enabled = false;
                    //}

                    //if (dTPQuitDate.Enabled == true)
                    //{
                    //    dTPQuitDate.Enabled = false;
                    //}

                    //if (btnSaveEmployee.Text == "Update Employee")
                    //{
                    //    btnSaveEmployee.Text = "Save Employee";
                    //}

                    //if (btnSaveEmployee.Enabled == true)
                    //{
                    //    btnSaveEmployee.Enabled = false;
                    //}

                    //if (btnAddEmployee.Enabled == false)
                    //{
                    //    btnAddEmployee.Enabled = true;
                    //}

                    //dataGridViewEmployeeList.DataSource = objEmployeeDetailsManager.ShowAllEmployee();
                    //dataGridViewEmployeeList.Columns[0].Visible = false;
                    //dataGridViewEmployeeList.Columns[4].Visible = false;
                    //dataGridViewEmployeeList.Columns[6].Visible = false;
                    //dataGridViewEmployeeList.Columns[9].Visible = false;
                    //dataGridViewEmployeeList.Columns[12].Visible = false;
                    //dataGridViewEmployeeList.Columns[13].Visible = false;
                    //dataGridViewEmployeeList.Columns[14].Visible = false;
                    //dataGridViewEmployeeList.Columns[3].DefaultCellStyle.Format = "MM/dd/yyyy";

                    //btnAddEmployee.Focus();

                    RefreshEmployee();
                }

                if (tabSMSapplication.SelectedTab.Text == "Division")
                {
                    //ClearDivision();

                    //CheckDesignation();

                    //if (cmbSelectTeam.Enabled == true)
                    //{
                    //    cmbSelectTeam.Enabled = false;
                    //}

                    //if (txtDivisionName.Enabled == true)
                    //{
                    //    txtDivisionName.Enabled = false;
                    //}

                    //if (cmbSelectDOForDivision.Enabled == true)
                    //{
                    //    cmbSelectDOForDivision.Enabled = false;
                    //}

                    //if (cmbSelectGMForDivision.Enabled == true)
                    //{
                    //    cmbSelectGMForDivision.Enabled = false;
                    //}

                    //if (cmbSelectDGMForDivision.Enabled == true)
                    //{
                    //    cmbSelectDGMForDivision.Enabled = false;
                    //}

                    //if (cmbSelectDMForDivision.Enabled == true)
                    //{
                    //    cmbSelectDMForDivision.Enabled = false;
                    //}

                    //if (cmbSelectSMForDivision.Enabled == true)
                    //{
                    //    cmbSelectSMForDivision.Enabled = false;
                    //}

                    //if (cmbSelectASMForDivision.Enabled == true)
                    //{
                    //    cmbSelectASMForDivision.Enabled = false;
                    //}

                    //if (cmbSelectTSMForDivision.Enabled == true)
                    //{
                    //    cmbSelectTSMForDivision.Enabled = false;
                    //}

                    //if (cmbSelectSRForDivision.Enabled == true)
                    //{
                    //    cmbSelectSRForDivision.Enabled = false;
                    //}

                    //if (cmbActiveForDivision.Enabled == true)
                    //{
                    //    cmbActiveForDivision.Enabled = false;
                    //}

                    //if (btnSaveDivision.Text == "Update Division")
                    //{
                    //    btnSaveDivision.Text = "Save Division";
                    //}

                    //if (btnSaveDivision.Enabled == true)
                    //{
                    //    btnSaveDivision.Enabled = false;
                    //}

                    //if (btnLoadSM.Enabled == true)
                    //{
                    //    btnLoadSM.Enabled = false;
                    //}

                    //if (btnLoadASM.Enabled == true)
                    //{
                    //    btnLoadASM.Enabled = false;
                    //}

                    //if (btnLoadTSM.Enabled == true)
                    //{
                    //    btnLoadTSM.Enabled = false;
                    //}

                    //if (btnLoadSR.Enabled == true)
                    //{
                    //    btnLoadSR.Enabled = false;
                    //}

                    //if (btnAddToTempDivision.Enabled == true)
                    //{
                    //    btnAddToTempDivision.Enabled = false;
                    //}

                    //if (btnLoadGroup.Enabled == true)
                    //{
                    //    btnLoadGroup.Enabled = false;
                    //}

                    //dgvDivision.Visible = false;
                    //dgvPreviousAddedEmpList.Visible = false;
                    //dgvLoadDistinctDivision.Visible = true;
                    //dgvLoadDistinctDivision.Size = new Size(960, 595);
                    //dgvLoadDistinctDivision.Location = new Point(372, 10);
                    //dgvLoadDistinctDivision.DataSource = objDivisionDetailsManager.ShowDistinctDivision();
                    ////dgvLoadDistinctDivision.Columns[1].Visible = false;

                    //cmbSelectDivisionForUpdate.DataSource = objDivisionDetailsManager.ShowDistinctDivision();
                    //cmbSelectDivisionForUpdate.DisplayMember = "Division_Name";
                    //cmbSelectDivisionForUpdate.ValueMember = "Division_Name";
                    //cmbSelectDivisionForUpdate.Text = "Select Division";

                    //if (objDivisionDetailsManager.ShowDistinctDivision().Rows.Count > 0)
                    //{
                    //    btnAddOrEditDataOfPrevDivision.Enabled = true;
                    //    cmbSelectDivisionForUpdate.Enabled = true;
                    //}
                    //else
                    //{
                    //    btnAddOrEditDataOfPrevDivision.Enabled = false;
                    //    cmbSelectDivisionForUpdate.Enabled = false;
                    //}

                    RefreshDivision();
                }

                if (tabSMSapplication.SelectedTab.Text == "Market") //if (tabSMSapplication.SelectedTab.ToolTipText.ToString() == "Market") 
                {
                    //ClearMarketTab();

                    //if (txtMarketCode.Enabled == true)
                    //{
                    //    txtMarketCode.Enabled = false;
                    //}

                    //if (txtMarketName.Enabled == true)
                    //{
                    //    txtMarketName.Enabled = false;
                    //}

                    //if (txtTotalNoOfParty.Enabled == true)
                    //{
                    //    txtTotalNoOfParty.Enabled = false;
                    //}

                    //if (txtTarget.Enabled == true)
                    //{
                    //    txtTarget.Enabled = false;
                    //}

                    //if (txtMonthlyNoOfVisit.Enabled == true)
                    //{
                    //    txtMonthlyNoOfVisit.Enabled = false;
                    //}

                    //if (cmbSelectDivisionForMarket.Enabled == true)
                    //{
                    //    cmbSelectDivisionForMarket.Enabled = false;
                    //}
                    ////closed on 17 May 2016
                    ////if (cmbSelectGroupForMarket.Enabled == true)
                    ////{
                    ////    cmbSelectGroupForMarket.Enabled = false;
                    ////}

                    ////if (cmbSelectEmpForMarket.Enabled == true)
                    ////{
                    ////    cmbSelectEmpForMarket.Enabled = false;
                    ////}
                    ////end closed on 17 May 2016

                    //if (cmbMarketActive.Enabled == true)
                    //{
                    //    cmbMarketActive.Enabled = false;
                    //}

                    //if (btnSaveMarket.Text == "Update Market") ;
                    //{
                    //    btnSaveMarket.Text = "Save Market";
                    //}

                    //if (btnSaveMarket.Enabled == true)
                    //{
                    //    btnSaveMarket.Enabled = false;
                    //}

                    //if (btnAddMarket.Enabled == false)
                    //{
                    //    btnAddMarket.Enabled = true;
                    //}

                    //// closed 31 May 2016
                    ////dataGridViewMarket.DataSource = objMarketDetailsManager.AllMarketDetails();
                    ////dataGridViewMarket.Columns[0].Visible = false;
                    ////dataGridViewMarket.Columns[7].Visible = false;
                    ////dataGridViewMarket.Columns[11].Visible = false;
                    ////dataGridViewMarket.Columns[13].Visible = false;
                    //// end closed 31 May 2016

                    //cmbSelectDivisionForMarket.DataSource = objDivisionDetailsManager.LoadSelectDivision();
                    //cmbSelectDivisionForMarket.DisplayMember = "Division_Name";
                    //cmbSelectDivisionForMarket.ValueMember = "Division_Name";
                    //cmbSelectDivisionForMarket.Text = "Select Division";
                    //txtTeamNameForMarket.Text = "";
                    //txtTeamIDForMarket.Text = "";

                    //dataGridViewMarket.DataSource = objMarketDetailsManager.AllMarketDetails();
                    //dataGridViewMarket.Columns[0].Visible = false;
                    //dataGridViewMarket.Columns[7].Visible = false;
                    //dataGridViewMarket.Columns[8].Visible = false;
                    //dataGridViewMarket.Columns[9].Visible = false;
                    //dataGridViewMarket.Columns[10].Visible = false;
                    //dataGridViewMarket.Columns[11].Visible = false;
                    ////dataGridViewMarket.Columns[13].Visible = false;
                    //btnAddMarket.Focus();

                    RefreshMarket();
                }

                if (tabSMSapplication.SelectedTab.Text == "Market Setup")
                {
                    //if (cmbSelectMarketForMarketSetup.Enabled == true)
                    //{
                    //    cmbSelectMarketForMarketSetup.Enabled = false;
                    //}

                    //if (cmbSelectGroupForMarketSetup.Enabled == true)
                    //{
                    //    cmbSelectGroupForMarketSetup.Enabled = false;
                    //}

                    //if (cmbSelectDevisionForMarketSetup.Enabled == true)
                    //{
                    //    cmbSelectDevisionForMarketSetup.Enabled = false;
                    //}

                    //if (cmbSelectEmployeeForMarketSetup.Enabled == true)
                    //{
                    //    cmbSelectEmployeeForMarketSetup.Enabled = false;
                    //}

                    //if (btnSaveMarketSetup.Text == "Update Market Setup")
                    //{
                    //    btnSaveMarketSetup.Text = "Save Market Setup";
                    //}

                    //btnSaveMarketSetup.Enabled = false;

                    //cmbSelectMarketForMarketSetup.Text = "Select Market";
                    //cmbSelectGroupForMarketSetup.Text = "Select Team";
                    //txtGroupIDForMarketSetup.Text = "";
                    //cmbSelectDevisionForMarketSetup.Text = "Select Division";
                    //cmbSelectEmployeeForMarketSetup.Text = "Select Employee";
                    //txtEmpIDForMarketSetup.Text = "";
                    //txtEmpDesigForMarketSetup.Text = "";
                    //txtEmpCellNoForMarketSetup.Text = "";
                    //if (dgvLoadMarketBySelectedDivision.Visible == true)
                    //{
                    //    dgvLoadMarketBySelectedDivision.Visible = false;
                    //}
                    //dgvLoadMarketBySelectedDivision.Hide();

                    //dataGridViewMarketSetup.DataSource = objMarketDetailsManager.AllMarketDetails();
                    //dataGridViewMarketSetup.Columns[0].Visible = false;
                    //dataGridViewMarketSetup.Columns[3].Visible = false;
                    //dataGridViewMarketSetup.Columns[4].Visible = false;
                    //dataGridViewMarketSetup.Columns[5].Visible = false;
                    //dataGridViewMarketSetup.Columns[7].Visible = false;
                    ////dataGridViewMarketSetup.Columns[8].Visible = false;
                    ////dataGridViewMarketSetup.Columns[9].Visible = false;
                    ////dataGridViewMarketSetup.Columns[10].Visible = false;
                    //dataGridViewMarketSetup.Columns[11].Visible = false;
                    ////dataGridViewMarketSetup.Columns[12].Visible = false;
                    ////dataGridViewMarketSetup.Columns[13].Visible = false;
                    ////dataGridViewMarketSetup.Columns[14].Visible = false;
                    ////end new on 18 May 2016
                    //dataGridViewMarketSetup.Show();

                    RefreshMarketSetUp();
                }

                if (tabSMSapplication.SelectedTab.Text == "Product")
                {
                    //ClearProductTab();

                    //if (txtProductCode.Enabled == true)
                    //{
                    //    txtProductCode.Enabled = false;
                    //}

                    //if (txtProductName.Enabled == true)
                    //{
                    //    txtProductName.Enabled = false;
                    //}

                    //if (cmbPackSize.Enabled == true)
                    //{
                    //    cmbPackSize.Enabled = false;
                    //}

                    //if (txtUnitCostPrice.Enabled == true)
                    //{
                    //    txtUnitCostPrice.Enabled = false;
                    //}

                    //if (txtUnitSalePrice.Enabled == true)
                    //{
                    //    txtUnitSalePrice.Enabled = false;
                    //}

                    //if (cmbProductActive.Enabled == true)
                    //{
                    //    cmbProductActive.Enabled = false;
                    //}

                    //if (btnSaveProduct.Text == "Update Product") ;
                    //{
                    //    btnSaveProduct.Text = "Save Product";
                    //}

                    //if (btnSaveProduct.Enabled == true)
                    //{
                    //    btnSaveProduct.Enabled = false;
                    //}

                    //if (btnAddProduct.Enabled == false)
                    //{
                    //    btnAddProduct.Enabled = true;
                    //}

                    //dataGridViewProduct.DataSource = objProductDetailsManager.ShowAllProduct();

                    //btnAddProduct.Focus();

                    RefreshProduct();
                }

                if (tabSMSapplication.SelectedTab.Text == "Product Price Log")
                {
                    //dgvProductPriceUpdateLog.Refresh();
                    //dgvProductPriceUpdateLog.DataSource = objProductDetailsManager.ShowUpdateLogForAllProduct();
                    //dgvProductPriceUpdateLog.Columns[0].Visible = false;

                    RefreshProductPriceLog();
                }

                if (tabSMSapplication.SelectedTab.Text == "Sales Target")
                {
                    //ClearSalesTargetTab();

                    //if (btnSaveTarget.Enabled == true)
                    //{
                    //    btnSaveTarget.Enabled = false;
                    //}

                    //if (btnSaveTarget.Text == "Update Target")
                    //{
                    //    btnSaveTarget.Text = "Save Target";
                    //}

                    //if (btnAddToList.Enabled == true)
                    //{
                    //    btnAddToList.Enabled = false;
                    //}

                    //if (btnAddToList.Text == "Update List")
                    //{
                    //    btnAddToList.Text = "Add To List";
                    //}

                    //if (txtFromDate.Enabled == true)
                    //{
                    //    txtFromDate.Enabled = false;
                    //}

                    //if (dTPFromDate.Enabled == true)
                    //{
                    //    dTPFromDate.Enabled = false;
                    //}

                    //if (txtToDate.Enabled == true)
                    //{
                    //    txtToDate.Enabled = false;
                    //}

                    //if (dTPToDate.Enabled == true)
                    //{
                    //    dTPToDate.Enabled = false;
                    //}

                    //if (btnBrowseProductCodeForSalesTarget.Enabled == true)
                    //{
                    //    btnBrowseProductCodeForSalesTarget.Enabled = false;
                    //}

                    //if (txtProductCodeForSalesTarget.ReadOnly == true)
                    //{
                    //    txtProductCodeForSalesTarget.ReadOnly = false;
                    //}

                    //if (txtProductIDForSalesTarget.ReadOnly == true)
                    //{
                    //    txtProductIDForSalesTarget.ReadOnly = false;
                    //}

                    //if (txtProductNameForSalesTarget.ReadOnly == true)
                    //{
                    //    txtProductNameForSalesTarget.ReadOnly = false;
                    //}

                    //if (txtProductPriceForSalesTarget.ReadOnly == true)
                    //{
                    //    txtProductPriceForSalesTarget.ReadOnly = false;
                    //}

                    //if (cmbSelectGroupForSalesTarget.Enabled == true)
                    //{
                    //    cmbSelectGroupForSalesTarget.Enabled = false;
                    //}
                    ////cmbSelectGroupForSalesTarget.DataSource = objGroupDetailsGateway.LoadSelectGroupForGroupSetup();
                    ////cmbSelectGroupForSalesTarget.DisplayMember = "Group_Name";
                    ////cmbSelectGroupForSalesTarget.ValueMember = "Group_Name";
                    //cmbSelectGroupForSalesTarget.Text = "";


                    //if (cmbSelectDesignationForSalesTarget.Enabled == true)
                    //{
                    //    cmbSelectDesignationForSalesTarget.Enabled = false;
                    //}
                    ////cmbSelectDesignationForSalesTarget.DataSource = objDesignationDetailsManager.LoadDesignationCombo();
                    ////cmbSelectDesignationForSalesTarget.DisplayMember = "Designation";
                    ////cmbSelectDesignationForSalesTarget.ValueMember = "Designation";
                    //cmbSelectDesignationForSalesTarget.Text = "";


                    //if (cmbSelectEmployeeForSalesTarget.Enabled == true)
                    //{
                    //    cmbSelectEmployeeForSalesTarget.Enabled = false;
                    //    //if (cmbSelectGroupForSalesTarget.Text != "" && cmbSelectDesignationForSalesTarget.Text != "")
                    //    //{
                    //    //    cmbSelectEmployeeForSalesTarget.DataSource =
                    //    //        objEmployeeDetailsManager.LoadEmployeeBySelectedGroupAndDesignation(cmbSelectGroupForSalesTarget.Text.ToString(), cmbSelectDesignationForSalesTarget.Text.ToString());
                    //    //    cmbSelectEmployeeForSalesTarget.DisplayMember = "Employee_Name";
                    //    //    cmbSelectEmployeeForSalesTarget.ValueMember = "Employee_Name";
                    //    //}
                    //    //cmbSelectEmployeeForSalesTarget.DataSource = objEmployeeDetailsManager.LoadEmployeeBySelectedGroupAndDesignation();
                    //}

                    //if (txtEmployeeIDForSalesTarget.ReadOnly == true)
                    //{
                    //    txtEmployeeIDForSalesTarget.ReadOnly = false;
                    //}

                    //if (txtEmpMobileNoForSalesTarget.ReadOnly == true)
                    //{
                    //    txtEmpMobileNoForSalesTarget.ReadOnly = false;
                    //}

                    //if (txtTargetUnitForSalesTarget.Enabled == true)
                    //{
                    //    txtTargetUnitForSalesTarget.Enabled = false;
                    //}

                    //if (txtTargetAmountForSalesTarget.ReadOnly == true)
                    //{
                    //    txtTargetAmountForSalesTarget.ReadOnly = false;
                    //}

                    ////if (dgvSalesDetails.Visible == true)
                    ////{
                    ////    dgvSalesDetails.Visible = false;
                    ////}

                    //if (dataGridViewSalesTarget.Visible == false)
                    //{
                    //    dataGridViewSalesTarget.Visible = true;
                    //}

                    ////dgvSalesDetails.Visible = false;
                    //dgvProductListForSalesTarget.Visible = false;
                    //dgvSalesTargetDetails.Visible = false;
                    //dgvPrevAddedSalesTargetDetails.Visible = false;

                    //dataGridViewSalesTarget.DataSource = objSalesTargerDetailsManager.ShowAllSalesTarget();
                    //dataGridViewSalesTarget.Columns[0].Visible = false;
                    //dataGridViewSalesTarget.Columns[3].Visible = false;
                    //dataGridViewSalesTarget.Columns[9].Visible = false;

                    //GlobalClass.SalesTargetDataGridViewValue = 0;
                    //btnAddTarget.Enabled = true;
                    //btnAddTarget.Focus();

                    RefreshSalesTarget();
                }

                if (tabSMSapplication.SelectedTab.Text == "Special Item Sale")
                {
                    //ClearSpecialItemSaleTargetTab();

                    //if (btnSpecialItemSaleAddTarget.Enabled == false)
                    //{
                    //    btnSpecialItemSaleAddTarget.Enabled = true;
                    //}

                    //if (btnSpecialItemSaleSaveTarget.Enabled == true)
                    //{
                    //    btnSpecialItemSaleSaveTarget.Enabled = false;
                    //}

                    //if (btnSpecialItemSaleProductCodeBrowse.Enabled == true)
                    //{
                    //    btnSpecialItemSaleProductCodeBrowse.Enabled = false;
                    //}

                    //if (txtSpecialItemSaleFromDate.Enabled == true)
                    //{
                    //    txtSpecialItemSaleFromDate.Enabled = false;
                    //}

                    //if (txtSpecialItemSaleToDate.Enabled == true)
                    //{
                    //    txtSpecialItemSaleToDate.Enabled = false;
                    //}

                    //if (txtSpecialItemSaleProductCode.Enabled == true)
                    //{
                    //    txtSpecialItemSaleProductCode.Enabled = false;
                    //}

                    //if (txtSpecialItemSaleProductID.Enabled == true)
                    //{
                    //    txtSpecialItemSaleProductID.Enabled = false;
                    //}

                    //if (txtSpecialItemSaleProductName.Enabled == true)
                    //{
                    //    txtSpecialItemSaleProductName.Enabled = false;
                    //}

                    //if (txtSpecialItemSaleProductCostPrice.Enabled == true)
                    //{
                    //    txtSpecialItemSaleProductCostPrice.Enabled = false;
                    //}

                    //if (txtSpecialItemSaleProductSalePrice.Enabled == true)
                    //{
                    //    txtSpecialItemSaleProductSalePrice.Enabled = false;
                    //}

                    //if (txtSpecialItemSaleProductSpecialPrice.Enabled == true)
                    //{
                    //    txtSpecialItemSaleProductSpecialPrice.Enabled = false;
                    //}

                    //if (cmbSpecialItemSaleSelectGroup.Enabled == true)
                    //{
                    //    cmbSpecialItemSaleSelectGroup.Enabled = false;
                    //}

                    //if (cmbSpecialItemSaleSelectDesignation.Enabled == true)
                    //{
                    //    cmbSpecialItemSaleSelectDesignation.Enabled = false;
                    //}

                    //if (cmbSpecialItemSaleSelectEmployee.Enabled == true)
                    //{
                    //    cmbSpecialItemSaleSelectEmployee.Enabled = false;
                    //}

                    //if (txtSpecialItemSaleEmployeeID.Enabled == true)
                    //{
                    //    txtSpecialItemSaleEmployeeID.Enabled = false;
                    //}

                    //if (txtSpecialItemSaleEmployeeMobileNo.Enabled == true)
                    //{
                    //    txtSpecialItemSaleEmployeeMobileNo.Enabled = false;
                    //}

                    //if (txtSpecialItemSaleTargetUnit.Enabled == true)
                    //{
                    //    txtSpecialItemSaleTargetUnit.Enabled = false;
                    //}

                    //if (txtSpecialItemSaleTargetAmount.Enabled == true)
                    //{
                    //    txtSpecialItemSaleTargetAmount.Enabled = false;
                    //}

                    //dgvSpecialItemSalesTarget.DataSource = objSalesTargerDetailsManager.ShowAllSpecialItemSalesTarget();
                    //dgvSpecialItemSalesTarget.Columns[0].Visible = false;
                    //dgvSpecialItemSalesTarget.Columns[3].Visible = false;
                    //dgvSpecialItemSalesTarget.Columns[11].Visible = false;

                    //btnSpecialItemSaleAddTarget.Focus();

                    RefreshSpecialItemSales();
                }

                if (tabSMSapplication.SelectedTab.Text == "Sales Details")
                {
                    //dgvSalesDetails.Columns.Clear();
                    //dgvSalesDetails.Refresh();
                    //dgvSalesDetails.DataSource = objSalesDetailsManager.ShowAllSales();
                    //dgvSalesDetails.Columns[0].Visible = false;
                    //dgvSalesDetails.Columns[1].DefaultCellStyle.Format = "MM/dd/yyyy";
                    //dgvSalesDetails.Columns[2].Visible = false;
                    //dgvSalesDetails.Columns[9].Visible = false;
                    
                    RefreshSalesDetails();
                }

                if (tabSMSapplication.SelectedTab.Text == "Reports")
                {
                    radioBtnSalesTargetReport.Checked = false;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void CheckDesignation()
        {
            string desigFromDesigTbl = "";
            string desigFromEmpTbl = "";
            int lblCmbX = 4;
            int lblCmbY = 105;
            int cmbX = 110;
            int cmbY = 105;
            DataTable dtDesignation = objDesignationDetailsManager.LoadDesignationCombo();
            DataTable dtEmpDesig = objEmployeeDetailsManager.GetDistinctActiveDesignation();

            for (int i = 0; i < dtDesignation.Rows.Count; i++)
            {
                desigFromDesigTbl = dtDesignation.Rows[i][1].ToString();
                for (int j = 0; j < dtEmpDesig.Rows.Count; j++)
                {
                    desigFromEmpTbl = dtEmpDesig.Rows[j][0].ToString();
                    if (desigFromDesigTbl == desigFromEmpTbl)
                    {
                        if (desigFromEmpTbl == "DO")
                        {
                            lblSelectDO.Visible = true;
                            cmbSelectDOForDivision.Visible = true;
                            lblCmbY = lblCmbY + 28;
                            cmbY = cmbY + 28;
                            lblSelectDO.Location = new Point(lblCmbX, lblCmbY);
                            cmbSelectDOForDivision.Location = new Point(cmbX, cmbY);
                        }
                        else if (desigFromEmpTbl == "GM")
                        {
                            lblSelectGM.Visible = true;
                            cmbSelectGMForDivision.Visible = true;
                            lblCmbY = lblCmbY + 28;
                            cmbY = cmbY + 28;
                            lblSelectGM.Location = new Point(lblCmbX, lblCmbY);
                            cmbSelectGMForDivision.Location = new Point(cmbX, cmbY);
                        }
                        else if (desigFromEmpTbl == "DGM")
                        {
                            lblSelectDGM.Visible = true;
                            cmbSelectDGMForDivision.Visible = true;
                            lblCmbY = lblCmbY + 28;
                            cmbY = cmbY + 28;
                            lblSelectDGM.Location = new Point(lblCmbX, lblCmbY);
                            cmbSelectDGMForDivision.Location = new Point(cmbX, cmbY);
                        }
                        else if (desigFromEmpTbl == "DM")
                        {
                            lblSelectDM.Visible = true;
                            cmbSelectDMForDivision.Visible = true;
                            lblCmbY = lblCmbY + 28;
                            cmbY = cmbY + 28;
                            lblSelectDM.Location = new Point(lblCmbX, lblCmbY);
                            cmbSelectDMForDivision.Location = new Point(cmbX, cmbY);
                        }
                        else if (desigFromEmpTbl == "SM")
                        {
                            lblSelectSM.Visible = true;
                            cmbSelectSMForDivision.Visible = true;
                            lblCmbY = lblCmbY + 28;
                            cmbY = cmbY + 28;
                            lblSelectSM.Location = new Point(lblCmbX, lblCmbY);
                            cmbSelectSMForDivision.Location = new Point(cmbX, cmbY);
                        }
                        else if (desigFromEmpTbl == "ASM")
                        {
                            lblSelectASM.Visible = true;
                            cmbSelectASMForDivision.Visible = true;
                            lblCmbY = lblCmbY + 28;
                            cmbY = cmbY + 28;
                            lblSelectASM.Location = new Point(lblCmbX, lblCmbY);
                            cmbSelectASMForDivision.Location = new Point(cmbX, cmbY);
                        }
                        else if (desigFromEmpTbl == "TSM")
                        {
                            lblSelectTSM.Visible = true;
                            cmbSelectTSMForDivision.Visible = true;
                            lblCmbY = lblCmbY + 28;
                            cmbY = cmbY + 28;
                            lblSelectTSM.Location = new Point(lblCmbX, lblCmbY);
                            cmbSelectTSMForDivision.Location = new Point(cmbX, cmbY);
                        }
                        else if (desigFromEmpTbl == "SR")
                        {
                            lblSelectSR.Visible = true;
                            cmbSelectSRForDivision.Visible = true;
                            lblCmbY = lblCmbY + 28;
                            cmbY = cmbY + 28;
                            lblSelectSR.Location = new Point(lblCmbX, lblCmbY);
                            cmbSelectSRForDivision.Location = new Point(cmbX, cmbY);
                        }
                        else if (desigFromEmpTbl == "RSM")
                        {
                            lblSelectRSM.Visible = true;
                            cmbSelectRSMForDivision.Visible = true;
                            lblCmbY = lblCmbY + 28;
                            cmbY = cmbY + 28;
                            lblSelectRSM.Location = new Point(lblCmbX, lblCmbY);
                            cmbSelectRSMForDivision.Location = new Point(cmbX, cmbY);
                        }
                    }
                }
            }
            groupBoxDivision.Size = new Size(360, cmbY + 34);
            btnAddDivision.Location = new Point(4, cmbY + 44);
            btnAddToTempDivision.Location = new Point(135, cmbY + 44);
            btnSaveDivision.Location = new Point(236, cmbY + 44);
            btnAddOrEditDataOfPrevDivision.Location = new Point(176, cmbY + 44 + 29);
            cmbSelectDivisionForUpdate.Location = new Point(6, cmbY + 44 + 29);
            cmbSelectDivisionForUpdate.Text = "Select Division";
            btnDivisionReport.Location = new Point(6, cmbY + 44 + 58);
            btnEnableDisableDivision.Location = new Point(6, cmbY + 44 + 87);
            btnRefreshDivision.Location = new Point(6, cmbY + 44 + 116);
        }

        public void ClearSpecialItemSaleTargetTab()
        {
            if (btnSpecialItemSaleSaveTarget.Enabled == false)
            {
                btnSpecialItemSaleSaveTarget.Enabled = true;
            }

            if (btnSpecialItemSaleSaveTarget.Text == "Update Special Target")
            {
                btnSpecialItemSaleSaveTarget.Text = "Save Special Target";
            }
            
            txtSpecialItemSaleFromDate.Text = "";
            txtSpecialItemSaleToDate.Text = "";
            txtSpecialItemSaleProductCode.Text = "";
            txtSpecialItemSaleProductID.Text = "";
            txtSpecialItemSaleProductName.Text = "";
            txtSpecialItemSaleProductCostPrice.Text = "";
            txtSpecialItemSaleProductSalePrice.Text = "";
            txtSpecialItemSaleProductSpecialPrice.Text = "";
            cmbSpecialItemSaleSelectGroup.Text = "Select Team";
            cmbSpecialItemSaleSelectDesignation.Text = "Select Designation";
            cmbSpecialItemSaleSelectEmployee.Text = "Select Employee";
            txtSpecialItemSaleEmployeeID.Text = "";
            txtSpecialItemSaleEmployeeMobileNo.Text = "";
            txtSpecialItemSaleTargetUnit.Text = "";
            txtSpecialItemSaleTargetAmount.Text = "";
        }

        public void ClearSalesTargetTab()
        {
            if (btnSaveTarget.Enabled == false)
            {
                btnSaveTarget.Enabled = true;
            }

            if (btnSaveTarget.Text == "Update Target")
            {
                btnSaveTarget.Text = "Save Target";
            }
            txtFromDate.Text = "";
            txtToDate.Text = "";
            txtProductCodeForSalesTarget.Text = "";
            txtProductIDForSalesTarget.Text = "";
            txtProductNameForSalesTarget.Text = "";
            txtProductPriceForSalesTarget.Text = "";
            cmbSelectGroupForSalesTarget.Text = "Select Team";
            cmbSelectDesignationForSalesTarget.Text = "Select Designation";
            cmbSelectEmployeeForSalesTarget.Text = "Select Employee";
            txtEmployeeIDForSalesTarget.Text = "";
            txtEmpMobileNoForSalesTarget.Text = "";
            txtTargetUnitForSalesTarget.Text = "";
            txtTargetAmountForSalesTarget.Text = "";

        }

        //closed on 17 May 2016
        //private void cmbSelectEmpForMarket_Enter(object sender, EventArgs e)
        //{
        //    if (cmbSelectEmpForMarket.Items.Count <= 0)
        //    {
        //        MessageBox.Show("Selected Group dosen't have any active SR! Please select another Group.");
        //        //cmbSelectGroupForMarket.Focus();
        //        if (txtEmpDesignationForMarket.Text != "" || txtEmpIDForMarket.Text != "" || txtEmpCellNoForMarket.Text != "")
        //        {
        //            txtEmpDesignationForMarket.Text = "";
        //            txtEmpIDForMarket.Text = "";
        //            txtEmpCellNoForMarket.Text = "";
        //        }
        //    }
        //}
        //end closed on 17 May 2016

        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            ClearProductTab();

            if (txtProductCode.Enabled == false)
            {
                txtProductCode.Enabled = true;
            }

            if (txtProductName.Enabled == false)
            {
                txtProductName.Enabled = true;
            }

            if (cmbPackSize.Enabled == false)
            {
                cmbPackSize.Enabled = true;
            }

            if (txtUnitCostPrice.Enabled == false)
            {
                txtUnitCostPrice.Enabled = true;
            }

            if (txtUnitSalePrice.Enabled == false)
            {
                txtUnitSalePrice.Enabled = true;
            }

            if (cmbProductActive.Enabled == false)
            {
                cmbProductActive.Enabled = true;
            }

            if (btnSaveProduct.Text == "Update Product")
            {
                btnSaveProduct.Text = "Save Product";
            }

            if (btnSaveProduct.Enabled == false)
            {
                btnSaveProduct.Enabled = true;
            }

            if (btnAddProduct.Enabled == false)
            {
                btnAddProduct.Enabled = true;
            }
            txtProductCode.Focus();
        }

        public void ClearProductTab()
        {
            if (btnSaveProduct.Enabled == false)
            {
                btnSaveProduct.Enabled = true;
            }
            txtProductCode.Text = "";
            txtProductName.Text = "";
            cmbPackSize.Text = "Select Pack Size";
            txtUnitCostPrice.Text = "";
            txtUnitSalePrice.Text = "";
            cmbProductActive.Text = "Select Active";
            txtProductCode.Focus();
        }

        private void btnSaveProduct_Click(object sender, EventArgs e)
        {
            int productID;
            string productCode;
            string productName;
            string packSize;
            decimal unitCostPrice;
            decimal unitSalePrice;
            string productActive;

            //for ProductPriceUpdateLog
            string today;
            today = now.ToShortDateString().ToString();//Convert.ToString(now.ToShortTimeString().Substring(0,2));
            int productIDForProductPriceLog;
            int productPriceUpdateLogID;
            //today = today.Replace()
            //txtEndTime.Text = txtEndTime.Text.Replace(':', ' ');
            //End of for ProductPriceUpdateLog
            productCode = txtProductCode.Text;
            productName = txtProductName.Text;
            packSize = cmbPackSize.Text;
            unitCostPrice = Convert.ToDecimal(txtUnitCostPrice.Text);
            unitSalePrice = Convert.ToDecimal(txtUnitSalePrice.Text);
            productActive = cmbProductActive.Text;

            if (btnSaveProduct.Text == "Save Product")
            {
               objProductDetailsManager.InsertProduct(productCode,productName,packSize,unitCostPrice,unitSalePrice,productActive);
               productIDForProductPriceLog = objProductDetailsManager.GetProductID(productCode);
               objProductDetailsManager.InsertProductPriceUpdateLog(productIDForProductPriceLog, productCode, productName, packSize, unitCostPrice, unitSalePrice, today, productActive);
               dataGridViewProduct.DataSource = objProductDetailsManager.ShowAllProduct();
               //dataGridViewProduct.Columns[0].Visible = false;
               btnSaveProduct.Text = "Save Product";
               btnAddProduct.Enabled = true;
               MessageBox.Show("Product Added Succesfully");
            }
            else if (btnSaveProduct.Text == "Update Product")
            {
                if (GlobalClass.CurrCostPrice != unitCostPrice ||
                    GlobalClass.CurrSalePrice != unitSalePrice)
                {
                    productID = Convert.ToInt32(GlobalClass.ProductIdForUpdateProduct.ToString());
                    productPriceUpdateLogID = objProductDetailsManager.GetProductPriceUpdateLogID(productID);
                    objProductDetailsManager.UpdateProductPriceUpdateLog(productPriceUpdateLogID,today); //, productCode, productName, packSize, unitCostPrice, unitSalePrice, today);
                    objProductDetailsManager.InsertProductPriceUpdateLog(productID, productCode, productName, packSize, unitCostPrice, unitSalePrice, today, productActive);
                    objProductDetailsManager.UpdateProduct(productID, productCode, productName, packSize, unitCostPrice, unitSalePrice, productActive);
                }
                else
                {
                    productID = Convert.ToInt32(GlobalClass.ProductIdForUpdateProduct.ToString());
                    productPriceUpdateLogID = objProductDetailsManager.GetProductPriceUpdateLogID(productID);
                    objProductDetailsManager.UpdateProduct(productID, productCode, productName, packSize, unitCostPrice, unitSalePrice, productActive);
                    objProductDetailsManager.UpdateProductPriceUpdateLogData(productPriceUpdateLogID, productID, productCode, productName, packSize, unitCostPrice, unitSalePrice, productActive);
                }
                dataGridViewProduct.DataSource = objProductDetailsManager.ShowAllProduct();
                //dataGridViewProduct.Columns[0].Visible = false;
                MessageBox.Show("Product Update Successfully.");
            }

            dgvProductPriceUpdateLog.Refresh();
            dgvProductPriceUpdateLog.DataSource = objProductDetailsManager.ShowUpdateLogForAllProduct();
            dgvProductPriceUpdateLog.Columns[0].Visible = false;

            ClearProductTab();

            if (txtProductCode.Enabled == true)
            {
                txtProductCode.Enabled = false;
            }

            if (txtProductName.Enabled == true)
            {
                txtProductName.Enabled = false;
            }

            if (cmbPackSize.Enabled == true)
            {
                cmbPackSize.Enabled = false;
            }

            if (txtUnitCostPrice.Enabled == true)
            {
                txtUnitCostPrice.Enabled = false;
            }

            if (txtUnitSalePrice.Enabled == true)
            {
                txtUnitSalePrice.Enabled = false;
            }

            if (cmbProductActive.Enabled == true)
            {
                cmbProductActive.Enabled = false;
            }

            if (btnSaveProduct.Text == "Update Product")
            {
                btnSaveProduct.Text = "Save Product";
            }

            if (btnSaveProduct.Enabled == true)
            {
                btnSaveProduct.Enabled = false;
            }

            if (btnAddProduct.Enabled == false)
            {
                btnAddProduct.Enabled = true;
            }
        }

        private void dataGridViewProduct_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (btnSaveProduct.Enabled == false)
            {
                btnSaveProduct.Enabled = true;
            }
            
            btnSaveProduct.Text = "Update Product";

            GlobalClass.ProductIdForUpdateProduct = dataGridViewProduct.CurrentRow.Cells[0].Value.ToString();
            //GlobalClass.DesignationIDforUpdateDesignation = dataGridViewDesignationList.CurrentRow.Cells[0].Value.ToString();
            txtProductCode.Text = dataGridViewProduct.CurrentRow.Cells[1].Value.ToString();
            txtProductName.Text = dataGridViewProduct.CurrentRow.Cells[2].Value.ToString();
            cmbPackSize.Text = dataGridViewProduct.CurrentRow.Cells[3].Value.ToString();
            txtUnitCostPrice.Text = dataGridViewProduct.CurrentRow.Cells[4].Value.ToString();
            txtUnitSalePrice.Text = dataGridViewProduct.CurrentRow.Cells[5].Value.ToString();
            cmbProductActive.Text = dataGridViewProduct.CurrentRow.Cells[6].Value.ToString();

            GlobalClass.ProductCode = dataGridViewProduct.CurrentRow.Cells[1].Value.ToString();
            GlobalClass.CurrCostPrice = Convert.ToDecimal(dataGridViewProduct.CurrentRow.Cells[4].Value.ToString());
            GlobalClass.CurrSalePrice = Convert.ToDecimal(dataGridViewProduct.CurrentRow.Cells[5].Value.ToString());

            if (txtProductCode.Enabled == false)
            {
                txtProductCode.Enabled = true;
            }

            if (txtProductName.Enabled == false)
            {
                txtProductName.Enabled = true;
            }

            if (cmbPackSize.Enabled == false)
            {
                cmbPackSize.Enabled = true;
            }

            if (txtUnitCostPrice.Enabled == false)
            {
                txtUnitCostPrice.Enabled = true;
            }

            if (txtUnitSalePrice.Enabled == false)
            {
                txtUnitSalePrice.Enabled = true;
            }

            if (cmbProductActive.Enabled == false)
            {
                cmbProductActive.Enabled = true;
            }

            if (btnSaveProduct.Enabled == false)
            {
                btnSaveProduct.Enabled = true;
            }

            if (btnAddProduct.Enabled == false)
            {
                btnAddProduct.Enabled = true;
            }
        }

        private void txtProductCode_Leave(object sender, EventArgs e)
        {
            try
            {
                txtProductCode.Text = txtProductCode.Text.ToUpper();
            }
            catch (Exception errorMsg)
            {
                MessageBox.Show(errorMsg.Message);
            }
        }

        private void txtDesignation_Leave(object sender, EventArgs e)
        {
            try
            {
                txtDesignation.Text = txtDesignation.Text.ToUpper();
            }
            catch (Exception errorMsg)
            {
                MessageBox.Show(errorMsg.Message);
            }
        }

        private void txtMarketCode_Leave(object sender, EventArgs e)
        {
            try
            {
                txtMarketCode.Text = txtMarketCode.Text.ToUpper();
            }
            catch (Exception errorMsg)
            {
                MessageBox.Show(errorMsg.Message);
            }
        }

        private void btnSearchEmployee_Click(object sender, EventArgs e)
        {
            if (radioBtnEmployeeName.Checked == true)
            {
                radioBtnByGroup.Checked = false;
                radioBtnOfficialMobileNumber.Checked = false;
                radioBtnByGroupAndDesignation.Checked = false;
                if (cmbSearchCriteriaForEmployeeByDesignation.Enabled == true)
                {
                    cmbSearchCriteriaForEmployeeByDesignation.Enabled = false;    
                }

                dataGridViewEmployeeList.DataSource = objEmployeeDetailsManager.SearchEmployeeByName(txtSearchCriteriaForEmployee.Text.ToString());
                if (dataGridViewEmployeeList.RowCount > 0)
                {
                    dataGridViewEmployeeList.Columns[0].Visible = false;
                    dataGridViewEmployeeList.Columns[4].Visible = false;
                    dataGridViewEmployeeList.Columns[6].Visible = false;
                    dataGridViewEmployeeList.Columns[9].Visible = false;
                    dataGridViewEmployeeList.Columns[12].Visible = false;
                    dataGridViewEmployeeList.Columns[13].Visible = false;
                    dataGridViewEmployeeList.Columns[14].Visible = false;
                    
                    txtSearchCriteriaForEmployee.Text = "";
                }
                else
                {
                    MessageBox.Show("No Data Found");
                }
            }

            if (radioBtnOfficialMobileNumber.Checked == true)
            {
                radioBtnEmployeeName.Checked = false;
                radioBtnByGroup.Checked = false;
                radioBtnByGroupAndDesignation.Checked = false;
                if (cmbSearchCriteriaForEmployeeByDesignation.Enabled == true)
                {
                    cmbSearchCriteriaForEmployeeByDesignation.Enabled = false;
                }

                dataGridViewEmployeeList.DataSource = objEmployeeDetailsManager.SearchEmployeeByMobile(txtSearchCriteriaForEmployee.Text.ToString());
                if (dataGridViewEmployeeList.RowCount > 0)
                {
                    dataGridViewEmployeeList.Columns[0].Visible = false;
                    dataGridViewEmployeeList.Columns[4].Visible = false;
                    dataGridViewEmployeeList.Columns[6].Visible = false;
                    dataGridViewEmployeeList.Columns[9].Visible = false;
                    dataGridViewEmployeeList.Columns[12].Visible = false;
                    dataGridViewEmployeeList.Columns[13].Visible = false;
                    dataGridViewEmployeeList.Columns[14].Visible = false;
                    txtSearchCriteriaForEmployee.Text = "";
                }
                else
                {
                    MessageBox.Show("No Data Found");
                }
            }

            if (radioBtnByGroup.Checked == true)
            {
                radioBtnEmployeeName.Checked = false;
                radioBtnOfficialMobileNumber.Checked = false;
                radioBtnByGroupAndDesignation.Checked = false;
                if (cmbSearchCriteriaForEmployeeByDesignation.Enabled == true)
                {
                    cmbSearchCriteriaForEmployeeByDesignation.Enabled = false;
                }

                dataGridViewEmployeeList.DataSource = objEmployeeDetailsManager.SearchEmployeeByGroup(txtSearchCriteriaForEmployee.Text.ToString());
                if (dataGridViewEmployeeList.RowCount > 0)
                {
                    dataGridViewEmployeeList.Columns[0].Visible = false;
                    dataGridViewEmployeeList.Columns[4].Visible = false;
                    dataGridViewEmployeeList.Columns[6].Visible = false;
                    dataGridViewEmployeeList.Columns[9].Visible = false;
                    dataGridViewEmployeeList.Columns[12].Visible = false;
                    dataGridViewEmployeeList.Columns[13].Visible = false;
                    dataGridViewEmployeeList.Columns[14].Visible = false;
                    txtSearchCriteriaForEmployee.Text = "";
                }
                else
                {
                    MessageBox.Show("No Data Found");
                }
            }

            if (radioBtnByGroupAndDesignation.Checked == true)
            {
                radioBtnEmployeeName.Checked = false;
                radioBtnOfficialMobileNumber.Checked = false;
                radioBtnByGroup.Checked = false;
                if (cmbSearchCriteriaForEmployeeByDesignation.Enabled == false)
                {
                    cmbSearchCriteriaForEmployeeByDesignation.Enabled = true;
                    cmbSearchCriteriaForEmployeeByDesignation.DataSource = objDesignationDetailsManager.LoadDesignationCombo();
                    cmbSearchCriteriaForEmployeeByDesignation.DisplayMember = "Designation";
                    cmbSearchCriteriaForEmployeeByDesignation.ValueMember = "Designation";
                }

                dataGridViewEmployeeList.DataSource = objEmployeeDetailsManager.SearchEmployeeByGroupNameAndDesignation(txtSearchCriteriaForEmployee.Text.ToString(), cmbSearchCriteriaForEmployeeByDesignation.Text.ToString());
                if (dataGridViewEmployeeList.RowCount > 0)
                {
                    dataGridViewEmployeeList.Columns[0].Visible = false;
                    dataGridViewEmployeeList.Columns[4].Visible = false;
                    dataGridViewEmployeeList.Columns[6].Visible = false;
                    dataGridViewEmployeeList.Columns[9].Visible = false;
                    dataGridViewEmployeeList.Columns[12].Visible = false;
                    dataGridViewEmployeeList.Columns[13].Visible = false;
                    dataGridViewEmployeeList.Columns[14].Visible = false;
                    txtSearchCriteriaForEmployee.Text = "";
                }
                else
                {
                    MessageBox.Show("No Data Found");
                }
            }
        }

        private void radioBtnEmployeeName_CheckedChanged(object sender, EventArgs e)
        {
            if (radioBtnEmployeeName.Checked == true)
            {
                radioBtnByGroup.Checked = false;
                radioBtnOfficialMobileNumber.Checked = false;
                radioBtnByGroupAndDesignation.Checked = false;
                if (cmbSearchCriteriaForEmployeeByDesignation.Enabled == true)
                {
                    cmbSearchCriteriaForEmployeeByDesignation.Enabled = false;
                }

                cmbSearchCriteriaForEmployeeByDesignation.Text = "";
                txtSearchCriteriaForEmployee.Focus();
            }
        }

        private void radioBtnOfficialMobileNumber_CheckedChanged(object sender, EventArgs e)
        {
            if (radioBtnOfficialMobileNumber.Checked == true)
            {
                radioBtnEmployeeName.Checked = false;
                radioBtnByGroup.Checked = false;
                radioBtnByGroupAndDesignation.Checked = false;
                if (cmbSearchCriteriaForEmployeeByDesignation.Enabled == true)
                {
                    cmbSearchCriteriaForEmployeeByDesignation.Enabled = false;
                }

                cmbSearchCriteriaForEmployeeByDesignation.Text = "";
                txtSearchCriteriaForEmployee.Focus();
            }
        }

        private void radioBtnByGroup_CheckedChanged(object sender, EventArgs e)
        {
            if (radioBtnByGroup.Checked == true)
            {
                radioBtnEmployeeName.Checked = false;
                radioBtnOfficialMobileNumber.Checked = false;
                radioBtnByGroupAndDesignation.Checked = false;
                if (cmbSearchCriteriaForEmployeeByDesignation.Enabled == true)
                {
                    cmbSearchCriteriaForEmployeeByDesignation.Enabled = false;
                }

                cmbSearchCriteriaForEmployeeByDesignation.Text = "";
                txtSearchCriteriaForEmployee.Focus();
            }
        }

        private void radioBtnByGroupAndDesignation_CheckedChanged(object sender, EventArgs e)
        {
            if (radioBtnByGroupAndDesignation.Checked == true)
            {
                radioBtnEmployeeName.Checked = false;
                radioBtnOfficialMobileNumber.Checked = false;
                radioBtnByGroup.Checked = false;
                if (cmbSearchCriteriaForEmployeeByDesignation.Enabled == false)
                {
                    cmbSearchCriteriaForEmployeeByDesignation.Enabled = true;
                    cmbSearchCriteriaForEmployeeByDesignation.DataSource = objDesignationDetailsManager.LoadDesignationCombo();
                    cmbSearchCriteriaForEmployeeByDesignation.DisplayMember = "Designation";
                    cmbSearchCriteriaForEmployeeByDesignation.ValueMember = "Designation";
                }

                txtSearchCriteriaForEmployee.Focus();
            }
        }

        private void radioBtnShowAllEmp_CheckedChanged(object sender, EventArgs e)
        {
            if (radioBtnShowAllEmp.Checked == true)
            {
                radioBtnEmployeeName.Checked = false;
                radioBtnOfficialMobileNumber.Checked = false;
                radioBtnByGroup.Checked = false;
                radioBtnByGroupAndDesignation.Checked = false;
                if (cmbSearchCriteriaForEmployeeByDesignation.Enabled == true)
                {
                    cmbSearchCriteriaForEmployeeByDesignation.Enabled = false;
                }

                cmbSearchCriteriaForEmployeeByDesignation.Text = "";

                dataGridViewEmployeeList.Refresh();
                dataGridViewEmployeeList.DataSource = objEmployeeDetailsManager.ShowAllEmployee();
                dataGridViewEmployeeList.Columns[0].Visible = false;
                dataGridViewEmployeeList.Columns[4].Visible = false;
                dataGridViewEmployeeList.Columns[6].Visible = false;
                dataGridViewEmployeeList.Columns[9].Visible = false;
                dataGridViewEmployeeList.Columns[12].Visible = false;
                dataGridViewEmployeeList.Columns[13].Visible = false;
                dataGridViewEmployeeList.Columns[14].Visible = false;
            }
        }

        private void btnBrowseProductCodeForSalesTarget_Click(object sender, EventArgs e)
        {
            GlobalClass.TabNameForProductListUi = tabSMSapplication.SelectedTab.Text.ToString();
            //MessageBox.Show(GlobalClass.TabNameForProductListUi.ToString());
            ProductListUI objProductListUi = new ProductListUI();
            objProductListUi.PassValue += new PassValueHandler(objProductListUi_PassValue);
            objProductListUi.Show();
        }

        public void objProductListUi_PassValue(string productCode, string productID, string productName, decimal productSalesPrice)
        {
            txtProductCodeForSalesTarget.Text = productCode;
            txtProductIDForSalesTarget.Text = productID;
            txtProductNameForSalesTarget.Text = productName;
            txtProductPriceForSalesTarget.Text = productSalesPrice.ToString();
        }

        public void objProductListUi_PassValue1(string productCode, string productID, string productName, decimal productCostPrice, decimal productSalesPrice)
        {
            txtSpecialItemSaleProductCode.Text = productCode;
            txtSpecialItemSaleProductID.Text = productID;
            txtSpecialItemSaleProductName.Text = productName;
            txtSpecialItemSaleProductCostPrice.Text = productCostPrice.ToString();
            txtSpecialItemSaleProductSalePrice.Text = productSalesPrice.ToString();
        }

        private void btnAddTarget_Click(object sender, EventArgs e)
        {
            try
            {
                ClearSalesTargetTab();
                
                if (btnSaveTarget.Enabled ==true)
                {
                    btnSaveTarget.Enabled = false;
                }

                if (btnSaveTarget.Text == "Update Target")
                {
                    btnSaveTarget.Text = "Save Target";
                }

                if(txtFromDate.Enabled == false)
                {
                    txtFromDate.Enabled = true;
                }

                if (dTPFromDate.Enabled == false)
                {
                    dTPFromDate.Enabled = true;
                }

                if (txtToDate.Enabled == false)
                {
                    txtToDate.Enabled = true;
                }

                if (dTPToDate.Enabled == false)
                {
                    dTPToDate.Enabled = true;
                }

                if (btnBrowseProductCodeForSalesTarget.Enabled == false)
                {
                    btnBrowseProductCodeForSalesTarget.Enabled = true;
                }

                if (txtProductCodeForSalesTarget.ReadOnly == false)
                {
                    txtProductCodeForSalesTarget.ReadOnly = true;
                }

                if (txtProductIDForSalesTarget.ReadOnly == false)
                {
                    txtProductIDForSalesTarget.ReadOnly = true;
                }

                if (txtProductNameForSalesTarget.ReadOnly == false)
                {
                    txtProductNameForSalesTarget.ReadOnly = true;
                }

                if (txtProductPriceForSalesTarget.ReadOnly == false)
                {
                    txtProductPriceForSalesTarget.ReadOnly = true;
                }

                if (cmbSelectGroupForSalesTarget.Enabled == false)
                {
                    cmbSelectGroupForSalesTarget.Enabled = true;
                }
                    cmbSelectGroupForSalesTarget.DataSource = objGroupDetailsGateway.LoadSelectGroupForGroupSetup();
                    cmbSelectGroupForSalesTarget.DisplayMember = "Group_Name";
                    cmbSelectGroupForSalesTarget.ValueMember = "Group_Name";
                    cmbSelectGroupForSalesTarget.Text = "";


                if (cmbSelectDesignationForSalesTarget.Enabled == false)
                {
                    cmbSelectDesignationForSalesTarget.Enabled = true;
                }
                    cmbSelectDesignationForSalesTarget.DataSource = objDesignationDetailsManager.LoadDesignationCombo();
                    cmbSelectDesignationForSalesTarget.DisplayMember = "Designation";
                    cmbSelectDesignationForSalesTarget.ValueMember = "Designation";
                    cmbSelectDesignationForSalesTarget.Text = "";
                

                if (cmbSelectEmployeeForSalesTarget.Enabled == false)
                {
                    cmbSelectEmployeeForSalesTarget.Enabled = true;
                    //if (cmbSelectGroupForSalesTarget.Text != "" && cmbSelectDesignationForSalesTarget.Text != "")
                    //{
                    //    cmbSelectEmployeeForSalesTarget.DataSource =
                    //        objEmployeeDetailsManager.LoadEmployeeBySelectedGroupAndDesignation(cmbSelectGroupForSalesTarget.Text.ToString(), cmbSelectDesignationForSalesTarget.Text.ToString());
                    //    cmbSelectEmployeeForSalesTarget.DisplayMember = "Employee_Name";
                    //    cmbSelectEmployeeForSalesTarget.ValueMember = "Employee_Name";
                    //}
                    //cmbSelectEmployeeForSalesTarget.DataSource = objEmployeeDetailsManager.LoadEmployeeBySelectedGroupAndDesignation();
                }

                if (txtEmployeeIDForSalesTarget.ReadOnly == false)
                {
                    txtEmployeeIDForSalesTarget.ReadOnly = true;
                }

                if (txtEmpMobileNoForSalesTarget.ReadOnly == false)
                {
                    txtEmpMobileNoForSalesTarget.ReadOnly = true;
                }

                if (txtTargetUnitForSalesTarget.Enabled == false)
                {
                    txtTargetUnitForSalesTarget.Enabled = true;
                }

                if (txtTargetAmountForSalesTarget.ReadOnly == false)
                {
                    txtTargetAmountForSalesTarget.ReadOnly = true;
                }

                //if (dataGridViewSalesTarget.Visible == true)
                //{
                //    dataGridViewSalesTarget.Visible = false;
                //    dgvSalesTargetDetails.Visible = true;
                //    dgvSalesTargetDetails.Location = new Point(380, 11);
                //    dgvSalesTargetDetails.Size = new Size(950, 585);
                //}

                GlobalClass.ProductCodeForSalesTarget = "";
                GlobalClass.ProductIdForSalesTarget = "";
                GlobalClass.ProductNameForSalesTarget = "";
                GlobalClass.ProductSalesPriceForSalesTarget = 0;

                GlobalClass.FromDateForSalesTarget = "";
                GlobalClass.ToDateForSalesTarget = "";
                GlobalClass.GroupNameForSalesTarget = "";
                GlobalClass.EmpDesignationForSalesTarget = "";
                GlobalClass.EmpNameForSalesTarget = "";
                GlobalClass.EmpIdForSalesTarget = "";
                GlobalClass.EmpMobileNoForSalesTarget = "";
                GlobalClass.SalesTargetDataGridViewValue = 1;

                objSalesTargerDetailsManager.DeleteTempSalesTarget();

                dataGridViewSalesTarget.DataSource = null;
                dataGridViewSalesTarget.Visible = false;
                
                dgvProductListForSalesTarget.DataSource = null;
                dgvProductListForSalesTarget.Visible = false;
                

                dgvPrevAddedSalesTargetDetails.DataSource = null;
                dgvPrevAddedSalesTargetDetails.Visible = false;

                dgvSalesTargetDetails.Refresh();
                dgvSalesTargetDetails.DataSource = objSalesTargerDetailsManager.ShowTempSalesTarget();
                dgvSalesTargetDetails.Columns[0].Visible = false;
                dgvSalesTargetDetails.Columns[3].Visible = false;
                dgvSalesTargetDetails.Columns[9].Visible = false;
                dgvSalesTargetDetails.Visible = true;
                //dgvSalesTargetDetails.Location = new Point(380, 11);
                dgvSalesTargetDetails.Location = new Point(372, 10);
                dgvSalesTargetDetails.Size = new Size(960, 290);
                //dgvSalesTargetDetails.Size = new Size(950, 290);
                
                btnAddToList.Enabled = true;

                txtFromDate.Focus();
                
                //GlobalClass.ProductCodeForSalesTarget = "";
                //GlobalClass.ProductIdForSalesTarget = "";
                //GlobalClass.ProductNameForSalesTarget = "";
                //GlobalClass.ProductSalesPriceForSalesTarget = 0;
                
                //GlobalClass.FromDateForSalesTarget = "";
                //GlobalClass.ToDateForSalesTarget = "";
                //GlobalClass.GroupNameForSalesTarget = "";
                //GlobalClass.EmpDesignationForSalesTarget = "";
                //GlobalClass.EmpNameForSalesTarget = "";
                //GlobalClass.EmpIdForSalesTarget = "";
                //GlobalClass.EmpMobileNoForSalesTarget = "";
                //GlobalClass.SalesTargetDataGridViewValue = 1;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cmbSelectDesignationForSalesTarget_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                cmbSelectEmployeeForSalesTarget.Text = "";
                if (cmbSelectGroupForSalesTarget.Text != "" && cmbSelectDesignationForSalesTarget.Text != "")
                {
                    cmbSelectEmployeeForSalesTarget.DataSource =
                        objEmployeeDetailsManager.LoadEmployeeBySelectedGroupAndDesignation(cmbSelectGroupForSalesTarget.Text.ToString(), cmbSelectDesignationForSalesTarget.Text.ToString());
                    cmbSelectEmployeeForSalesTarget.DisplayMember = "Employee_Name";
                    cmbSelectEmployeeForSalesTarget.ValueMember = "Employee_Name";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSaveTarget_Click(object sender, EventArgs e)
        {
            int salesTargetID;
            string fromDate;
            string toDate;
            int productID;
            string productCode;
            string productName;
            decimal productPrice;
            int salesTargetUnit;
            decimal salesTargetAmount;
            int employeeID;
            string employeeName;
            string empDesignation;
            string empOfficialCell;
            string empGroupName;
            string divisionName;

            if (btnSaveTarget.Text == "Save Target")
            {
                //objSalesTargerDetailsManager.InsertSalesTarget(fromDate, toDate, productID, productCode, productName,
                //    productPrice, salesTargetUnit, salesTargetAmount, employeeID, employeeName, empDesignation,
                //    empOfficialCell, empGroupName);

                //dataGridViewSalesTarget.DataSource = objSalesTargerDetailsManager.ShowAllSalesTarget();
                //dataGridViewSalesTarget.Columns[0].Visible = false;
                //dataGridViewSalesTarget.Columns[3].Visible = false;
                //dataGridViewSalesTarget.Columns[9].Visible = false;

                //btnSaveTarget.Text = "Save Target";
                //btnAddTarget.Enabled = true;
                //MessageBox.Show("Target Added Succesfully");

                if (objSalesTargerDetailsManager.ShowTempSalesTarget().Rows.Count > 0)
                {
                    try
                    {
                        objSalesTargerDetailsManager.InsertSalesTarget_New();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
                objSalesTargerDetailsManager.DeleteTempSalesTarget();
                dgvSalesTargetDetails.Hide();
                dataGridViewSalesTarget.DataSource = objSalesTargerDetailsManager.ShowAllSalesTarget();
                dataGridViewSalesTarget.Columns[0].Visible = false;
                dataGridViewSalesTarget.Columns[3].Visible = false;
                dataGridViewSalesTarget.Columns[9].Visible = false;
                dataGridViewSalesTarget.Visible = true;
                btnAddToList.Enabled = false;
                btnSaveTarget.Enabled = false;
                MessageBox.Show("Target Added Successfully");
            }
            else if (btnSaveTarget.Text == "Update Target")
            {
                fromDate = txtFromDate.Text.ToString();
                toDate = txtToDate.Text.ToString();
                productID = Convert.ToInt32(txtProductIDForSalesTarget.Text.ToString());
                productCode = txtProductCodeForSalesTarget.Text.ToString();
                productName = txtProductNameForSalesTarget.Text.ToString();
                productPrice = Convert.ToDecimal(txtProductPriceForSalesTarget.Text.ToString());
                salesTargetUnit = Convert.ToInt32(txtTargetUnitForSalesTarget.Text.ToString());
                salesTargetAmount = Convert.ToDecimal(txtTargetAmountForSalesTarget.Text.ToString());
                employeeID = Convert.ToInt32(txtEmployeeIDForSalesTarget.Text.ToString());
                employeeName = cmbSelectEmployeeForSalesTarget.Text.ToString();
                empDesignation = cmbSelectDesignationForSalesTarget.Text.ToString();
                empOfficialCell = txtEmpMobileNoForSalesTarget.Text.ToString();
                empGroupName = cmbSelectGroupForSalesTarget.Text.ToString();
                divisionName = Convert.ToString(objDivisionDetailsManager.GetDivisionNameBySelectedTeamAndEmplyoyee(empGroupName, employeeName));
                
                salesTargetID = Convert.ToInt32(GlobalClass.SalesTargetIdForUpdateSalesTarget);

                if (
                    objSalesTargerDetailsManager.CheckDuplicateInMainTBL(fromDate, toDate, employeeName, productCode, salesTargetUnit)
                        .Rows.Count > 0)
                {
                    MessageBox.Show("Product already added, please select another product...");
                    txtProductCodeForSalesTarget.Text = "";
                    txtProductIDForSalesTarget.Text = "";
                    txtProductNameForSalesTarget.Text = "";
                    txtProductPriceForSalesTarget.Text = "";
                    txtTargetUnitForSalesTarget.Text = "";
                    txtTargetAmountForSalesTarget.Text = "";
                    btnBrowseProductCodeForSalesTarget.Enabled = true;
                    btnBrowseProductCodeForSalesTarget_Click(null, null);
                }
                else
                {
                    objSalesTargerDetailsManager.UpdateSalesTarget(salesTargetID, fromDate, toDate, productID, productCode, productName,
                    productPrice, salesTargetUnit, salesTargetAmount, employeeID, employeeName, empDesignation,
                    empOfficialCell, empGroupName,divisionName);

                    dataGridViewSalesTarget.DataSource = objSalesTargerDetailsManager.ShowAllSalesTarget();
                    dataGridViewSalesTarget.Columns[0].Visible = false;
                    dataGridViewSalesTarget.Columns[3].Visible = false;
                    dataGridViewSalesTarget.Columns[9].Visible = false;
                    dataGridViewSalesTarget.Visible = true;
                    MessageBox.Show("Target Update Successfully.");
                    ClearSalesTargetTab();
                    btnAddToList.Enabled = false;
                    btnSaveTarget.Enabled = false;
                    GlobalClass.SalesTargetDataGridViewValue = 0;
                }
            }
            ClearSalesTargetTab();
        }

        private void dTPFromDate_CloseUp(object sender, EventArgs e)
        {
            txtFromDate.Text = dTPFromDate.Text.ToString();
        }

        private void dTPToDate_CloseUp(object sender, EventArgs e)
        {
            txtToDate.Text = dTPToDate.Text.ToString();
        }

        private void cmbSelectEmployeeForSalesTarget_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.txtEmployeeIDForSalesTarget.Text =
                 objEmployeeDetailsManager.GetEmployeeID(cmbSelectEmployeeForSalesTarget.Text);
            this.txtEmpMobileNoForSalesTarget.Text = objEmployeeDetailsManager.GetEmployeeMobileNo(cmbSelectEmployeeForSalesTarget.Text);

            ////28/06/2016
            //GlobalClass.DivisionNameOfEmployeeForSalesTarget =
            //    objDivisionDetailsManager.GetDivisionNameBySelectedTeamAndEmplyoyee(cmbSelectGroupForSalesTarget.Text, cmbSelectEmployeeForSalesTarget.Text).ToString();

            txtEmpDivNameForSalesTarget.Text = objDivisionDetailsManager.GetDivisionNameBySelectedTeamAndEmplyoyee(cmbSelectGroupForSalesTarget.Text, cmbSelectEmployeeForSalesTarget.Text);
            GlobalClass.DivisionNameOfEmployeeForSalesTarget = txtEmpDivNameForSalesTarget.Text.ToString();
            //end of 28/06/2016
            //objSalesTargerDetailsManager.DeleteTempSalesTarget();

            //if (objSalesTargerDetailsManager.SearchTargetByName(txtFromDate.Text, txtToDate.Text,
            //    cmbSelectEmployeeForSalesTarget.Text).Rows.Count > 0)
            //{
            //    objSalesTargerDetailsManager.InsertPreviousSalesTargetIntoTemp(txtFromDate.Text, txtToDate.Text,
            //    cmbSelectEmployeeForSalesTarget.Text);

            //    dataGridViewSalesTarget.Visible = false;
            //    dgvProductListForSalesTarget.Visible = false;
            //    dgvSalesTargetDetails.Visible = true;
            //    dgvSalesTargetDetails.Location = new Point(380, 11);
            //    //dgvSalesTargetDetails.Size = new Size(950, 585);
            //    dgvSalesTargetDetails.Size = new Size(950, 290);
            //    dgvSalesTargetDetails.DataSource = objSalesTargerDetailsManager.ShowTempSalesTarget();
            //    dgvSalesTargetDetails.Columns[0].Visible = false;
            //    dgvSalesTargetDetails.Columns[3].Visible = false;
            //    dgvSalesTargetDetails.Columns[9].Visible = false;
            //    //btnSaveTarget.Enabled = true;
            //}
        }

        private void txtTargetUnitForSalesTarget_TextChanged(object sender, EventArgs e)
        {
            int targetUnit;
            float productPrice;
            float totalAmount;
            if (txtProductPriceForSalesTarget.Text != "")
            {
                //targetUnit = Convert.ToInt32(txtTargetUnitForSalesTarget.Text.ToString());
                if (txtTargetUnitForSalesTarget.Text == "")
                {
                    
                }
                else
                {
                    targetUnit = Int32.Parse(txtTargetUnitForSalesTarget.Text);
                    //productPrice = Convert.ToDecimal(txtProductPriceForSalesTarget.Text.ToString());
                    productPrice = float.Parse(txtProductPriceForSalesTarget.Text);
                    totalAmount = productPrice * targetUnit;
                    txtTargetAmountForSalesTarget.Text = totalAmount.ToString();
                }
            }
            //else if (txtProductPriceForSalesTarget.Text != "" && txtTargetUnitForSalesTarget.Text == "")
            //{
            //    txtTargetUnitForSalesTarget.Focus();
            //}
        }

        private void cmbSelectEmployeeForSalesTarget_SelectedValueChanged(object sender, EventArgs e)
        {
            this.txtEmployeeIDForSalesTarget.Text =
                 objEmployeeDetailsManager.GetEmployeeID(cmbSelectEmployeeForSalesTarget.Text);
            this.txtEmpMobileNoForSalesTarget.Text = objEmployeeDetailsManager.GetEmployeeMobileNo(cmbSelectEmployeeForSalesTarget.Text);

            //28/06/2016
            //GlobalClass.DivisionNameOfEmployeeForSalesTarget =
            //    objDivisionDetailsManager.GetDivisionNameBySelectedTeamAndEmplyoyee(cmbSelectGroupForSalesTarget.Text, cmbSelectEmployeeForSalesTarget.Text).ToString();
            txtEmpDivNameForSalesTarget.Text = objDivisionDetailsManager.GetDivisionNameBySelectedTeamAndEmplyoyee(cmbSelectGroupForSalesTarget.Text, cmbSelectEmployeeForSalesTarget.Text);
            GlobalClass.DivisionNameOfEmployeeForSalesTarget = txtEmpDivNameForSalesTarget.Text.ToString();
            // End of 28/06/2016

            //objSalesTargerDetailsManager.DeleteTempSalesTarget();

            //if (objSalesTargerDetailsManager.SearchTargetByName(txtFromDate.Text, txtToDate.Text,
            //    cmbSelectEmployeeForSalesTarget.Text).Rows.Count > 0)
            //{
            //    objSalesTargerDetailsManager.InsertPreviousSalesTargetIntoTemp(txtFromDate.Text, txtToDate.Text,
            //    cmbSelectEmployeeForSalesTarget.Text);

            //    dataGridViewSalesTarget.Visible = false;
            //    dgvProductListForSalesTarget.Visible = false;
            //    dgvSalesTargetDetails.Visible = true;
            //    dgvSalesTargetDetails.Location = new Point(380, 11);
            //    //dgvSalesTargetDetails.Size = new Size(950, 585);
            //    dgvSalesTargetDetails.Size = new Size(950, 290);
            //    dgvSalesTargetDetails.DataSource = objSalesTargerDetailsManager.ShowTempSalesTarget();
            //    dgvSalesTargetDetails.Columns[0].Visible = false;
            //    dgvSalesTargetDetails.Columns[3].Visible = false;
            //    dgvSalesTargetDetails.Columns[9].Visible = false;
            //}
        }

        private void dtpSearchDateFrom_CloseUp(object sender, EventArgs e)
        {
            txtSearchDateFrom.Text = dtpSearchDateFrom.Text.ToString();
        }

        private void dtpSearchDateTo_CloseUp(object sender, EventArgs e)
        {
            txtSearchDateTo.Text = dtpSearchDateTo.Text.ToString();
        }

        private void radioButtonByNameForSalesTarget_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonByNameForSalesTarget.Checked == true)
            {
                radioButtonByMobileForSalesTarget.Checked = false;
                radioButtonByGroupForSalesTarget.Checked = false;
                radioButtonByDesignationForSalesTarget.Checked = false;
                radioButtonByGroupAndDesigForSalesTarget.Checked = false;
                radioButtonShowAllForSalesTarget.Checked = false;
                radioButtonByProductCodeForSalesTarget.Checked = false;

                cmbSearchCriteriaByDesigForSalesTarget.Text = "";
                txtSearchCriteriaForSalesTarget.Text = "";

                if (cmbSearchCriteriaByDesigForSalesTarget.Enabled == true)
                {
                    cmbSearchCriteriaByDesigForSalesTarget.Enabled = false;
                }

                if (txtSearchCriteriaForSalesTarget.Enabled == false)
                {
                    txtSearchCriteriaForSalesTarget.Enabled = true;
                }

                txtSearchCriteriaForSalesTarget.Focus();
            }
        }

        private void radioButtonByMobileForSalesTarget_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonByMobileForSalesTarget.Checked == true)
            {
                radioButtonByNameForSalesTarget.Checked = false;
                radioButtonByGroupForSalesTarget.Checked = false;
                radioButtonByDesignationForSalesTarget.Checked = false;
                radioButtonByGroupAndDesigForSalesTarget.Checked = false;
                radioButtonShowAllForSalesTarget.Checked = false;
                radioButtonByProductCodeForSalesTarget.Checked = false;

                cmbSearchCriteriaByDesigForSalesTarget.Text = "";
                txtSearchCriteriaForSalesTarget.Text = "";

                if (cmbSearchCriteriaByDesigForSalesTarget.Enabled == true)
                {
                    cmbSearchCriteriaByDesigForSalesTarget.Enabled = false;
                }

                if (txtSearchCriteriaForSalesTarget.Enabled == false)
                {
                    txtSearchCriteriaForSalesTarget.Enabled = true;
                }

                txtSearchCriteriaForSalesTarget.Focus();
            }
        }

        private void radioButtonByGroupForSalesTarget_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonByGroupForSalesTarget.Checked == true)
            {
                radioButtonByNameForSalesTarget.Checked = false;
                radioButtonByMobileForSalesTarget.Checked = false;
                radioButtonByDesignationForSalesTarget.Checked = false;
                radioButtonByGroupAndDesigForSalesTarget.Checked = false;
                radioButtonShowAllForSalesTarget.Checked = false;
                radioButtonByProductCodeForSalesTarget.Checked = false;

                cmbSearchCriteriaByDesigForSalesTarget.Text = "";
                txtSearchCriteriaForSalesTarget.Text = "";

                if (cmbSearchCriteriaByDesigForSalesTarget.Enabled == true)
                {
                    cmbSearchCriteriaByDesigForSalesTarget.Enabled = false;
                }

                if (txtSearchCriteriaForSalesTarget.Enabled == false)
                {
                    txtSearchCriteriaForSalesTarget.Enabled = true;
                }

                txtSearchCriteriaForSalesTarget.Focus();
            }
        }

        private void radioButtonByDesignationForSalesTarget_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonByDesignationForSalesTarget.Checked == true)
            {
                radioButtonByNameForSalesTarget.Checked = false;
                radioButtonByMobileForSalesTarget.Checked = false;
                radioButtonByGroupForSalesTarget.Checked = false;
                radioButtonByGroupAndDesigForSalesTarget.Checked = false;
                radioButtonShowAllForSalesTarget.Checked = false;
                radioButtonByProductCodeForSalesTarget.Checked = false;

                cmbSearchCriteriaByDesigForSalesTarget.Text = "";
                txtSearchCriteriaForSalesTarget.Text = "";

                if (cmbSearchCriteriaByDesigForSalesTarget.Enabled == false)
                {
                    cmbSearchCriteriaByDesigForSalesTarget.Enabled = true;
                    cmbSearchCriteriaByDesigForSalesTarget.DataSource = objDesignationDetailsManager.LoadDesignationCombo();
                    cmbSearchCriteriaByDesigForSalesTarget.DisplayMember = "Designation";
                    cmbSearchCriteriaByDesigForSalesTarget.ValueMember = "Designation";
                }

                if (txtSearchCriteriaForSalesTarget.Enabled == true)
                {
                    txtSearchCriteriaForSalesTarget.Enabled = false;
                }

                cmbSearchCriteriaByDesigForSalesTarget.Focus();
            }
        }

        private void radioButtonByGroupAndDesigForSalesTarget_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonByGroupAndDesigForSalesTarget.Checked == true)
            {
                radioButtonByNameForSalesTarget.Checked = false;
                radioButtonByMobileForSalesTarget.Checked = false;
                radioButtonByGroupForSalesTarget.Checked = false;
                radioButtonByDesignationForSalesTarget.Checked = false;
                radioButtonShowAllForSalesTarget.Checked = false;
                radioButtonByProductCodeForSalesTarget.Checked = false;

                cmbSearchCriteriaByDesigForSalesTarget.Text = "";
                txtSearchCriteriaForSalesTarget.Text = "";

                if (cmbSearchCriteriaByDesigForSalesTarget.Enabled == false)
                {
                    cmbSearchCriteriaByDesigForSalesTarget.Enabled = true;
                    cmbSearchCriteriaByDesigForSalesTarget.DataSource = objDesignationDetailsManager.LoadDesignationCombo();
                    cmbSearchCriteriaByDesigForSalesTarget.DisplayMember = "Designation";
                    cmbSearchCriteriaByDesigForSalesTarget.ValueMember = "Designation";
                }

                if (txtSearchCriteriaForSalesTarget.Enabled == false)
                {
                    txtSearchCriteriaForSalesTarget.Enabled = true;
                }

                txtSearchCriteriaForSalesTarget.Focus();
            }
        }

        private void radioButtonShowAllForSalesTarget_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonShowAllForSalesTarget.Checked == true)
            {
                radioButtonByNameForSalesTarget.Checked = false;
                radioButtonByMobileForSalesTarget.Checked = false;
                radioButtonByGroupForSalesTarget.Checked = false;
                radioButtonByGroupAndDesigForSalesTarget.Checked = false;
                radioButtonByDesignationForSalesTarget.Checked = false;
                radioButtonByProductCodeForSalesTarget.Checked = false;

                cmbSearchCriteriaByDesigForSalesTarget.Text = "";
                txtSearchCriteriaForSalesTarget.Text = "";

                if (cmbSearchCriteriaByDesigForSalesTarget.Enabled == true)
                {
                    cmbSearchCriteriaByDesigForSalesTarget.Enabled = false;
                }

                if (txtSearchCriteriaForSalesTarget.Enabled == true)
                {
                    txtSearchCriteriaForSalesTarget.Enabled = false;
                }

                btnSearchForSalesTarget.Focus();
                //txtSearchCriteriaForSalesTarget.Focus();
            }
        }

        private void btnSearchForSalesTarget_Click(object sender, EventArgs e)
        {
            if (radioButtonShowAllForSalesTarget.Checked == true)
            {
                
            }
            else
            {
                if (txtSearchDateFrom.Text == "")
                {
                    MessageBox.Show("From Date can't be blank!");
                    txtSearchDateFrom.Focus();
                }

                else if (txtSearchDateTo.Text == "")
                {
                    MessageBox.Show("To Date can't be blank!");
                    txtSearchDateTo.Focus();
                }
            }
            
            if (radioButtonByNameForSalesTarget.Checked == true)
            {
                dataGridViewSalesTarget.DataSource = objSalesTargerDetailsManager.SearchTargetByName(txtSearchDateFrom.Text,txtSearchDateTo.Text,txtSearchCriteriaForSalesTarget.Text);
                if (dataGridViewSalesTarget.RowCount > 0)
                {
                    dataGridViewSalesTarget.Columns[0].Visible = false;
                    dataGridViewSalesTarget.Columns[3].Visible = false;
                    dataGridViewSalesTarget.Columns[9].Visible = false;
                }
                else
                {
                    MessageBox.Show("No data found. Loading all data...");
                    dataGridViewSalesTarget.DataSource = objSalesTargerDetailsManager.ShowAllSalesTarget();
                    dataGridViewSalesTarget.Columns[0].Visible = false;
                    dataGridViewSalesTarget.Columns[3].Visible = false;
                    dataGridViewSalesTarget.Columns[9].Visible = false;
                }
            }

            if (radioButtonByMobileForSalesTarget.Checked == true)
            {
                dataGridViewSalesTarget.DataSource = objSalesTargerDetailsManager.SearchTargetByMobile(txtSearchDateFrom.Text, txtSearchDateTo.Text, txtSearchCriteriaForSalesTarget.Text);
                if (dataGridViewSalesTarget.RowCount > 0)
                {
                    dataGridViewSalesTarget.Columns[0].Visible = false;
                    dataGridViewSalesTarget.Columns[3].Visible = false;
                    dataGridViewSalesTarget.Columns[9].Visible = false;
                }
                else
                {
                    MessageBox.Show("No data found. Loading all data...");
                    dataGridViewSalesTarget.DataSource = objSalesTargerDetailsManager.ShowAllSalesTarget();
                    dataGridViewSalesTarget.Columns[0].Visible = false;
                    dataGridViewSalesTarget.Columns[3].Visible = false;
                    dataGridViewSalesTarget.Columns[9].Visible = false;
                }
            }

            if (radioButtonByGroupForSalesTarget.Checked == true)
            {
                dataGridViewSalesTarget.DataSource = objSalesTargerDetailsManager.SearchTargetByGroupName(txtSearchDateFrom.Text, txtSearchDateTo.Text, txtSearchCriteriaForSalesTarget.Text);
                if (dataGridViewSalesTarget.RowCount > 0)
                {
                    dataGridViewSalesTarget.Columns[0].Visible = false;
                    dataGridViewSalesTarget.Columns[3].Visible = false;
                    dataGridViewSalesTarget.Columns[9].Visible = false;
                }
                else
                {
                    MessageBox.Show("No data found. Loading all data...");
                    dataGridViewSalesTarget.DataSource = objSalesTargerDetailsManager.ShowAllSalesTarget();
                    dataGridViewSalesTarget.Columns[0].Visible = false;
                    dataGridViewSalesTarget.Columns[3].Visible = false;
                    dataGridViewSalesTarget.Columns[9].Visible = false;
                }
            }

            if (radioButtonByDesignationForSalesTarget.Checked == true)
            {
                dataGridViewSalesTarget.DataSource = objSalesTargerDetailsManager.SearchTargetByDesignation(txtSearchDateFrom.Text, txtSearchDateTo.Text, cmbSearchCriteriaByDesigForSalesTarget.Text);
                if (dataGridViewSalesTarget.RowCount > 0)
                {
                    dataGridViewSalesTarget.Columns[0].Visible = false;
                    dataGridViewSalesTarget.Columns[3].Visible = false;
                    dataGridViewSalesTarget.Columns[9].Visible = false;
                }
                else
                {
                    MessageBox.Show("No data found. Loading all data...");
                    dataGridViewSalesTarget.DataSource = objSalesTargerDetailsManager.ShowAllSalesTarget();
                    dataGridViewSalesTarget.Columns[0].Visible = false;
                    dataGridViewSalesTarget.Columns[3].Visible = false;
                    dataGridViewSalesTarget.Columns[9].Visible = false;
                }
            }

            if (radioButtonByGroupAndDesigForSalesTarget.Checked == true)
            {
                dataGridViewSalesTarget.DataSource = objSalesTargerDetailsManager.SearchTargetByGroupAndDesignation(txtSearchDateFrom.Text, txtSearchDateTo.Text, txtSearchCriteriaForSalesTarget.Text,cmbSearchCriteriaByDesigForSalesTarget.Text);
                if (dataGridViewSalesTarget.RowCount > 0)
                {
                    dataGridViewSalesTarget.Columns[0].Visible = false;
                    dataGridViewSalesTarget.Columns[3].Visible = false;
                    dataGridViewSalesTarget.Columns[9].Visible = false;
                }
                else
                {
                    MessageBox.Show("No data found. Loading all data...");
                    dataGridViewSalesTarget.DataSource = objSalesTargerDetailsManager.ShowAllSalesTarget();
                    dataGridViewSalesTarget.Columns[0].Visible = false;
                    dataGridViewSalesTarget.Columns[3].Visible = false;
                    dataGridViewSalesTarget.Columns[9].Visible = false;
                }
            }

            if (radioButtonByProductCodeForSalesTarget.Checked == true)
            {
                dataGridViewSalesTarget.DataSource = objSalesTargerDetailsManager.SearchTargetByProductCode(txtSearchDateFrom.Text, txtSearchDateTo.Text, txtSearchCriteriaForSalesTarget.Text);
                if (dataGridViewSalesTarget.RowCount > 0)
                {
                    dataGridViewSalesTarget.Columns[0].Visible = false;
                    dataGridViewSalesTarget.Columns[3].Visible = false;
                    dataGridViewSalesTarget.Columns[9].Visible = false;
                }
                else
                {
                    MessageBox.Show("No data found. Loading all data...");
                    dataGridViewSalesTarget.DataSource = objSalesTargerDetailsManager.ShowAllSalesTarget();
                    dataGridViewSalesTarget.Columns[0].Visible = false;
                    dataGridViewSalesTarget.Columns[3].Visible = false;
                    dataGridViewSalesTarget.Columns[9].Visible = false;
                }
            }

            if (radioButtonShowAllForSalesTarget.Checked == true)
            {
                dataGridViewSalesTarget.DataSource = objSalesTargerDetailsManager.ShowAllSalesTargetByDateRange(txtSearchDateFrom.Text, txtSearchDateTo.Text);
                if (dataGridViewSalesTarget.RowCount > 0)
                {
                    //dataGridViewSalesTarget.DataSource = objSalesTargerDetailsManager.ShowAllSalesTarget();
                    dataGridViewSalesTarget.Columns[0].Visible = false;
                    dataGridViewSalesTarget.Columns[3].Visible = false;
                    dataGridViewSalesTarget.Columns[9].Visible = false;
                }
                else
                {
                    MessageBox.Show("No data found. Loading all data...");
                    dataGridViewSalesTarget.DataSource = objSalesTargerDetailsManager.ShowAllSalesTarget();
                    dataGridViewSalesTarget.Columns[0].Visible = false;
                    dataGridViewSalesTarget.Columns[3].Visible = false;
                    dataGridViewSalesTarget.Columns[9].Visible = false;
                }
            }
        }

        private void radioButtonByProductCode_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonByProductCodeForSalesTarget.Checked == true)
            {
                radioButtonByMobileForSalesTarget.Checked = false;
                radioButtonByGroupForSalesTarget.Checked = false;
                radioButtonByDesignationForSalesTarget.Checked = false;
                radioButtonByGroupAndDesigForSalesTarget.Checked = false;
                radioButtonShowAllForSalesTarget.Checked = false;
                radioButtonByNameForSalesTarget.Checked = false;

                cmbSearchCriteriaByDesigForSalesTarget.Text = "";
                txtSearchCriteriaForSalesTarget.Text = "";

                if (cmbSearchCriteriaByDesigForSalesTarget.Enabled == true)
                {
                    cmbSearchCriteriaByDesigForSalesTarget.Enabled = false;
                }

                if (txtSearchCriteriaForSalesTarget.Enabled == false)
                {
                    txtSearchCriteriaForSalesTarget.Enabled = true;
                }

                txtSearchCriteriaForSalesTarget.Focus();
            }
        }

        private void dataGridViewSalesTarget_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            GlobalClass.SalesTargetDataGridViewValue = 2;

            if (btnSaveTarget.Enabled == false)
            {
                btnSaveTarget.Enabled = true;
                btnSaveTarget.Text = "Update Target";
            }

            if (btnSaveTarget.Text == "Save Target")
            {
                btnSaveTarget.Text = "Update Target";
            }
            GlobalClass.SalesTargetIdForUpdateSalesTarget = Convert.ToInt32(dataGridViewSalesTarget.CurrentRow.Cells[0].Value.ToString());

            if (txtFromDate.Enabled == false)
            {
                txtFromDate.Enabled = true;
            }

            if (dTPFromDate.Enabled == false)
            {
                dTPFromDate.Enabled = true;
            }

            if (txtToDate.Enabled == false)
            {
                txtToDate.Enabled = true;
            }

            if (dTPToDate.Enabled == false)
            {
                dTPToDate.Enabled = true;
            }

            if (btnBrowseProductCodeForSalesTarget.Enabled == false)
            {
                btnBrowseProductCodeForSalesTarget.Enabled = true;
            }

            if (cmbSelectGroupForSalesTarget.Enabled == false)
            {
                cmbSelectGroupForSalesTarget.Enabled = true;
            }

            if (cmbSelectDesignationForSalesTarget.Enabled == false)
            {
                cmbSelectDesignationForSalesTarget.Enabled = true;
            }

            if (cmbSelectEmployeeForSalesTarget.Enabled == false)
            {
                cmbSelectEmployeeForSalesTarget.Enabled = true;
            }

            if (txtTargetUnitForSalesTarget.Enabled == false)
            {
                txtTargetUnitForSalesTarget.Enabled = true;
            }

            //txtDOB.Text = dobOfEmp.Replace("12:00:00 AM", "");
            //txtDOB.Text = txtDOB.Text.Trim();
            txtFromDate.Text = dataGridViewSalesTarget.CurrentRow.Cells[1].Value.ToString();
            txtFromDate.Text = txtFromDate.Text.Replace("12:00:00 AM", "");
            txtFromDate.Text = txtFromDate.Text.Trim();
            txtToDate.Text = dataGridViewSalesTarget.CurrentRow.Cells[2].Value.ToString();
            txtToDate.Text = txtToDate.Text.Replace("12:00:00 AM", "");
            txtToDate.Text = txtToDate.Text.Trim();
            txtProductCodeForSalesTarget.Text = dataGridViewSalesTarget.CurrentRow.Cells[4].Value.ToString();
            txtProductIDForSalesTarget.Text = dataGridViewSalesTarget.CurrentRow.Cells[3].Value.ToString();
            txtProductNameForSalesTarget.Text = dataGridViewSalesTarget.CurrentRow.Cells[5].Value.ToString();
            txtProductPriceForSalesTarget.Text = dataGridViewSalesTarget.CurrentRow.Cells[6].Value.ToString();
            cmbSelectGroupForSalesTarget.Text = dataGridViewSalesTarget.CurrentRow.Cells[13].Value.ToString();
            cmbSelectDesignationForSalesTarget.Text = dataGridViewSalesTarget.CurrentRow.Cells[11].Value.ToString();
            cmbSelectEmployeeForSalesTarget.Text = dataGridViewSalesTarget.CurrentRow.Cells[10].Value.ToString();
            txtEmployeeIDForSalesTarget.Text = dataGridViewSalesTarget.CurrentRow.Cells[9].Value.ToString();
            txtEmpMobileNoForSalesTarget.Text = dataGridViewSalesTarget.CurrentRow.Cells[12].Value.ToString();
            txtTargetUnitForSalesTarget.Text = dataGridViewSalesTarget.CurrentRow.Cells[7].Value.ToString();
            txtTargetAmountForSalesTarget.Text = dataGridViewSalesTarget.CurrentRow.Cells[8].Value.ToString();

            if (cmbSelectGroupForSalesTarget.Enabled == false)
            {
                cmbSelectGroupForSalesTarget.Enabled = true;
            }
            cmbSelectGroupForSalesTarget.DataSource = objGroupDetailsGateway.LoadSelectGroupForGroupSetup();
            cmbSelectGroupForSalesTarget.DisplayMember = "Group_Name";
            cmbSelectGroupForSalesTarget.ValueMember = "Group_Name";
            cmbSelectGroupForSalesTarget.Text = dataGridViewSalesTarget.CurrentRow.Cells[13].Value.ToString(); ;


            if (cmbSelectDesignationForSalesTarget.Enabled == false)
            {
                cmbSelectDesignationForSalesTarget.Enabled = true;
            }
            cmbSelectDesignationForSalesTarget.DataSource = objDesignationDetailsManager.LoadDesignationCombo();
            cmbSelectDesignationForSalesTarget.DisplayMember = "Designation";
            cmbSelectDesignationForSalesTarget.ValueMember = "Designation";
            cmbSelectDesignationForSalesTarget.Text = dataGridViewSalesTarget.CurrentRow.Cells[11].Value.ToString(); ;


            if (cmbSelectEmployeeForSalesTarget.Enabled == false)
            {
                cmbSelectEmployeeForSalesTarget.Enabled = true;
            }
            
            if (cmbSelectGroupForSalesTarget.Text != "" && cmbSelectDesignationForSalesTarget.Text != "")
                {
                    cmbSelectEmployeeForSalesTarget.DataSource =
                        objEmployeeDetailsManager.LoadEmployeeBySelectedGroupAndDesignation(cmbSelectGroupForSalesTarget.Text.ToString(), cmbSelectDesignationForSalesTarget.Text.ToString());
                    cmbSelectEmployeeForSalesTarget.DisplayMember = "Employee_Name";
                    cmbSelectEmployeeForSalesTarget.ValueMember = "Employee_Name";
                }
                //cmbSelectEmployeeForSalesTarget.DataSource = objEmployeeDetailsManager.LoadEmployeeBySelectedGroupAndDesignation();
                cmbSelectEmployeeForSalesTarget.Text = dataGridViewSalesTarget.CurrentRow.Cells[10].Value.ToString();

                dataGridViewSalesTarget.DataSource = objSalesTargerDetailsManager.ShowAllSalesTarget();
                dataGridViewSalesTarget.Columns[0].Visible = false;
                dataGridViewSalesTarget.Columns[3].Visible = false;
                dataGridViewSalesTarget.Columns[9].Visible = false;
        }

        private void txtProductPriceForSalesTarget_TextChanged(object sender, EventArgs e)
        {
            if (txtTargetUnitForSalesTarget.Text != "" && txtTargetAmountForSalesTarget.Text != "" && txtProductPriceForSalesTarget.Text != "")
            {
                int targetUnit;
                float productPrice;
                float totalAmount;
                
                targetUnit = Int32.Parse(txtTargetUnitForSalesTarget.Text); //Convert.ToInt32(txtTargetUnitForSalesTarget.Text.ToString());
                productPrice = float.Parse(txtProductPriceForSalesTarget.Text);// Convert.ToDecimal(txtProductPriceForSalesTarget.Text.ToString());
                totalAmount = productPrice * targetUnit;
                txtTargetAmountForSalesTarget.Text = totalAmount.ToString();
            }
        }

        private void btnDBBackup_Click(object sender, EventArgs e)
        {
            try
            {
                DateTime getCurrDate = DateTime.Now;
                dbBackupPath = Application.StartupPath.ToString();
                dbBackipFolderName = dbBackupPath + "\\DB_Backup\\";
                getDate = getCurrDate.ToString("MMddyyyy");//String.Format(getCurrDate.ToShortDateString(),"MMDDYYYY").ToString();
                getTime = getCurrDate.ToString("HHmmss"); //String.Format(getCurrDate.ToShortTimeString(), "HHMMSS").ToString();
                backUpFileName = dbBackipFolderName + GlobalClass.DatabaseName + "_" + getDate + "_" + getTime + ".bak";
                
                //tbSelectedFolder.Text += string.Format("\\GononetPosBackup-{0}.Bak", DateTime.Now.ToString("yyyyMMdd"));
                //if (GlobalClass.MakeDatabaseBackup(backUpFileName)) MessageBox.Show("Backup created");


                //string srcDir = dbBackipFolderName;45r

                //string[] bakList = Directory.GetFiles(srcDir, "*.bak");

                //if (Directory.Exists(srcDir))
                //{
                //    foreach (string f in bakList)
                //    {
                //        File.Delete(f);
                //    }
                //}

                SqlCommand cmd = new SqlCommand("SP_DB_Backup", DBConnection.SqlConnectionObject);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@DiskPath", backUpFileName);
                DBConnection.SqlConnectionObject.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("BackUp completed...");
                DBConnection.SqlConnectionObject.Close();
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            //MessageBox.Show("Under process");
        }

        private void radioBtnPriceUpdateLogSearchByPCode_CheckedChanged(object sender, EventArgs e)
        {
            if (radioBtnPriceUpdateLogSearchByPCode.Checked == true)
            {
                radioBtnPriceUpdateLogSearchByPName.Checked = false;
                radioBtnPriceUpdateLogShowAll.Checked = false;
            }

            txtPriceUpdateLogSearchCriteria.Enabled = true;
            txtPriceUpdateLogSearchCriteria.Text = "";
            txtPriceUpdateLogSearchCriteria.Focus();
        }

        private void radioBtnPriceUpdateLogSearchByPName_CheckedChanged(object sender, EventArgs e)
        {
            if (radioBtnPriceUpdateLogSearchByPName.Checked == true)
            {
                radioBtnPriceUpdateLogSearchByPCode.Checked = false;
                radioBtnPriceUpdateLogShowAll.Checked = false;
            }

            txtPriceUpdateLogSearchCriteria.Enabled = true;
            txtPriceUpdateLogSearchCriteria.Text = "";
            txtPriceUpdateLogSearchCriteria.Focus();
        }

        private void radioBtnPriceUpdateLogShowAll_CheckedChanged(object sender, EventArgs e)
        {
            if (radioBtnPriceUpdateLogShowAll.Checked == true)
            {
                radioBtnPriceUpdateLogSearchByPCode.Checked = false;
                radioBtnPriceUpdateLogSearchByPName.Checked = false;
            }

            txtPriceUpdateLogSearchCriteria.Enabled = false;
            txtPriceUpdateLogSearchCriteria.Text = "";
            btnPriceUpdateLogSearch.Focus();
        }

        private void btnPriceUpdateLogSearch_Click(object sender, EventArgs e)
        {
            if (radioBtnPriceUpdateLogSearchByPCode.Checked == true)
            {
                radioBtnPriceUpdateLogSearchByPName.Checked = false;
                radioBtnPriceUpdateLogShowAll.Checked = false;

                dgvProductPriceUpdateLog.DataSource = objProductDetailsManager.GetProductUpdateLogByProductCode(txtPriceUpdateLogSearchCriteria.Text.ToString());
                if (dgvProductPriceUpdateLog.RowCount > 0)
                {
                    dgvProductPriceUpdateLog.Refresh();
                    dgvProductPriceUpdateLog.Columns[0].Visible = false;
                    txtPriceUpdateLogSearchCriteria.Text = "";
                }
                else
                {
                    MessageBox.Show("No Data Found");
                }
            }

            if (radioBtnPriceUpdateLogSearchByPName.Checked == true)
            {
                radioBtnPriceUpdateLogSearchByPCode.Checked = false;
                radioBtnPriceUpdateLogShowAll.Checked = false;

                dgvProductPriceUpdateLog.DataSource = objProductDetailsManager.GetProductUpdateLogByProductName(txtPriceUpdateLogSearchCriteria.Text.ToString());
                if (dgvProductPriceUpdateLog.RowCount > 0)
                {
                    dgvProductPriceUpdateLog.Refresh();
                    dgvProductPriceUpdateLog.Columns[0].Visible = false;
                    txtPriceUpdateLogSearchCriteria.Text = "";
                }
                else
                {
                    MessageBox.Show("No Data Found");
                }
            }

            if (radioBtnPriceUpdateLogShowAll.Checked == true)
            {
                radioBtnPriceUpdateLogSearchByPCode.Checked = false;
                radioBtnPriceUpdateLogSearchByPName.Checked = false;

                dgvProductPriceUpdateLog.DataSource = objProductDetailsManager.ShowUpdateLogForAllProduct();
                if (dgvProductPriceUpdateLog.RowCount > 0)
                {
                    dgvProductPriceUpdateLog.Refresh();
                    dgvProductPriceUpdateLog.Columns[0].Visible = false;
                    txtPriceUpdateLogSearchCriteria.Text = "";
                }
                else
                {
                    MessageBox.Show("No Data Found");
                }
            }
        }

        private void btnSpecialItemSaleAddTarget_Click(object sender, EventArgs e)
        {
            try
            {
                ClearSpecialItemSaleTargetTab();

                if (btnSpecialItemSaleSaveTarget.Enabled == false)
                {
                    btnSpecialItemSaleSaveTarget.Enabled = true;
                }

                if (btnSpecialItemSaleSaveTarget.Text == "Update Special Target")
                {
                    btnSpecialItemSaleSaveTarget.Text = "Save Special Target";
                }

                if (txtSpecialItemSaleFromDate.Enabled == false)
                {
                    txtSpecialItemSaleFromDate.Enabled = true;
                }

                if (dtPSpecialItemSaleFromDate.Enabled == false)
                {
                    dtPSpecialItemSaleFromDate.Enabled = true;
                }

                if (txtSpecialItemSaleToDate.Enabled == false)
                {
                    txtSpecialItemSaleToDate.Enabled = true;
                }

                if (dtPSpecialItemSaleToDate.Enabled == false)
                {
                    dtPSpecialItemSaleToDate.Enabled = true;
                }

                if (btnSpecialItemSaleProductCodeBrowse.Enabled == false)
                {
                    btnSpecialItemSaleProductCodeBrowse.Enabled = true;
                }

                if (txtSpecialItemSaleProductCode.ReadOnly == false)
                {
                    txtSpecialItemSaleProductCode.ReadOnly = true;
                }

                if (txtSpecialItemSaleProductID.ReadOnly == false)
                {
                    txtSpecialItemSaleProductID.ReadOnly = true;
                }

                if (txtSpecialItemSaleProductName.ReadOnly == false)
                {
                    txtSpecialItemSaleProductName.ReadOnly = true;
                }

                if (txtSpecialItemSaleProductCostPrice.ReadOnly == false)
                {
                    txtSpecialItemSaleProductCostPrice.ReadOnly = true;
                }

                if (txtSpecialItemSaleProductSalePrice.ReadOnly == false)
                {
                    txtSpecialItemSaleProductSalePrice.ReadOnly = true;
                }

                if (txtSpecialItemSaleProductSpecialPrice.Enabled == false)
                {
                    txtSpecialItemSaleProductSpecialPrice.Enabled = true;
                }

                if (cmbSpecialItemSaleSelectGroup.Enabled == false)
                {
                    cmbSpecialItemSaleSelectGroup.Enabled = true;
                }
                cmbSpecialItemSaleSelectGroup.DataSource = objGroupDetailsGateway.LoadSelectGroupForGroupSetup();
                cmbSpecialItemSaleSelectGroup.DisplayMember = "Group_Name";
                cmbSpecialItemSaleSelectGroup.ValueMember = "Group_Name";
                cmbSpecialItemSaleSelectGroup.Text = "";


                if (cmbSpecialItemSaleSelectDesignation.Enabled == false)
                {
                    cmbSpecialItemSaleSelectDesignation.Enabled = true;
                }
                cmbSpecialItemSaleSelectDesignation.DataSource = objDesignationDetailsManager.LoadDesignationCombo();
                cmbSpecialItemSaleSelectDesignation.DisplayMember = "Designation";
                cmbSpecialItemSaleSelectDesignation.ValueMember = "Designation";
                cmbSpecialItemSaleSelectDesignation.Text = "";


                if (cmbSpecialItemSaleSelectEmployee.Enabled == false)
                {
                    cmbSpecialItemSaleSelectEmployee.Enabled = true;
                    //if (cmbSelectGroupForSalesTarget.Text != "" && cmbSelectDesignationForSalesTarget.Text != "")
                    //{
                    //    cmbSelectEmployeeForSalesTarget.DataSource =
                    //        objEmployeeDetailsManager.LoadEmployeeBySelectedGroupAndDesignation(cmbSelectGroupForSalesTarget.Text.ToString(), cmbSelectDesignationForSalesTarget.Text.ToString());
                    //    cmbSelectEmployeeForSalesTarget.DisplayMember = "Employee_Name";
                    //    cmbSelectEmployeeForSalesTarget.ValueMember = "Employee_Name";
                    //}
                    //cmbSelectEmployeeForSalesTarget.DataSource = objEmployeeDetailsManager.LoadEmployeeBySelectedGroupAndDesignation();
                }

                if (txtSpecialItemSaleEmployeeID.ReadOnly == false)
                {
                    txtSpecialItemSaleEmployeeID.ReadOnly = true;
                }

                if (txtSpecialItemSaleEmployeeMobileNo.ReadOnly == false)
                {
                    txtSpecialItemSaleEmployeeMobileNo.ReadOnly = true;
                }

                if (txtSpecialItemSaleTargetUnit.Enabled == false)
                {
                    txtSpecialItemSaleTargetUnit.Enabled = true;
                }

                if (txtSpecialItemSaleTargetAmount.ReadOnly == false)
                {
                    txtSpecialItemSaleTargetAmount.ReadOnly = true;
                }

                GlobalClass.ProductCodeForSpecialSalesTarget = "";
                GlobalClass.ProductIdForSpecialSalesTarget = "";
                GlobalClass.ProductNameForSpecialSalesTarget = "";
                GlobalClass.ProductCostPriceForSpecialSalesTarget = 0;
                GlobalClass.ProductSalesPriceForSpecialSalesTarget = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSpecialItemSaleProductCodeBrowse_Click(object sender, EventArgs e)
        {
            GlobalClass.TabNameForProductListUi = tabSMSapplication.SelectedTab.Text.ToString();
            //MessageBox.Show(GlobalClass.TabNameForProductListUi.ToString());
            ProductListUI objProductListUi = new ProductListUI();
            objProductListUi.PassValue1 += new PassValueHandler1(objProductListUi_PassValue1);
            objProductListUi.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //GlobalClass.SmsDetails = "CP 50, CPO 100, CPPN 100, EPMG 100A";
            //char lastChar = GlobalClass.SmsDetails[GlobalClass.SmsDetails.Length-1];
            //if (lastChar != ',')
            //{
            //    if (lastChar == '.' || lastChar == '#' || !Char.IsDigit(lastChar))
            //    {
            //        GlobalClass.SmsDetails = GlobalClass.SmsDetails.Replace(lastChar, ',');
            //    }
            //    else
            //    {
            //        GlobalClass.SmsDetails = GlobalClass.SmsDetails + ",";
            //    }
            //}
            //do
            //{
            //    int index = GlobalClass.SmsDetails.IndexOf(",");
            //    if (index > 0)
            //    {
            //        GlobalClass.SmsCutting = GlobalClass.SmsDetails.Substring(0, index).Trim();
            //        GlobalClass.SmsDetails = GlobalClass.SmsDetails.Remove(0, index + 1).Trim();
            //        GlobalClass.ProCodeForSales = GlobalClass.SmsCutting.Substring(0, GlobalClass.SmsCutting.IndexOf(" "));
            //        GlobalClass.ProQuantityForSales = Convert.ToInt16(GlobalClass.SmsCutting.Substring(GlobalClass.SmsCutting.LastIndexOf(" ") + 1));
            //        DataTable dtProductDetails = new DataTable();
            //        dtProductDetails = objProductDetailsManager.GetProductDetailsForSales(GlobalClass.ProCodeForSales);
            //        if (dtProductDetails.Rows.Count > 0)
            //        {
            //            GlobalClass.ProIdForSales = dtProductDetails.Rows[0][0].ToString();
            //            GlobalClass.ProCodeForSales = dtProductDetails.Rows[0][1].ToString();
            //            GlobalClass.ProNameForSales = dtProductDetails.Rows[0][2].ToString();
            //            GlobalClass.ProCostPriceForSales = Convert.ToDecimal(dtProductDetails.Rows[0][4].ToString());
            //            GlobalClass.ProSalePriceForSales = Convert.ToDecimal(dtProductDetails.Rows[0][5].ToString());
            //            if (GlobalClass.ProQuantityForSales > 0 && GlobalClass.ProSalePriceForSales != null)
            //            {
            //                GlobalClass.ProSaleAmountForSales = (GlobalClass.ProQuantityForSales * GlobalClass.ProSalePriceForSales);
            //            }
            //        }
            //    }
            //    else if (index <= 0)
            //    {
            //        MessageBox.Show("Nothing left for CUT.....");
            //    }
            //} while(GlobalClass.SmsDetails.Contains(","));
        }

        private void btnReportShow_Click(object sender, EventArgs e)
        {
            if (radioBtnSalesTargetReport.Checked == true)
            {
                SalesTargetReportUI objSalesTargetReportUi = new SalesTargetReportUI();
                objSalesTargetReportUi.ShowDialog();
            }
            else if (radioButtonUserReport.Checked == true)
            {
                UserReportUI objUserReportUI = new UserReportUI();
                objUserReportUI.ShowDialog();
            }
            else if (radioButtonProductReport.Checked == true)
            {
                ProductReportUI objProductReportUi = new ProductReportUI();
                objProductReportUi.ShowDialog();
            }
            else if (radioButtonDivisionReport.Checked == true)
            {
                DivisionReportUI objDivisionReportUi = new DivisionReportUI();
                objDivisionReportUi.ShowDialog();
            }
        }

        private void btnBrowseProductCodeForSalesTarget_Click_1(object sender, EventArgs e)
        {
            // closed for check on 14-April-2016
            ////GlobalClass.TabNameForProductListUi = tabSMSapplication.SelectedTab.Text.ToString();
            //////MessageBox.Show(GlobalClass.TabNameForProductListUi.ToString());
            ////ProductListUI objProductListUi = new ProductListUI();
            ////objProductListUi.PassValue += new PassValueHandler(objProductListUi_PassValue);
            ////objProductListUi.Show();
            //end of closed for check on 14-April-2016

            //ProductListForSalesTargetUI objProductListForSalesTargetUi = new ProductListForSalesTargetUI();
            //objProductListForSalesTargetUi.Show();

            try
            {
                if (txtFromDate.Text == "")
                {
                    MessageBox.Show("From Date can't be blank");
                    txtFromDate.Focus();
                }

                else if (txtToDate.Text == "")
                {
                    MessageBox.Show("To Date can't be blank");
                    txtToDate.Focus();
                }

                else if (cmbSelectGroupForSalesTarget.Text == "")
                {
                    MessageBox.Show("Please select a Team");
                    cmbSelectGroupForSalesTarget.Focus();
                }

                else if (cmbSelectDesignationForSalesTarget.Text == "")
                {
                    MessageBox.Show("Please select Designation");
                    cmbSelectDesignationForSalesTarget.Focus();
                }

                else if (cmbSelectEmployeeForSalesTarget.Text == "")
                {
                    MessageBox.Show("Please select Employee");
                    cmbSelectEmployeeForSalesTarget.Focus();
                }
                
                else if (GlobalClass.SalesTargetDataGridViewValue == 1)
                {
                    DataGridViewCheckBoxColumn checkBoxColumn = new DataGridViewCheckBoxColumn();
                    DataGridViewTextBoxColumn orderQTY = new DataGridViewTextBoxColumn();

                    objSalesTargerDetailsManager.DeleteTempSalesTarget();

                    GlobalClass.FromDateForSalesTarget = txtFromDate.Text;
                    GlobalClass.ToDateForSalesTarget = txtToDate.Text;
                    GlobalClass.GroupNameForSalesTarget = cmbSelectGroupForSalesTarget.Text;
                    GlobalClass.EmpDesignationForSalesTarget = cmbSelectDesignationForSalesTarget.Text;
                    GlobalClass.EmpNameForSalesTarget = cmbSelectEmployeeForSalesTarget.Text;
                    GlobalClass.EmpIdForSalesTarget = txtEmployeeIDForSalesTarget.Text;
                    GlobalClass.EmpMobileNoForSalesTarget = txtEmpMobileNoForSalesTarget.Text;

                    if (objSalesTargerDetailsManager.SearchTargetByName(GlobalClass.FromDateForSalesTarget, GlobalClass.ToDateForSalesTarget,
                        GlobalClass.EmpNameForSalesTarget).Rows.Count >0)
                    {
                        objSalesTargerDetailsManager.InsertPreviousSalesTargetIntoTemp(GlobalClass.FromDateForSalesTarget, GlobalClass.ToDateForSalesTarget,
                        GlobalClass.EmpNameForSalesTarget);

                        dataGridViewSalesTarget.DataSource = null;
                        dataGridViewSalesTarget.Visible = false;
                        dgvSalesTargetDetails.DataSource = null;
                        dgvSalesTargetDetails.Visible = false;

                        dgvPrevAddedSalesTargetDetails.DataSource = objSalesTargerDetailsManager.ShowTempSalesTarget();
                        dgvPrevAddedSalesTargetDetails.Visible = true;
                        //dgvPrevAddedSalesTargetDetails.Location = new Point(380, 11);
                        dgvPrevAddedSalesTargetDetails.Location = new Point(372, 10);
                        //dgvPrevAddedSalesTargetDetails.Size = new Size(950, 290);
                        dgvPrevAddedSalesTargetDetails.Size = new Size(960, 290);
                        dgvPrevAddedSalesTargetDetails.Columns[0].Visible = false;
                        dgvPrevAddedSalesTargetDetails.Columns[3].Visible = false;
                        dgvPrevAddedSalesTargetDetails.Columns[9].Visible = false;
                        
                        dgvProductListForSalesTarget.Columns.Clear();
                        while (dgvProductListForSalesTarget.Columns.Count >= 1)
                        {
                            dgvProductListForSalesTarget.Columns.RemoveAt(0);
                        }

                        dgvProductListForSalesTarget.DataSource = objProductDetailsManager.ShowAllProduct();
                        
                        dgvProductListForSalesTarget.Visible = true;
                        //dgvProductListForSalesTarget.Location = new Point(380, 301);
                        dgvProductListForSalesTarget.Location = new Point(372, 300);
                        dgvProductListForSalesTarget.Size = new Size(960, 290);
                        //dgvProductListForSalesTarget.Size = new Size(950, 290);
                        dgvProductListForSalesTarget.Columns[4].Visible = false;
                        dgvProductListForSalesTarget.Columns[6].Visible = false;
                        dgvProductListForSalesTarget.Columns[0].ReadOnly = true;
                        dgvProductListForSalesTarget.Columns[1].ReadOnly = true;
                        dgvProductListForSalesTarget.Columns[2].ReadOnly = true;
                        dgvProductListForSalesTarget.Columns[3].ReadOnly = true;
                        dgvProductListForSalesTarget.Columns[5].ReadOnly = true;

                        dgvProductListForSalesTarget.Columns.Insert(7, orderQTY);
                        orderQTY.Name = "orderQTY";
                        orderQTY.HeaderText = "Order QTY";
                        orderQTY.ReadOnly = false;

                        dgvProductListForSalesTarget.Columns.Insert(8, checkBoxColumn);
                        checkBoxColumn.Name = "checkBoxColumn";
                        checkBoxColumn.HeaderText = "Check to Insert";
                        checkBoxColumn.ReadOnly = false;

                        btnBrowseProductCodeForSalesTarget.Enabled = false;
                        dgvProductListForSalesTarget.Focus();
                    }
                    else
                    {
                        objSalesTargerDetailsManager.InsertPreviousSalesTargetIntoTemp(GlobalClass.FromDateForSalesTarget, GlobalClass.ToDateForSalesTarget,
                        GlobalClass.EmpNameForSalesTarget);

                        dataGridViewSalesTarget.DataSource = null;
                        dataGridViewSalesTarget.Visible = false;
                        dgvSalesTargetDetails.DataSource = null;
                        dgvSalesTargetDetails.Visible = false;

                        dgvPrevAddedSalesTargetDetails.DataSource = objSalesTargerDetailsManager.ShowTempSalesTarget();
                        dgvPrevAddedSalesTargetDetails.Visible = true;
                        //dgvPrevAddedSalesTargetDetails.Location = new Point(380, 11);
                        //dgvPrevAddedSalesTargetDetails.Size = new Size(950, 290);
                        dgvPrevAddedSalesTargetDetails.Location = new Point(372, 10);
                        dgvPrevAddedSalesTargetDetails.Size = new Size(960, 290);
                        dgvPrevAddedSalesTargetDetails.Columns[0].Visible = false;
                        dgvPrevAddedSalesTargetDetails.Columns[3].Visible = false;
                        dgvPrevAddedSalesTargetDetails.Columns[9].Visible = false;

                        dgvProductListForSalesTarget.Columns.Clear();
                        while (dgvProductListForSalesTarget.Columns.Count >= 1)
                        {
                            dgvProductListForSalesTarget.Columns.RemoveAt(0);
                        }

                        dgvProductListForSalesTarget.DataSource = objProductDetailsManager.ShowAllProduct();

                        dgvProductListForSalesTarget.Visible = true;
                        //dgvProductListForSalesTarget.Location = new Point(380, 301);
                        //dgvProductListForSalesTarget.Size = new Size(950, 290);
                        dgvProductListForSalesTarget.Location = new Point(372, 300);
                        dgvProductListForSalesTarget.Size = new Size(960, 290);
                        dgvProductListForSalesTarget.Columns[4].Visible = false;
                        dgvProductListForSalesTarget.Columns[6].Visible = false;

                        dgvProductListForSalesTarget.Columns[0].ReadOnly = true;
                        dgvProductListForSalesTarget.Columns[1].ReadOnly = true;
                        dgvProductListForSalesTarget.Columns[2].ReadOnly = true;
                        dgvProductListForSalesTarget.Columns[3].ReadOnly = true;
                        dgvProductListForSalesTarget.Columns[5].ReadOnly = true;

                        dgvProductListForSalesTarget.Columns.Insert(7, orderQTY);
                        orderQTY.Name = "orderQTY";
                        orderQTY.HeaderText = "Order QTY";
                        orderQTY.ReadOnly = false;

                        dgvProductListForSalesTarget.Columns.Insert(8, checkBoxColumn);
                        checkBoxColumn.Name = "checkBoxColumn";
                        checkBoxColumn.HeaderText = "Check to Insert";
                        checkBoxColumn.ReadOnly = false;

                        btnBrowseProductCodeForSalesTarget.Enabled = false;
                        dgvProductListForSalesTarget.Focus();
                    }
                }
                else if (GlobalClass.SalesTargetDataGridViewValue == 2)
                {
                    GlobalClass.TabNameForProductListUi = tabSMSapplication.SelectedTab.Text.ToString();
                    //MessageBox.Show(GlobalClass.TabNameForProductListUi.ToString());
                    ProductListUI objProductListUi = new ProductListUI();
                    objProductListUi.PassValue += new PassValueHandler(objProductListUi_PassValue);
                    objProductListUi.Show();
                    btnBrowseProductCodeForSalesTarget.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnAddToList_Click(object sender, EventArgs e)
        {
            //////int tmpSalesTargetID;
            //////string tmpFromDate;
            //////string tmpToDate;
            //////int tmpProductID;
            //////string tmpProductCode;
            //////string tmpProductName;
            //////decimal tmpProductPrice;
            //////int tmpSalesTargetUnit;
            //////decimal tmpSalesTargetAmount;
            //////int tmpEmployeeID;
            //////string tmpEmployeeName;
            //////string tmpEmpDesignation;
            //////string tmpEmpOfficialCell;
            //////string tmpEmpGroupName;

            //////if (txtFromDate.Text == "")
            //////{
            //////    MessageBox.Show("From Date can't be blank");
            //////    txtFromDate.Focus();
            //////}

            //////else if (txtToDate.Text == "")
            //////{
            //////    MessageBox.Show("To Date can't be blank");
            //////    txtToDate.Focus();
            //////}

            //////else if (cmbSelectGroupForSalesTarget.Text == "")
            //////{
            //////    MessageBox.Show("Please select a Team");
            //////    cmbSelectGroupForSalesTarget.Focus();
            //////}

            //////else if (cmbSelectDesignationForSalesTarget.Text == "")
            //////{
            //////    MessageBox.Show("Please select Designation");
            //////    cmbSelectDesignationForSalesTarget.Focus();
            //////}

            //////else if (cmbSelectEmployeeForSalesTarget.Text == "")
            //////{
            //////    MessageBox.Show("Please select Employee");
            //////    cmbSelectEmployeeForSalesTarget.Focus();
            //////}

            //////else if (txtProductCodeForSalesTarget.Text == "")
            //////{
            //////    MessageBox.Show("Please select a Product");
            //////    btnBrowseProductCodeForSalesTarget_Click(null,null);
            //////}
            //////else
            //////{
            //////    tmpFromDate = txtFromDate.Text.ToString();
            //////    tmpToDate = txtToDate.Text.ToString();
            //////    tmpProductID = Convert.ToInt32(txtProductIDForSalesTarget.Text.ToString());
            //////    tmpProductCode = txtProductCodeForSalesTarget.Text.ToString();
            //////    tmpProductName = txtProductNameForSalesTarget.Text.ToString();
            //////    tmpProductPrice = Convert.ToDecimal(txtProductPriceForSalesTarget.Text.ToString());
            //////    tmpSalesTargetUnit = Convert.ToInt32(txtTargetUnitForSalesTarget.Text.ToString());
            //////    tmpSalesTargetAmount = Convert.ToDecimal(txtTargetAmountForSalesTarget.Text.ToString());
            //////    tmpEmployeeID = Convert.ToInt32(txtEmployeeIDForSalesTarget.Text.ToString());
            //////    tmpEmployeeName = cmbSelectEmployeeForSalesTarget.Text.ToString();
            //////    tmpEmpDesignation = cmbSelectDesignationForSalesTarget.Text.ToString();
            //////    tmpEmpOfficialCell = txtEmpMobileNoForSalesTarget.Text.ToString();
            //////    tmpEmpGroupName = cmbSelectGroupForSalesTarget.Text.ToString();

            //////    if (btnAddToList.Text == "Add To List")
            //////    {
            //////        //objMarketDetailsManager.InsertMarket(marketCode, marketName, noOfParty, target, monthlyNoOfVisit,
            //////        //    marketActive, empIdForMarket, empNameForMarket, officialCellNO, empDesignationForMarket, groupIdForMarket, groupNameForMarket);

            //////        if (objSalesTargerDetailsManager.CheckDuplicate(tmpProductCode).Rows.Count > 0)
            //////        {
            //////            MessageBox.Show("Product already added, please select another product...");
            //////            txtProductCodeForSalesTarget.Text = "";
            //////            txtProductIDForSalesTarget.Text = "";
            //////            txtProductNameForSalesTarget.Text = "";
            //////            txtProductPriceForSalesTarget.Text = "";
            //////            txtTargetUnitForSalesTarget.Text = "";
            //////            txtTargetAmountForSalesTarget.Text = "";
            //////            btnBrowseProductCodeForSalesTarget.Enabled = true;
            //////            btnBrowseProductCodeForSalesTarget_Click(null, null);
            //////        }
            //////        else
            //////        {
            //////            objSalesTargerDetailsManager.InsertTempSalesTarget(tmpFromDate, tmpToDate, tmpProductID, tmpProductCode, tmpProductName,
            //////            tmpProductPrice, tmpSalesTargetUnit, tmpSalesTargetAmount, tmpEmployeeID, tmpEmployeeName, tmpEmpDesignation,
            //////            tmpEmpOfficialCell, tmpEmpGroupName);

            //////            btnAddToList.Text = "Add To List";
            //////            btnAddTarget.Enabled = false;
            //////            if (MessageBox.Show("Do you want to Add another Product ?", "Add Product!", MessageBoxButtons.YesNo) ==
            //////                DialogResult.Yes)
            //////            {
            //////                txtProductCodeForSalesTarget.Text = "";
            //////                txtProductIDForSalesTarget.Text = "";
            //////                txtProductNameForSalesTarget.Text = "";
            //////                txtProductPriceForSalesTarget.Text = "";
            //////                txtTargetUnitForSalesTarget.Text = "";
            //////                txtTargetAmountForSalesTarget.Text = "";
            //////                btnBrowseProductCodeForSalesTarget.Enabled = true;
            //////                btnBrowseProductCodeForSalesTarget_Click(null, null);
            //////                //btnBrowseProductCodeForSalesTarget.Focus();
            //////            }
            //////            else
            //////            {
            //////                //ClearSalesTargetTab();
            //////                txtProductCodeForSalesTarget.Text = "";
            //////                txtProductIDForSalesTarget.Text = "";
            //////                txtProductNameForSalesTarget.Text = "";
            //////                txtProductPriceForSalesTarget.Text = "";
            //////                txtTargetUnitForSalesTarget.Text = "";
            //////                txtTargetAmountForSalesTarget.Text = "";
            //////                btnAddTarget.Enabled = false;
            //////                btnAddToList.Enabled = true;
            //////                btnSaveTarget.Enabled = true;
            //////            }
            //////            dgvSalesTargetDetails.DataSource = objSalesTargerDetailsManager.ShowTempSalesTarget();
            //////            dgvSalesTargetDetails.Columns[0].Visible = false;
            //////            dgvSalesTargetDetails.Columns[3].Visible = false;
            //////            dgvSalesTargetDetails.Columns[9].Visible = false;
            //////            //MessageBox.Show("Target Added Succesfully");
            //////        }
                    
            //////    }
            //////    else if (btnAddToList.Text == "Update List")
            //////    {
            //////        tmpSalesTargetID = Convert.ToInt32(GlobalClass.SalesTargetIdForUpdateSalesTarget);

            //////        objSalesTargerDetailsManager.UpdateTempSalesTarget(tmpSalesTargetID, tmpFromDate, tmpToDate, tmpProductID, tmpProductCode, tmpProductName,
            //////            tmpProductPrice, tmpSalesTargetUnit, tmpSalesTargetAmount, tmpEmployeeID, tmpEmployeeName, tmpEmpDesignation,
            //////            tmpEmpOfficialCell, tmpEmpGroupName);

            //////        //dgvSalesDetails.DataSource = objSalesTargerDetailsManager.ShowAllSalesTarget();
            //////        //dgvSalesDetails.Columns[0].Visible = false;
            //////        //dgvSalesDetails.Columns[3].Visible = false;
            //////        //dgvSalesDetails.Columns[9].Visible = false;
            //////        dgvSalesTargetDetails.DataSource = objSalesTargerDetailsManager.ShowTempSalesTarget();
            //////        dgvSalesTargetDetails.Columns[0].Visible = false;
            //////        dgvSalesTargetDetails.Columns[3].Visible = false;
            //////        dgvSalesTargetDetails.Columns[9].Visible = false;
            //////        MessageBox.Show("List Updated Successfully.");
                    
            //////        btnAddToList.Text = "Add To List";
            //////        btnAddTarget.Enabled = false;

            //////        if (MessageBox.Show("Do you want to Add another Product ?", "Add Product!", MessageBoxButtons.YesNo) ==
            //////            DialogResult.Yes)
            //////        {
            //////            txtProductCodeForSalesTarget.Text = "";
            //////            txtProductIDForSalesTarget.Text = "";
            //////            txtProductNameForSalesTarget.Text = "";
            //////            txtProductPriceForSalesTarget.Text = "";
            //////            txtTargetUnitForSalesTarget.Text = "";
            //////            txtTargetAmountForSalesTarget.Text = "";
            //////            btnBrowseProductCodeForSalesTarget.Enabled = true;
            //////            btnBrowseProductCodeForSalesTarget_Click(null, null);
            //////            //btnBrowseProductCodeForSalesTarget.Focus();
            //////        }
            //////        else
            //////        {
            //////            //ClearSalesTargetTab();
            //////            txtProductCodeForSalesTarget.Text = "";
            //////            txtProductIDForSalesTarget.Text = "";
            //////            txtProductNameForSalesTarget.Text = "";
            //////            txtProductPriceForSalesTarget.Text = "";
            //////            txtTargetUnitForSalesTarget.Text = "";
            //////            txtTargetAmountForSalesTarget.Text = "";
            //////            btnAddTarget.Enabled = false;
            //////            btnAddToList.Enabled = true;
            //////            btnSaveTarget.Enabled = true;
            //////        }
            //////    }
            //////}

            int tmpSalesTargetID;
            string tmpFromDate;
            string tmpToDate;
            int tmpProductID;
            string tmpProductCode;
            string tmpProductName;
            decimal tmpProductPrice;
            int tmpSalesTargetUnit;
            decimal tmpSalesTargetAmount;
            int tmpEmployeeID;
            string tmpEmployeeName;
            string tmpEmpDesignation;
            string tmpEmpOfficialCell;
            string tmpEmpGroupName;
            string tmpDivisionNane;


            if (btnAddToList.Text == "Add To List")
            {
                ////dgvSalesTargetDetails.DataSource = objSalesTargerDetailsManager.ShowTempSalesTarget();
                ////dgvSalesTargetDetails.Columns[0].Visible = false;
                ////dgvSalesTargetDetails.Columns[3].Visible = false;
                ////dgvSalesTargetDetails.Columns[9].Visible = false;
                ////btnSaveTarget.Enabled = true;

                try
                {
                    objSalesTargerDetailsManager.DeleteTempSalesTarget();

                    for (int i = 0; i <= dgvProductListForSalesTarget.RowCount - 1; i++)
                    {
                        if (Convert.ToBoolean(dgvProductListForSalesTarget.Rows[i].Cells[8].Value))
                        {
                            //MessageBox.Show(GlobalClass.FromDateForSalesTarget);
                            //MessageBox.Show(GlobalClass.ToDateForSalesTarget);
                            //MessageBox.Show(GlobalClass.GroupNameForSalesTarget);
                            //MessageBox.Show(GlobalClass.EmpDesignationForSalesTarget);
                            //MessageBox.Show(GlobalClass.EmpNameForSalesTarget);
                            //MessageBox.Show(GlobalClass.EmpIdForSalesTarget);
                            //MessageBox.Show(GlobalClass.EmpMobileNoForSalesTarget);
                            //MessageBox.Show(dgvProductListForSalesTarget.Rows[i].Cells[0].Value.ToString());
                            //MessageBox.Show(dgvProductListForSalesTarget.Rows[i].Cells[1].Value.ToString());
                            //MessageBox.Show(dgvProductListForSalesTarget.Rows[i].Cells[2].Value.ToString());
                            //MessageBox.Show(dgvProductListForSalesTarget.Rows[i].Cells[5].Value.ToString());
                            //MessageBox.Show(dgvProductListForSalesTarget.Rows[i].Cells[7].Value.ToString());
                            GlobalClass.OrderAmountForSalesTarget =
                                Convert.ToDecimal(dgvProductListForSalesTarget.Rows[i].Cells[5].Value.ToString()) *
                                Convert.ToInt32(dgvProductListForSalesTarget.Rows[i].Cells[7].Value.ToString());

                            GlobalClass.DivisionNameOfEmployeeForSalesTarget = txtEmpDivNameForSalesTarget.Text.ToString();
                               //Convert.ToString(objDivisionDetailsManager.GetDivisionNameBySelectedTeamAndEmplyoyee(cmbSelectGroupForSalesTarget.Text, cmbSelectEmployeeForSalesTarget.Text).ToString());
                            //MessageBox.Show(GlobalClass.OrderAmountForSalesTarget.ToString());

                            objSalesTargerDetailsManager.InsertTempSalesTarget(
                                GlobalClass.FromDateForSalesTarget.ToString(),
                                GlobalClass.ToDateForSalesTarget.ToString(),
                                Convert.ToInt32(dgvProductListForSalesTarget.Rows[i].Cells[0].Value.ToString()),
                                dgvProductListForSalesTarget.Rows[i].Cells[1].Value.ToString(),
                                dgvProductListForSalesTarget.Rows[i].Cells[2].Value.ToString(),
                                Convert.ToDecimal(dgvProductListForSalesTarget.Rows[i].Cells[5].Value.ToString()),
                                Convert.ToInt32(dgvProductListForSalesTarget.Rows[i].Cells[7].Value.ToString()),
                                Convert.ToDecimal(GlobalClass.OrderAmountForSalesTarget.ToString()),
                                Convert.ToInt32(GlobalClass.EmpIdForSalesTarget),
                                GlobalClass.EmpNameForSalesTarget.ToString(),
                                GlobalClass.EmpDesignationForSalesTarget.ToString(),
                                GlobalClass.EmpMobileNoForSalesTarget.ToString(),
                                GlobalClass.GroupNameForSalesTarget.ToString(),
                                GlobalClass.DivisionNameOfEmployeeForSalesTarget.ToString()
                                //GlobalClass.DivisionNameOfEmployeeForSalesTarget.ToString()
                                );
                        }
                    }
                }
                catch (Exception exp)
                {
                    MessageBox.Show(exp.Message);
                }
                finally
                {
                    dataGridViewSalesTarget.Visible = false;
                    dgvProductListForSalesTarget.Visible = false;
                    dgvPrevAddedSalesTargetDetails.Visible = false;
                    dgvSalesTargetDetails.Visible = true;
                    //dgvSalesTargetDetails.Location = new Point(380, 11);
                    //dgvSalesTargetDetails.Size = new Size(950, 585);
                    dgvSalesTargetDetails.Location = new Point(372, 10);
                    dgvSalesTargetDetails.Size = new Size(960, 585);
                    //dgvSalesTargetDetails.Size = new Size(950, 290);
                    dgvSalesTargetDetails.DataSource = objSalesTargerDetailsManager.ShowTempSalesTarget();
                    dgvSalesTargetDetails.Columns[0].Visible = false;
                    dgvSalesTargetDetails.Columns[3].Visible = false;
                    dgvSalesTargetDetails.Columns[9].Visible = false;
                    btnSaveTarget.Enabled = true;
                    
                    //objSmSapplication.loadTempSalesTarget();
                    //this.Close();
                }

            }
            else if (btnAddToList.Text == "Update List")
            {
                tmpFromDate = txtFromDate.Text.ToString();
                tmpToDate = txtToDate.Text.ToString();
                tmpProductID = Convert.ToInt32(txtProductIDForSalesTarget.Text.ToString());
                tmpProductCode = txtProductCodeForSalesTarget.Text.ToString();
                tmpProductName = txtProductNameForSalesTarget.Text.ToString();
                tmpProductPrice = Convert.ToDecimal(txtProductPriceForSalesTarget.Text.ToString());
                tmpSalesTargetUnit = Convert.ToInt32(txtTargetUnitForSalesTarget.Text.ToString());
                tmpSalesTargetAmount = Convert.ToDecimal(txtTargetAmountForSalesTarget.Text.ToString());
                tmpEmployeeID = Convert.ToInt32(txtEmployeeIDForSalesTarget.Text.ToString());
                tmpEmployeeName = cmbSelectEmployeeForSalesTarget.Text.ToString();
                tmpEmpDesignation = cmbSelectDesignationForSalesTarget.Text.ToString();
                tmpEmpOfficialCell = txtEmpMobileNoForSalesTarget.Text.ToString();
                tmpEmpGroupName = cmbSelectGroupForSalesTarget.Text.ToString();
                //GlobalClass.DivisionNameOfEmployeeForSalesTarget = txtEmpDivNameForSalesTarget.Text.ToString();
                tmpDivisionNane = objDivisionDetailsManager.GetDivisionNameBySelectedTeamAndEmplyoyee(tmpEmpGroupName, tmpEmployeeName).ToString();
                
                tmpSalesTargetID = Convert.ToInt32(GlobalClass.SalesTargetIdForUpdateSalesTarget);

                objSalesTargerDetailsManager.UpdateTempSalesTarget(tmpSalesTargetID, tmpFromDate, tmpToDate,
                    tmpProductID, tmpProductCode, tmpProductName,
                    tmpProductPrice, tmpSalesTargetUnit, tmpSalesTargetAmount, tmpEmployeeID, tmpEmployeeName,
                    tmpEmpDesignation,
                    tmpEmpOfficialCell, tmpEmpGroupName, tmpDivisionNane);

                ////dgvSalesDetails.DataSource = objSalesTargerDetailsManager.ShowAllSalesTarget();
                ////dgvSalesDetails.Columns[0].Visible = false;
                ////dgvSalesDetails.Columns[3].Visible = false;
                ////dgvSalesDetails.Columns[9].Visible = false;
                
                ////dgvSalesTargetDetails.DataSource = objSalesTargerDetailsManager.ShowTempSalesTarget();
                ////dgvSalesTargetDetails.Columns[0].Visible = false;
                ////dgvSalesTargetDetails.Columns[3].Visible = false;
                ////dgvSalesTargetDetails.Columns[9].Visible = false;
                
                dataGridViewSalesTarget.Visible = false;
                dgvProductListForSalesTarget.Visible = false;
                dgvPrevAddedSalesTargetDetails.Visible = false;
                dgvSalesTargetDetails.Visible = true;
                //dgvSalesTargetDetails.Location = new Point(380, 11);
                //dgvSalesTargetDetails.Size = new Size(950, 585);
                dgvSalesTargetDetails.Location = new Point(372, 10);
                dgvSalesTargetDetails.Size = new Size(960, 585);
                //dgvSalesTargetDetails.Size = new Size(950, 290);
                dgvSalesTargetDetails.DataSource = objSalesTargerDetailsManager.ShowTempSalesTarget();
                dgvSalesTargetDetails.Columns[0].Visible = false;
                dgvSalesTargetDetails.Columns[3].Visible = false;
                dgvSalesTargetDetails.Columns[9].Visible = false;
                //btnSaveTarget.Enabled = true;
                MessageBox.Show("List Updated Successfully.");

                btnAddToList.Text = "Add To List";
                btnAddTarget.Enabled = false;
                btnSaveTarget.Enabled = true;
            }
        }

        private void dgvSalesTargetDetails_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            btnSaveTarget.Enabled = false;

            if (btnAddToList.Text == "Add To List")
            {
                btnAddToList.Text = "Update List";
            }

            GlobalClass.SalesTargetDataGridViewValue = 2;
            GlobalClass.SalesTargetIdForUpdateSalesTarget = Convert.ToInt32(dgvSalesTargetDetails.CurrentRow.Cells[0].Value.ToString());

            if (txtFromDate.Enabled == false)
            {
                txtFromDate.Enabled = true;
            }

            if (dTPFromDate.Enabled == false)
            {
                dTPFromDate.Enabled = true;
            }

            if (txtToDate.Enabled == false)
            {
                txtToDate.Enabled = true;
            }

            if (dTPToDate.Enabled == false)
            {
                dTPToDate.Enabled = true;
            }

            if (btnBrowseProductCodeForSalesTarget.Enabled == false)
            {
                btnBrowseProductCodeForSalesTarget.Enabled = true;
            }

            if (cmbSelectGroupForSalesTarget.Enabled == false)
            {
                cmbSelectGroupForSalesTarget.Enabled = true;
            }

            if (cmbSelectDesignationForSalesTarget.Enabled == false)
            {
                cmbSelectDesignationForSalesTarget.Enabled = true;
            }

            if (cmbSelectEmployeeForSalesTarget.Enabled == false)
            {
                cmbSelectEmployeeForSalesTarget.Enabled = true;
            }

            if (txtTargetUnitForSalesTarget.Enabled == false)
            {
                txtTargetUnitForSalesTarget.Enabled = true;
            }

            //txtDOB.Text = dobOfEmp.Replace("12:00:00 AM", "");
            //txtDOB.Text = txtDOB.Text.Trim();
            txtFromDate.Text = dgvSalesTargetDetails.CurrentRow.Cells[1].Value.ToString();
            txtFromDate.Text = txtFromDate.Text.Replace("12:00:00 AM", "");
            txtFromDate.Text = txtFromDate.Text.Trim();
            txtToDate.Text = dgvSalesTargetDetails.CurrentRow.Cells[2].Value.ToString();
            txtToDate.Text = txtToDate.Text.Replace("12:00:00 AM", "");
            txtToDate.Text = txtToDate.Text.Trim();
            txtProductCodeForSalesTarget.Text = dgvSalesTargetDetails.CurrentRow.Cells[4].Value.ToString();
            txtProductIDForSalesTarget.Text = dgvSalesTargetDetails.CurrentRow.Cells[3].Value.ToString();
            txtProductNameForSalesTarget.Text = dgvSalesTargetDetails.CurrentRow.Cells[5].Value.ToString();
            txtProductPriceForSalesTarget.Text = dgvSalesTargetDetails.CurrentRow.Cells[6].Value.ToString();
            cmbSelectGroupForSalesTarget.Text = dgvSalesTargetDetails.CurrentRow.Cells[13].Value.ToString();
            cmbSelectDesignationForSalesTarget.Text = dgvSalesTargetDetails.CurrentRow.Cells[11].Value.ToString();
            cmbSelectEmployeeForSalesTarget.Text = dgvSalesTargetDetails.CurrentRow.Cells[10].Value.ToString();
            txtEmployeeIDForSalesTarget.Text = dgvSalesTargetDetails.CurrentRow.Cells[9].Value.ToString();
            txtEmpMobileNoForSalesTarget.Text = dgvSalesTargetDetails.CurrentRow.Cells[12].Value.ToString();
            txtTargetUnitForSalesTarget.Text = dgvSalesTargetDetails.CurrentRow.Cells[7].Value.ToString();
            txtTargetAmountForSalesTarget.Text = dgvSalesTargetDetails.CurrentRow.Cells[8].Value.ToString();

            if (cmbSelectGroupForSalesTarget.Enabled == false)
            {
                cmbSelectGroupForSalesTarget.Enabled = true;
            }
            cmbSelectGroupForSalesTarget.DataSource = objGroupDetailsGateway.LoadSelectGroupForGroupSetup();
            cmbSelectGroupForSalesTarget.DisplayMember = "Group_Name";
            cmbSelectGroupForSalesTarget.ValueMember = "Group_Name";
            //cmbSelectGroupForSalesTarget.Text = dataGridViewSalesTarget.CurrentRow.Cells[13].Value.ToString();
            cmbSelectGroupForSalesTarget.Text = dgvSalesTargetDetails.CurrentRow.Cells[13].Value.ToString(); ;

            if (cmbSelectDesignationForSalesTarget.Enabled == false)
            {
                cmbSelectDesignationForSalesTarget.Enabled = true;
            }
            cmbSelectDesignationForSalesTarget.DataSource = objDesignationDetailsManager.LoadDesignationCombo();
            cmbSelectDesignationForSalesTarget.DisplayMember = "Designation";
            cmbSelectDesignationForSalesTarget.ValueMember = "Designation";
            //cmbSelectDesignationForSalesTarget.Text = dataGridViewSalesTarget.CurrentRow.Cells[11].Value.ToString();
            cmbSelectDesignationForSalesTarget.Text = dgvSalesTargetDetails.CurrentRow.Cells[11].Value.ToString(); ;

            if (cmbSelectEmployeeForSalesTarget.Enabled == false)
            {
                cmbSelectEmployeeForSalesTarget.Enabled = true;
            }

            if (cmbSelectGroupForSalesTarget.Text != "" && cmbSelectDesignationForSalesTarget.Text != "")
            {
                cmbSelectEmployeeForSalesTarget.DataSource =
                    objEmployeeDetailsManager.LoadEmployeeBySelectedGroupAndDesignation(cmbSelectGroupForSalesTarget.Text.ToString(), cmbSelectDesignationForSalesTarget.Text.ToString());
                cmbSelectEmployeeForSalesTarget.DisplayMember = "Employee_Name";
                cmbSelectEmployeeForSalesTarget.ValueMember = "Employee_Name";
            }
            //cmbSelectEmployeeForSalesTarget.DataSource = objEmployeeDetailsManager.LoadEmployeeBySelectedGroupAndDesignation();
            cmbSelectEmployeeForSalesTarget.Text = dgvSalesTargetDetails.CurrentRow.Cells[10].Value.ToString();
        }

        private void btnSaveList_Click(object sender, EventArgs e)
        {
            //MessageBox.Show("Product List Added Successfully.");
            //btnSaveTarget.Enabled = true;
            //btnAddToList.Enabled = false;
            //btnAddTarget.Enabled = false;
            //btnSaveTarget.Focus();
        }

        private void txtProductPriceForSalesTarget_TextChanged_1(object sender, EventArgs e)
        {
            if (txtTargetUnitForSalesTarget.Text != "" && txtTargetAmountForSalesTarget.Text != "" && txtProductPriceForSalesTarget.Text != "")
            {
                int targetUnit;
                float productPrice;
                float totalAmount;

                targetUnit = Int32.Parse(txtTargetUnitForSalesTarget.Text); //Convert.ToInt32(txtTargetUnitForSalesTarget.Text.ToString());
                productPrice = float.Parse(txtProductPriceForSalesTarget.Text);// Convert.ToDecimal(txtProductPriceForSalesTarget.Text.ToString());
                totalAmount = productPrice * targetUnit;
                txtTargetAmountForSalesTarget.Text = totalAmount.ToString();
            }
        }

        private void dgvProductListForSalesTarget_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                if (e.KeyChar == (char)Keys.F2)
                {
                    if (dgvProductListForSalesTarget.CurrentCell.OwningColumn.HeaderText == "Order QTY" ||
                        dgvProductListForSalesTarget.CurrentCell.OwningColumn.HeaderText == "Check to Insert")
                    {
                        dgvProductListForSalesTarget.BeginEdit(true);
                    }
                }
                //else if (e.KeyChar == (char) Keys.Enter)
                //{
                //    if (dgvProductListForSalesTarget.CurrentCell.OwningColumn.HeaderText == "Order QTY" ||
                //        dgvProductListForSalesTarget.CurrentCell.OwningColumn.HeaderText == "Check to Insert")
                //    {
                //        dgvProductListForSalesTarget.BeginEdit(true);
                //    }
                //}
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }

        private void btnAddMarketSetup_Click(object sender, EventArgs e)
        {
            //if (cmbSelectMarketForMarketSetup.Enabled == false)
            //{
            //    cmbSelectMarketForMarketSetup.Enabled = true;
            //}

            txtGroupIDForMarketSetup.Text = "";

            if (cmbSelectGroupForMarketSetup.Enabled == false)
            {
                cmbSelectGroupForMarketSetup.Enabled = true;
            }

            if (cmbSelectDevisionForMarketSetup.Enabled == false)
            {
                cmbSelectDevisionForMarketSetup.Enabled = true;
            }

            if (cmbSelectEmployeeForMarketSetup.Enabled == false)
            {
                cmbSelectEmployeeForMarketSetup.Enabled = true;
            }

            if (btnSaveMarketSetup.Text == "Update Market Setup")
            {
                btnSaveMarketSetup.Text = "Save Market Setup";
            }

            btnSaveMarketSetup.Enabled = true;
            //cmbSelectMarketForMarketSetup.DataSource = objMarketDetailsManager.LoadAllMarket();
            //cmbSelectMarketForMarketSetup.DisplayMember = "Market_Code";
            //cmbSelectMarketForMarketSetup.ValueMember = "Market_Code";
            //cmbSelectMarketForMarketSetup.Text = "Select Market";

            cmbSelectGroupForMarketSetup.DataSource = objGroupDetailsManager.LoadSelectGroupCombo();
            cmbSelectGroupForMarketSetup.Text = "Select Team";
            cmbSelectGroupForMarketSetup.DisplayMember = "Group_Name";
            cmbSelectGroupForMarketSetup.ValueMember = "Group_Name";
            
            cmbSelectGroupForMarketSetup.Text = "Select Team";
            cmbSelectDevisionForMarketSetup.Text = "Select Division";
            cmbSelectEmployeeForMarketSetup.Text = "Select Employee";
            txtGroupIDForMarketSetup.Text = "";

            btnSaveMarketSetup.Enabled = true;
            cmbSelectGroupForMarketSetup.Focus();
        }

        private void btnAddDivision_Click(object sender, EventArgs e)
        {
            ClearDivision();
            
            if (cmbSelectTeam.Enabled == false)
            {
                cmbSelectTeam.Enabled = true;
            }

            cmbSelectTeam.DataSource = objGroupDetailsManager.LoadSelectGroupCombo();
            cmbSelectTeam.DisplayMember = "Group_Name";
            cmbSelectTeam.ValueMember = "Group_Name";
            cmbSelectTeam.Text = "Select Team";
            txtTeamIDForDivision.Text = "";

            if (txtDivisionName.Enabled == false)
            {
                txtDivisionName.Enabled = true;
            }

            if (cmbActiveForDivision.Enabled == false)
            {
                cmbActiveForDivision.Enabled = true;
            }

            if (btnSaveDivision.Text == "Update Division")
            {
                btnSaveDivision.Text = "Save Division";
            }

            if (btnSaveDivision.Enabled == false)
            {
                btnSaveDivision.Enabled = true;
            }

            if (btnLoadGroup.Enabled == false)
            {
                btnLoadGroup.Enabled = true;
            }

            if (btnAddToTempDivision.Enabled == false)
            {
                btnAddToTempDivision.Enabled = true;
            }

            btnLoadSM.Visible = false;
            btnLoadASM.Visible = false;
            btnLoadTSM.Visible = false;
            btnLoadTSM.Visible = false;
            btnLoadGroup.Enabled = true;
            btnAddToTempDivision.Enabled = true;

            //24-May-2016 "btnAddOrEditDataOfPrevDivision" not completed so "btnAddOrEditDataOfPrevDivision" is hidden......
            //btnAddOrEditDataOfPrevDivision.Visible = false;
            //24-May-2016 "btnAddOrEditDataOfPrevDivision" not completed

            cmbSelectTeam.Focus();
        }

        public void ClearDivision()
        {
            cmbSelectTeam.Text = "Select Team";
            cmbSelectTeam.Enabled = false;
            txtTeamIDForDivision.Text = "";
            txtDivisionName.Text = "";
            cmbSelectDOForDivision.Text = "Select DO";
            cmbSelectDOForDivision.Enabled = false;
            cmbSelectGMForDivision.Text = "Select GM";
            cmbSelectGMForDivision.Enabled = false;
            cmbSelectDGMForDivision.Text = "Select DGM";
            cmbSelectDGMForDivision.Enabled = false;
            cmbSelectDMForDivision.Text = "Select DM";
            cmbSelectDMForDivision.Enabled = false;
            cmbSelectSMForDivision.Text = "Select SM";
            cmbSelectSMForDivision.Enabled = false;
            cmbSelectASMForDivision.Text = "Select ASM";
            cmbSelectASMForDivision.Enabled = false;
            cmbSelectTSMForDivision.Text = "Select TSM";
            cmbSelectTSMForDivision.Enabled = false;
            cmbSelectSRForDivision.Text = "Select SR";
            cmbSelectSRForDivision.Enabled = false;
            cmbSelectRSMForDivision.Text = "Select RSM";
            cmbSelectRSMForDivision.Enabled = false;
            cmbActiveForDivision.Text = "Select Active";
            cmbActiveForDivision.Enabled = false;
            if (btnSaveDivision.Text == "Update Division")
            {
                btnSaveDivision.Text = "Save Division";
            }
            cmbSelectDivisionForUpdate.Text = "Select Division";
            //txtEnableDisableFormValueForReloadDivisionGrid.Text = "0";
        }

        private void cmbSelectTeam_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (btnSaveDivision.Text == "Save Division")
            {
                this.txtTeamIDForDivision.Text = objGroupDetailsManager.GetGroupID(cmbSelectTeam.Text);
                //cmbSelectDOForDivision.DataSource = objEmployeeDetailsManager.LoadDO(cmbSelectTeam.Text);
                //cmbSelectDOForDivision.DisplayMember = "Employee_Name";
                //cmbSelectDOForDivision.ValueMember = "Employee_Name";
            }
            else if (btnSaveDivision.Text == "Update Division")
            {
                CheckDesignation();

                this.txtTeamIDForDivision.Text = objGroupDetailsManager.GetGroupID(cmbSelectTeam.Text);

                if (cmbSelectDOForDivision.Visible == true && GlobalClass.EmpDesiForUpdateDivision == "DO")
                {
                    cmbSelectDOForDivision.Enabled = true;
                    cmbSelectDOForDivision.DataSource =
                        objEmployeeDetailsManager.LoadEmployeeForDivisionBySelectedGroupAndDesignation(
                            cmbSelectTeam.Text.ToString(), GlobalClass.EmpDesiForUpdateDivision.ToString());
                    cmbSelectDOForDivision.DisplayMember = "Employee_Name";
                    cmbSelectDOForDivision.ValueMember = "Employee_Name";
                    cmbSelectDOForDivision.Text = GlobalClass.EmpNameForUpdateDivision;
                }

                else if (cmbSelectDMForDivision.Visible = true && GlobalClass.EmpDesiForUpdateDivision == "DM")
                {
                    cmbSelectDMForDivision.Enabled = true;
                    cmbSelectDMForDivision.DataSource =
                        objEmployeeDetailsManager.LoadEmployeeForDivisionBySelectedGroupAndDesignation(
                            cmbSelectTeam.Text.ToString(), GlobalClass.EmpDesiForUpdateDivision.ToString());
                    cmbSelectDMForDivision.DisplayMember = "Employee_Name";
                    cmbSelectDMForDivision.ValueMember = "Employee_Name";
                    cmbSelectDMForDivision.Text = GlobalClass.EmpNameForUpdateDivision;
                }

                else if (cmbSelectASMForDivision.Visible = true && GlobalClass.EmpDesiForUpdateDivision == "ASM")
                {
                    cmbSelectASMForDivision.Enabled = true;
                    cmbSelectASMForDivision.DataSource =
                        objEmployeeDetailsManager.LoadEmployeeForDivisionBySelectedGroupAndDesignation(
                            cmbSelectTeam.Text.ToString(), GlobalClass.EmpDesiForUpdateDivision.ToString());
                    cmbSelectASMForDivision.DisplayMember = "Employee_Name";
                    cmbSelectASMForDivision.ValueMember = "Employee_Name";
                    cmbSelectASMForDivision.Text = GlobalClass.EmpNameForUpdateDivision;
                }

                else if (cmbSelectTSMForDivision.Visible = true && GlobalClass.EmpDesiForUpdateDivision == "TSM")
                {
                    cmbSelectTSMForDivision.Enabled = true;
                    cmbSelectTSMForDivision.DataSource =
                        objEmployeeDetailsManager.LoadEmployeeForDivisionBySelectedGroupAndDesignation(
                            cmbSelectTeam.Text.ToString(), GlobalClass.EmpDesiForUpdateDivision.ToString());
                    cmbSelectTSMForDivision.DisplayMember = "Employee_Name";
                    cmbSelectTSMForDivision.ValueMember = "Employee_Name";
                    cmbSelectTSMForDivision.Text = GlobalClass.EmpNameForUpdateDivision;
                }

                else if (cmbSelectSRForDivision.Visible = true && GlobalClass.EmpDesiForUpdateDivision == "SR")
                {
                    cmbSelectSRForDivision.Enabled = true;
                    cmbSelectSRForDivision.DataSource =
                        objEmployeeDetailsManager.LoadEmployeeForDivisionBySelectedGroupAndDesignation(
                            cmbSelectTeam.Text.ToString(), GlobalClass.EmpDesiForUpdateDivision.ToString());
                    cmbSelectSRForDivision.DisplayMember = "Employee_Name";
                    cmbSelectSRForDivision.ValueMember = "Employee_Name";
                    cmbSelectSRForDivision.Text = GlobalClass.EmpNameForUpdateDivision;
                }

                else if (cmbSelectRSMForDivision.Visible = true && GlobalClass.EmpDesiForUpdateDivision == "RSM")
                {
                    cmbSelectRSMForDivision.Enabled = true;
                    cmbSelectRSMForDivision.DataSource =
                        objEmployeeDetailsManager.LoadEmployeeForDivisionBySelectedGroupAndDesignation(
                            cmbSelectTeam.Text.ToString(), GlobalClass.EmpDesiForUpdateDivision.ToString());
                    cmbSelectRSMForDivision.DisplayMember = "Employee_Name";
                    cmbSelectRSMForDivision.ValueMember = "Employee_Name";
                    cmbSelectRSMForDivision.Text = GlobalClass.EmpNameForUpdateDivision;
                }
            }

            CheckDesignation();
        }

        private void cmbSelectTeam_SelectedValueChanged(object sender, EventArgs e)
        {
            if (btnSaveDivision.Text == "Save Division")
            {
                this.txtTeamIDForDivision.Text = objGroupDetailsManager.GetGroupID(cmbSelectTeam.Text);
                //cmbSelectDOForDivision.DataSource = objEmployeeDetailsManager.LoadDO(cmbSelectTeam.Text);
                //cmbSelectDOForDivision.DisplayMember = "Employee_Name";
                //cmbSelectDOForDivision.ValueMember = "Employee_Name";
            }
            else if (btnSaveDivision.Text == "Update Division")
            {
                CheckDesignation();

                this.txtTeamIDForDivision.Text = objGroupDetailsManager.GetGroupID(cmbSelectTeam.Text);

                if (cmbSelectDOForDivision.Visible == true && GlobalClass.EmpDesiForUpdateDivision == "DO")
                {
                    cmbSelectDOForDivision.Enabled = true;
                    cmbSelectDOForDivision.DataSource =
                        objEmployeeDetailsManager.LoadEmployeeForDivisionBySelectedGroupAndDesignation(
                            cmbSelectTeam.Text.ToString(), GlobalClass.EmpDesiForUpdateDivision.ToString());
                    cmbSelectDOForDivision.DisplayMember = "Employee_Name";
                    cmbSelectDOForDivision.ValueMember = "Employee_Name";
                    cmbSelectDOForDivision.Text = GlobalClass.EmpNameForUpdateDivision;
                }

                else if (cmbSelectDMForDivision.Visible = true && GlobalClass.EmpDesiForUpdateDivision == "DM")
                {
                    cmbSelectDMForDivision.Enabled = true;
                    cmbSelectDMForDivision.DataSource =
                        objEmployeeDetailsManager.LoadEmployeeForDivisionBySelectedGroupAndDesignation(
                            cmbSelectTeam.Text.ToString(), GlobalClass.EmpDesiForUpdateDivision.ToString());
                    cmbSelectDMForDivision.DisplayMember = "Employee_Name";
                    cmbSelectDMForDivision.ValueMember = "Employee_Name";
                    cmbSelectDMForDivision.Text = GlobalClass.EmpNameForUpdateDivision;
                }

                else if (cmbSelectASMForDivision.Visible = true && GlobalClass.EmpDesiForUpdateDivision == "ASM")
                {
                    cmbSelectASMForDivision.Enabled = true;
                    cmbSelectASMForDivision.DataSource =
                        objEmployeeDetailsManager.LoadEmployeeForDivisionBySelectedGroupAndDesignation(
                            cmbSelectTeam.Text.ToString(), GlobalClass.EmpDesiForUpdateDivision.ToString());
                    cmbSelectASMForDivision.DisplayMember = "Employee_Name";
                    cmbSelectASMForDivision.ValueMember = "Employee_Name";
                    cmbSelectASMForDivision.Text = GlobalClass.EmpNameForUpdateDivision;
                }

                else if (cmbSelectTSMForDivision.Visible = true && GlobalClass.EmpDesiForUpdateDivision == "TSM")
                {
                    cmbSelectTSMForDivision.Enabled = true;
                    cmbSelectTSMForDivision.DataSource =
                        objEmployeeDetailsManager.LoadEmployeeForDivisionBySelectedGroupAndDesignation(
                            cmbSelectTeam.Text.ToString(), GlobalClass.EmpDesiForUpdateDivision.ToString());
                    cmbSelectTSMForDivision.DisplayMember = "Employee_Name";
                    cmbSelectTSMForDivision.ValueMember = "Employee_Name";
                    cmbSelectTSMForDivision.Text = GlobalClass.EmpNameForUpdateDivision;
                }

                else if (cmbSelectSRForDivision.Visible = true && GlobalClass.EmpDesiForUpdateDivision == "SR")
                {
                    cmbSelectSRForDivision.Enabled = true;
                    cmbSelectSRForDivision.DataSource =
                        objEmployeeDetailsManager.LoadEmployeeForDivisionBySelectedGroupAndDesignation(
                            cmbSelectTeam.Text.ToString(), GlobalClass.EmpDesiForUpdateDivision.ToString());
                    cmbSelectSRForDivision.DisplayMember = "Employee_Name";
                    cmbSelectSRForDivision.ValueMember = "Employee_Name";
                    cmbSelectSRForDivision.Text = GlobalClass.EmpNameForUpdateDivision;
                }

                else if (cmbSelectRSMForDivision.Visible = true && GlobalClass.EmpDesiForUpdateDivision == "RSM")
                {
                    cmbSelectRSMForDivision.Enabled = true;
                    cmbSelectRSMForDivision.DataSource =
                        objEmployeeDetailsManager.LoadEmployeeForDivisionBySelectedGroupAndDesignation(
                            cmbSelectTeam.Text.ToString(), GlobalClass.EmpDesiForUpdateDivision.ToString());
                    cmbSelectRSMForDivision.DisplayMember = "Employee_Name";
                    cmbSelectRSMForDivision.ValueMember = "Employee_Name";
                    cmbSelectRSMForDivision.Text = GlobalClass.EmpNameForUpdateDivision;
                }
            }

            CheckDesignation();
        }

        private void cmbSelectTeam_TextChanged(object sender, EventArgs e)
        {
            if (btnSaveDivision.Text == "Save Division")
            {
                this.txtTeamIDForDivision.Text = objGroupDetailsManager.GetGroupID(cmbSelectTeam.Text);
                //cmbSelectDOForDivision.DataSource = objEmployeeDetailsManager.LoadDO(cmbSelectTeam.Text);
                //cmbSelectDOForDivision.DisplayMember = "Employee_Name";
                //cmbSelectDOForDivision.ValueMember = "Employee_Name";
            }
            else if (btnSaveDivision.Text == "Update Division")
            {
                CheckDesignation();

                this.txtTeamIDForDivision.Text = objGroupDetailsManager.GetGroupID(cmbSelectTeam.Text);

                if (cmbSelectDOForDivision.Visible == true && GlobalClass.EmpDesiForUpdateDivision == "DO")
                {
                    cmbSelectDOForDivision.Enabled = true;
                    cmbSelectDOForDivision.DataSource =
                        objEmployeeDetailsManager.LoadEmployeeForDivisionBySelectedGroupAndDesignation(
                            cmbSelectTeam.Text.ToString(), GlobalClass.EmpDesiForUpdateDivision.ToString());
                    cmbSelectDOForDivision.DisplayMember = "Employee_Name";
                    cmbSelectDOForDivision.ValueMember = "Employee_Name";
                    cmbSelectDOForDivision.Text = GlobalClass.EmpNameForUpdateDivision;
                }

                else if (cmbSelectDMForDivision.Visible = true && GlobalClass.EmpDesiForUpdateDivision == "DM")
                {
                    cmbSelectDMForDivision.Enabled = true;
                    cmbSelectDMForDivision.DataSource =
                        objEmployeeDetailsManager.LoadEmployeeForDivisionBySelectedGroupAndDesignation(
                            cmbSelectTeam.Text.ToString(), GlobalClass.EmpDesiForUpdateDivision.ToString());
                    cmbSelectDMForDivision.DisplayMember = "Employee_Name";
                    cmbSelectDMForDivision.ValueMember = "Employee_Name";
                    cmbSelectDMForDivision.Text = GlobalClass.EmpNameForUpdateDivision;
                }

                else if (cmbSelectASMForDivision.Visible = true && GlobalClass.EmpDesiForUpdateDivision == "ASM")
                {
                    cmbSelectASMForDivision.Enabled = true;
                    cmbSelectASMForDivision.DataSource =
                        objEmployeeDetailsManager.LoadEmployeeForDivisionBySelectedGroupAndDesignation(
                            cmbSelectTeam.Text.ToString(), GlobalClass.EmpDesiForUpdateDivision.ToString());
                    cmbSelectASMForDivision.DisplayMember = "Employee_Name";
                    cmbSelectASMForDivision.ValueMember = "Employee_Name";
                    cmbSelectASMForDivision.Text = GlobalClass.EmpNameForUpdateDivision;
                }

                else if (cmbSelectTSMForDivision.Visible = true && GlobalClass.EmpDesiForUpdateDivision == "TSM")
                {
                    cmbSelectTSMForDivision.Enabled = true;
                    cmbSelectTSMForDivision.DataSource =
                        objEmployeeDetailsManager.LoadEmployeeForDivisionBySelectedGroupAndDesignation(
                            cmbSelectTeam.Text.ToString(), GlobalClass.EmpDesiForUpdateDivision.ToString());
                    cmbSelectTSMForDivision.DisplayMember = "Employee_Name";
                    cmbSelectTSMForDivision.ValueMember = "Employee_Name";
                    cmbSelectTSMForDivision.Text = GlobalClass.EmpNameForUpdateDivision;
                }

                else if (cmbSelectSRForDivision.Visible = true && GlobalClass.EmpDesiForUpdateDivision == "SR")
                {
                    cmbSelectSRForDivision.Enabled = true;
                    cmbSelectSRForDivision.DataSource =
                        objEmployeeDetailsManager.LoadEmployeeForDivisionBySelectedGroupAndDesignation(
                            cmbSelectTeam.Text.ToString(), GlobalClass.EmpDesiForUpdateDivision.ToString());
                    cmbSelectSRForDivision.DisplayMember = "Employee_Name";
                    cmbSelectSRForDivision.ValueMember = "Employee_Name";
                    cmbSelectSRForDivision.Text = GlobalClass.EmpNameForUpdateDivision;
                }

                else if (cmbSelectRSMForDivision.Visible = true && GlobalClass.EmpDesiForUpdateDivision == "RSM")
                {
                    cmbSelectRSMForDivision.Enabled = true;
                    cmbSelectRSMForDivision.DataSource =
                        objEmployeeDetailsManager.LoadEmployeeForDivisionBySelectedGroupAndDesignation(
                            cmbSelectTeam.Text.ToString(), GlobalClass.EmpDesiForUpdateDivision.ToString());
                    cmbSelectRSMForDivision.DisplayMember = "Employee_Name";
                    cmbSelectRSMForDivision.ValueMember = "Employee_Name";
                    cmbSelectRSMForDivision.Text = GlobalClass.EmpNameForUpdateDivision;
                }
            }

            CheckDesignation();
        }

        private void btnLoadGroup_Click(object sender, EventArgs e)
        {
            DataGridViewCheckBoxColumn checkBoxColumnEmpSelected = new DataGridViewCheckBoxColumn();
            //DataGridViewCheckBoxColumn checkBoxColumnEmpActive = new DataGridViewCheckBoxColumn();

            objDivisionDetailsManager.DeleteTempDivision();

            dgvDivision.Visible = false;
            dgvLoadDistinctDivision.Visible = false;
            dgvLoadGroup.Visible = true;
            
            dgvLoadGroup.Columns.Clear();
            while (dgvLoadGroup.Columns.Count >= 1)
            {
                dgvLoadGroup.Columns.RemoveAt(0);
            }

            dgvLoadGroup.DataSource = objEmployeeDetailsManager.GetEmpList(cmbSelectTeam.Text);
            //MessageBox.Show(objEmployeeDetailsManager.GetEmpList(cmbSelectTeam.Text).Rows.Count.ToString());
            if (objEmployeeDetailsManager.GetEmpList(cmbSelectTeam.Text).Rows.Count > 0)
            {
                dgvLoadGroup.Visible = true;
                dgvLoadGroup.Location = new Point(372, 10);
                dgvLoadGroup.Size = new Size(960, 290);
                dgvLoadGroup.Columns[0].Visible = false;
                dgvLoadGroup.Columns[2].Visible = false;
                dgvLoadGroup.Columns[3].Visible = false;
                dgvLoadGroup.Columns[4].Visible = false;
                dgvLoadGroup.Columns[6].Visible = false;
                dgvLoadGroup.Columns[7].Visible = false;
                dgvLoadGroup.Columns[9].Visible = false;
                dgvLoadGroup.Columns[10].Visible = false;
                dgvLoadGroup.Columns[11].Visible = false;
                dgvLoadGroup.Columns[12].Visible = false;
                dgvLoadGroup.Columns[13].Visible = false;
                dgvLoadGroup.Columns[14].Visible = false;
                dgvLoadGroup.Columns[15].Visible = false;

                dgvLoadGroup.Columns[1].ReadOnly = true;
                dgvLoadGroup.Columns[5].ReadOnly = true;
                dgvLoadGroup.Columns[8].ReadOnly = true;

                dgvLoadGroup.Columns.Insert(16, checkBoxColumnEmpSelected);
                checkBoxColumnEmpSelected.Name = "checkBoxColumnEmpSelected";
                checkBoxColumnEmpSelected.HeaderText = "Select Emp";
                checkBoxColumnEmpSelected.ReadOnly = false;

                //dgvLoadGroup.Columns.Insert(17, checkBoxColumnEmpActive);
                //checkBoxColumnEmpActive.Name = "checkBoxColumnEmpActive";
                //checkBoxColumnEmpActive.HeaderText = "Check to Active";
                //checkBoxColumnEmpActive.ReadOnly = false;

                //dgvPrevAddedSalesTargetDetails.Location = new Point(372, 10);
                //dgvPrevAddedSalesTargetDetails.Size = new Size(950, 290);
                //dgvPrevAddedSalesTargetDetails.Size = new Size(960, 290);
                dgvLoadGroup.Focus();
            }
        }

        private void btnAddToTempDivision_Click(object sender, EventArgs e)
        {
            if (txtDivisionName.Text == "")
            {
                MessageBox.Show("Division Name can't be blank.");
                txtDivisionName.Focus();
            }
            else if (cmbActiveForDivision.Text == "")
            {
                MessageBox.Show("Active can't be blank.");
                cmbActiveForDivision.Focus();
            }
            else
            {
                int tmpDivisionID;
                string tmpDivisionName;
                string tmpGroupName;
                int tmpGroupID;
                string tmpDivisionActive;

                if (btnAddToTempDivision.Text == "Add to List")
                {
                    try
                    {
                        objDivisionDetailsManager.DeleteTempDivision();
                        for (int i = 0; i <= dgvLoadGroup.RowCount - 1; i++)
                        {
                            if (Convert.ToBoolean(dgvLoadGroup.Rows[i].Cells[16].Value))//&& Convert.ToBoolean(dgvProductListForSalesTarget.Rows[i].Cells[17].Value)
                            {
                                tmpDivisionName = txtDivisionName.Text;
                                tmpGroupName = cmbSelectTeam.Text;
                                tmpGroupID = Convert.ToInt16(txtTeamIDForDivision.Text);
                                tmpDivisionActive = cmbActiveForDivision.Text;
                                objDivisionDetailsManager.InsertTempDivision(
                                    tmpDivisionName.ToString(),
                                    tmpGroupName.ToString(),
                                    tmpGroupID,
                                    dgvLoadGroup.Rows[i].Cells["Employee_Name"].Value.ToString(),
                                    dgvLoadGroup.Rows[i].Cells["Designation"].Value.ToString(),
                                    tmpDivisionActive.ToString()
                                    );
                            }
                        }
                    }
                    catch (Exception exp)
                    {
                        MessageBox.Show(exp.Message);
                    }
                    finally
                    {
                        dgvDivision.Visible = false;
                        dgvLoadTempDivision.Visible = true;
                        //dgvLoadTempDivision.Location = new Point(372,330);
                        //dgvLoadTempDivision.Size = new Size(960, 290);

                        dgvLoadTempDivision.Location = new Point(372, 420);
                        dgvLoadTempDivision.Size = new Size(960, 190);
                        dgvLoadTempDivision.DataSource = objDivisionDetailsManager.ShowTempDivision();
                        dgvLoadTempDivision.Columns[0].Visible = false;
                        dgvLoadTempDivision.Columns[3].Visible = false;
                    }

                }
                else if (btnAddToTempDivision.Text == "Update List")
                {
                    //tmpFromDate = txtFromDate.Text.ToString();
                    //tmpToDate = txtToDate.Text.ToString();
                    //tmpProductID = Convert.ToInt32(txtProductIDForSalesTarget.Text.ToString());
                    //tmpProductCode = txtProductCodeForSalesTarget.Text.ToString();
                    //tmpProductName = txtProductNameForSalesTarget.Text.ToString();
                    //tmpProductPrice = Convert.ToDecimal(txtProductPriceForSalesTarget.Text.ToString());
                    //tmpSalesTargetUnit = Convert.ToInt32(txtTargetUnitForSalesTarget.Text.ToString());
                    //tmpSalesTargetAmount = Convert.ToDecimal(txtTargetAmountForSalesTarget.Text.ToString());
                    //tmpEmployeeID = Convert.ToInt32(txtEmployeeIDForSalesTarget.Text.ToString());
                    //tmpEmployeeName = cmbSelectEmployeeForSalesTarget.Text.ToString();
                    //tmpEmpDesignation = cmbSelectDesignationForSalesTarget.Text.ToString();
                    //tmpEmpOfficialCell = txtEmpMobileNoForSalesTarget.Text.ToString();
                    //tmpEmpGroupName = cmbSelectGroupForSalesTarget.Text.ToString();

                    //tmpSalesTargetID = Convert.ToInt32(GlobalClass.SalesTargetIdForUpdateSalesTarget);

                    //objSalesTargerDetailsManager.UpdateTempSalesTarget(tmpSalesTargetID, tmpFromDate, tmpToDate,
                    //    tmpProductID, tmpProductCode, tmpProductName,
                    //    tmpProductPrice, tmpSalesTargetUnit, tmpSalesTargetAmount, tmpEmployeeID, tmpEmployeeName,
                    //    tmpEmpDesignation,
                    //    tmpEmpOfficialCell, tmpEmpGroupName);

                    //////dgvSalesDetails.DataSource = objSalesTargerDetailsManager.ShowAllSalesTarget();
                    //////dgvSalesDetails.Columns[0].Visible = false;
                    //////dgvSalesDetails.Columns[3].Visible = false;
                    //////dgvSalesDetails.Columns[9].Visible = false;

                    //////dgvSalesTargetDetails.DataSource = objSalesTargerDetailsManager.ShowTempSalesTarget();
                    //////dgvSalesTargetDetails.Columns[0].Visible = false;
                    //////dgvSalesTargetDetails.Columns[3].Visible = false;
                    //////dgvSalesTargetDetails.Columns[9].Visible = false;

                    //dataGridViewSalesTarget.Visible = false;
                    //dgvProductListForSalesTarget.Visible = false;
                    //dgvPrevAddedSalesTargetDetails.Visible = false;
                    //dgvSalesTargetDetails.Visible = true;
                    ////dgvSalesTargetDetails.Location = new Point(380, 11);-
                    ////dgvSalesTargetDetails.Size = new Size(950, 585);
                    //dgvSalesTargetDetails.Location = new Point(372, 10);
                    //dgvSalesTargetDetails.Size = new Size(960, 585);
                    ////dgvSalesTargetDetails.Size = new Size(950, 290);
                    //dgvSalesTargetDetails.DataSource = objSalesTargerDetailsManager.ShowTempSalesTarget();
                    //dgvSalesTargetDetails.Columns[0].Visible = false;
                    //dgvSalesTargetDetails.Columns[3].Visible = false;
                    //dgvSalesTargetDetails.Columns[9].Visible = false;
                    ////btnSaveTarget.Enabled = true;
                    MessageBox.Show("Under Process......");

                    //btnAddToList.Text = "Add To List";
                    //btnAddTarget.Enabled = false;
                    //btnSaveTarget.Enabled = true;
                }
            }
        }

        private void btnSaveDivision_Click(object sender, EventArgs e)
        {
            int tmpDivisionID;
            string tmpDivisionName;
            string tmpGroupName;
            int tmpGroupID;
            string tmpEmpName;
            string tmpEmpDesig;
            string tmpDivisionActive;

            if (btnSaveDivision.Text == "Save Division")
            {
                if (objDivisionDetailsManager.ShowTempDivision().Rows.Count > 0)
                {
                    try
                    {
                        objDivisionDetailsManager.InsertDivision_New();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
                objDivisionDetailsManager.DeleteTempDivision();
                dgvLoadGroup.Hide();
                dgvLoadTempDivision.Hide();
                dgvPreviousAddedEmpList.Hide();
                dgvDivision.Visible = true;
                dgvDivision.Location = new Point(372, 10);
                dgvDivision.Size = new Size(960, 585);
                dgvDivision.DataSource = objDivisionDetailsManager.ShowAllDivision();
                dgvDivision.Columns[0].Visible = false;
                dgvDivision.Columns[3].Visible = false;
                ClearDivision();
                MessageBox.Show("Division Added Successfully");
            }
            else if (btnSaveDivision.Text == "Update Division")
            {
                tmpDivisionID = GlobalClass.DivisionIdForUpdateDivision;
                tmpDivisionName = txtDivisionName.Text.ToString();
                tmpGroupName = cmbSelectTeam.Text.ToString();
                tmpGroupID = Convert.ToInt16(txtTeamIDForDivision.Text.ToString());
                tmpEmpName = GlobalClass.EmpNameForUpdateDivision.ToString();
                tmpEmpDesig = GlobalClass.EmpDesiForUpdateDivision;
                tmpDivisionActive = cmbActiveForDivision.Text.ToString();
                
                if (tmpEmpDesig == "DO")
                {
                    tmpEmpName = cmbSelectDOForDivision.Text.ToString();
                }
                else if (tmpEmpDesig == "GM")
                {
                    tmpEmpName = cmbSelectGMForDivision.Text.ToString();
                }
                else if (tmpEmpDesig == "DGM")
                {
                    tmpEmpName = cmbSelectDGMForDivision.Text.ToString();
                }
                else if (tmpEmpDesig == "DM")
                {
                    tmpEmpName = cmbSelectDMForDivision.Text.ToString();
                }
                else if (tmpEmpDesig == "SM")
                {
                    tmpEmpName = cmbSelectSMForDivision.Text.ToString();
                }
                else if (tmpEmpDesig == "ASM")
                {
                    tmpEmpName = cmbSelectASMForDivision.Text.ToString();
                }
                else if (tmpEmpDesig == "TSM")
                {
                    tmpEmpName = cmbSelectTSMForDivision.Text.ToString();
                }
                else if (tmpEmpDesig == "SR")
                {
                    tmpEmpName = cmbSelectSRForDivision.Text.ToString();
                }
                else if (tmpEmpDesig == "RSM")
                {
                    tmpEmpName = cmbSelectRSMForDivision.Text.ToString();
                }
                objDivisionDetailsManager.UpdateDivision(tmpDivisionID, tmpDivisionName,tmpGroupName,tmpGroupID,tmpEmpName,tmpEmpDesig,tmpDivisionActive);

                objMarketDetailsManager.UpdateMarketByChangingDivision(tmpEmpName,tmpGroupID,tmpGroupName,tmpDivisionName,tmpDivisionActive);

                ClearDivision();
                dgvDivision.Visible = true;
                dgvDivision.Location = new Point(372, 10);
                dgvDivision.Size = new Size(960, 585);
                dgvDivision.DataSource = objDivisionDetailsManager.ShowAllDivision();
                dgvDivision.Columns[0].Visible = false;
                dgvDivision.Columns[3].Visible = false;
                MessageBox.Show("Division Updated Succesfully");
            }
        }

        private void dgvDivision_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                ClearDivision();
                if (btnSaveDivision.Enabled == false)
                {
                    btnSaveDivision.Enabled = true;
                    btnSaveDivision.Text = "Update Division";
                }
                else
                {
                    btnSaveDivision.Enabled = true;
                    btnSaveDivision.Text = "Update Division";
                }

                if (btnLoadGroup.Enabled == true)
                {
                    btnLoadGroup.Enabled = false;
                }
                else
                {
                    btnLoadGroup.Enabled = false;
                }

                GlobalClass.DivisionIdForUpdateDivision = Convert.ToInt32(dgvDivision.CurrentRow.Cells[0].Value.ToString());
                GlobalClass.DivisionNameForUpdateDivision = dgvDivision.CurrentRow.Cells[1].Value.ToString();
                GlobalClass.GroupNameForUpdateDivision = dgvDivision.CurrentRow.Cells[2].Value.ToString();
                GlobalClass.GroupIdForUpdateDivision = Convert.ToInt32(dgvDivision.CurrentRow.Cells[3].Value.ToString());
                GlobalClass.EmpNameForUpdateDivision = dgvDivision.CurrentRow.Cells[4].Value.ToString();
                GlobalClass.EmpDesiForUpdateDivision = dgvDivision.CurrentRow.Cells[5].Value.ToString();
                GlobalClass.EmpActivateForUpdateDivision = dgvDivision.CurrentRow.Cells[6].Value.ToString();

                cmbSelectTeam.DataSource = objGroupDetailsManager.LoadSelectGroupCombo();
                cmbSelectTeam.DisplayMember = "Group_Name";
                cmbSelectTeam.ValueMember = "Group_Name";
                //cmbSelectTeam.Text = "Select Team";
                //txtTeamIDForDivision.Text = "";

                cmbSelectTeam.Text = GlobalClass.GroupNameForUpdateDivision;
                txtTeamIDForDivision.Text = GlobalClass.GroupIdForUpdateDivision.ToString();
                txtDivisionName.Text = GlobalClass.DivisionNameForUpdateDivision;
                cmbActiveForDivision.Text = GlobalClass.EmpActivateForUpdateDivision;

                CheckDesignation();

                if (GlobalClass.EmpDesiForUpdateDivision == "DO")
                {
                    cmbSelectDOForDivision.Enabled = true;
                    cmbSelectDOForDivision.DataSource =
                        objEmployeeDetailsManager.LoadEmployeeForDivisionBySelectedGroupAndDesignation(
                            cmbSelectTeam.Text.ToString(), GlobalClass.EmpDesiForUpdateDivision.ToString());
                    cmbSelectDOForDivision.DisplayMember = "Employee_Name";
                    cmbSelectDOForDivision.ValueMember = "Employee_Name";
                    cmbSelectDOForDivision.Text = GlobalClass.EmpNameForUpdateDivision;
                }

                if (GlobalClass.EmpDesiForUpdateDivision == "DM")
                {
                    cmbSelectDMForDivision.Enabled = true;
                    cmbSelectDMForDivision.DataSource =
                        objEmployeeDetailsManager.LoadEmployeeForDivisionBySelectedGroupAndDesignation(
                            cmbSelectTeam.Text.ToString(), GlobalClass.EmpDesiForUpdateDivision.ToString());
                    cmbSelectDMForDivision.DisplayMember = "Employee_Name";
                    cmbSelectDMForDivision.ValueMember = "Employee_Name";
                    cmbSelectDMForDivision.Text = GlobalClass.EmpNameForUpdateDivision;
                }

                if (GlobalClass.EmpDesiForUpdateDivision == "ASM")
                {
                    cmbSelectASMForDivision.Enabled = true;
                    cmbSelectASMForDivision.DataSource =
                        objEmployeeDetailsManager.LoadEmployeeForDivisionBySelectedGroupAndDesignation(
                            cmbSelectTeam.Text.ToString(), GlobalClass.EmpDesiForUpdateDivision.ToString());
                    cmbSelectASMForDivision.DisplayMember = "Employee_Name";
                    cmbSelectASMForDivision.ValueMember = "Employee_Name";
                    cmbSelectASMForDivision.Text = GlobalClass.EmpNameForUpdateDivision;
                }

                if (GlobalClass.EmpDesiForUpdateDivision == "TSM")
                {
                    cmbSelectTSMForDivision.Enabled = true;
                    cmbSelectTSMForDivision.DataSource =
                        objEmployeeDetailsManager.LoadEmployeeForDivisionBySelectedGroupAndDesignation(
                            cmbSelectTeam.Text.ToString(), GlobalClass.EmpDesiForUpdateDivision.ToString());
                    cmbSelectTSMForDivision.DisplayMember = "Employee_Name";
                    cmbSelectTSMForDivision.ValueMember = "Employee_Name";
                    cmbSelectTSMForDivision.Text = GlobalClass.EmpNameForUpdateDivision;
                }

                if (GlobalClass.EmpDesiForUpdateDivision == "SR")
                {
                    cmbSelectSRForDivision.Enabled = true;
                    cmbSelectSRForDivision.DataSource =
                        objEmployeeDetailsManager.LoadEmployeeForDivisionBySelectedGroupAndDesignation(
                            cmbSelectTeam.Text.ToString(), GlobalClass.EmpDesiForUpdateDivision.ToString());
                    cmbSelectSRForDivision.DisplayMember = "Employee_Name";
                    cmbSelectSRForDivision.ValueMember = "Employee_Name";
                    cmbSelectSRForDivision.Text = GlobalClass.EmpNameForUpdateDivision;
                }

                if (GlobalClass.EmpDesiForUpdateDivision == "RSM")
                {
                    cmbSelectRSMForDivision.Enabled = true;
                    cmbSelectRSMForDivision.DataSource =
                        objEmployeeDetailsManager.LoadEmployeeForDivisionBySelectedGroupAndDesignation(
                            cmbSelectTeam.Text.ToString(), GlobalClass.EmpDesiForUpdateDivision.ToString());
                    cmbSelectRSMForDivision.DisplayMember = "Employee_Name";
                    cmbSelectRSMForDivision.ValueMember = "Employee_Name";
                    cmbSelectRSMForDivision.Text = GlobalClass.EmpNameForUpdateDivision;
                }

                if (cmbActiveForDivision.Enabled == false)
                {
                    cmbActiveForDivision.Enabled = true;
                }
                else
                {
                    cmbActiveForDivision.Enabled = true;
                }

                if (cmbSelectTeam.Enabled == false)
                {
                    cmbSelectTeam.Enabled = true;
                }
                else
                {
                    cmbSelectTeam.Enabled = true;
                }

                if (txtDivisionName.Enabled == false)
                {
                    txtDivisionName.Enabled = true;
                }
                else
                {
                    txtDivisionName.Enabled = true;
                }
            }
            catch (Exception excep)
            {
                MessageBox.Show(excep.Message);
            }
        }

        private void dgvLoadDistinctDivision_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            GlobalClass.DivisionNameToLoadDivision = dgvLoadDistinctDivision.CurrentRow.Cells[0].Value.ToString();
            dgvLoadDistinctDivision.Visible = false;
            dgvLoadGroup.Visible = false;
            dgvLoadTempDivision.Visible = false;
            dgvPreviousAddedEmpList.Visible = false;

            dgvDivision.Visible = true;
            dgvDivision.Size = new Size(960, 595);
            dgvDivision.Location = new Point(372, 10);
            //dgvDivision.DataSource = objDivisionDetailsManager.ShowAllDivision();
            dgvDivision.DataSource = objDivisionDetailsManager.LoadDivisionByDivisionName(GlobalClass.DivisionNameToLoadDivision);
            dgvDivision.Columns[0].Visible = false;
            //dgvDivision.Columns[1].Visible = false;
            dgvDivision.Columns[3].Visible = false;
        }

        //private void cmbSelectGroupForMarketSetup_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    //if (objDivisionDetailsManager.LoadDivisionBySelectedGroup(cmbSelectGroupForMarketSetup.Text).Rows.Count > 0)
        //    //{
        //        //cmbSelectDevisionForMarketSetup.DataSource = objDivisionDetailsManager.LoadDivisionBySelectedGroup(cmbSelectGroupForMarketSetup.Text);
        //        cmbSelectDevisionForMarketSetup.DataSource = objDivisionDetailsManager.LoadSelectDivision();
        //        cmbSelectDevisionForMarketSetup.DisplayMember = "Division_Name";
        //        cmbSelectDevisionForMarketSetup.ValueMember = "Division_Name";
        //        cmbSelectDevisionForMarketSetup.Text = "Select Division";
        //    //}
        //    //else
        //    //{
        //    //    cmbSelectDevisionForMarketSetup.Text = "";
        //    //    MessageBox.Show("No Division Available, please Add a Division.");
        //    //}
        //}

       private void txtGroupIDForMarketSetup_TextChanged(object sender, EventArgs e)
        {
            //if (cmbSelectGroupForMarketSetup.Text == "Select Team")
            //{

            //}
            //else
            //{
            //    if (objDivisionDetailsManager.LoadDivisionBySelectedGroup(cmbSelectGroupForMarketSetup.Text).Rows.Count > 0)
            //    {
            //        //cmbSelectDevisionForMarketSetup.DataSource = objDivisionDetailsManager.LoadDivisionBySelectedGroup(cmbSelectGroupForMarketSetup.Text);
            //        //cmbSelectDevisionForMarketSetup.DisplayMember = "Division_Name";
            //        //cmbSelectDevisionForMarketSetup.ValueMember = "Division_Name";
            //        //cmbSelectDevisionForMarketSetup.Text = "Select Division";
            //    }
            //    else
            //    {
            //        cmbSelectDevisionForMarketSetup.Text = "Select Division";
            //        //MessageBox.Show("No Division Available. Please Add Division under '" + cmbSelectGroupForMarketSetup.Text + "' Team");
            //    }
            //}
        }

       //private void cmbSelectGroupForMarketSetup_SelectedIndexChanged(object sender, EventArgs e)
       //{
       //    if (cmbSelectGroupForMarketSetup.SelectedItem.ToString() == "Select Team")
       //    {
               
       //    }
       //    else
       //    {
       //        this.txtGroupIDForMarketSetup.Text = objGroupDetailsManager.GetGroupID(cmbSelectGroupForMarketSetup.Text);
       //    }
       //}

       //private void cmbSelectGroupForMarketSetup_SelectedValueChanged(object sender, EventArgs e)
       //{
       //    if (cmbSelectGroupForMarketSetup.SelectedItem.ToString() == "Select Team")
       //    {
               
       //    }
       //    else
       //    {
       //        this.txtGroupIDForMarketSetup.Text = objGroupDetailsManager.GetGroupID(cmbSelectGroupForMarketSetup.Text);
       //    }
       //}

       private void cmbSelectGroupForMarketSetup_SelectedIndexChanged(object sender, EventArgs e)
       {
           if (cmbSelectGroupForMarketSetup.SelectedItem.ToString() == "Select Team")
           {
               txtGroupIDForMarketSetup.Text = "";
           }
           else
           {
               this.txtGroupIDForMarketSetup.Text = objGroupDetailsManager.GetGroupID(cmbSelectGroupForMarketSetup.Text);
               cmbSelectDevisionForMarketSetup.Focus();
           }
       }

       private void cmbSelectGroupForMarketSetup_SelectedValueChanged(object sender, EventArgs e)
       {
           //if (cmbSelectGroupForMarketSetup.SelectedItem.ToString() == "Select Team")
           //{

           //}
           if (cmbSelectGroupForMarketSetup.Text == "Select Team")
           {
               txtGroupIDForMarketSetup.Text = "";
           }
           else
           {
               this.txtGroupIDForMarketSetup.Text = objGroupDetailsManager.GetGroupID(cmbSelectGroupForMarketSetup.Text);
               //if (txtGroupIDForMarketSetup.Text != "")
               //{
               //    cmbSelectDevisionForMarketSetup.DataSource = objDivisionDetailsManager.LoadDivisionBySelectedGroup(cmbSelectGroupForMarketSetup.Text);
               //    cmbSelectDevisionForMarketSetup.DisplayMember = "Division_Name";
               //    cmbSelectDevisionForMarketSetup.ValueMember = "Division_Name";
               //}
               //cmbSelectDevisionForMarketSetup.Text = "Select Division";
               cmbSelectDevisionForMarketSetup.Focus();
           }
       }

       private void cmbSelectGroupForMarketSetup_Leave(object sender, EventArgs e)
       {
           if (btnSaveMarketSetup.Text == "Save Market Setup")
           {
               if (txtGroupIDForMarketSetup.Text != "")
               {
                   cmbSelectDevisionForMarketSetup.DataSource = objDivisionDetailsManager.LoadDivisionBySelectedGroup(cmbSelectGroupForMarketSetup.Text);
                   cmbSelectDevisionForMarketSetup.DisplayMember = "Division_Name";
                   cmbSelectDevisionForMarketSetup.ValueMember = "Division_Name";
                   cmbSelectDevisionForMarketSetup.Text = "Select Division";

                   dgvLoadMarketBySelectedDivision.DataSource = objMarketDetailsManager.LoadMarketBySelectedDivision(cmbSelectDevisionForMarketSetup.Text);
                   dgvLoadMarketBySelectedDivision.Location = new Point(372, 10);
                   dgvLoadMarketBySelectedDivision.Size = new Size(960, 280);
                   //if (objDivisionDetailsManager.LoadDivisionBySelectedGroup(cmbSelectGroupForMarketSetup.Text).Rows.Count >0)
                   //{

                   //}
                   //else
                   //{
                   //    MessageBox.Show("No Division Available. Please Add Division under '" + cmbSelectGroupForMarketSetup.Text + "' Team");    
                   //}

               }
           }
           else if (btnSaveMarketSetup.Text == "Update Market Setup")
           {
               if (txtGroupIDForMarketSetup.Text != "")
               {
                   cmbSelectDevisionForMarketSetup.DataSource = objDivisionDetailsManager.LoadDivisionBySelectedGroup(cmbSelectGroupForMarketSetup.Text);
                   cmbSelectDevisionForMarketSetup.DisplayMember = "Division_Name";
                   cmbSelectDevisionForMarketSetup.ValueMember = "Division_Name";
                   cmbSelectDevisionForMarketSetup.Text = "Select Division";
               }
           }
       }

       private void clearMarketSetup()
        {
            if (cmbSelectMarketForMarketSetup.Enabled == true)
            {
                cmbSelectMarketForMarketSetup.Enabled = false;
            }

            if (cmbSelectGroupForMarketSetup.Enabled == true)
            {
                cmbSelectGroupForMarketSetup.Enabled = false;
            }

            if (cmbSelectDevisionForMarketSetup.Enabled == true)
            {
                cmbSelectDevisionForMarketSetup.Enabled = false;
            }

            if (cmbSelectEmployeeForMarketSetup.Enabled == true)
            {
                cmbSelectEmployeeForMarketSetup.Enabled = false;
            }

            if (btnSaveMarketSetup.Text == "Update Market Setup")
            {
                btnSaveMarketSetup.Text = "Save Market Setup";
            }

            btnSaveMarketSetup.Enabled = false;
            cmbSelectMarketForMarketSetup.Text = "Select Market";
            cmbSelectGroupForMarketSetup.Text = "Select Team";
            txtGroupIDForMarketSetup.Text = "";
            cmbSelectDevisionForMarketSetup.Text = "Select Division";
            cmbSelectEmployeeForMarketSetup.Text = "Select Employee";
            txtEmpIDForMarketSetup.Text = "";
            txtEmpDesigForMarketSetup.Text = "";
            txtEmpCellNoForMarketSetup.Text = "";
            if (dgvLoadMarketBySelectedDivision.Visible == true)
            {
                dgvLoadMarketBySelectedDivision.Visible = false;
            }
            dgvLoadMarketBySelectedDivision.Hide();
            dataGridViewMarketSetup.Show();

        }

       private void btnSaveMarketSetup_Click(object sender, EventArgs e)
       {
           int marketID;
           string marketCode;
           Int16 groupID;
           string groupName;
           string divisionName;
           string empName;
           Int16 empID;
           string empDesignation;
           string empCell;
           
           if (btnSaveMarketSetup.Text == "Save Market Setup")
           {
               try
               {
                   for (int i = 0; i <= dgvLoadMarketBySelectedDivision.RowCount - 1; i++)
                   {
                       //if (Convert.ToBoolean(dgvProductListForSalesTarget.Rows[i].Cells[8].Value))
                       
                       ////if (Convert.ToBoolean(dgvLoadMarketBySelectedDivision.Rows[i].Cells[2].Value))
                       ////{
                       ////    marketCode = dgvLoadMarketBySelectedDivision.Rows[i].Cells[0].ToString();
                       ////    MessageBox.Show(marketCode);
                       ////}

                       if (Convert.ToBoolean(dgvLoadMarketBySelectedDivision.Rows[i].Cells[0].Value) == true)
                       {
                           marketCode = dgvLoadMarketBySelectedDivision.Rows[i].Cells[1].Value.ToString();
                           empName = cmbSelectEmployeeForMarketSetup.Text;
                           empID = Convert.ToInt16(txtEmpIDForMarketSetup.Text.ToString());
                           empDesignation = txtEmpDesigForMarketSetup.Text;
                           empCell = txtEmpCellNoForMarketSetup.Text;

                           objMarketDetailsManager.UpdateMarketSetup(marketCode, empName, empID, empDesignation, empCell);
                       }
                   }
                   
                   dgvLoadMarketBySelectedDivision.Hide();

                   dataGridViewMarketSetup.Visible = true;
                   dataGridViewMarketSetup.DataSource = objMarketDetailsManager.AllMarketDetails();
                   dataGridViewMarketSetup.Columns[0].Visible = false;
                   dataGridViewMarketSetup.Columns[3].Visible = false;
                   dataGridViewMarketSetup.Columns[4].Visible = false;
                   dataGridViewMarketSetup.Columns[5].Visible = false;
                   dataGridViewMarketSetup.Columns[7].Visible = false;
                   //dataGridViewMarketSetup.Columns[8].Visible = false;
                   //dataGridViewMarketSetup.Columns[9].Visible = false;
                   //dataGridViewMarketSetup.Columns[10].Visible = false;
                   dataGridViewMarketSetup.Columns[11].Visible = false;

                   MessageBox.Show("Market Setup Saved Successfully");
               }
               catch (Exception exp)
               {
                   MessageBox.Show(exp.Message);
               }
           }
           else if (btnSaveMarketSetup.Text == "Update Market Setup")
           {
               GlobalClass.MarketCodeForUpdateMarketSetup = cmbSelectMarketForMarketSetup.Text;
               groupName = cmbSelectGroupForMarketSetup.Text;
               groupID = Convert.ToInt16(txtGroupIDForMarketSetup.Text);
               divisionName = cmbSelectDevisionForMarketSetup.Text;
               empName = cmbSelectEmployeeForMarketSetup.Text;
               empID = Convert.ToInt16(txtEmpIDForMarketSetup.Text);
               empDesignation = txtEmpDesigForMarketSetup.Text;
               empCell = txtEmpCellNoForMarketSetup.Text;

               objMarketDetailsManager.UpdateMarketSetupNew(GlobalClass.MarketCodeForUpdateMarketSetup, groupName, groupID, divisionName, empName, empID, empDesignation, empCell);
               dataGridViewMarketSetup.Visible = true;
               dataGridViewMarketSetup.DataSource = objMarketDetailsManager.AllMarketDetails();
               dataGridViewMarketSetup.Columns[0].Visible = false;
               dataGridViewMarketSetup.Columns[3].Visible = false;
               dataGridViewMarketSetup.Columns[4].Visible = false;
               dataGridViewMarketSetup.Columns[5].Visible = false;
               dataGridViewMarketSetup.Columns[7].Visible = false;
               //dataGridViewMarketSetup.Columns[8].Visible = false;
               //dataGridViewMarketSetup.Columns[9].Visible = false;
               //dataGridViewMarketSetup.Columns[10].Visible = false;
               dataGridViewMarketSetup.Columns[11].Visible = false;

               MessageBox.Show("Market Setup Updated Successfully");
               clearMarketSetup();
               //MessageBox.Show("Development Under Process.");
           }
           
       }

       private void btnAddOrEditDataOfPrevDivision_Click(object sender, EventArgs e)
       {
           if (cmbSelectDivisionForUpdate.Text != "Select Division")
           {
               
               //btnLoadGroup_Click(null,null);

                   DataGridViewCheckBoxColumn checkBoxColumnEmpSelected = new DataGridViewCheckBoxColumn();
                   //DataGridViewCheckBoxColumn checkBoxColumnEmpActive = new DataGridViewCheckBoxColumn();

                   objDivisionDetailsManager.DeleteTempDivision();

                   dgvDivision.Visible = false;
                   dgvLoadDistinctDivision.Visible = false;
                   dgvLoadGroup.Visible = true;

                   dgvLoadGroup.Columns.Clear();
                   while (dgvLoadGroup.Columns.Count >= 1)
                   {
                       dgvLoadGroup.Columns.RemoveAt(0);
                   }

                   dgvLoadGroup.DataSource = objEmployeeDetailsManager.GetEmpList(cmbSelectTeam.Text);

                   DataTable prevAddedEmp = objDivisionDetailsManager.GetPrevAddedEmpList(cmbSelectDivisionForUpdate.Text);
                   DataTable empList = objEmployeeDetailsManager.GetEmpNameFromList(cmbSelectTeam.Text);
                   
                   string empName="";
                   string empNameFromEmpInfo="";

               //if (empList.Rows.Count > 0 && prevAddedEmp.Rows.Count > 0)
               //{
               //    for (int i = 0; i < empList.Rows.Count; i++)
               //    {
               //        empNameFromEmpInfo = empList.Rows[i][0].ToString();
               //        if (i < prevAddedEmp.Rows.Count)
               //        {
               //            empName = prevAddedEmp.Rows[i][0].ToString();
               //        }
               //        else
               //        {
               //            empName = "";
               //        }

               //        if (empNameFromEmpInfo == empName)
               //        {
               //            dgvLoadGroup.Rows.Remove(dgvLoadGroup.CurrentRow);
               //        }
               //        else
               //        {
               //            dgvLoadGroup.Visible = true;
               //            dgvLoadGroup.Location = new Point(372, 10);
               //            dgvLoadGroup.Size = new Size(960, 290);
               //            dgvLoadGroup.Columns[0].Visible = false;
               //            dgvLoadGroup.Columns[2].Visible = false;
               //            dgvLoadGroup.Columns[3].Visible = false;
               //            dgvLoadGroup.Columns[4].Visible = false;
               //            dgvLoadGroup.Columns[6].Visible = false;
               //            dgvLoadGroup.Columns[7].Visible = false;
               //            dgvLoadGroup.Columns[9].Visible = false;
               //            dgvLoadGroup.Columns[10].Visible = false;
               //            dgvLoadGroup.Columns[11].Visible = false;
               //            dgvLoadGroup.Columns[12].Visible = false;
               //            dgvLoadGroup.Columns[13].Visible = false;
               //            dgvLoadGroup.Columns[14].Visible = false;
               //            dgvLoadGroup.Columns[15].Visible = false;

               //            dgvLoadGroup.Columns[1].ReadOnly = true;
               //            dgvLoadGroup.Columns[5].ReadOnly = true;
               //            dgvLoadGroup.Columns[8].ReadOnly = true;

               //            dgvLoadGroup.Columns.Insert(16, checkBoxColumnEmpSelected);

               //            checkBoxColumnEmpSelected.Name = "checkBoxColumnEmpSelected";
               //            checkBoxColumnEmpSelected.HeaderText = "Select Emp";
               //            checkBoxColumnEmpSelected.ReadOnly = false;

               //            //dgvLoadGroup.Columns.Insert(17, checkBoxColumnEmpActive);
               //            //checkBoxColumnEmpActive.Name = "checkBoxColumnEmpActive";
               //            //checkBoxColumnEmpActive.HeaderText = "Check to Active";
               //            //checkBoxColumnEmpActive.ReadOnly = false;

               //            //dgvPrevAddedSalesTargetDetails.Location = new Point(372, 10);
               //            //dgvPrevAddedSalesTargetDetails.Size = new Size(950, 290);
               //            //dgvPrevAddedSalesTargetDetails.Size = new Size(960, 290);
               //            dgvLoadGroup.Focus();
               //        }

               //    }
               //}

                   //MessageBox.Show(objEmployeeDetailsManager.GetEmpList(cmbSelectTeam.Text).Rows.Count.ToString());
                   if (objEmployeeDetailsManager.GetEmpList(cmbSelectTeam.Text).Rows.Count > 0)
                   {
                       dgvLoadGroup.Visible = true;
                       dgvLoadGroup.Location = new Point(372, 10);
                       dgvLoadGroup.Size = new Size(960, 200);
                       dgvLoadGroup.Columns[0].Visible = false;
                       dgvLoadGroup.Columns[2].Visible = false;
                       dgvLoadGroup.Columns[3].Visible = false;
                       dgvLoadGroup.Columns[4].Visible = false;
                       dgvLoadGroup.Columns[6].Visible = false;
                       dgvLoadGroup.Columns[7].Visible = false;
                       dgvLoadGroup.Columns[9].Visible = false;
                       dgvLoadGroup.Columns[10].Visible = false;
                       dgvLoadGroup.Columns[11].Visible = false;
                       dgvLoadGroup.Columns[12].Visible = false;
                       dgvLoadGroup.Columns[13].Visible = false;
                       dgvLoadGroup.Columns[14].Visible = false;
                       dgvLoadGroup.Columns[15].Visible = false;

                       dgvLoadGroup.Columns[1].ReadOnly = true;
                       dgvLoadGroup.Columns[5].ReadOnly = true;
                       dgvLoadGroup.Columns[8].ReadOnly = true;

                       dgvLoadGroup.Columns.Insert(16, checkBoxColumnEmpSelected);

                       checkBoxColumnEmpSelected.Name = "checkBoxColumnEmpSelected";
                       checkBoxColumnEmpSelected.HeaderText = "Select Emp";
                       checkBoxColumnEmpSelected.ReadOnly = false;

                       //dgvLoadGroup.Columns.Insert(17, checkBoxColumnEmpActive);
                       //checkBoxColumnEmpActive.Name = "checkBoxColumnEmpActive";
                       //checkBoxColumnEmpActive.HeaderText = "Check to Active";
                       //checkBoxColumnEmpActive.ReadOnly = false;

                       //dgvPrevAddedSalesTargetDetails.Location = new Point(372, 10);
                       //dgvPrevAddedSalesTargetDetails.Size = new Size(950, 290);
                       //dgvPrevAddedSalesTargetDetails.Size = new Size(960, 290);
                       dgvLoadGroup.Focus();
                   }

               if (prevAddedEmp.Rows.Count > 0)
               {
                   dgvPreviousAddedEmpList.DataSource = prevAddedEmp;

                   dgvPreviousAddedEmpList.Visible = true;
                   dgvPreviousAddedEmpList.Columns[0].Visible = false;
                   dgvPreviousAddedEmpList.Columns[1].Visible = false;
                   dgvPreviousAddedEmpList.Columns[2].Visible = false;
                   dgvPreviousAddedEmpList.Columns[3].Visible = false;
                   dgvPreviousAddedEmpList.Columns[6].Visible = false;

                   dgvPreviousAddedEmpList.Location = new Point(372, 215);
                   dgvPreviousAddedEmpList.Size = new Size(960, 200);
               }

               btnAddToTempDivision.Enabled = true;
               btnSaveDivision.Enabled = true;
           }
       }

       private void cmbSelectDivisionForUpdate_ValueMemberChanged(object sender, EventArgs e)
       {
           
       }

       private void cmbSelectDivisionForUpdate_TextChanged(object sender, EventArgs e)
       {
           DataTable divDetails = objDivisionDetailsManager.GetDivisionInfo(cmbSelectDivisionForUpdate.Text);
           if (divDetails.Rows.Count > 0)
           {
               cmbSelectTeam.Text = divDetails.Rows[0][1].ToString();
               txtTeamIDForDivision.Text = divDetails.Rows[0][2].ToString();
               txtDivisionName.Text = divDetails.Rows[0][0].ToString();
               cmbActiveForDivision.Text = divDetails.Rows[0][3].ToString();

               cmbSelectTeam.Enabled = false;
               txtTeamIDForDivision.ReadOnly = true;
               txtDivisionName.Enabled = false;
               cmbActiveForDivision.Enabled = false;
           }
       }

       private void dataGridViewMarketSetup_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
       {
           btnSaveMarketSetup.Text = "Update Market Setup";
           btnSaveMarketSetup.Enabled = true;
           if (cmbSelectMarketForMarketSetup.Enabled == false)
           {
               cmbSelectMarketForMarketSetup.Enabled = true;
           }

           if (cmbSelectGroupForMarketSetup.Enabled == false)
           {
               cmbSelectGroupForMarketSetup.Enabled = true;
           }

           if (cmbSelectDevisionForMarketSetup.Enabled == false)
           {
               cmbSelectDevisionForMarketSetup.Enabled = true;
           }

           if (cmbSelectEmployeeForMarketSetup.Enabled == false)
           {
               cmbSelectEmployeeForMarketSetup.Enabled = true;
           }

           cmbSelectMarketForMarketSetup.DataSource = objMarketDetailsManager.LoadAllMarket();
           cmbSelectMarketForMarketSetup.DisplayMember = "Market_Code";
           cmbSelectMarketForMarketSetup.ValueMember = "Market_Code";
           //cmbSelectMarketForMarketSetup.Text = "Select Market";

           cmbSelectGroupForMarketSetup.DataSource = objGroupDetailsManager.LoadSelectGroupCombo();
           //cmbSelectGroupForMarketSetup.Text = "Select Team";
           cmbSelectGroupForMarketSetup.DisplayMember = "Group_Name";
           cmbSelectGroupForMarketSetup.ValueMember = "Group_Name";

           if (txtGroupIDForMarketSetup.Text != "")
           {
               cmbSelectDevisionForMarketSetup.DataSource =
                   objDivisionDetailsManager.LoadDivisionBySelectedGroup(cmbSelectGroupForMarketSetup.Text);
               cmbSelectDevisionForMarketSetup.DisplayMember = "Division_Name";
               cmbSelectDevisionForMarketSetup.ValueMember = "Division_Name";
               //cmbSelectDevisionForMarketSetup.Text = "Select Division";

               //dgvLoadMarketBySelectedDivision.DataSource = objMarketDetailsManager.LoadMarketBySelectedDivision(cmbSelectDevisionForMarketSetup.Text);
               //dgvLoadMarketBySelectedDivision.Location = new Point(372, 10);
               //dgvLoadMarketBySelectedDivision.Size = new Size(960, 280);
               //if (objDivisionDetailsManager.LoadDivisionBySelectedGroup(cmbSelectGroupForMarketSetup.Text).Rows.Count >0)
               //{

               //}
               //else
               //{
               //    MessageBox.Show("No Division Available. Please Add Division under '" + cmbSelectGroupForMarketSetup.Text + "' Team");    
               //}
           }
           else
           {
               cmbSelectDevisionForMarketSetup.DataSource =
                   objDivisionDetailsManager.LoadSelectDivision();
               cmbSelectDevisionForMarketSetup.DisplayMember = "Division_Name";
               cmbSelectDevisionForMarketSetup.ValueMember = "Division_Name";
           }

           //GlobalClass.MarketCodeForUpdateMarketSetup = dataGridViewMarketSetup.CurrentRow.Cells[1].Value.ToString();
           cmbSelectMarketForMarketSetup.Text = dataGridViewMarketSetup.CurrentRow.Cells[1].Value.ToString();
           cmbSelectGroupForMarketSetup.Text = dataGridViewMarketSetup.CurrentRow.Cells[12].Value.ToString();
           txtGroupIDForMarketSetup.Text = dataGridViewMarketSetup.CurrentRow.Cells[11].Value.ToString();
           cmbSelectDevisionForMarketSetup.Text = dataGridViewMarketSetup.CurrentRow.Cells[13].Value.ToString();
           cmbSelectEmployeeForMarketSetup.Text = dataGridViewMarketSetup.CurrentRow.Cells[8].Value.ToString();
           txtEmpIDForMarketSetup.Text = dataGridViewMarketSetup.CurrentRow.Cells[7].Value.ToString();
           txtEmpDesigForMarketSetup.Text = dataGridViewMarketSetup.CurrentRow.Cells[10].Value.ToString();
           txtEmpCellNoForMarketSetup.Text = dataGridViewMarketSetup.CurrentRow.Cells[9].Value.ToString();
           
           dgvLoadMarketBySelectedDivision.Hide();
           dataGridViewMarketSetup.Show();

       }

       private void cmbSelectDivisionForMarket_SelectedValueChanged(object sender, EventArgs e)
       {
           if (cmbSelectDivisionForMarket.Text != "Select Division")
           {
               DataTable objDataTable = objDivisionDetailsManager.GetTeamNameAndTeamID(cmbSelectDivisionForMarket.Text);

               if (objDataTable.Rows.Count > 0)
               {
                   txtTeamNameForMarket.Text = objDataTable.Rows[0][1].ToString();
                   txtTeamIDForMarket.Text = objDataTable.Rows[0][2].ToString();
               }
           }
       }

       private void cmbSelectDivisionForMarket_TextChanged(object sender, EventArgs e)
       {
           if (cmbSelectDivisionForMarket.Text != "Select Division")
           {
               DataTable objDataTable = objDivisionDetailsManager.GetTeamNameAndTeamID(cmbSelectDivisionForMarket.Text);

               if (objDataTable.Rows.Count > 0)
               {
                   txtTeamNameForMarket.Text = objDataTable.Rows[0][1].ToString();
                   txtTeamIDForMarket.Text = objDataTable.Rows[0][2].ToString();
               }
           }
       }

       private void cmbSelectDivisionForMarket_SelectionChangeCommitted(object sender, EventArgs e)
       {
           //if (cmbSelectDivisionForMarket.Text != "Select Division")
           //{
           //    DataTable objDataTable = objDivisionDetailsManager.GetTeamNameAndTeamID(cmbSelectDivisionForMarket.Text);

           //    if (objDataTable.Rows.Count > 0)
           //    {
           //        txtTeamNameForMarket.Text = objDataTable.Rows[0][1].ToString();
           //        txtTeamIDForMarket.Text = objDataTable.Rows[0][2].ToString();
           //    }

           //}
       }

       private void cmbSelectDevisionForMarketSetup_SelectionChangeCommitted(object sender, EventArgs e)
       {
           //if (cmbSelectDevisionForMarketSetup.Text != "Select Division")
           //{
           //    cmbSelectEmployeeForMarketSetup.DataSource = objDivisionDetailsManager.LoadEmployeeBySelectedDivision(cmbSelectDevisionForMarketSetup.Text);
           //    cmbSelectEmployeeForMarketSetup.DisplayMember = "Employee_Name";
           //    cmbSelectEmployeeForMarketSetup.ValueMember = "Employee_Name";
           //}
       }

       private void cmbSelectDevisionForMarketSetup_SelectedValueChanged(object sender, EventArgs e)
       {
           if (btnSaveMarketSetup.Text == "Save Market Setup")
           {
               if (cmbSelectDevisionForMarketSetup.Text != "Select Division")
               {
                   cmbSelectEmployeeForMarketSetup.DataSource = objDivisionDetailsManager.LoadEmployeeBySelectedDivision(cmbSelectDevisionForMarketSetup.Text);
                   cmbSelectEmployeeForMarketSetup.DisplayMember = "Employee_Name";
                   cmbSelectEmployeeForMarketSetup.ValueMember = "Employee_Name";
                   cmbSelectEmployeeForMarketSetup.Text = "Select Employee";
                   txtEmpIDForMarketSetup.Text = "";
                   txtEmpDesigForMarketSetup.Text = "";
                   txtEmpCellNoForMarketSetup.Text = "";
                   if (dgvLoadMarketBySelectedDivision.Visible == false)
                   {
                       dataGridViewMarketSetup.Hide();
                       dgvLoadMarketBySelectedDivision.Visible = true;
                   }

                   dgvLoadMarketBySelectedDivision.DataSource = objMarketDetailsManager.LoadMarketBySelectedDivision(cmbSelectDevisionForMarketSetup.Text);
                   dgvLoadMarketBySelectedDivision.Location = new Point(372, 10);
                   dgvLoadMarketBySelectedDivision.Size = new Size(960, 280);
               }
           }
           else if (btnSaveMarketSetup.Text == "Update Market Setup")
           {
               if (cmbSelectDevisionForMarketSetup.Text != "Select Division")
               {
                   cmbSelectEmployeeForMarketSetup.DataSource = objDivisionDetailsManager.LoadEmployeeBySelectedDivision(cmbSelectDevisionForMarketSetup.Text);
                   cmbSelectEmployeeForMarketSetup.DisplayMember = "Employee_Name";
                   cmbSelectEmployeeForMarketSetup.ValueMember = "Employee_Name";
                   //cmbSelectEmployeeForMarketSetup.Text = "Select Employee";
                   //txtEmpIDForMarketSetup.Text = "";
                   //txtEmpDesigForMarketSetup.Text = "";
                   //txtEmpCellNoForMarketSetup.Text = "";
                   //if (dgvLoadMarketBySelectedDivision.Visible == false)
                   //{
                   //    dataGridViewMarketSetup.Hide();
                   //    dgvLoadMarketBySelectedDivision.Visible = true;
                   //}

                   //dgvLoadMarketBySelectedDivision.DataSource = objMarketDetailsManager.LoadMarketBySelectedDivision(cmbSelectDevisionForMarketSetup.Text);
                   //dgvLoadMarketBySelectedDivision.Location = new Point(372, 10);
                   //dgvLoadMarketBySelectedDivision.Size = new Size(960, 280);
               }
           }
       }

       private void cmbSelectEmployeeForMarketSetup_SelectedIndexChanged(object sender, EventArgs e)
       {
           if (cmbSelectEmployeeForMarketSetup.Text != "Select Employee")
           {
               DataTable objDataTable = objEmployeeDetailsManager.GetEmployeeDetailsForMarketSetup(cmbSelectEmployeeForMarketSetup.Text);
               if (objEmployeeDetailsManager.GetEmployeeDetailsForMarketSetup(cmbSelectEmployeeForMarketSetup.Text).Rows.Count > 0)
               {
                   txtEmpIDForMarketSetup.Text = objDataTable.Rows[0][0].ToString();
                   txtEmpDesigForMarketSetup.Text = objDataTable.Rows[0][1].ToString();
                   txtEmpCellNoForMarketSetup.Text = objDataTable.Rows[0][2].ToString();
               }
           }
       }

       private void cmbSelectEmployeeForMarketSetup_SelectedValueChanged(object sender, EventArgs e)
       {
           if (cmbSelectEmployeeForMarketSetup.Text != "Select Employee")
           {
               DataTable objDataTable = objEmployeeDetailsManager.GetEmployeeDetailsForMarketSetup(cmbSelectEmployeeForMarketSetup.Text);
               if (objEmployeeDetailsManager.GetEmployeeDetailsForMarketSetup(cmbSelectEmployeeForMarketSetup.Text).Rows.Count > 0)
               {
                   txtEmpIDForMarketSetup.Text = objDataTable.Rows[0][0].ToString();
                   txtEmpDesigForMarketSetup.Text = objDataTable.Rows[0][1].ToString();
                   txtEmpCellNoForMarketSetup.Text = objDataTable.Rows[0][2].ToString();
               }
           }
       }

       private void cmbSelectDevisionForMarketSetup_SelectedIndexChanged(object sender, EventArgs e)
       {
           if (btnSaveMarketSetup.Text == "Save Market Setup")
           {
               if (cmbSelectDevisionForMarketSetup.Text != "Select Division")
               {
                   cmbSelectEmployeeForMarketSetup.DataSource = objDivisionDetailsManager.LoadEmployeeBySelectedDivision(cmbSelectDevisionForMarketSetup.Text);
                   cmbSelectEmployeeForMarketSetup.DisplayMember = "Employee_Name";
                   cmbSelectEmployeeForMarketSetup.ValueMember = "Employee_Name";
                   cmbSelectEmployeeForMarketSetup.Text = "Select Employee";
                   txtEmpIDForMarketSetup.Text = "";
                   txtEmpDesigForMarketSetup.Text = "";
                   txtEmpCellNoForMarketSetup.Text = "";

                   if (dgvLoadMarketBySelectedDivision.Visible == false)
                   {
                       dataGridViewMarketSetup.Hide();
                       dgvLoadMarketBySelectedDivision.Visible = true;
                   }

                   dgvLoadMarketBySelectedDivision.DataSource = objMarketDetailsManager.LoadMarketBySelectedDivision(cmbSelectDevisionForMarketSetup.Text);
                   dgvLoadMarketBySelectedDivision.Location = new Point(372, 10);
                   dgvLoadMarketBySelectedDivision.Size = new Size(960, 280);
               }
           }
           else if (btnSaveMarketSetup.Text == "Update Market Setup")
           {
               if (cmbSelectDevisionForMarketSetup.Text != "Select Division")
               {
                   cmbSelectEmployeeForMarketSetup.DataSource = objDivisionDetailsManager.LoadEmployeeBySelectedDivision(cmbSelectDevisionForMarketSetup.Text);
                   cmbSelectEmployeeForMarketSetup.DisplayMember = "Employee_Name";
                   cmbSelectEmployeeForMarketSetup.ValueMember = "Employee_Name";
                   //cmbSelectEmployeeForMarketSetup.Text = "Select Employee";
                   //txtEmpIDForMarketSetup.Text = "";
                   //txtEmpDesigForMarketSetup.Text = "";
                   //txtEmpCellNoForMarketSetup.Text = "";

                   //if (dgvLoadMarketBySelectedDivision.Visible == false)
                   //{
                   //    dataGridViewMarketSetup.Hide();
                   //    dgvLoadMarketBySelectedDivision.Visible = true;
                   //}

                   //dgvLoadMarketBySelectedDivision.DataSource = objMarketDetailsManager.LoadMarketBySelectedDivision(cmbSelectDevisionForMarketSetup.Text);
                   //dgvLoadMarketBySelectedDivision.Location = new Point(372, 10);
                   //dgvLoadMarketBySelectedDivision.Size = new Size(960, 280);
               }
           }
       }

       private void cmbSelectDevisionForMarketSetup_TextChanged(object sender, EventArgs e)
       {
           if (btnSaveMarketSetup.Text == "Save Market Setup")
           {
               dgvLoadMarketBySelectedDivision.Columns.Clear();
               while (dgvLoadMarketBySelectedDivision.Columns.Count >= 1)
               {
                   dgvLoadMarketBySelectedDivision.Columns.RemoveAt(0);
               }

               dgvLoadMarketBySelectedDivision.DataSource = objMarketDetailsManager.LoadMarketBySelectedDivision(cmbSelectDevisionForMarketSetup.Text);
               dgvLoadMarketBySelectedDivision.Location = new Point(372, 10);
               dgvLoadMarketBySelectedDivision.Size = new Size(960, 280);

               if (cmbSelectDevisionForMarketSetup.SelectedText != "Select Division" || cmbSelectDevisionForMarketSetup.SelectedText != "")
               {
                   if (objMarketDetailsManager.LoadMarketBySelectedDivision(cmbSelectDevisionForMarketSetup.Text).Rows.Count > 0)
                   {
                       DataGridViewCheckBoxColumn checkBoxColumnMarketSelected = new DataGridViewCheckBoxColumn();
                       dgvLoadMarketBySelectedDivision.Columns.Insert(2, checkBoxColumnMarketSelected);
                       checkBoxColumnMarketSelected.Name = "checkBoxColumnMarketSelected";
                       checkBoxColumnMarketSelected.HeaderText = "Select Market";
                       checkBoxColumnMarketSelected.ReadOnly = false;
                       dgvLoadMarketBySelectedDivision.Focus();
                   }
               }
           }

       }

       private void btnUserReport_Click(object sender, EventArgs e)
       {
           UserReportUI objUserReportUI = new UserReportUI();
           objUserReportUI.ShowDialog();
       }

       private void btnDivisionReport_Click(object sender, EventArgs e)
       {
           DivisionReportUI objDivisionReportUi = new DivisionReportUI();
           objDivisionReportUi.ShowDialog();
       }

       private void btnProductReport_Click(object sender, EventArgs e)
       {
           ProductReportUI objProductReportUi = new ProductReportUI();
           objProductReportUi.ShowDialog();
       }

       public void btnEnableDisableDivision_Click(object sender, EventArgs e)
       {
           ClearDivision();
           EnableDisableDivisionUI objEnableDisableDivisionUi = new EnableDisableDivisionUI();
           objEnableDisableDivisionUi.ShowDialog();
       }

       public void btnRefreshDivision_Click(object sender, EventArgs e)
       {
           tabSMSapplication.SelectedTab.Text = "Division";
           
           if (tabSMSapplication.SelectedTab.Text == "Division")
           {
               ClearDivision();

               CheckDesignation();

               if (cmbSelectTeam.Enabled == true)
               {
                   cmbSelectTeam.Enabled = false;
               }

               if (txtDivisionName.Enabled == true)
               {
                   txtDivisionName.Enabled = false;
               }

               if (cmbSelectDOForDivision.Enabled == true)
               {
                   cmbSelectDOForDivision.Enabled = false;
               }

               if (cmbSelectGMForDivision.Enabled == true)
               {
                   cmbSelectGMForDivision.Enabled = false;
               }

               if (cmbSelectDGMForDivision.Enabled == true)
               {
                   cmbSelectDGMForDivision.Enabled = false;
               }

               if (cmbSelectDMForDivision.Enabled == true)
               {
                   cmbSelectDMForDivision.Enabled = false;
               }

               if (cmbSelectSMForDivision.Enabled == true)
               {
                   cmbSelectSMForDivision.Enabled = false;
               }

               if (cmbSelectASMForDivision.Enabled == true)
               {
                   cmbSelectASMForDivision.Enabled = false;
               }

               if (cmbSelectTSMForDivision.Enabled == true)
               {
                   cmbSelectTSMForDivision.Enabled = false;
               }

               if (cmbSelectSRForDivision.Enabled == true)
               {
                   cmbSelectSRForDivision.Enabled = false;
               }

               if (cmbActiveForDivision.Enabled == true)
               {
                   cmbActiveForDivision.Enabled = false;
               }

               if (btnSaveDivision.Text == "Update Division")
               {
                   btnSaveDivision.Text = "Save Division";
               }

               if (btnSaveDivision.Enabled == true)
               {
                   btnSaveDivision.Enabled = false;
               }

               if (btnLoadSM.Enabled == true)
               {
                   btnLoadSM.Enabled = false;
               }

               if (btnLoadASM.Enabled == true)
               {
                   btnLoadASM.Enabled = false;
               }

               if (btnLoadTSM.Enabled == true)
               {
                   btnLoadTSM.Enabled = false;
               }

               if (btnLoadSR.Enabled == true)
               {
                   btnLoadSR.Enabled = false;
               }

               if (btnAddToTempDivision.Enabled == true)
               {
                   btnAddToTempDivision.Enabled = false;
               }

               if (btnLoadGroup.Enabled == true)
               {
                   btnLoadGroup.Enabled = false;
               }

               dgvDivision.Visible = false;
               dgvPreviousAddedEmpList.Visible = false;
               dgvLoadDistinctDivision.Visible = true;
               dgvLoadDistinctDivision.Size = new Size(960, 595);
               dgvLoadDistinctDivision.Location = new Point(372, 10);
               dgvLoadDistinctDivision.DataSource = objDivisionDetailsManager.ShowDistinctDivision();
               //dgvLoadDistinctDivision.Columns[1].Visible = false;

               cmbSelectDivisionForUpdate.DataSource = objDivisionDetailsManager.ShowDistinctDivision();
               cmbSelectDivisionForUpdate.DisplayMember = "Division_Name";
               cmbSelectDivisionForUpdate.ValueMember = "Division_Name";
               cmbSelectDivisionForUpdate.Text = "Select Division";

               if (objDivisionDetailsManager.ShowDistinctDivision().Rows.Count > 0)
               {
                   btnAddOrEditDataOfPrevDivision.Enabled = true;
                   cmbSelectDivisionForUpdate.Enabled = true;
               }
               else
               {
                   btnAddOrEditDataOfPrevDivision.Enabled = false;
                   cmbSelectDivisionForUpdate.Enabled = false;
               }
           }
       }

       private void cmbSelectEmployeeForSalesTarget_TextChanged(object sender, EventArgs e)
       {
           txtEmpDivNameForSalesTarget.Text = objDivisionDetailsManager.GetDivisionNameBySelectedTeamAndEmplyoyee(cmbSelectGroupForSalesTarget.Text, cmbSelectEmployeeForSalesTarget.Text);
       }

       private void txtEmployeeIDForSalesTarget_TextChanged(object sender, EventArgs e)
       {
           txtEmpDivNameForSalesTarget.Text = objDivisionDetailsManager.GetDivisionNameBySelectedTeamAndEmplyoyee(cmbSelectGroupForSalesTarget.Text, cmbSelectEmployeeForSalesTarget.Text);
       }

       private void dtPSalesDetailsFormDate_CloseUp(object sender, EventArgs e)
       {
           txtSalesDetailsFormDate.Text = dtPSalesDetailsFormDate.Text.ToString();
       }

       private void dtPSalesDetailsToDate_CloseUp(object sender, EventArgs e)
       {
           txtSalesDetailsToDate.Text = dtPSalesDetailsToDate.Text.ToString();
       }

       private void btnSalesDetailsSearch_Click(object sender, EventArgs e)
       {
           MessageBox.Show("Development Under Process");
       }

       private void btnRefreshUser_Click(object sender, EventArgs e)
       {
           RefreshUser();
       }

       private void RefreshUser()
        {
            ClearCreateUserTab();

            if (btnSaveUser.Enabled == true)
            {
                btnSaveUser.Enabled = false;
            }

            if (txtUserName.Enabled == true)
            {
                txtUserName.Enabled = false;
            }

            if (txtPassword.Enabled == true)
            {
                txtPassword.Enabled = false;
            }

            if (cmbUserRole.Enabled == true)
            {
                cmbUserRole.Enabled = false;
            }

            if (cmbActive.Enabled == true)
            {
                cmbActive.Enabled = false;
            }

            if (btnSaveUser.Text == "Update User")
            {
                btnSaveUser.Text = "Save User";
            }
            dataGridViewUserDetails.DataSource = objUserDetailsManager.AllUserDetails();
            dataGridViewUserDetails.Columns[0].Visible = false;
            dataGridViewUserDetails.Columns[3].Visible = false;
            //dataGridViewUserDetails.Columns[6].Visible = false;

            btnAddUser.Focus();
        }

       private void btnRefreshDepartment_Click(object sender, EventArgs e)
       {
           RefreshDept();
       }

        private void RefreshDept()
        {
            ClearDepartmentTab();

            if (txtDepartment.Enabled == true)
            {
                txtDepartment.Enabled = false;
            }
            if (cmbActiveDepartment.Enabled == true)
            {
                cmbActiveDepartment.Enabled = false;
            }
            if (btnSaveDepartment.Enabled == true)
            {
                btnSaveDepartment.Enabled = false;
            }
            if (btnAddDepartment.Enabled == false)
            {
                btnAddDepartment.Enabled = true;
            }
            if (btnSaveDepartment.Text == "Update Department")
            {
                btnSaveDepartment.Text = "Save Department";
            }
            dataGridViewDepartmentDetails.DataSource = objDepartmentDetailsManager.AllDepartmentDetails();
            dataGridViewDepartmentDetails.Columns[0].Visible = false;

            btnAddDepartment.Focus();
        }
        
       private void btnRefreshDesignation_Click(object sender, EventArgs e)
       {
           RefreshDesi();
       }

       private void RefreshDesi()
        {
            ClearDesignationTab();

            if (txtDesignation.Enabled == true)
            {
                txtDesignation.Enabled = false;
            }
            if (txtDesignationDetails.Enabled == true)
            {
                txtDesignationDetails.Enabled = false;
            }
            if (cmbActiveDesignation.Enabled == true)
            {
                cmbActiveDesignation.Enabled = false;
            }
            if (btnSaveDesignation.Enabled == true)
            {
                btnSaveDesignation.Enabled = false;
            }
            if (btnAddDesignation.Enabled == false)
            {
                btnAddDesignation.Enabled = true;
            }
            if (btnSaveDesignation.Text == "Update Designation")
            {
                btnSaveDesignation.Text = "Save Designation";
            }
            dataGridViewDesignationList.DataSource = objDesignationDetailsManager.ShowAllDesignation();
            dataGridViewDesignationList.Columns[0].Visible = false;

            btnAddDesignation.Focus();
        }
       
       private void btnRefreshTeam_Click(object sender, EventArgs e)
       {
           RefreshTeam();
       }

       private void RefreshTeam()
       {
            ClearGroupTab();

            if (txtGroupName.Enabled == true)
            {
                txtGroupName.Enabled = false;
            }
            if (txtLocation.Enabled == true)
            {
                txtLocation.Enabled = false;
            }
            if (cmbGroupActive.Enabled == true)
            {
                cmbGroupActive.Enabled = false;
            }
            if (btnSaveGroup.Enabled == true)
            {
                btnSaveGroup.Enabled = false;
            }
            if (btnAddGroup.Enabled == false)
            {
                btnAddGroup.Enabled = true;
            }
            if (btnSaveGroup.Text == "Update Group")
            {
                btnSaveGroup.Text = "Save Group";
            }

            dataGridViewGroupDetails.DataSource = objGroupDetailsManager.AllGroupDetails();
            dataGridViewGroupDetails.Columns[0].Visible = false;

            btnAddGroup.Focus();
        }

       private void RefreshEmployee()
        {
            ClearEmployeeTab();

            if (txtEmployeeName.Enabled == true)
            {
                txtEmployeeName.Enabled = false;
            }

            if (txtAddress.Enabled == true)
            {
                txtAddress.Enabled = false;
            }

            if (txtDOB.Enabled == true)
            {
                txtDOB.Enabled = false;
            }

            if (dTPDateOfBirth.Enabled == true)
            {
                dTPDateOfBirth.Enabled = false;
            }

            if (cmbEmployeeDesignation.Enabled == true)
            {
                cmbEmployeeDesignation.Enabled = false;
            }

            if (cmbEmployeeDepartment.Enabled == true)
            {
                cmbEmployeeDepartment.Enabled = false;
            }

            if (txtOfficialCellNo.Enabled == true)
            {
                txtOfficialCellNo.Enabled = false;
            }

            if (cmbEmployeeGroup.Enabled == true)
            {
                cmbEmployeeGroup.Enabled = false;
            }

            if (cmbEmployeeActive.Enabled == true)
            {
                cmbEmployeeActive.Enabled = false;
            }

            if (txtQuitDate.Enabled == true)
            {
                txtQuitDate.Enabled = false;
            }

            if (dTPQuitDate.Enabled == true)
            {
                dTPQuitDate.Enabled = false;
            }

            if (btnSaveEmployee.Text == "Update Employee")
            {
                btnSaveEmployee.Text = "Save Employee";
            }

            if (btnSaveEmployee.Enabled == true)
            {
                btnSaveEmployee.Enabled = false;
            }

            if (btnAddEmployee.Enabled == false)
            {
                btnAddEmployee.Enabled = true;
            }

            dataGridViewEmployeeList.DataSource = objEmployeeDetailsManager.ShowAllEmployee();
            dataGridViewEmployeeList.Columns[0].Visible = false;
            dataGridViewEmployeeList.Columns[4].Visible = false;
            dataGridViewEmployeeList.Columns[6].Visible = false;
            dataGridViewEmployeeList.Columns[9].Visible = false;
            dataGridViewEmployeeList.Columns[12].Visible = false;
            dataGridViewEmployeeList.Columns[13].Visible = false;
            dataGridViewEmployeeList.Columns[14].Visible = false;
            dataGridViewEmployeeList.Columns[3].DefaultCellStyle.Format = "MM/dd/yyyy";

            btnAddEmployee.Focus();
        }

       private void btnRefreshEmployee_Click(object sender, EventArgs e)
       {
           RefreshEmployee();
       }

       private void RefreshDivision()
        {
            ClearDivision();

            CheckDesignation();

            if (cmbSelectTeam.Enabled == true)
            {
                cmbSelectTeam.Enabled = false;
            }

            if (txtDivisionName.Enabled == true)
            {
                txtDivisionName.Enabled = false;
            }

            if (cmbSelectDOForDivision.Enabled == true)
            {
                cmbSelectDOForDivision.Enabled = false;
            }

            if (cmbSelectGMForDivision.Enabled == true)
            {
                cmbSelectGMForDivision.Enabled = false;
            }

            if (cmbSelectDGMForDivision.Enabled == true)
            {
                cmbSelectDGMForDivision.Enabled = false;
            }

            if (cmbSelectDMForDivision.Enabled == true)
            {
                cmbSelectDMForDivision.Enabled = false;
            }

            if (cmbSelectSMForDivision.Enabled == true)
            {
                cmbSelectSMForDivision.Enabled = false;
            }

            if (cmbSelectASMForDivision.Enabled == true)
            {
                cmbSelectASMForDivision.Enabled = false;
            }

            if (cmbSelectTSMForDivision.Enabled == true)
            {
                cmbSelectTSMForDivision.Enabled = false;
            }

            if (cmbSelectSRForDivision.Enabled == true)
            {
                cmbSelectSRForDivision.Enabled = false;
            }

            if (cmbActiveForDivision.Enabled == true)
            {
                cmbActiveForDivision.Enabled = false;
            }

            if (btnSaveDivision.Text == "Update Division")
            {
                btnSaveDivision.Text = "Save Division";
            }

            if (btnSaveDivision.Enabled == true)
            {
                btnSaveDivision.Enabled = false;
            }

            if (btnLoadSM.Enabled == true)
            {
                btnLoadSM.Enabled = false;
            }

            if (btnLoadASM.Enabled == true)
            {
                btnLoadASM.Enabled = false;
            }

            if (btnLoadTSM.Enabled == true)
            {
                btnLoadTSM.Enabled = false;
            }

            if (btnLoadSR.Enabled == true)
            {
                btnLoadSR.Enabled = false;
            }

            if (btnAddToTempDivision.Enabled == true)
            {
                btnAddToTempDivision.Enabled = false;
            }

            if (btnLoadGroup.Enabled == true)
            {
                btnLoadGroup.Enabled = false;
            }

            dgvDivision.Visible = false;
            dgvPreviousAddedEmpList.Visible = false;
            dgvLoadDistinctDivision.Visible = true;
            dgvLoadDistinctDivision.Size = new Size(960, 595);
            dgvLoadDistinctDivision.Location = new Point(372, 10);
            dgvLoadDistinctDivision.DataSource = objDivisionDetailsManager.ShowDistinctDivision();
            //dgvLoadDistinctDivision.Columns[1].Visible = false;

            cmbSelectDivisionForUpdate.DataSource = objDivisionDetailsManager.ShowDistinctDivision();
            cmbSelectDivisionForUpdate.DisplayMember = "Division_Name";
            cmbSelectDivisionForUpdate.ValueMember = "Division_Name";
            cmbSelectDivisionForUpdate.Text = "Select Division";

            if (objDivisionDetailsManager.ShowDistinctDivision().Rows.Count > 0)
            {
                btnAddOrEditDataOfPrevDivision.Enabled = true;
                cmbSelectDivisionForUpdate.Enabled = true;
            }
            else
            {
                btnAddOrEditDataOfPrevDivision.Enabled = false;
                cmbSelectDivisionForUpdate.Enabled = false;
            }
        }

       private void btnRefreshMarket_Click(object sender, EventArgs e)
       {
           RefreshMarket();
       }

       private void RefreshMarket()
        {
            ClearMarketTab();

            if (txtMarketCode.Enabled == true)
            {
                txtMarketCode.Enabled = false;
            }

            if (txtMarketName.Enabled == true)
            {
                txtMarketName.Enabled = false;
            }

            if (txtTotalNoOfParty.Enabled == true)
            {
                txtTotalNoOfParty.Enabled = false;
            }

            if (txtTarget.Enabled == true)
            {
                txtTarget.Enabled = false;
            }

            if (txtMonthlyNoOfVisit.Enabled == true)
            {
                txtMonthlyNoOfVisit.Enabled = false;
            }

            if (cmbSelectDivisionForMarket.Enabled == true)
            {
                cmbSelectDivisionForMarket.Enabled = false;
            }
            //closed on 17 May 2016
            //if (cmbSelectGroupForMarket.Enabled == true)
            //{
            //    cmbSelectGroupForMarket.Enabled = false;
            //}

            //if (cmbSelectEmpForMarket.Enabled == true)
            //{
            //    cmbSelectEmpForMarket.Enabled = false;
            //}
            //end closed on 17 May 2016

            if (cmbMarketActive.Enabled == true)
            {
                cmbMarketActive.Enabled = false;
            }

            if (btnSaveMarket.Text == "Update Market")
            {
                btnSaveMarket.Text = "Save Market";
            }

            if (btnSaveMarket.Enabled == true)
            {
                btnSaveMarket.Enabled = false;
            }

            if (btnAddMarket.Enabled == false)
            {
                btnAddMarket.Enabled = true;
            }

            // closed 31 May 2016
            //dataGridViewMarket.DataSource = objMarketDetailsManager.AllMarketDetails();
            //dataGridViewMarket.Columns[0].Visible = false;
            //dataGridViewMarket.Columns[7].Visible = false;
            //dataGridViewMarket.Columns[11].Visible = false;
            //dataGridViewMarket.Columns[13].Visible = false;
            // end closed 31 May 2016

            cmbSelectDivisionForMarket.DataSource = objDivisionDetailsManager.LoadSelectDivision();
            cmbSelectDivisionForMarket.DisplayMember = "Division_Name";
            cmbSelectDivisionForMarket.ValueMember = "Division_Name";
            cmbSelectDivisionForMarket.Text = "Select Division";
            txtTeamNameForMarket.Text = "";
            txtTeamIDForMarket.Text = "";

            dataGridViewMarket.DataSource = objMarketDetailsManager.AllMarketDetails();
            dataGridViewMarket.Columns[0].Visible = false;
            dataGridViewMarket.Columns[7].Visible = false;
            dataGridViewMarket.Columns[8].Visible = false;
            dataGridViewMarket.Columns[9].Visible = false;
            dataGridViewMarket.Columns[10].Visible = false;
            dataGridViewMarket.Columns[11].Visible = false;
            //dataGridViewMarket.Columns[13].Visible = false;
            btnAddMarket.Focus();
        }

       private void btnRefreshMarketSetup_Click(object sender, EventArgs e)
       {
           RefreshMarketSetUp();
       }

       private void RefreshMarketSetUp()
        {
            if (cmbSelectMarketForMarketSetup.Enabled == true)
            {
                cmbSelectMarketForMarketSetup.Enabled = false;
            }

            if (cmbSelectGroupForMarketSetup.Enabled == true)
            {
                cmbSelectGroupForMarketSetup.Enabled = false;
            }

            if (cmbSelectDevisionForMarketSetup.Enabled == true)
            {
                cmbSelectDevisionForMarketSetup.Enabled = false;
            }

            if (cmbSelectEmployeeForMarketSetup.Enabled == true)
            {
                cmbSelectEmployeeForMarketSetup.Enabled = false;
            }

            if (btnSaveMarketSetup.Text == "Update Market Setup")
            {
                btnSaveMarketSetup.Text = "Save Market Setup";
            }

            btnSaveMarketSetup.Enabled = false;

            cmbSelectMarketForMarketSetup.Text = "Select Market";
            cmbSelectGroupForMarketSetup.Text = "Select Team";
            txtGroupIDForMarketSetup.Text = "";
            cmbSelectDevisionForMarketSetup.Text = "Select Division";
            cmbSelectEmployeeForMarketSetup.Text = "Select Employee";
            txtEmpIDForMarketSetup.Text = "";
            txtEmpDesigForMarketSetup.Text = "";
            txtEmpCellNoForMarketSetup.Text = "";
            if (dgvLoadMarketBySelectedDivision.Visible == true)
            {
                dgvLoadMarketBySelectedDivision.Visible = false;
            }
            dgvLoadMarketBySelectedDivision.Hide();

            dataGridViewMarketSetup.DataSource = objMarketDetailsManager.AllMarketDetails();
            dataGridViewMarketSetup.Columns[0].Visible = false;
            dataGridViewMarketSetup.Columns[3].Visible = false;
            dataGridViewMarketSetup.Columns[4].Visible = false;
            dataGridViewMarketSetup.Columns[5].Visible = false;
            dataGridViewMarketSetup.Columns[7].Visible = false;
            //dataGridViewMarketSetup.Columns[8].Visible = false;
            //dataGridViewMarketSetup.Columns[9].Visible = false;
            //dataGridViewMarketSetup.Columns[10].Visible = false;
            dataGridViewMarketSetup.Columns[11].Visible = false;
            //dataGridViewMarketSetup.Columns[12].Visible = false;
            //dataGridViewMarketSetup.Columns[13].Visible = false;
            //dataGridViewMarketSetup.Columns[14].Visible = false;
            //end new on 18 May 2016
            dataGridViewMarketSetup.Show();
        }

       private void btnRefreshProduct_Click(object sender, EventArgs e)
       {
           RefreshProduct();
       }

        private void RefreshProduct()
        {
            ClearProductTab();

            if (txtProductCode.Enabled == true)
            {
                txtProductCode.Enabled = false;
            }

            if (txtProductName.Enabled == true)
            {
                txtProductName.Enabled = false;
            }

            if (cmbPackSize.Enabled == true)
            {
                cmbPackSize.Enabled = false;
            }

            if (txtUnitCostPrice.Enabled == true)
            {
                txtUnitCostPrice.Enabled = false;
            }

            if (txtUnitSalePrice.Enabled == true)
            {
                txtUnitSalePrice.Enabled = false;
            }

            if (cmbProductActive.Enabled == true)
            {
                cmbProductActive.Enabled = false;
            }

            if (btnSaveProduct.Text == "Update Product") 
            {
                btnSaveProduct.Text = "Save Product";
            }

            if (btnSaveProduct.Enabled == true)
            {
                btnSaveProduct.Enabled = false;
            }

            if (btnAddProduct.Enabled == false)
            {
                btnAddProduct.Enabled = true;
            }

            dataGridViewProduct.DataSource = objProductDetailsManager.ShowAllProduct();

            btnAddProduct.Focus();
        }

       private void btnRefreshSalesTarget_Click(object sender, EventArgs e)
       {
           RefreshSalesTarget();
       }

       private void RefreshSalesTarget()
        {
            ClearSalesTargetTab();

            if (btnSaveTarget.Enabled == true)
            {
                btnSaveTarget.Enabled = false;
            }

            if (btnSaveTarget.Text == "Update Target")
            {
                btnSaveTarget.Text = "Save Target";
            }

            if (btnAddToList.Enabled == true)
            {
                btnAddToList.Enabled = false;
            }

            if (btnAddToList.Text == "Update List")
            {
                btnAddToList.Text = "Add To List";
            }

            if (txtFromDate.Enabled == true)
            {
                txtFromDate.Enabled = false;
            }

            if (dTPFromDate.Enabled == true)
            {
                dTPFromDate.Enabled = false;
            }

            if (txtToDate.Enabled == true)
            {
                txtToDate.Enabled = false;
            }

            if (dTPToDate.Enabled == true)
            {
                dTPToDate.Enabled = false;
            }

            if (btnBrowseProductCodeForSalesTarget.Enabled == true)
            {
                btnBrowseProductCodeForSalesTarget.Enabled = false;
            }

            if (txtProductCodeForSalesTarget.ReadOnly == true)
            {
                txtProductCodeForSalesTarget.ReadOnly = false;
            }

            if (txtProductIDForSalesTarget.ReadOnly == true)
            {
                txtProductIDForSalesTarget.ReadOnly = false;
            }

            if (txtProductNameForSalesTarget.ReadOnly == true)
            {
                txtProductNameForSalesTarget.ReadOnly = false;
            }

            if (txtProductPriceForSalesTarget.ReadOnly == true)
            {
                txtProductPriceForSalesTarget.ReadOnly = false;
            }

            if (cmbSelectGroupForSalesTarget.Enabled == true)
            {
                cmbSelectGroupForSalesTarget.Enabled = false;
            }
            //cmbSelectGroupForSalesTarget.DataSource = objGroupDetailsGateway.LoadSelectGroupForGroupSetup();
            //cmbSelectGroupForSalesTarget.DisplayMember = "Group_Name";
            //cmbSelectGroupForSalesTarget.ValueMember = "Group_Name";
            cmbSelectGroupForSalesTarget.Text = "";


            if (cmbSelectDesignationForSalesTarget.Enabled == true)
            {
                cmbSelectDesignationForSalesTarget.Enabled = false;
            }
            //cmbSelectDesignationForSalesTarget.DataSource = objDesignationDetailsManager.LoadDesignationCombo();
            //cmbSelectDesignationForSalesTarget.DisplayMember = "Designation";
            //cmbSelectDesignationForSalesTarget.ValueMember = "Designation";
            cmbSelectDesignationForSalesTarget.Text = "";


            if (cmbSelectEmployeeForSalesTarget.Enabled == true)
            {
                cmbSelectEmployeeForSalesTarget.Enabled = false;
                //if (cmbSelectGroupForSalesTarget.Text != "" && cmbSelectDesignationForSalesTarget.Text != "")
                //{
                //    cmbSelectEmployeeForSalesTarget.DataSource =
                //        objEmployeeDetailsManager.LoadEmployeeBySelectedGroupAndDesignation(cmbSelectGroupForSalesTarget.Text.ToString(), cmbSelectDesignationForSalesTarget.Text.ToString());
                //    cmbSelectEmployeeForSalesTarget.DisplayMember = "Employee_Name";
                //    cmbSelectEmployeeForSalesTarget.ValueMember = "Employee_Name";
                //}
                //cmbSelectEmployeeForSalesTarget.DataSource = objEmployeeDetailsManager.LoadEmployeeBySelectedGroupAndDesignation();
            }

            if (txtEmployeeIDForSalesTarget.ReadOnly == true)
            {
                txtEmployeeIDForSalesTarget.ReadOnly = false;
            }

            if (txtEmpMobileNoForSalesTarget.ReadOnly == true)
            {
                txtEmpMobileNoForSalesTarget.ReadOnly = false;
            }

            if (txtTargetUnitForSalesTarget.Enabled == true)
            {
                txtTargetUnitForSalesTarget.Enabled = false;
            }

            if (txtTargetAmountForSalesTarget.ReadOnly == true)
            {
                txtTargetAmountForSalesTarget.ReadOnly = false;
            }

            //if (dgvSalesDetails.Visible == true)
            //{
            //    dgvSalesDetails.Visible = false;
            //}

            if (dataGridViewSalesTarget.Visible == false)
            {
                dataGridViewSalesTarget.Visible = true;
            }

            //dgvSalesDetails.Visible = false;
            dgvProductListForSalesTarget.Visible = false;
            dgvSalesTargetDetails.Visible = false;
            dgvPrevAddedSalesTargetDetails.Visible = false;

            dataGridViewSalesTarget.DataSource = objSalesTargerDetailsManager.ShowAllSalesTarget();
            dataGridViewSalesTarget.Columns[0].Visible = false;
            dataGridViewSalesTarget.Columns[3].Visible = false;
            dataGridViewSalesTarget.Columns[9].Visible = false;

            GlobalClass.SalesTargetDataGridViewValue = 0;
            btnAddTarget.Enabled = true;
            btnAddTarget.Focus();
        }

       private void btnRefreshSalesDetails_Click(object sender, EventArgs e)
       {
           RefreshSalesDetails();
       }

        private void RefreshSalesDetails()
        {
            dgvSalesDetails.Columns.Clear();
            dgvSalesDetails.Refresh();
            dgvSalesDetails.DataSource = objSalesDetailsManager.ShowAllSales();
            dgvSalesDetails.Columns[0].Visible = false;
            dgvSalesDetails.Columns[1].DefaultCellStyle.Format = "MM/dd/yyyy";
            dgvSalesDetails.Columns[2].Visible = false;
            dgvSalesDetails.Columns[9].Visible = false;
        }

       private void btnRefreshProductPriceLog_Click(object sender, EventArgs e)
       {
           RefreshProductPriceLog();
       }

        private void RefreshProductPriceLog()
        {
            dgvProductPriceUpdateLog.Columns.Clear();
            dgvProductPriceUpdateLog.Refresh();
            dgvProductPriceUpdateLog.DataSource = objProductDetailsManager.ShowUpdateLogForAllProduct();
            dgvProductPriceUpdateLog.Columns[0].Visible = false;
        }

        private void RefreshSpecialItemSales()
        {
            ClearSpecialItemSaleTargetTab();

            if (btnSpecialItemSaleAddTarget.Enabled == false)
            {
                btnSpecialItemSaleAddTarget.Enabled = true;
            }

            if (btnSpecialItemSaleSaveTarget.Enabled == true)
            {
                btnSpecialItemSaleSaveTarget.Enabled = false;
            }

            if (btnSpecialItemSaleProductCodeBrowse.Enabled == true)
            {
                btnSpecialItemSaleProductCodeBrowse.Enabled = false;
            }

            if (txtSpecialItemSaleFromDate.Enabled == true)
            {
                txtSpecialItemSaleFromDate.Enabled = false;
            }

            if (txtSpecialItemSaleToDate.Enabled == true)
            {
                txtSpecialItemSaleToDate.Enabled = false;
            }

            if (txtSpecialItemSaleProductCode.Enabled == true)
            {
                txtSpecialItemSaleProductCode.Enabled = false;
            }

            if (txtSpecialItemSaleProductID.Enabled == true)
            {
                txtSpecialItemSaleProductID.Enabled = false;
            }

            if (txtSpecialItemSaleProductName.Enabled == true)
            {
                txtSpecialItemSaleProductName.Enabled = false;
            }

            if (txtSpecialItemSaleProductCostPrice.Enabled == true)
            {
                txtSpecialItemSaleProductCostPrice.Enabled = false;
            }

            if (txtSpecialItemSaleProductSalePrice.Enabled == true)
            {
                txtSpecialItemSaleProductSalePrice.Enabled = false;
            }

            if (txtSpecialItemSaleProductSpecialPrice.Enabled == true)
            {
                txtSpecialItemSaleProductSpecialPrice.Enabled = false;
            }

            if (cmbSpecialItemSaleSelectGroup.Enabled == true)
            {
                cmbSpecialItemSaleSelectGroup.Enabled = false;
            }

            if (cmbSpecialItemSaleSelectDesignation.Enabled == true)
            {
                cmbSpecialItemSaleSelectDesignation.Enabled = false;
            }

            if (cmbSpecialItemSaleSelectEmployee.Enabled == true)
            {
                cmbSpecialItemSaleSelectEmployee.Enabled = false;
            }

            if (txtSpecialItemSaleEmployeeID.Enabled == true)
            {
                txtSpecialItemSaleEmployeeID.Enabled = false;
            }

            if (txtSpecialItemSaleEmployeeMobileNo.Enabled == true)
            {
                txtSpecialItemSaleEmployeeMobileNo.Enabled = false;
            }

            if (txtSpecialItemSaleTargetUnit.Enabled == true)
            {
                txtSpecialItemSaleTargetUnit.Enabled = false;
            }

            if (txtSpecialItemSaleTargetAmount.Enabled == true)
            {
                txtSpecialItemSaleTargetAmount.Enabled = false;
            }

            dgvSpecialItemSalesTarget.DataSource = objSalesTargerDetailsManager.ShowAllSpecialItemSalesTarget();
            dgvSpecialItemSalesTarget.Columns[0].Visible = false;
            dgvSpecialItemSalesTarget.Columns[3].Visible = false;
            dgvSpecialItemSalesTarget.Columns[11].Visible = false;

            btnSpecialItemSaleAddTarget.Focus();
        }

        //public void checkProductCodeFromProductListUIForSalesTargetValue()
        //{
        //    if (GlobalClass.ProductCodeForSalesTarget != "")
        //    {
        //        txtProductCodeForSalesTarget.Text = GlobalClass.ProductCodeForSalesTarget.ToString();
        //    }
        //}
    }
}


//Dim SqlApp As New SQLDMO.Application
//Dim ServerList As String
//Dim ServCount As Integer

//Dim getDate As String
//Dim getTime As String
//Dim uniqueBackUpName As String
//Dim sqlServerName As String

//'Create the SQL-DMO Objects:
//Dim cn As SQLDMO.SQLServer, db As SQLDMO.Database
//Dim Backup As SQLDMO.Backup

//'Instantiate objects:
//Set Backup = New Backup
//Set cn = New SQLServer
//getDate = Format(Now(), "MMDDYYYY")
//getTime = Format(Time(), "HHMMSS")
//uniqueBackUpName = getDate + "_" + getTime + ".bak"

//ServerList = SqlApp.ListAvailableSQLServers(0)


//'List either MSDE or SQL Server (i.e. all Registered Servers)
//For ServCount = 1 To SqlApp.ServerGroups(1).RegisteredServers.Count
//    'MsgBox SqlApp.ServerGroups(1).RegisteredServers.Item(ServCount).Name
//sqlServerName = SqlApp.ServerGroups(1).RegisteredServers.Item(ServCount).Name
//Next

//'MsgBox sqlServerName
//'MsgBox uniqueBackUpName

//'Connect to SQL Server:
//cn.Connect sqlServerName, "sa", "123"

//'Create Database object:
//Set db = cn.Databases("InventoryAccountsManagementSystem")

//'Setup Backup object:
//Backup.Database = db.Name
//Backup.Files = "D:\DB_BackUp\" + uniqueBackUpName

//'Perform backup:
//Backup.SQLBackup cn

//MsgBox "Backup Created Successfully"

//'Clean up:
//cn.Disconnect
//Set Backup = Nothing
//Set db = Nothing
//Set cn = Nothing
//Exit Sub

//'Handle errors and clean up:
//ErrorHandler:
//MsgBox Err.Description, vbCritical, "Couldn't complete backup"
//cn.Disconnect
//Set Backup = Nothing
//Set db = Nothing
//Set cn = Nothing






//private void cmbSelectGroup_SelectedIndexChanged(object sender, EventArgs e)
//{
//    GlobalClass.GroupSelectedFromGroupSetup = cmbSelectGroup.Text;
//    GlobalClass.GroupIdForGroupSetup = objGroupDetailsManager.GetGroupID(GlobalClass.GroupSelectedFromGroupSetup);
//}

//private void cmbSelectGroup_SelectedValueChanged(object sender, EventArgs e)
//{
//    GlobalClass.GroupSelectedFromGroupSetup = cmbSelectGroup.Text;
//    GlobalClass.GroupIdForGroupSetup = objGroupDetailsManager.GetGroupID(GlobalClass.GroupSelectedFromGroupSetup);
//    //LoadGroupSetupCombo();
//}

/*
public void LoadGroupSetupCombo()
{
    cmbSelectGM.DataSource = objGroupSetupManager.LoadGM();
    if (objGroupSetupManager.LoadGM().Rows.Count > 0)
    {
        if (cmbSelectGM.Enabled == false)
        {
            cmbSelectGM.Enabled = true;
        }
        cmbSelectGM.DisplayMember = "Employee_Name";
        cmbSelectGM.ValueMember = "Employee_Name";
    }
    else
    {
        cmbSelectGM.Text = "";
        cmbSelectGM.Enabled = false;
    }

    cmbSelectDGM.DataSource = objGroupSetupManager.LoadDGM();
    if (objGroupSetupManager.LoadDGM().Rows.Count > 0)
    {
        if (cmbSelectDGM.Enabled == false)
        {
            cmbSelectDGM.Enabled = true;
        }
        cmbSelectDGM.DisplayMember = "Employee_Name";
        cmbSelectDGM.ValueMember = "Employee_Name";
    }
    else
    {
        cmbSelectDGM.Text = "";
        cmbSelectDGM.Enabled = false;
    }

    cmbSelectDM.DataSource = objGroupSetupManager.LoadDM();
    if (objGroupSetupManager.LoadDM().Rows.Count > 0)
    {
        if (cmbSelectDM.Enabled == false)
        {
            cmbSelectDM.Enabled = true;
        }
        cmbSelectDM.DisplayMember = "Employee_Name";
        cmbSelectDM.ValueMember = "Employee_Name";
    }
    else
    {
        cmbSelectDM.Text = "";
        cmbSelectDM.Enabled = false;
    }

    cmbSelectSM.DataSource = objGroupSetupManager.LoadSM();
    if (objGroupSetupManager.LoadSM().Rows.Count > 0)
    {
        if (cmbSelectSM.Enabled == false)
        {
            cmbSelectSM.Enabled = true;
        }
        cmbSelectSM.DisplayMember = "Employee_Name";
        cmbSelectSM.ValueMember = "Employee_Name";
    }
    else
    {
        cmbSelectSM.Text = "";
        cmbSelectSM.Enabled = false;
    }

    cmbSelectASM.DataSource = objGroupSetupManager.LoadASM();
    if (objGroupSetupManager.LoadASM().Rows.Count > 0)
    {
        if (cmbSelectASM.Enabled == false)
        {
            cmbSelectASM.Enabled = true;
        }
        cmbSelectASM.DisplayMember = "Employee_Name";
        cmbSelectASM.ValueMember = "Employee_Name";
    }
    else
    {
        cmbSelectASM.Text = "";
        cmbSelectASM.Enabled = false;
    }

    cmbSelectTSM.DataSource = objGroupSetupManager.LoadTSM();
    if (objGroupSetupManager.LoadTSM().Rows.Count > 0)
    {
        if (cmbSelectTSM.Enabled == false)
        {
            cmbSelectTSM.Enabled = true;
        }
        cmbSelectTSM.DisplayMember = "Employee_Name";
        cmbSelectTSM.ValueMember = "Employee_Name";
    }
    else
    {
        cmbSelectTSM.Text = "";
        cmbSelectTSM.Enabled = false;
    }

    cmbSelectSR.DataSource = objGroupSetupManager.LoadSR();
    if (objGroupSetupManager.LoadSR().Rows.Count > 0)
    {
        if (cmbSelectSR.Enabled == false)
        {
            cmbSelectSR.Enabled = true;
        }
        cmbSelectSR.DisplayMember = "Employee_Name";
        cmbSelectSR.ValueMember = "Employee_Name";
    }
    else
    {
        cmbSelectSR.Text = "";
        cmbSelectSR.Enabled = false;
    }

}
*/

//private void btnSaveGroupSetup_Click(object sender, EventArgs e)
//{
//    string groupName;
//    int DO;
//    int GM;
//    int DGM;
//    int DM;
//    int SM;
//    int ASM;
//    int TSM;
//    int SR;
//    int groupID;
//    int groupSetupID;

//    groupName = cmbSelectGroup.Text;
//    DO = Convert.ToInt32(txtNumberOfDO.Text);
//    GM = Convert.ToInt32(txtNumberOfGM.Text);
//    DGM = Convert.ToInt32(txtNumberOfDGM.Text);
//    DM = Convert.ToInt32(txtNumberOfDM.Text);
//    SM = Convert.ToInt32(txtNumberOfSM.Text);
//    ASM = Convert.ToInt32(txtNumberOfASM.Text);
//    TSM = Convert.ToInt32(txtNumberOfTSM.Text);
//    SR = Convert.ToInt32(txtNumberOfSR.Text);
//    groupID = Convert.ToInt32(GlobalClass.GroupIdForGroupSetup);
//    groupSetupID = Convert.ToInt32(GlobalClass.GroupSetupIdForUpdateGroupSetup);

//    if (btnSaveGroupSetup.Text == "Save")
//    {
//        objGroupSetupManager.InsertGroupData(groupName, DO, GM,DGM, DM, SM, ASM, TSM, SR, groupID);    
//    }

//    if (btnSaveGroupSetup.Text == "Update")
//    {
//        objGroupSetupManager.UpdateGroupData(groupSetupID, groupName, DO, GM, DGM, DM, SM, ASM, TSM, SR, groupID);
//    }
//}

//private void dataGridViewGroupSetup_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
//{
//    if (btnSaveGroupSetup.Enabled == false)
//    {
//        btnSaveGroupSetup.Enabled = true;
//    }
//    GlobalClass.GroupSetupIdForUpdateGroupSetup = dataGridViewGroupSetup.CurrentRow.Cells[0].Value.ToString();


//    //dataGridViewUserDetails.CurrentRow.Cells[0].Value.ToString();
//    /*
//        if (btnSaveUser.Enabled == false)
//    {
//        btnSaveUser.Enabled = true;
//    }
//    btnSaveUser.Text = "Update User";
//    GlobalClass.UserIdForEditUserDetails = dataGridViewUserDetails.CurrentRow.Cells[0].Value.ToString();
//    txtUserName.Text = dataGridViewUserDetails.CurrentRow.Cells[1].Value.ToString();
//    txtPassword.Text = dataGridViewUserDetails.CurrentRow.Cells[2].Value.ToString();
//    cmbUserRole.Text = dataGridViewUserDetails.CurrentRow.Cells[4].Value.ToString();
//    txtRoleID.Text = dataGridViewUserDetails.CurrentRow.Cells[3].Value.ToString();
//    cmbActive.Text = dataGridViewUserDetails.CurrentRow.Cells[5].Value.ToString();
//        */
//}

/*
private void btnAddEmployeeSetup_Click(object sender, EventArgs e)
{
    if (btnSaveGroupSetup.Enabled == false)
    {
        btnSaveGroupSetup.Enabled = true;
        btnAddGroupSetup.Enabled = false;
    }
    //cmbSelectDO.Text = "";
    cmbSelectGroup.Text = "";
    //cmbSelectGM.Text = "";
    //cmbSelectDGM.Text = "";
    //cmbSelectDM.Text = "";
    //cmbSelectSM.Text = "";
    //cmbSelectASM.Text = "";
    //cmbSelectTSM.Text = "";
    //cmbSelectSR.Text = "";
    //cmbSelectDO.Focus();
}

private void btnSaveEmployeeSetup_Click(object sender, EventArgs e)
{
    MessageBox.Show("Save & Update under process");
}
*/

//private void tbEmployee_Click(object sender, EventArgs e)
//{
//    cmbEmployeeDesignation.DataSource = objDesignationDetailsManager.LoadDesignationCombo();
//    cmbEmployeeDesignation.DisplayMember = "Designation";
//    cmbEmployeeDesignation.ValueMember = "Designation";

//    cmbEmployeeDepartment.DataSource = objDepartmentDetailsManager.LoadDepartmentCombo();
//    cmbEmployeeDepartment.DisplayMember = "Department_Name";
//    cmbEmployeeDepartment.ValueMember = "Department_Name";

//    cmbEmployeeGroup.DataSource = objGroupDetailsManager.LoadGroupCombo();
//    cmbEmployeeGroup.DisplayMember = "Group_Name";
//    cmbEmployeeGroup.ValueMember = "Group_Name";
//}

//private void txtTimeCheck_Enter(object sender, EventArgs e)
//{
//    ToolTip tt = new ToolTip();
//    tt.IsBalloon = true;
//    tt.InitialDelay = 0;
//    tt.ShowAlways = true;
//    tt.SetToolTip(txtStartTime, "Please enter value in this Format HH,MM,SS");
//}

//private void txtEndTime_Enter(object sender, EventArgs e)
//{
//    ToolTip tt = new ToolTip();
//    tt.IsBalloon = true;
//    tt.InitialDelay = 0;
//    tt.ShowAlways = true;
//    tt.SetToolTip(txtEndTime, "Please enter value in this Format HH,MM,SS");
//}

//private void txtEndTime_KeyUp(object sender, KeyEventArgs e)
//{
//    if (e.KeyCode == Keys.Enter)
//    {
//        MessageBox.Show(txtStartTime.Text);
//        MessageBox.Show(txtEndTime.Text);

//    }
//}
    
/*      private bool ShouldRunNow()
        {
            //////TimeSpan startTime = new TimeSpan(8, 0, 0);
            //////TimeSpan endTime = new TimeSpan(18, 0, 0);
            //////DateTime now = DateTime.Now;

            //////// Only run Saturday and Sunday
            //////if (now.DayOfWeek != DayOfWeek.Saturday && now.DayOfWeek != DayOfWeek.Sunday)
            //////    return false;

            //////// Only run between the specified times.
            //////if (endTime == startTime)
            //////    return true;

            //////if (endTime < startTime)
            //////    return now.TimeOfDay <= endTime || now.TimeOfDay >= startTime;

            //////return now.TimeOfDay >= startTime && now.TimeOfDay <= endTime;
            
            //workable test by Tanvir
            //TimeSpan startTime = new TimeSpan(5, 0, 0);
            //TimeSpan endTime = new TimeSpan(6, 10, 0);
            //if (endTime > startTime)
            //{
            //    return true;
            //}
            //return true;

            //close on 06/03/2016
            //TimeSpan startTime = new TimeSpan(4,0,0);
            //TimeSpan endTime = new TimeSpan(9,0,0);
            //end of close on 06/03/2016
            
            DateTime now = DateTime.Now;
            
            txtEndTime.Text = Convert.ToString(now.ToShortTimeString());
            int end_Time = Convert.ToInt32(txtStartTime.Text);
            int hour = Convert.ToInt32(now.ToShortTimeString().Substring(0, 2));
            

            // Only run Saturday and Sunday
            //if (now.DayOfWeek != DayOfWeek.Saturday && now.DayOfWeek != DayOfWeek.Sunday)
            //    return false;

            // Only run between the specified times.
            //MessageBox.Show(hour.ToString());
            //MessageBox.Show(end_Time.ToString());
            //MessageBox.Show(endTime.ToString());

            //close on 06/03/2016
            //if (endTime > startTime && end_Time > hour)
            //{
            //    flag = 1;
            //}
            //else if (endTime < startTime)
            //{
            //    flag = 0;
            //}
            //end of close on 06/03/2016

            //new code 06/03/2016
            if (hour == end_Time)
            {
                flag = 1;
                MessageBox.Show(flag.ToString());
            }
            else
            {
                flag = 0;
            }
            //end of new code 06/03/2016
            if (flag == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
            //if (endTime < startTime)
            //    return now.TimeOfDay <= endTime || now.TimeOfDay >= startTime;

            //return now.TimeOfDay >= startTime && now.TimeOfDay <= endTime;
            //return true;
        }
*/

/*

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.IO.Ports;
using System.Threading;
using System.Text.RegularExpressions;
using System.Windows.Forms;
 
namespace SMSapplication
{
    public class clsSMS
    {
 
        #region Open and Close Ports
        //Open Port
        public SerialPort OpenPort(string p_strPortName, int p_uBaudRate, int p_uDataBits, int p_uReadTimeout, int p_uWriteTimeout)
        {
            receiveNow = new AutoResetEvent(false);
            SerialPort port = new SerialPort();
 
            try
            {           
                port.PortName = p_strPortName;                 //COM1
                port.BaudRate = p_uBaudRate;                   //9600
                port.DataBits = p_uDataBits;                   //8
                port.StopBits = StopBits.One;                  //1
                port.Parity = Parity.None;                     //None
                port.ReadTimeout = p_uReadTimeout;             //300
                port.WriteTimeout = p_uWriteTimeout;           //300
                port.Encoding = Encoding.GetEncoding("iso-8859-1");
                port.DataReceived += new SerialDataReceivedEventHandler(port_DataReceived);
                port.Open();
                port.DtrEnable = true;
                port.RtsEnable = true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return port;
        }
 
        //Close Port
        public void ClosePort(SerialPort port)
        {
            try
            {
                port.Close();
                port.DataReceived -= new SerialDataReceivedEventHandler(port_DataReceived);
                port = null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
 
        #endregion

        //Execute AT Command
        public string ExecCommand(SerialPort port,string command, int responseTimeout, string errorMessage)
        {
            try
            {
               
                port.DiscardOutBuffer();
                port.DiscardInBuffer();
                receiveNow.Reset();
                port.Write(command + "\r");
           
                string input = ReadResponse(port, responseTimeout);
                if ((input.Length == 0) || ((!input.EndsWith("\r\n> ")) && (!input.EndsWith("\r\nOK\r\n"))))
                    throw new ApplicationException("No success message was received.");
                return input;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }   
 
        //Receive data from port
        public void port_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                if (e.EventType == SerialData.Chars)
                {
                    receiveNow.Set();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public string ReadResponse(SerialPort port,int timeout)
        {
            string buffer = string.Empty;
            try
            {    
                do
                {
                    if (receiveNow.WaitOne(timeout, false))
                    {
                        string t = port.ReadExisting();
                        buffer += t;
                    }
                    else
                    {
                        if (buffer.Length > 0)
                            throw new ApplicationException("Response received is incomplete.");
                        else
                            throw new ApplicationException("No data received from phone.");
                    }
                }
                while (!buffer.EndsWith("\r\nOK\r\n") && !buffer.EndsWith("\r\n> ") && !buffer.EndsWith("\r\nERROR\r\n"));
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return buffer;
        }
 
        #region Count SMS
        public int CountSMSmessages(SerialPort port)
        {
            int CountTotalMessages = 0;
            try
            {
 
                #region Execute Command

                string recievedData = ExecCommand(port, "AT", 300, "No phone connected at ");
                recievedData = ExecCommand(port, "AT+CMGF=1", 300, "Failed to set message format.");
                String command = "AT+CPMS=\"MT\"";
                recievedData = ExecCommand(port, command, 1000, "Failed to count SMS message");
                int uReceivedDataLength = recievedData.Length;
 
                #endregion

                #region If command is executed successfully
                if ((recievedData.Length >= 45) && (recievedData.StartsWith("AT+CPMS")))
                {
 
                    #region Parsing SMS
                    string[] strSplit = recievedData.Split(',');
                    MessageBox.Show(recievedData);
                    string strMessageStorageArea1 = strSplit[0];     //SM
                    string strMessageExist1 = strSplit[1];           //Msgs exist in SM
                    #endregion

                    #region Count Total Number of SMS In SIM
                    CountTotalMessages = Convert.ToInt32(strMessageExist1);
                    #endregion

                }
                #endregion

                #region If command is not executed successfully
                else if (recievedData.Contains("ERROR"))
                {
 
                    #region Error in Counting total number of SMS
                    string recievedError = recievedData;
                    recievedError = recievedError.Trim();
                    recievedData = "Following error occured while counting the message" + recievedError;
                    #endregion

                }
                #endregion

                return CountTotalMessages;
 
            }
            catch (Exception ex)
            {
                throw ex;
            }
           
        }
        #endregion

        #region Read SMS

        public AutoResetEvent receiveNow;
 
        public ShortMessageCollection ReadSMS(SerialPort port, string p_strCommand)
        {
 
            // Set up the phone and read the messages
            ShortMessageCollection messages = null;
            try
            {
 
                #region Execute Command
                // Check connection
                ExecCommand(port,"AT", 300, "No phone connected");
                // Use message format "Text mode"
                ExecCommand(port,"AT+CMGF=1", 300, "Failed to set message format.");
                // Use character set "PCCP437"
                ExecCommand(port,"AT+CSCS=\"PCCP437\"", 300, "Failed to set character set.");
                // Select SIM storage
                ExecCommand(port,"AT+CPMS=\"MT\"", 300, "Failed to select message storage.");
                // Read the messages
                string input = ExecCommand(port, p_strCommand, 5000, "Failed to read the messages.");
                #endregion

                #region Parse messages
                messages = ParseMessages(input);
                #endregion

            }
            catch (Exception ex)
            {
                throw ex;
            }
 
            if (messages != null)
                return messages;
            else
                return null;
        
        }
        public ShortMessageCollection ParseMessages(string input)
        {
            ShortMessageCollection messages = new ShortMessageCollection();
            try
            {     
                Regex r = new Regex(@"\+CMGL: (\d+),""(.+)"",""(.+)"",(.*),""(.+)""\r\n(.+)\r\n");
                Match m = r.Match(input);
                while (m.Success)
                {
                    ShortMessage msg = new ShortMessage();
                    //msg.Index = int.Parse(m.Groups[1].Value);
                    msg.Index = m.Groups[1].Value;
                    msg.Status = m.Groups[2].Value;
                    msg.Sender = m.Groups[3].Value;
                    msg.Alphabet = m.Groups[4].Value;
                    msg.Sent = m.Groups[5].Value;
                    msg.Message = m.Groups[6].Value;
                    messages.Add(msg);
 
                    m = m.NextMatch();
                }
 
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return messages;
        }
 
        #endregion

        #region Send SMS
       
        static AutoResetEvent readNow = new AutoResetEvent(false);
 
        public bool sendMsg(SerialPort port, string PhoneNo, string Message)
        {
            bool isSend = false;
 
            try
            {
                
                string recievedData = ExecCommand(port,"AT", 300, "No phone connected");
                recievedData = ExecCommand(port,"AT+CMGF=1", 300, "Failed to set message format.");
                String command = "AT+CMGS=\"" + PhoneNo + "\"";
                recievedData = ExecCommand(port,command, 300, "Failed to accept phoneNo");         
                command = Message + char.ConvertFromUtf32(26) + "\r";
                recievedData = ExecCommand(port,command, 3000, "Failed to send message"); //3 seconds
                if (recievedData.EndsWith("\r\nOK\r\n"))
                {
                    isSend = true;
                }
                else if (recievedData.Contains("ERROR"))
                {
                    isSend = false;
                }
                return isSend;
            }
            catch (Exception ex)
            {
                throw ex; 
            }
          
        }     
        static void DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                if (e.EventType == SerialData.Chars)
                    readNow.Set();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
 
        #endregion

        #region Delete SMS
        public bool DeleteMsg(SerialPort port , string p_strCommand)
        {
            bool isDeleted = false;
            try
            {
 
                #region Execute Command
                string recievedData = ExecCommand(port,"AT", 300, "No phone connected");
                recievedData = ExecCommand(port,"AT+CMGF=1", 300, "Failed to set message format.");
                String command = p_strCommand;
                recievedData = ExecCommand(port,command, 300, "Failed to delete message");
                #endregion

                if (recievedData.EndsWith("\r\nOK\r\n"))
                {
                    isDeleted = true;
                }
                if (recievedData.Contains("ERROR"))
                {
                    isDeleted = false;
                }
                return isDeleted;
            }
            catch (Exception ex)
            {
                throw ex; 
            }
            
        }  
        #endregion

    }
}
*/

/*
else if (GlobalClass.SelectOption == 2)
{
    ////////closed 03 Mar 2016
    //////this.tabSMSapplication.TabPages.Add(tbUserCreate);
    //////this.tabSMSapplication.TabPages.Add(tbGroup);
    //////this.tabSMSapplication.TabPages.Add(tbDepartment);
    //////this.tabSMSapplication.TabPages.Add(tbDesignation);
    //////this.tabSMSapplication.TabPages.Add(tbEmployee);
    //////this.tabSMSapplication.TabPages.Add(tbEmployeeSetUp);
    //////this.tabSMSapplication.TabPages.Add(tbProduct);
    //////this.tabSMSapplication.TabPages.Remove(tbPortSettings);
    ////////end closed 03 Mar 2016

    //////this.btnDisconnect.Enabled = false;
    //////this.btnOK.Enabled = false;
                    
    ////////load ComboBox's
    ////////closed 03 Mar 2016
    //////cmbUserRole.DataSource = objUserDetailsManager.com_UserType_Display();
    //////cmbUserRole.DisplayMember = "User_Role";
    //////cmbUserRole.ValueMember = "User_Role";
    ////////end closed 03 Mar 2016

    ////////closed 03 Mar 2016
    //////this.txtRoleID.Text = objUserRoleDetailsManager.GetUserRoleID(cmbUserRole.Text);
    ////////end closed 03 Mar 2016

    ////////load UserList
    ////////closed 03 Mar 2016
    //////dataGridViewUserDetails.DataSource = objUserDetailsManager.AllUserDetails();
    //////dataGridViewUserDetails.Columns[0].Visible = false;
    //////dataGridViewUserDetails.Columns[3].Visible = false;
    ////////end closed 03 Mar 2016

    ////////load Group List
    ////////closed 03 Mar 2016
    //////dataGridViewGroupDetails.DataSource = objGroupDetailsManager.AllGroupDetails();
    //////dataGridViewGroupDetails.Columns[0].Visible = false;

    //////btnSaveUser.Enabled = false;
    //////btnSaveGroup.Enabled = false;
    //////btnSaveDepartment.Enabled = false;
    //////btnSaveDesignation.Enabled = false;
    //////btnSaveEmployee.Enabled = false;
    ////////end closed 03 Mar 2016

    //////// load Department Grid View List
    //////dataGridViewDepartmentDetails.DataSource = objDepartmentDetailsManager.AllDepartmentDetails();
    //////dataGridViewDepartmentDetails.Columns[0].Visible = false;

    ////////load Designagnation
    //////dataGridViewDesignationList.DataSource = objDesignationDetailsManager.ShowAllDesignation();
    //////dataGridViewDesignationList.Columns[0].Visible = false;

    //////dataGridViewEmployeeList.DataSource = objEmployeeDetailsManager.ShowAllEmployee();
    //////dataGridViewEmployeeList.Columns[0].Visible = false;
    //////dataGridViewEmployeeList.Columns[4].Visible = false;
    //////dataGridViewEmployeeList.Columns[6].Visible = false;
    //////dataGridViewEmployeeList.Columns[9].Visible = false;

    //////cmbEmployeeDesignation.DataSource = objDesignationDetailsManager.LoadDesignationCombo();
    //////cmbEmployeeDesignation.DisplayMember = "Designation";
    //////cmbEmployeeDesignation.ValueMember = "Designation";

    //////cmbEmployeeDepartment.DataSource = objDepartmentDetailsManager.LoadDepartmentCombo();
    //////cmbEmployeeDepartment.DisplayMember = "Department_Name";
    //////cmbEmployeeDepartment.ValueMember = "Department_Name";

    //////cmbEmployeeGroup.DataSource = objGroupDetailsManager.LoadGroupCombo();
    //////cmbEmployeeGroup.DisplayMember = "Group_Name";
    //////cmbEmployeeGroup.ValueMember = "Group_Name";

    //////if (reset_Focus_Timer.Enabled == true)
    //////{
    //////    reset_Focus_Timer.Enabled = false;
    //////    //MessageBox.Show("Timer Started......");
    //////}

    //////if (Auto_Read_Timer.Enabled == true)
    //////{
    //////    Auto_Read_Timer.Enabled = false;
    //////}

    //////txtStartTime.Enabled = false;
    //////txtEndTime.Enabled = false;
    //////checkBoxSMSRead.Enabled = false;
    //////checkBoxSMSSend.Enabled = false;

}
*/
// private bool ShouldRunNow() //previous code
/*  Part 1
    TimeSpan startTime = new TimeSpan(8, 0, 0);
    TimeSpan endTime = new TimeSpan(18, 0, 0);
    DateTime now = DateTime.Now;

    // Only run Saturday and Sunday
    if (now.DayOfWeek != DayOfWeek.Saturday && now.DayOfWeek != DayOfWeek.Sunday)
        return false;

    // Only run between the specified times.
    if (endTime == startTime)
        return true;

    if (endTime < startTime)
        return now.TimeOfDay <= endTime || now.TimeOfDay >= startTime;

    return now.TimeOfDay >= startTime && now.TimeOfDay <= endTime;
            
    //workable test by Tanvir
    TimeSpan startTime = new TimeSpan(5, 0, 0);
    TimeSpan endTime = new TimeSpan(6, 10, 0);
    if (endTime > startTime)
    {
        return true;
    }
    return true;

    //close on 06/03/2016
    TimeSpan startTime = new TimeSpan(4,0,0);
    TimeSpan endTime = new TimeSpan(9,0,0);
    //end of close on 06/03/2016
*/

/* Part2
    // Only run Saturday and Sunday
    //if (now.DayOfWeek != DayOfWeek.Saturday && now.DayOfWeek != DayOfWeek.Sunday)
    //    return false;

    // Only run between the specified times.
    //MessageBox.Show(hour.ToString());
    //MessageBox.Show(end_Time.ToString());
    //MessageBox.Show(endTime.ToString());

    //close on 06/03/2016
    //if (endTime > startTime && end_Time > hour)
    //{
    //    flag = 1;
    //}
    //else if (endTime < startTime)
    //{
    //    flag = 0;
    //}
    //end of close on 06/03/2016
    */

/* Part 3
    //if (endTime < startTime)
    //    return now.TimeOfDay <= endTime || now.TimeOfDay >= startTime;

    //return now.TimeOfDay >= startTime && now.TimeOfDay <= endTime;
    //return true;
*/
// End of previous code
