﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using SMSapplication.BLL;
using SMSapplication.DAL.DAO;

namespace SMSapplication.UI
{
    public partial class EnableDisableDivisionUI : Form
    {
        
        DivisionDetailsManager  objDivisionDetailsManager = new DivisionDetailsManager();
        SMSapplication objSmSapplication = new SMSapplication();
        public EnableDisableDivisionUI()
        {
            InitializeComponent();
        }

        private void EnableDisableDivisionUI_Load(object sender, EventArgs e)
        {
            if (cmbSelectDivisionForEnableOrDisable.Enabled == true)
            {
                cmbSelectDivisionForEnableOrDisable.Enabled = false;
            }

            radioButtonDisableDivision.Checked = false;
            radioButtonEnableDivision.Checked = false;

            btnEnableOrDisable.Focus();
        }

        private void radioButtonEnableDivision_CheckedChanged(object sender, EventArgs e)
        {
            //if (radioButtonDisableDivision.Checked == true)
            //{
            //    radioButtonDisableDivision.Checked = false;
            //}

            //cmbSelectDivisionForEnableOrDisable.Enabled = true;
            //cmbSelectDivisionForEnableOrDisable.DataSource = objDivisionDetailsManager.LoadDistinctDisabledDivision();
            //cmbSelectDivisionForEnableOrDisable.DisplayMember = "Division_Name";
            //cmbSelectDivisionForEnableOrDisable.ValueMember = "Division_Name";
            //cmbSelectDivisionForEnableOrDisable.Text = "Select Division";
        }

        private void radioButtonDisableDivision_CheckedChanged(object sender, EventArgs e)
        {
            //if (radioButtonEnableDivision.Checked == true)
            //{
            //    radioButtonEnableDivision.Checked = false;
            //}

            //cmbSelectDivisionForEnableOrDisable.Enabled = true;
            //cmbSelectDivisionForEnableOrDisable.DataSource = objDivisionDetailsManager.LoadDistinctEnabledDivision();
            //cmbSelectDivisionForEnableOrDisable.DisplayMember = "Division_Name";
            //cmbSelectDivisionForEnableOrDisable.ValueMember = "Division_Name";
            //cmbSelectDivisionForEnableOrDisable.Text = "Select Division";
        }

        private void radioButtonEnableDivision_Click(object sender, EventArgs e)
        {
            if (radioButtonDisableDivision.Checked == true)
            {
                radioButtonDisableDivision.Checked = false;
            }

            cmbSelectDivisionForEnableOrDisable.Enabled = true;
            cmbSelectDivisionForEnableOrDisable.DataSource = objDivisionDetailsManager.LoadDistinctDisabledDivision();
            cmbSelectDivisionForEnableOrDisable.DisplayMember = "Division_Name";
            cmbSelectDivisionForEnableOrDisable.ValueMember = "Division_Name";
            cmbSelectDivisionForEnableOrDisable.Text = "Select Division";
        }

        private void radioButtonDisableDivision_Click(object sender, EventArgs e)
        {
            if (radioButtonEnableDivision.Checked == true)
            {
                radioButtonEnableDivision.Checked = false;
            }

            cmbSelectDivisionForEnableOrDisable.Enabled = true;
            cmbSelectDivisionForEnableOrDisable.DataSource = objDivisionDetailsManager.LoadDistinctEnabledDivision();
            cmbSelectDivisionForEnableOrDisable.DisplayMember = "Division_Name";
            cmbSelectDivisionForEnableOrDisable.ValueMember = "Division_Name";
            cmbSelectDivisionForEnableOrDisable.Text = "Select Division";
        }

        private void btnCancelEnableOrDisable_Click(object sender, EventArgs e)
        {
            ActiveForm.Close();
        }

        private void btnEnableOrDisable_Click(object sender, EventArgs e)
        {
            if (radioButtonDisableDivision.Checked == true)
            {
                if (cmbSelectDivisionForEnableOrDisable.Text != "Select Division")
                {
                    objDivisionDetailsManager.DisableDivision(cmbSelectDivisionForEnableOrDisable.Text, cmbSelectGroupForEnableDisableDivision.Text);
                }
                MessageBox.Show("Division Disabled Successfully");
            }
            else if (radioButtonEnableDivision.Checked == true)
            {
                if (cmbSelectDivisionForEnableOrDisable.Text != "Select Division")
                {
                    objDivisionDetailsManager.EnableDivision(cmbSelectDivisionForEnableOrDisable.Text, cmbSelectGroupForEnableDisableDivision.Text);
                }
                MessageBox.Show("Division Enabled Successfully");
            }

            GlobalClass.EnableDisableFormValueForReloadDivisionGrid = 1;
            objSmSapplication.dgvLoadDistinctDivision.DataSource = objDivisionDetailsManager.ShowDistinctDivision();
            //objSmSapplication.dgvLoadDistinctDivision.Columns[1].Visible = false;
            this.Close();
            objSmSapplication.dgvLoadDistinctDivision.Focus();
            
            //objSmSapplication.Refresh();
        }

        private void cmbSelectDivisionForEnableOrDisable_TextChanged(object sender, EventArgs e)
        {
            if (cmbSelectDivisionForEnableOrDisable.Text != "Select Division")
            {
                cmbSelectGroupForEnableDisableDivision.Enabled = true;
                cmbSelectGroupForEnableDisableDivision.DataSource = objDivisionDetailsManager.LoadDistinctGroup(cmbSelectDivisionForEnableOrDisable.Text);
                cmbSelectGroupForEnableDisableDivision.DisplayMember = "Group_Name";
                cmbSelectGroupForEnableDisableDivision.ValueMember = "Group_Name";
                cmbSelectGroupForEnableDisableDivision.Text = "Select Team";
            }
        }
    }
}
