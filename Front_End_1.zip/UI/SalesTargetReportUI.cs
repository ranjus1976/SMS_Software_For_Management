﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using CrystalDecisions.Windows.Forms;
using SMSapplication.Reports;
using SMSapplication.BLL;
using SMSapplication.DAL.DAO;
using SMSapplication.DAL.Gateway;

namespace SMSapplication.UI
{
    public partial class SalesTargetReportUI : Form
    {
        GroupDetailsManager objGroupDetailsManager = new GroupDetailsManager();
        DivisionDetailsManager objDivisionDetailsManager = new DivisionDetailsManager();
        SalesTargerDetailsManager objSalesTargerDetailsManager = new SalesTargerDetailsManager();
        DataTable dt = new DataTable();
        DataTable tmpDt = new DataTable();
        public SalesTargetReportUI()
        {
            InitializeComponent();
        }

        private void btnUserReport_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtSearchDateFrom.Text == "")
                {
                    MessageBox.Show("From Date can't be blank !");
                    txtSearchDateFrom.Focus();
                }
                else if ( txtSearchDateTo.Text == "")
                {
                    MessageBox.Show("To Date can't be blank !");
                    txtSearchDateTo.Focus();
                }

                if (cmbSelectGroupForSalesTarget.Text == "Select Team" || cmbSelectGroupForSalesTarget.Text == "All Team" && cmbSelectDivisionForSalesTarget.Text == "Select Division" || cmbSelectDivisionForSalesTarget.Enabled == false && cmbSelectEmployeeForSalesTarget.Enabled == false || cmbSelectEmployeeForSalesTarget.Text == "Select Employee")
                {
                    dt = objSalesTargerDetailsManager.GetAllSalesTarget(txtSearchDateFrom.Text, txtSearchDateTo.Text);
                }

                string reportPath = Application.StartupPath + "\\Reports\\SalesTargetReport.rpt";

                tmpDt = objSalesTargerDetailsManager.GetTempData();

                ReportDocument reportDocument = new ReportDocument();
                ReportViewer objViewer = new ReportViewer();
                reportDocument.Load(reportPath);
                reportDocument.SetDataSource(tmpDt);
                objViewer.CrystalReportViewer1.ReportSource = reportDocument;
                objViewer.CrystalReportViewer1.Refresh();
                objViewer.ShowDialog();
                this.Close();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void SalesTargetReportUI_Load(object sender, EventArgs e)
        {
            
        }

        private void cmbSelectGroupForSalesTarget_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbSelectGroupForSalesTarget.Text == "Select Team")
            {
                
            }
            else if (cmbSelectGroupForSalesTarget.Text == "All Team")
            {

            }
            else if (cmbSelectGroupForSalesTarget.Text != "Select Team" || cmbSelectGroupForSalesTarget.Text != "All Team")
            {
                //if (cmbSelectDivisionForSalesTarget.Enabled == false)
                //{
                //    cmbSelectDivisionForSalesTarget.Enabled = true;
                //}
                
                cmbSelectDivisionForSalesTarget.DataSource = objDivisionDetailsManager.LoadDivisionBySelectedGroup(cmbSelectGroupForSalesTarget.Text);
                cmbSelectDivisionForSalesTarget.DisplayMember = "Division_Name";
                cmbSelectDivisionForSalesTarget.ValueMember = "Division_Name";
                cmbSelectDivisionForSalesTarget.Text = "Select Division";
            }
        }

        private void dtpSearchDateTo_CloseUp(object sender, EventArgs e)
        {
            txtSearchDateTo.Text = dtpSearchDateTo.Text.ToString();

            cmbSelectGroupForSalesTarget.DataSource = objGroupDetailsManager.LoadGroupCombo();
            cmbSelectGroupForSalesTarget.DisplayMember = "Group_Name";
            cmbSelectGroupForSalesTarget.ValueMember = "Group_Name";
            cmbSelectGroupForSalesTarget.Text = "Select Team";

            if (cmbSelectGroupForSalesTarget.Enabled == false)
            {
                cmbSelectGroupForSalesTarget.Enabled = true;
            }
          
        }

        private void cmbSelectDivisionForSalesTarget_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbSelectDivisionForSalesTarget.Text == "Select Division")
            {

            }
            else if (cmbSelectDivisionForSalesTarget.Text == "All Division")
            {

            }
            else if (cmbSelectDivisionForSalesTarget.Text != "Select Division" || cmbSelectDivisionForSalesTarget.Text != "All Division")
            {
                //if (cmbSelectEmployeeForSalesTarget.Enabled == false)
                //{
                //    cmbSelectEmployeeForSalesTarget.Enabled = true;
                //}

                cmbSelectEmployeeForSalesTarget.DataSource = objDivisionDetailsManager.LoadEmployeeBySelectedDivision(cmbSelectDivisionForSalesTarget.Text);
                cmbSelectEmployeeForSalesTarget.DisplayMember = "Employee_Name";
                cmbSelectEmployeeForSalesTarget.ValueMember = "Employee_Name";
                cmbSelectEmployeeForSalesTarget.Text = "Select Employee";
            }
        }

        private void cmbSelectEmployeeForSalesTarget_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbSelectEmployeeForSalesTarget.Text == "Select Employee")
            {

            }
            else if (cmbSelectEmployeeForSalesTarget.Text == "All Employee")
            {

            }
            else if (cmbSelectEmployeeForSalesTarget.Text != "Select Employee" || cmbSelectEmployeeForSalesTarget.Text != "All Employee")
            {
                
            }
        }

        private void dtpSearchDateFrom_CloseUp(object sender, EventArgs e)
        {
            txtSearchDateFrom.Text = dtpSearchDateFrom.Text.ToString();
        }

        private void cmbSelectGroupForSalesTarget_SelectedValueChanged(object sender, EventArgs e)
        {
            if (cmbSelectGroupForSalesTarget.Text == "Select Team")
            {

            }
            else if (cmbSelectGroupForSalesTarget.Text == "All Team")
            {

            }
            else if (cmbSelectGroupForSalesTarget.Text != "Select Team" || cmbSelectGroupForSalesTarget.Text != "All Team")
            {
                if (cmbSelectDivisionForSalesTarget.Enabled == false)
                {
                    cmbSelectDivisionForSalesTarget.Enabled = true;
                }

                cmbSelectDivisionForSalesTarget.DataSource = objDivisionDetailsManager.LoadDivisionBySelectedGroup(cmbSelectGroupForSalesTarget.Text);
                cmbSelectDivisionForSalesTarget.DisplayMember = "Division_Name";
                cmbSelectDivisionForSalesTarget.ValueMember = "Division_Name";
                cmbSelectDivisionForSalesTarget.Text = "Select Division";
            }
        }
    }
}
