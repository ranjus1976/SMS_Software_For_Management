﻿namespace SMSapplication.UI
{
    partial class ProductListForSalesTargetUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProductListForSalesTargetUI));
            this.btnSaveProductList = new System.Windows.Forms.Button();
            this.dgvProductListForSalesTarget = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProductListForSalesTarget)).BeginInit();
            this.SuspendLayout();
            // 
            // btnSaveProductList
            // 
            this.btnSaveProductList.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveProductList.Location = new System.Drawing.Point(829, 474);
            this.btnSaveProductList.Name = "btnSaveProductList";
            this.btnSaveProductList.Size = new System.Drawing.Size(120, 25);
            this.btnSaveProductList.TabIndex = 68;
            this.btnSaveProductList.Text = "Save List";
            this.btnSaveProductList.UseVisualStyleBackColor = true;
            this.btnSaveProductList.Click += new System.EventHandler(this.btnSaveProductList_Click);
            // 
            // dgvProductListForSalesTarget
            // 
            this.dgvProductListForSalesTarget.AllowUserToAddRows = false;
            this.dgvProductListForSalesTarget.AllowUserToDeleteRows = false;
            this.dgvProductListForSalesTarget.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvProductListForSalesTarget.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dgvProductListForSalesTarget.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProductListForSalesTarget.Location = new System.Drawing.Point(1, 1);
            this.dgvProductListForSalesTarget.MultiSelect = false;
            this.dgvProductListForSalesTarget.Name = "dgvProductListForSalesTarget";
            this.dgvProductListForSalesTarget.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvProductListForSalesTarget.Size = new System.Drawing.Size(952, 462);
            this.dgvProductListForSalesTarget.TabIndex = 69;
            this.dgvProductListForSalesTarget.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvProductListForSalesTarget_CellClick);
            this.dgvProductListForSalesTarget.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dgvProductListForSalesTarget_KeyPress);
            // 
            // ProductListForSalesTargetUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(955, 598);
            this.Controls.Add(this.dgvProductListForSalesTarget);
            this.Controls.Add(this.btnSaveProductList);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ProductListForSalesTargetUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Product List";
            this.Load += new System.EventHandler(this.ProductListForSalesTargetUI_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvProductListForSalesTarget)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnSaveProductList;
        private System.Windows.Forms.DataGridView dgvProductListForSalesTarget;
    }
}