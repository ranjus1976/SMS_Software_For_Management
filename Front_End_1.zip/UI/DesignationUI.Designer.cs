﻿namespace SMSapplication.UI
{
    partial class DesignationUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DesignationUI));
            this.groupBoxDesignation = new System.Windows.Forms.GroupBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnDesignationReport = new System.Windows.Forms.Button();
            this.btnRefreshDesignation = new System.Windows.Forms.Button();
            this.btnAddDesignation = new System.Windows.Forms.Button();
            this.btnSaveDesignation = new System.Windows.Forms.Button();
            this.cmbActiveDesignation = new System.Windows.Forms.ComboBox();
            this.lblDesignationActive = new System.Windows.Forms.Label();
            this.txtDesignationDetails = new System.Windows.Forms.TextBox();
            this.txtDesignation = new System.Windows.Forms.TextBox();
            this.lblDesignationDetails = new System.Windows.Forms.Label();
            this.lblDesignation = new System.Windows.Forms.Label();
            this.dataGridViewDesignationList = new System.Windows.Forms.DataGridView();
            this.groupBoxDesignation.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDesignationList)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBoxDesignation
            // 
            this.groupBoxDesignation.Controls.Add(this.btnClose);
            this.groupBoxDesignation.Controls.Add(this.btnDesignationReport);
            this.groupBoxDesignation.Controls.Add(this.btnRefreshDesignation);
            this.groupBoxDesignation.Controls.Add(this.btnAddDesignation);
            this.groupBoxDesignation.Controls.Add(this.btnSaveDesignation);
            this.groupBoxDesignation.Controls.Add(this.cmbActiveDesignation);
            this.groupBoxDesignation.Controls.Add(this.lblDesignationActive);
            this.groupBoxDesignation.Controls.Add(this.txtDesignationDetails);
            this.groupBoxDesignation.Controls.Add(this.txtDesignation);
            this.groupBoxDesignation.Controls.Add(this.lblDesignationDetails);
            this.groupBoxDesignation.Controls.Add(this.lblDesignation);
            this.groupBoxDesignation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxDesignation.Location = new System.Drawing.Point(6, 0);
            this.groupBoxDesignation.Name = "groupBoxDesignation";
            this.groupBoxDesignation.Size = new System.Drawing.Size(722, 120);
            this.groupBoxDesignation.TabIndex = 15;
            this.groupBoxDesignation.TabStop = false;
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Location = new System.Drawing.Point(598, 86);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(120, 25);
            this.btnClose.TabIndex = 7;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnDesignationReport
            // 
            this.btnDesignationReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDesignationReport.Location = new System.Drawing.Point(356, 86);
            this.btnDesignationReport.Name = "btnDesignationReport";
            this.btnDesignationReport.Size = new System.Drawing.Size(120, 25);
            this.btnDesignationReport.TabIndex = 5;
            this.btnDesignationReport.Text = "Desg. Report";
            this.btnDesignationReport.UseVisualStyleBackColor = true;
            this.btnDesignationReport.Click += new System.EventHandler(this.btnDesignationReport_Click);
            // 
            // btnRefreshDesignation
            // 
            this.btnRefreshDesignation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefreshDesignation.Location = new System.Drawing.Point(477, 86);
            this.btnRefreshDesignation.Name = "btnRefreshDesignation";
            this.btnRefreshDesignation.Size = new System.Drawing.Size(120, 25);
            this.btnRefreshDesignation.TabIndex = 6;
            this.btnRefreshDesignation.Text = "Refresh";
            this.btnRefreshDesignation.UseVisualStyleBackColor = true;
            // 
            // btnAddDesignation
            // 
            this.btnAddDesignation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddDesignation.Location = new System.Drawing.Point(356, 56);
            this.btnAddDesignation.Name = "btnAddDesignation";
            this.btnAddDesignation.Size = new System.Drawing.Size(180, 25);
            this.btnAddDesignation.TabIndex = 0;
            this.btnAddDesignation.Text = "Add Designation";
            this.btnAddDesignation.UseVisualStyleBackColor = true;
            this.btnAddDesignation.Click += new System.EventHandler(this.btnAddDesignation_Click);
            // 
            // btnSaveDesignation
            // 
            this.btnSaveDesignation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveDesignation.Location = new System.Drawing.Point(538, 56);
            this.btnSaveDesignation.Name = "btnSaveDesignation";
            this.btnSaveDesignation.Size = new System.Drawing.Size(180, 25);
            this.btnSaveDesignation.TabIndex = 4;
            this.btnSaveDesignation.Text = "Save Designation";
            this.btnSaveDesignation.UseVisualStyleBackColor = true;
            this.btnSaveDesignation.Click += new System.EventHandler(this.btnSaveDesignation_Click);
            // 
            // cmbActiveDesignation
            // 
            this.cmbActiveDesignation.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbActiveDesignation.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbActiveDesignation.Enabled = false;
            this.cmbActiveDesignation.FormattingEnabled = true;
            this.cmbActiveDesignation.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cmbActiveDesignation.Location = new System.Drawing.Point(124, 87);
            this.cmbActiveDesignation.Name = "cmbActiveDesignation";
            this.cmbActiveDesignation.Size = new System.Drawing.Size(226, 24);
            this.cmbActiveDesignation.TabIndex = 3;
            this.cmbActiveDesignation.Text = "Select Active";
            // 
            // lblDesignationActive
            // 
            this.lblDesignationActive.AutoSize = true;
            this.lblDesignationActive.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDesignationActive.Location = new System.Drawing.Point(4, 90);
            this.lblDesignationActive.Name = "lblDesignationActive";
            this.lblDesignationActive.Size = new System.Drawing.Size(59, 16);
            this.lblDesignationActive.TabIndex = 11;
            this.lblDesignationActive.Text = "Active :";
            // 
            // txtDesignationDetails
            // 
            this.txtDesignationDetails.Enabled = false;
            this.txtDesignationDetails.Location = new System.Drawing.Point(124, 57);
            this.txtDesignationDetails.Name = "txtDesignationDetails";
            this.txtDesignationDetails.Size = new System.Drawing.Size(226, 22);
            this.txtDesignationDetails.TabIndex = 2;
            // 
            // txtDesignation
            // 
            this.txtDesignation.Enabled = false;
            this.txtDesignation.Location = new System.Drawing.Point(124, 24);
            this.txtDesignation.Name = "txtDesignation";
            this.txtDesignation.Size = new System.Drawing.Size(226, 22);
            this.txtDesignation.TabIndex = 1;
            // 
            // lblDesignationDetails
            // 
            this.lblDesignationDetails.AutoSize = true;
            this.lblDesignationDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDesignationDetails.Location = new System.Drawing.Point(4, 60);
            this.lblDesignationDetails.Name = "lblDesignationDetails";
            this.lblDesignationDetails.Size = new System.Drawing.Size(114, 16);
            this.lblDesignationDetails.TabIndex = 1;
            this.lblDesignationDetails.Text = "Desig. Details :";
            // 
            // lblDesignation
            // 
            this.lblDesignation.AutoSize = true;
            this.lblDesignation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDesignation.Location = new System.Drawing.Point(4, 30);
            this.lblDesignation.Name = "lblDesignation";
            this.lblDesignation.Size = new System.Drawing.Size(102, 16);
            this.lblDesignation.TabIndex = 0;
            this.lblDesignation.Text = "Desig. Code :";
            // 
            // dataGridViewDesignationList
            // 
            this.dataGridViewDesignationList.AllowUserToAddRows = false;
            this.dataGridViewDesignationList.AllowUserToDeleteRows = false;
            this.dataGridViewDesignationList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewDesignationList.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridViewDesignationList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDesignationList.Location = new System.Drawing.Point(6, 129);
            this.dataGridViewDesignationList.MultiSelect = false;
            this.dataGridViewDesignationList.Name = "dataGridViewDesignationList";
            this.dataGridViewDesignationList.ReadOnly = true;
            this.dataGridViewDesignationList.RowHeadersWidth = 40;
            this.dataGridViewDesignationList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewDesignationList.Size = new System.Drawing.Size(722, 392);
            this.dataGridViewDesignationList.TabIndex = 16;
            this.dataGridViewDesignationList.TabStop = false;
            this.dataGridViewDesignationList.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewDesignationList_CellContentDoubleClick);
            this.dataGridViewDesignationList.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewDesignationList_CellDoubleClick);
            // 
            // DesignationUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(734, 526);
            this.Controls.Add(this.dataGridViewDesignationList);
            this.Controls.Add(this.groupBoxDesignation);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "DesignationUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add / Edit Designation";
            this.Load += new System.EventHandler(this.DesignationUI_Load);
            this.groupBoxDesignation.ResumeLayout(false);
            this.groupBoxDesignation.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDesignationList)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxDesignation;
        private System.Windows.Forms.ComboBox cmbActiveDesignation;
        private System.Windows.Forms.Label lblDesignationActive;
        private System.Windows.Forms.TextBox txtDesignationDetails;
        private System.Windows.Forms.TextBox txtDesignation;
        private System.Windows.Forms.Label lblDesignationDetails;
        private System.Windows.Forms.Label lblDesignation;
        private System.Windows.Forms.Button btnRefreshDesignation;
        private System.Windows.Forms.Button btnAddDesignation;
        private System.Windows.Forms.Button btnSaveDesignation;
        private System.Windows.Forms.DataGridView dataGridViewDesignationList;
        private System.Windows.Forms.Button btnDesignationReport;
        private System.Windows.Forms.Button btnClose;
    }
}