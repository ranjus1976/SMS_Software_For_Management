﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using SMSapplication.BLL;
using SMSapplication.DAL;
using SMSapplication.DAL.DAO;
using SMSapplication.DAL.Gateway;
using SMSapplication.UI;

namespace SMSapplication.UI
{
    public partial class ZoneUI : Form
    {
        DivisionDetailsManager objDivisionDetailsManager = new DivisionDetailsManager();
        DesignationDetailsManager objDesignationDetailsManager = new DesignationDetailsManager();
        EmployeeDetailsManager objEmployeeDetailsManager = new EmployeeDetailsManager();
        GroupDetailsManager objGroupDetailsManager = new GroupDetailsManager();
        RegionDetailsManager objRegionDetailsManager = new RegionDetailsManager();
        ZoneDetailsManager objZoneDetailsManager = new ZoneDetailsManager();
        

        private int zoneId;
        private string zoneName;
        private string empName;
        private string empDesignationCode;
        private string zoneActivityStartDate;
        private string zoneActivityEndDate;
        private string zoneActive;
        private string regionNameForZone;
        private int regionIdForZone;
        
        public ZoneUI()
        {
            InitializeComponent();
            RefreshZone();
        }

        public void RefreshZone()
        {
            ClearZone();

            if (txtZoneName.Enabled == true)
            {
                txtZoneName.Enabled = false;
            }

            if (cmbSelectDesignationForZone.Enabled == true)
            {
                cmbSelectDesignationForZone.Enabled = false;
            }

            if (cmbSelectEmployeeForZone.Enabled == true)
            {
                cmbSelectEmployeeForZone.Enabled = false;
            }

            if (txtZoneActivityStartDate.Enabled == true)
            {
                txtZoneActivityStartDate.Enabled = false;
            }

            if (dTPZoneActivityStartDate.Enabled == true)
            {
                dTPZoneActivityStartDate.Enabled = false;
            }

            if (txtZoneActivityEndDate.Enabled == true)
            {
                txtZoneActivityEndDate.Enabled = false;
            }

            if (dTPZoneActivityEndDate.Enabled == true)
            {
                dTPZoneActivityEndDate.Enabled = false;
            }

            if (cmbSelectRegionForZone.Enabled == true)
            {
                cmbSelectRegionForZone.Enabled = false;
            }

            if (cmbZoneActive.Enabled == true)
            {
                cmbZoneActive.Enabled = false;
            }

            if (btnSaveZone.Text == "Update Zone")
            {
                btnSaveZone.Text = "Save Zone";
            }

            if (btnSaveZone.Enabled == true)
            {
                btnSaveZone.Enabled = false;
            }

            dataGridViewZoneDetails.DataSource = objZoneDetailsManager.ShowAllZone();
            dataGridViewZoneDetails.Columns[0].Visible = false;
            DataGridViewZoneDetailsHeaderText();
            btnAddZone.Focus();
        }

        public void DataGridViewZoneDetailsHeaderText()
        {
            dataGridViewZoneDetails.Columns[1].HeaderText = "Zone Name";
            dataGridViewZoneDetails.Columns[2].HeaderText = "Employee Name";
            dataGridViewZoneDetails.Columns[3].HeaderText = "Designation Code";
            dataGridViewZoneDetails.Columns[4].HeaderText = "Activity Start Date";
            dataGridViewZoneDetails.Columns[5].HeaderText = "Activity End Date";
            dataGridViewZoneDetails.Columns[7].HeaderText = "Region Name";
            dataGridViewZoneDetails.Columns[8].HeaderText = "Region ID";
        }

        public void ClearZone()
        {
            txtZoneName.Text = "";
            cmbSelectDesignationForZone.DataSource = objDesignationDetailsManager.LoadDesignationCombo();
            cmbSelectDesignationForZone.DisplayMember = "Designation_Code";
            cmbSelectDesignationForZone.ValueMember = "Designation_Code";
            cmbSelectDesignationForZone.Text = "Select Designation";
            cmbSelectEmployeeForZone.Text = "Select Employee";
            txtZoneActivityStartDate.Text = "";
            txtZoneActivityEndDate.Text = "";

            cmbSelectRegionForZone.DataSource = objRegionDetailsManager.LoadDistinctEnabledRegion();
            cmbSelectRegionForZone.DisplayMember = "Region_Name";
            cmbSelectRegionForZone.ValueMember = "Region_Name";
            cmbSelectRegionForZone.Text = "Select Region";
            txtRegionIDForZone.Text = "";
            txtRegionIDForZone.ReadOnly = true;
            cmbZoneActive.Text = "Select Active";
            if (btnSaveZone.Text == "Update Zone")
            {
                btnSaveZone.Text = "Save Zone";
            }
            
            chkTeam.Checked = false;
            chkDivision.Checked = false;
            
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSaveZone_Click(object sender, EventArgs e)
        {
            if (txtZoneName.Text == "")
            {
                MessageBox.Show("Zone Name can't be blank.");
                txtZoneName.Focus();
            }
            else if (cmbSelectDesignationForZone.Text == "Select Designation" || cmbSelectDesignationForZone.Text == "")
            {
                MessageBox.Show("Please select Designation.");
                cmbSelectDesignationForZone.Focus();
            }
            else if (cmbSelectEmployeeForZone.Text == "Select Employee" || cmbSelectEmployeeForZone.Text == "")
            {
                MessageBox.Show("Please select Employee.");
                cmbSelectEmployeeForZone.Focus();
            }
            else if (txtZoneActivityStartDate.Text == "")
            {
                MessageBox.Show("Activity Start Date can't be blank.");
                txtZoneActivityStartDate.Focus();
            }
            else if (cmbZoneActive.Text == "Select Active" || cmbZoneActive.Text == "")
            {
                MessageBox.Show("Please select Active for Zone.");
                cmbZoneActive.Focus();
            }
            else if (cmbZoneActive.Text == "No" && txtZoneActivityEndDate.Text == "")
            {
                MessageBox.Show("Activity End Date can't be blank.");
                txtZoneActivityEndDate.Focus();
            }
            else if (txtZoneActivityEndDate.Text != "" && txtZoneActivityStartDate.Text != "" &&
                     Convert.ToDateTime(txtZoneActivityEndDate.Text) <
                     Convert.ToDateTime(txtZoneActivityStartDate.Text))
            {
                MessageBox.Show("Activity End Date can't be small than Activity Start Date.");
                txtZoneActivityEndDate.Focus();
            }
            else if (cmbSelectRegionForZone.Text == "Select Region" || cmbSelectRegionForZone.Text == "" ||
                     txtRegionIDForZone.Text == "")
            {
                MessageBox.Show("Please select Region.");
                cmbSelectRegionForZone.Focus();
            }
            else
            {
                zoneName = txtZoneName.Text;
                empDesignationCode = cmbSelectDesignationForZone.Text;
                empName = cmbSelectEmployeeForZone.Text;
                zoneActivityStartDate = txtZoneActivityStartDate.Text;
                zoneActive = cmbZoneActive.Text;
                zoneActivityEndDate = txtZoneActivityEndDate.Text;
                regionIdForZone = Convert.ToInt16(txtRegionIDForZone.Text);
                regionNameForZone = cmbSelectRegionForZone.Text;
                zoneId = GlobalClass.ZoneIdForUpdateZone;
                
                if (btnSaveZone.Text == "Save Zone")
                {
                    if (chkTeam.Checked == true)
                    {
                        if (lblSelectRegionForZone.Text == "Select Team" &&
                            lblSelectRegionForZone.Text != "Select Region")
                        {
                            DataTable TeamDataTable = objGroupDetailsManager.GetTeamDetails(regionNameForZone);

                            string empNameFromTeam = TeamDataTable.Rows[0][0].ToString();
                            string empDesignationCodeFromTeam = TeamDataTable.Rows[0][1].ToString();
                            string empActivityStartDateFromTeam = TeamDataTable.Rows[0][2].ToString();
                            empActivityStartDateFromTeam = empActivityStartDateFromTeam.Replace("12:00:00 AM", "");
                            empActivityStartDateFromTeam = empActivityStartDateFromTeam.Trim();
                            regionNameForZone = regionNameForZone + " " + zoneName;

                            objDivisionDetailsManager.InsertDivision(regionNameForZone, empDesignationCodeFromTeam,
                                empNameFromTeam, empActivityStartDateFromTeam, zoneActive, regionIdForZone);

                            int divisionIDForRegion =
                                Convert.ToInt16(objDivisionDetailsManager.GetDivisionID(regionNameForZone));

                            objRegionDetailsManager.InsertRegion(regionNameForZone, empDesignationCodeFromTeam, empNameFromTeam,
                                empActivityStartDateFromTeam, zoneActive, divisionIDForRegion, regionNameForZone);

                            regionIdForZone = Convert.ToInt16(objRegionDetailsManager.GetRegionID(regionNameForZone));

                            objZoneDetailsManager.InsertZone(zoneName, empDesignationCode, empName, zoneActivityStartDate, zoneActive, regionIdForZone, regionNameForZone);
                            btnAddZone.Enabled = true;
                            btnSaveZone.Enabled = false;

                            MessageBox.Show("Region Added Succesfully");
                        }
                    }
                    else if (chkDivision.Checked == true)
                    {
                        if (lblSelectRegionForZone.Text == "Select Division" &&
                            lblSelectRegionForZone.Text != "Select Region")
                        {
                            DataTable DivisionDataTable = objDivisionDetailsManager.GetDivisionDetails(regionNameForZone);

                            string empNameFromDivision = DivisionDataTable.Rows[0][0].ToString();
                            string empDesignationCodeFromDivision = DivisionDataTable.Rows[0][1].ToString();
                            string empActivityStartDateFromDivision = DivisionDataTable.Rows[0][2].ToString();
                            empActivityStartDateFromDivision = empActivityStartDateFromDivision.Replace("12:00:00 AM", "");
                            empActivityStartDateFromDivision = empActivityStartDateFromDivision.Trim();
                            string divName = DivisionDataTable.Rows[0][3].ToString();
                            regionNameForZone = regionNameForZone + " " + zoneName;

                            //objDivisionDetailsManager.InsertDivision(regionNameForZone, empDesignationCodeFromTeam, empNameFromTeam, empActivityStartDateFromTeam, zoneActive, regionIdForZone);

                            //int divisionIDForRegion = Convert.ToInt16(objDivisionDetailsManager.GetDivisionID(regionNameForZone));

                            objRegionDetailsManager.InsertRegion(regionNameForZone, empDesignationCodeFromDivision, empNameFromDivision,
                                empActivityStartDateFromDivision, zoneActive, regionIdForZone, divName);

                            regionIdForZone = Convert.ToInt16(objRegionDetailsManager.GetRegionID(regionNameForZone));
                            
                            objZoneDetailsManager.InsertZone(zoneName, empDesignationCode, empName, zoneActivityStartDate, zoneActive, regionIdForZone, regionNameForZone);
                            btnAddZone.Enabled = true;
                            btnSaveZone.Enabled = false;

                            MessageBox.Show("Region Added Succesfully");
                        }
                    }
                    else
                    {
                        objZoneDetailsManager.InsertZone(zoneName, empDesignationCode, empName, zoneActivityStartDate, zoneActive, regionIdForZone, regionNameForZone);
                        btnAddZone.Enabled = true;
                        btnSaveZone.Enabled = false;

                        MessageBox.Show("Zone Added Succesfully");
                    }
                }
                else if (btnSaveZone.Text == "Update Zone")
                {

                    if (chkTeam.Checked == true)
                    {
                        //if (lblSelectRegionForZone.Text == "Select Team" &&
                        //    lblSelectRegionForZone.Text != "Select Region")
                        //{
                        //    DataTable TeamDataTable = objGroupDetailsManager.GetTeamDetails(regionNameForZone);

                        //    string empNameFromTeam = TeamDataTable.Rows[0][0].ToString();
                        //    string empDesignationCodeFromTeam = TeamDataTable.Rows[0][1].ToString();
                        //    string empActivityStartDateFromTeam = TeamDataTable.Rows[0][2].ToString();
                        //    empActivityStartDateFromTeam = empActivityStartDateFromTeam.Replace("12:00:00 AM", "");
                        //    empActivityStartDateFromTeam = empActivityStartDateFromTeam.Trim();
                        //    regionNameForZone = regionNameForZone + " " + zoneName;

                        //    objDivisionDetailsManager.InsertDivision(regionNameForZone, empDesignationCodeFromTeam,
                        //        empNameFromTeam, empActivityStartDateFromTeam, zoneActive, regionIdForZone);

                        //    int divisionIDForRegion =
                        //        Convert.ToInt16(objDivisionDetailsManager.GetDivisionID(regionNameForZone));

                        //    objRegionDetailsManager.InsertRegion(regionNameForZone, empDesignationCodeFromTeam, empNameFromTeam,
                        //        empActivityStartDateFromTeam, zoneActive, divisionIDForRegion, regionNameForZone);

                        //    regionIdForZone = Convert.ToInt16(objRegionDetailsManager.GetRegionID(regionNameForZone));

                        //    objZoneDetailsManager.InsertZone(zoneName, empDesignationCode, empName, zoneActivityStartDate, zoneActive, regionIdForZone, regionNameForZone);
                        //    btnAddZone.Enabled = true;
                        //    btnSaveZone.Enabled = false;

                        //    MessageBox.Show("Region Added Succesfully");
                        //}

                        //// 1) update tbl_division (done)
                        //// 2) update tbl_team_division (done)
                        //// 3) update tbl_team_details(done)
                        //// 4) update tbl_region (done)
                        //// 5) update tbl_division_region
                        //// 6) update tbl_team_details

                        if (lblSelectRegionForZone.Text == "Select Team" &&
                            lblSelectRegionForZone.Text != "Select Region")
                        {
                            DataTable TeamDataTable = objGroupDetailsManager.GetTeamDetails(regionNameForZone);
                            
                            string empNameFromTeam = TeamDataTable.Rows[0][0].ToString();
                            string empDesignationCodeFromTeam = TeamDataTable.Rows[0][1].ToString();
                            string empActivityStartDateFromTeam = TeamDataTable.Rows[0][2].ToString();
                            empActivityStartDateFromTeam = empActivityStartDateFromTeam.Replace("12:00:00 AM", "");
                            empActivityStartDateFromTeam = empActivityStartDateFromTeam.Trim();
                            regionNameForZone = regionNameForZone + " " + zoneName;


                            DataTable TeamDetails = objGroupDetailsManager.GetDataFromTeamDetails(GlobalClass.PreviousZoneName);
                            int teamID_TeamDetails = Convert.ToInt16(TeamDetails.Rows[0][0].ToString());
                            string teamName_TeamDetails = TeamDetails.Rows[0][1].ToString();
                            int divID_TeamDetails = Convert.ToInt16(TeamDetails.Rows[0][2].ToString());
                            string divName_TeamDetails = TeamDetails.Rows[0][3].ToString();
                            int regID_TeamDetails = Convert.ToInt16(TeamDetails.Rows[0][4].ToString());
                            string regName_TeamDetails = TeamDetails.Rows[0][5].ToString();
                            int zoneID_TeamDetails = Convert.ToInt16(TeamDetails.Rows[0][6].ToString());
                            string zoneName_TeamDetails = TeamDetails.Rows[0][7].ToString();

                            //// update tbl_region
                            objRegionDetailsManager.UpdateRegion(regID_TeamDetails, regionNameForZone, empDesignationCodeFromTeam, empNameFromTeam, empActivityStartDateFromTeam, zoneActivityEndDate,zoneActive,divName_TeamDetails,divID_TeamDetails);

                            objRegionDetailsManager.UpdateTeamDetailsForCheck(regID_TeamDetails, regionNameForZone, empDesignationCodeFromTeam, empNameFromTeam, empActivityStartDateFromTeam, zoneActivityEndDate, zoneActive, regionNameForZone, divID_TeamDetails, Convert.ToInt16(txtRegionIDForZone.Text), cmbSelectRegionForZone.Text);

                            //// update tbl_division
                            objDivisionDetailsManager.UpdateDivision(divID_TeamDetails,regionNameForZone,empDesignationCodeFromTeam,empNameFromTeam, empActivityStartDateFromTeam, zoneActivityEndDate,zoneActive, cmbSelectRegionForZone.Text,Convert.ToInt16(txtRegionIDForZone.Text) );

                            //// update tbl_team_division
                            objDivisionDetailsManager.UpdateTeamDivision(divID_TeamDetails, regionNameForZone, empDesignationCodeFromTeam, empNameFromTeam, empActivityStartDateFromTeam, zoneActivityEndDate, zoneActive, cmbSelectRegionForZone.Text, Convert.ToInt16(txtRegionIDForZone.Text));

                            //// update TEAM_ID, TEAM_NAME, DIVISION_ID, DIVISION_NAME of tbl_team_details
                            objDivisionDetailsManager.UpdateTeamDetailsByUpdateTeamName(divID_TeamDetails, regionNameForZone, empDesignationCodeFromTeam, empNameFromTeam, empActivityStartDateFromTeam, zoneActivityEndDate, zoneActive, cmbSelectRegionForZone.Text, Convert.ToInt16(txtRegionIDForZone.Text));

                            regionIdForZone = Convert.ToInt16(objRegionDetailsManager.GetRegionID(regionNameForZone));

                            if (GlobalClass.PreviousZoneName != txtZoneName.Text && GlobalClass.PreviousEmployeeNameForZone == cmbSelectEmployeeForZone.Text)
                            {
                                if (MessageBox.Show("Do you want to Update " + GlobalClass.PreviousZoneName + " as " + txtZoneName.Text + " ? All Previous Data and Records of " + GlobalClass.PreviousZoneName + " will be updated as " + txtZoneName.Text + " from now on.", "Save!", MessageBoxButtons.YesNo) == DialogResult.Yes)
                                {
                                    UpdateZone();
                                }
                            }
                            else if (GlobalClass.PreviousZoneName == txtZoneName.Text && GlobalClass.PreviousEmployeeNameForZone != cmbSelectEmployeeForZone.Text)
                            {
                                if (MessageBox.Show("Do you want to Update Employee of " + GlobalClass.PreviousZoneName + " ? All Data and Records of " + GlobalClass.PreviousEmployeeNameForRegion + " for " + GlobalClass.PreviousZoneName + " will be Updated as " + cmbSelectEmployeeForZone.Text + " from now on.", "Save!", MessageBoxButtons.YesNo) == DialogResult.Yes)
                                {
                                    UpdateZone();
                                }
                            }
                            else if (GlobalClass.PreviousZoneName != txtZoneName.Text && GlobalClass.PreviousEmployeeNameForRegion != cmbSelectEmployeeForZone.Text)
                            {
                                if (MessageBox.Show("Do you want to Update " + GlobalClass.PreviousZoneName + " and Employee of " + GlobalClass.PreviousZoneName + " ? All Data and Records will be Updated as " + txtZoneName.Text + " and Employee for " + txtZoneName.Text + " as " + cmbSelectEmployeeForZone.Text + " from now on.", "Save!", MessageBoxButtons.YesNo) == DialogResult.Yes)
                                {
                                    UpdateZone();
                                }
                            }
                            else if (GlobalClass.PreviousRegionNameForZone != cmbSelectRegionForZone.Text && GlobalClass.PreviousRegionIdForZone != Convert.ToInt16(txtRegionIDForZone.Text.ToString()))
                            {
                                if (MessageBox.Show("Do you want to Update " + GlobalClass.PreviousRegionNameForZone + " to " + cmbSelectRegionForZone.Text + " ? All Data and Records of " + GlobalClass.PreviousRegionNameForZone + " will be Updated as " + cmbSelectRegionForZone.Text + " from now on.", "Save!", MessageBoxButtons.YesNo) == DialogResult.Yes)
                                {
                                    UpdateZoneByUpdatingRegion();
                                }
                            }
                            else
                            {
                                UpdateZone();
                            }
                        }

                        //MessageBox.Show("Under Process...........");
                    }
                    else if (chkDivision.Checked == true)
                    {
                        //if (lblSelectRegionForZone.Text == "Select Division" &&
                        //    lblSelectRegionForZone.Text != "Select Region")
                        //{
                        //    DataTable DivisionDataTable = objDivisionDetailsManager.GetDivisionDetails(regionNameForZone);

                        //    string empNameFromDivision = DivisionDataTable.Rows[0][0].ToString();
                        //    string empDesignationCodeFromDivision = DivisionDataTable.Rows[0][1].ToString();
                        //    string empActivityStartDateFromDivision = DivisionDataTable.Rows[0][2].ToString();
                        //    empActivityStartDateFromDivision = empActivityStartDateFromDivision.Replace("12:00:00 AM", "");
                        //    empActivityStartDateFromDivision = empActivityStartDateFromDivision.Trim();
                        //    string divName = DivisionDataTable.Rows[0][3].ToString();
                        //    regionNameForZone = regionNameForZone + " " + zoneName;

                        //    //objDivisionDetailsManager.InsertDivision(regionNameForZone, empDesignationCodeFromTeam, empNameFromTeam, empActivityStartDateFromTeam, zoneActive, regionIdForZone);

                        //    //int divisionIDForRegion = Convert.ToInt16(objDivisionDetailsManager.GetDivisionID(regionNameForZone));

                        //    objRegionDetailsManager.InsertRegion(regionNameForZone, empDesignationCodeFromDivision, empNameFromDivision,
                        //        empActivityStartDateFromDivision, zoneActive, regionIdForZone, divName);

                        //    regionIdForZone = Convert.ToInt16(objRegionDetailsManager.GetRegionID(regionNameForZone));

                        //    objZoneDetailsManager.InsertZone(zoneName, empDesignationCode, empName, zoneActivityStartDate, zoneActive, regionIdForZone, regionNameForZone);
                        //    btnAddZone.Enabled = true;
                        //    btnSaveZone.Enabled = false;

                        //    MessageBox.Show("Region Added Succesfully");
                        //}

                        //// 1) update tbl_division
                        //// 2) update tbl_team_division
                        //// 3) update tbl_team_details
                        //// 4) update tbl_region
                        //// 5) update tbl_division_region
                        //// 6) update tbl_team_details

                        //MessageBox.Show("Under Process...........");

                        if (lblSelectRegionForZone.Text == "Select Division" &&
                            lblSelectRegionForZone.Text != "Select Region")
                        {
                            DataTable DivisionDetails = objDivisionDetailsManager.GetTeamDetails(regionIdForZone);

                            DataTable TeamDataTable = objGroupDetailsManager.GetTeamDetails(DivisionDetails.Rows[0][1].ToString());
                            
                            string empNameFromTeam = TeamDataTable.Rows[0][0].ToString();
                            string empDesignationCodeFromTeam = TeamDataTable.Rows[0][1].ToString();
                            string empActivityStartDateFromTeam = TeamDataTable.Rows[0][2].ToString();
                            empActivityStartDateFromTeam = empActivityStartDateFromTeam.Replace("12:00:00 AM", "");
                            empActivityStartDateFromTeam = empActivityStartDateFromTeam.Trim();
                            regionNameForZone = regionNameForZone + " " + zoneName;


                            DataTable TeamDetails = objGroupDetailsManager.GetDataFromTeamDetails(GlobalClass.PreviousZoneName);
                            int teamID_TeamDetails = Convert.ToInt16(TeamDetails.Rows[0][0].ToString());
                            string teamName_TeamDetails = TeamDetails.Rows[0][1].ToString();
                            int divID_TeamDetails = Convert.ToInt16(TeamDetails.Rows[0][2].ToString());
                            string divName_TeamDetails = TeamDetails.Rows[0][3].ToString();
                            int regID_TeamDetails = Convert.ToInt16(TeamDetails.Rows[0][4].ToString());
                            string regName_TeamDetails = TeamDetails.Rows[0][5].ToString();
                            int zoneID_TeamDetails = Convert.ToInt16(TeamDetails.Rows[0][6].ToString());
                            string zoneName_TeamDetails = TeamDetails.Rows[0][7].ToString();

                            //// update tbl_region
                            objRegionDetailsManager.UpdateRegion(regID_TeamDetails, regionNameForZone, empDesignationCodeFromTeam, empNameFromTeam, empActivityStartDateFromTeam, zoneActivityEndDate, zoneActive, divName_TeamDetails, divID_TeamDetails);

                            objRegionDetailsManager.UpdateTeamDetailsForCheck(regID_TeamDetails, regionNameForZone, empDesignationCodeFromTeam, empNameFromTeam, empActivityStartDateFromTeam, zoneActivityEndDate, zoneActive, regionNameForZone, divID_TeamDetails, Convert.ToInt16(DivisionDetails.Rows[0][0].ToString()), DivisionDetails.Rows[0][1].ToString());

                            //// update tbl_division
                            objDivisionDetailsManager.UpdateDivision(divID_TeamDetails, regionNameForZone, empDesignationCodeFromTeam, empNameFromTeam, empActivityStartDateFromTeam, zoneActivityEndDate, zoneActive, DivisionDetails.Rows[0][1].ToString(), Convert.ToInt16(DivisionDetails.Rows[0][0].ToString()));

                            //// update tbl_team_division
                            objDivisionDetailsManager.UpdateTeamDivision(divID_TeamDetails, regionNameForZone, empDesignationCodeFromTeam, empNameFromTeam, empActivityStartDateFromTeam, zoneActivityEndDate, zoneActive, DivisionDetails.Rows[0][1].ToString(), Convert.ToInt16(DivisionDetails.Rows[0][0].ToString()));

                            //// update TEAM_ID, TEAM_NAME, DIVISION_ID, DIVISION_NAME of tbl_team_details
                            objDivisionDetailsManager.UpdateTeamDetailsByUpdateTeamName(divID_TeamDetails, regionNameForZone, empDesignationCodeFromTeam, empNameFromTeam, empActivityStartDateFromTeam, zoneActivityEndDate, zoneActive, DivisionDetails.Rows[0][1].ToString(), Convert.ToInt16(DivisionDetails.Rows[0][0].ToString()));

                            regionIdForZone = Convert.ToInt16(objRegionDetailsManager.GetRegionID(regionNameForZone));

                            if (GlobalClass.PreviousZoneName != txtZoneName.Text && GlobalClass.PreviousEmployeeNameForZone == cmbSelectEmployeeForZone.Text)
                            {
                                if (MessageBox.Show("Do you want to Update " + GlobalClass.PreviousZoneName + " as " + txtZoneName.Text + " ? All Previous Data and Records of " + GlobalClass.PreviousZoneName + " will be updated as " + txtZoneName.Text + " from now on.", "Save!", MessageBoxButtons.YesNo) == DialogResult.Yes)
                                {
                                    UpdateZone();
                                }
                            }
                            else if (GlobalClass.PreviousZoneName == txtZoneName.Text && GlobalClass.PreviousEmployeeNameForZone != cmbSelectEmployeeForZone.Text)
                            {
                                if (MessageBox.Show("Do you want to Update Employee of " + GlobalClass.PreviousZoneName + " ? All Data and Records of " + GlobalClass.PreviousEmployeeNameForRegion + " for " + GlobalClass.PreviousZoneName + " will be Updated as " + cmbSelectEmployeeForZone.Text + " from now on.", "Save!", MessageBoxButtons.YesNo) == DialogResult.Yes)
                                {
                                    UpdateZone();
                                }
                            }
                            else if (GlobalClass.PreviousZoneName != txtZoneName.Text && GlobalClass.PreviousEmployeeNameForRegion != cmbSelectEmployeeForZone.Text)
                            {
                                if (MessageBox.Show("Do you want to Update " + GlobalClass.PreviousZoneName + " and Employee of " + GlobalClass.PreviousZoneName + " ? All Data and Records will be Updated as " + txtZoneName.Text + " and Employee for " + txtZoneName.Text + " as " + cmbSelectEmployeeForZone.Text + " from now on.", "Save!", MessageBoxButtons.YesNo) == DialogResult.Yes)
                                {
                                    UpdateZone();
                                }
                            }
                            else if (GlobalClass.PreviousRegionNameForZone != cmbSelectRegionForZone.Text && GlobalClass.PreviousRegionIdForZone != Convert.ToInt16(txtRegionIDForZone.Text.ToString()))
                            {
                                if (MessageBox.Show("Do you want to Update " + GlobalClass.PreviousRegionNameForZone + " to " + cmbSelectRegionForZone.Text + " ? All Data and Records of " + GlobalClass.PreviousRegionNameForZone + " will be Updated as " + cmbSelectRegionForZone.Text + " from now on.", "Save!", MessageBoxButtons.YesNo) == DialogResult.Yes)
                                {
                                    UpdateZoneByUpdatingRegion();
                                }
                            }
                            else
                            {
                                UpdateZone();
                            }
                        }
                    }
                    else
                    {
                        if (GlobalClass.PreviousZoneName != txtZoneName.Text && GlobalClass.PreviousEmployeeNameForZone == cmbSelectEmployeeForZone.Text)
                        {
                            if (MessageBox.Show("Do you want to Update " + GlobalClass.PreviousZoneName + " as " + txtZoneName.Text + " ? All Previous Data and Records of " + GlobalClass.PreviousZoneName + " will be updated as " + txtZoneName.Text + " from now on.", "Save!", MessageBoxButtons.YesNo) == DialogResult.Yes)
                            {
                                UpdateZone();
                            }
                        }
                        else if (GlobalClass.PreviousZoneName == txtZoneName.Text && GlobalClass.PreviousEmployeeNameForZone != cmbSelectEmployeeForZone.Text)
                        {
                            if (MessageBox.Show("Do you want to Update Employee of " + GlobalClass.PreviousZoneName + " ? All Data and Records of " + GlobalClass.PreviousEmployeeNameForRegion + " for " + GlobalClass.PreviousZoneName + " will be Updated as " + cmbSelectEmployeeForZone.Text + " from now on.", "Save!", MessageBoxButtons.YesNo) == DialogResult.Yes)
                            {
                                UpdateZone();
                            }
                        }
                        else if (GlobalClass.PreviousZoneName != txtZoneName.Text && GlobalClass.PreviousEmployeeNameForRegion != cmbSelectEmployeeForZone.Text)
                        {
                            if (MessageBox.Show("Do you want to Update " + GlobalClass.PreviousZoneName + " and Employee of " + GlobalClass.PreviousZoneName + " ? All Data and Records will be Updated as " + txtZoneName.Text + " and Employee for " + txtZoneName.Text + " as " + cmbSelectEmployeeForZone.Text + " from now on.", "Save!", MessageBoxButtons.YesNo) == DialogResult.Yes)
                            {
                                UpdateZone();
                            }
                        }
                        else if (GlobalClass.PreviousRegionNameForZone != cmbSelectRegionForZone.Text && GlobalClass.PreviousRegionIdForZone != Convert.ToInt16(txtRegionIDForZone.Text.ToString()))
                        {
                            if (MessageBox.Show("Do you want to Update " + GlobalClass.PreviousRegionNameForZone + " to " + cmbSelectRegionForZone.Text + " ? All Data and Records of " + GlobalClass.PreviousRegionNameForZone + " will be Updated as " + cmbSelectRegionForZone.Text + " from now on.", "Save!", MessageBoxButtons.YesNo) == DialogResult.Yes)
                            {
                                UpdateZoneByUpdatingRegion();
                            }
                        }
                        else
                        {
                            UpdateZone();
                        }
                    }
                }
                RefreshZone();
            }
        }

        private void UpdateZone()
        {
            if (cmbZoneActive.Text == "No" && txtZoneActivityEndDate.Text != "")
            {
                objZoneDetailsManager.UpdateZoneWithEndDate(zoneId, zoneName, empDesignationCode, empName, zoneActivityStartDate, zoneActivityEndDate, zoneActive, regionNameForZone, regionIdForZone);
                objZoneDetailsManager.UpdateTeamDetailsWithEndDate(zoneId, zoneName, empDesignationCode, empName, zoneActivityStartDate, zoneActivityEndDate, zoneActive, regionNameForZone, regionIdForZone);
                objZoneDetailsManager.UpdateRegionZone(zoneId, zoneName, empDesignationCode, empName, zoneActivityStartDate, zoneActivityEndDate, zoneActive, regionNameForZone, regionIdForZone);
                btnAddZone.Enabled = true;
                btnSaveZone.Enabled = false;
                MessageBox.Show("Zone Updated Succesfully");
            }
            else
            {
                objZoneDetailsManager.UpdateZone(zoneId, zoneName, empDesignationCode, empName, zoneActivityStartDate, zoneActivityEndDate, zoneActive, regionNameForZone, regionIdForZone);
                objZoneDetailsManager.UpdateTeamDetails(zoneId, zoneName, empDesignationCode, empName, zoneActivityStartDate, zoneActivityEndDate, zoneActive, regionNameForZone, regionIdForZone);
                objZoneDetailsManager.UpdateRegionZone(zoneId, zoneName, empDesignationCode, empName, zoneActivityStartDate, zoneActivityEndDate, zoneActive, regionNameForZone, regionIdForZone);
                btnAddZone.Enabled = true;
                btnSaveZone.Enabled = false;
                MessageBox.Show("Zone Updated Succesfully");
            }
        }

        private void UpdateZoneByUpdatingRegion()
        {
            UpdateZone();
            objZoneDetailsManager.UpdateTeamDetailsByUpdateRegionName(zoneId, zoneName, empDesignationCode, empName, zoneActivityStartDate, zoneActivityEndDate, zoneActive, regionNameForZone, regionIdForZone);
        }

        private void btnAddZone_Click(object sender, EventArgs e)
        {
            if (btnSaveZone.Enabled == false)
            {
                btnSaveZone.Enabled = true;
            }
            if (txtZoneName.Enabled == false)
            {
                txtZoneName.Enabled = true;
            }
            if (cmbSelectDesignationForZone.Enabled == false)
            {
                cmbSelectDesignationForZone.Enabled = true;
            }
            if (cmbSelectEmployeeForZone.Enabled == false)
            {
                cmbSelectEmployeeForZone.Enabled = true;
            }
            if (txtZoneActivityStartDate.Enabled == false)
            {
                txtZoneActivityStartDate.Enabled = true;
            }
            if (dTPZoneActivityStartDate.Enabled == false)
            {
                dTPZoneActivityStartDate.Enabled = true;
            }
            if (txtZoneActivityEndDate.Enabled == true)
            {
                txtZoneActivityEndDate.Enabled = false;
            }
            if (dTPZoneActivityEndDate.Enabled == true)
            {
                dTPZoneActivityEndDate.Enabled = false;
            }
            if (cmbZoneActive.Enabled == false)
            {
                cmbZoneActive.Enabled = true;
            }
            if (btnAddZone.Enabled == false)
            {
                btnAddZone.Enabled = true;
            }
            if (btnSaveZone.Text == "Update Zone")
            {
                btnSaveZone.Text = "Save Zone";
            }

            if (cmbSelectRegionForZone.Enabled == false)
            {
                cmbSelectRegionForZone.Enabled = true;
            }
            ClearZone();
            txtZoneName.Focus();
        }

        private void ZoneUI_Load(object sender, EventArgs e)
        {
            RefreshZone();
        }

        private void cmbSelectDesignationForZone_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (btnSaveZone.Text == "Save Zone")
            {
                if (cmbSelectDesignationForZone.Text != "Select Designation")
                {
                    cmbSelectEmployeeForZone.DataSource = objEmployeeDetailsManager.SearchEmployeeDesignation(cmbSelectDesignationForZone.Text.ToString());
                    cmbSelectEmployeeForZone.DisplayMember = "Employee_Name";
                    cmbSelectEmployeeForZone.ValueMember = "Employee_Name";
                    cmbSelectEmployeeForZone.Text = "Select Employee";
                }
            }
            else if (btnSaveZone.Text == "Update Zone")
            {
                if (cmbSelectDesignationForZone.Text != "Select Designation")
                {
                    cmbSelectEmployeeForZone.DataSource = objEmployeeDetailsManager.SearchEmployeeDesignation(cmbSelectDesignationForZone.Text.ToString());
                    cmbSelectEmployeeForZone.DisplayMember = "Employee_Name";
                    cmbSelectEmployeeForZone.ValueMember = "Employee_Name";
                }
            }
        }

        private void cmbSelectDesignationForZone_SelectedValueChanged(object sender, EventArgs e)
        {
            if (btnSaveZone.Text == "Save Zone")
            {
                if (cmbSelectDesignationForZone.Text != "Select Designation")
                {
                    cmbSelectEmployeeForZone.DataSource = objEmployeeDetailsManager.SearchEmployeeDesignation(cmbSelectDesignationForZone.Text.ToString());
                    cmbSelectEmployeeForZone.DisplayMember = "Employee_Name";
                    cmbSelectEmployeeForZone.ValueMember = "Employee_Name";
                    cmbSelectEmployeeForZone.Text = "Select Employee";
                }
            }
            else if (btnSaveZone.Text == "Update Zone")
            {
                if (cmbSelectDesignationForZone.Text != "Select Designation")
                {
                    cmbSelectEmployeeForZone.DataSource = objEmployeeDetailsManager.SearchEmployeeDesignation(cmbSelectDesignationForZone.Text.ToString());
                    cmbSelectEmployeeForZone.DisplayMember = "Employee_Name";
                    cmbSelectEmployeeForZone.ValueMember = "Employee_Name";
                }
            }
        }

        private void dTPZoneActivityEndDate_CloseUp(object sender, EventArgs e)
        {
            txtZoneActivityEndDate.Text = dTPZoneActivityEndDate.Text.ToString();
            txtZoneActivityEndDate.Focus();
        }

        private void dTPZoneActivityStartDate_CloseUp(object sender, EventArgs e)
        {
            txtZoneActivityStartDate.Text = dTPZoneActivityStartDate.Text.ToString();
            txtZoneActivityStartDate.Focus();
        }

        private void cmbSelectRegionForZone_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (chkTeam.Checked == true)
            {
                txtRegionIDForZone.Text = objGroupDetailsManager.GetTeamID(cmbSelectRegionForZone.Text.ToString());
            }
            else if (chkDivision.Checked == true)
            {
                txtRegionIDForZone.Text = objDivisionDetailsManager.GetDivisionID(cmbSelectRegionForZone.Text.ToString());
            }
            else
            {
                txtRegionIDForZone.Text = objRegionDetailsManager.GetRegionID(cmbSelectRegionForZone.Text);
            }
        }

        private void btnRefreshZone_Click(object sender, EventArgs e)
        {
            RefreshZone();
        }

        private void cmbZoneActive_SelectedValueChanged(object sender, EventArgs e)
        {
            if (cmbZoneActive.Text == "No")
            {
                txtZoneActivityEndDate.Enabled = true;
                dTPZoneActivityEndDate.Enabled = true;
                txtZoneActivityEndDate.Focus();
            }
            else if (cmbZoneActive.Text == "Yes")
            {
                txtZoneActivityEndDate.Text = "";
                txtZoneActivityEndDate.Enabled = false;
                dTPZoneActivityEndDate.Enabled = false;
            }
        }

        private void dataGridViewZoneDetails_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (btnSaveZone.Enabled == false)
            {
                btnSaveZone.Enabled = true;
            }
            btnSaveZone.Text = "Update Zone";

            GlobalClass.ZoneIdForUpdateZone = Convert.ToInt16(dataGridViewZoneDetails.CurrentRow.Cells[0].Value.ToString());
            GlobalClass.PreviousZoneName = dataGridViewZoneDetails.CurrentRow.Cells[1].Value.ToString();
            txtZoneName.Text = dataGridViewZoneDetails.CurrentRow.Cells[1].Value.ToString();
            cmbSelectDesignationForZone.Text = dataGridViewZoneDetails.CurrentRow.Cells[3].Value.ToString();
            GlobalClass.PreviousEmployeeNameForZone = dataGridViewZoneDetails.CurrentRow.Cells[2].Value.ToString();
            cmbSelectEmployeeForZone.Text = dataGridViewZoneDetails.CurrentRow.Cells[2].Value.ToString();
            txtZoneActivityStartDate.Text = dataGridViewZoneDetails.CurrentRow.Cells[4].Value.ToString();
            txtZoneActivityStartDate.Text = txtZoneActivityStartDate.Text.Replace("12:00:00 AM", "");
            txtZoneActivityStartDate.Text = txtZoneActivityStartDate.Text.Trim();
            txtZoneActivityEndDate.Text = dataGridViewZoneDetails.CurrentRow.Cells[5].Value.ToString();
            if (txtZoneActivityEndDate.Text != "")
            {
                txtZoneActivityEndDate.Text = txtZoneActivityEndDate.Text.Replace("12:00:00 AM", "");
                txtZoneActivityEndDate.Text = txtZoneActivityEndDate.Text.Trim();
            }
            cmbZoneActive.Text = dataGridViewZoneDetails.CurrentRow.Cells[6].Value.ToString();
            cmbSelectRegionForZone.Text = dataGridViewZoneDetails.CurrentRow.Cells[7].Value.ToString();
            GlobalClass.PreviousRegionNameForZone = dataGridViewZoneDetails.CurrentRow.Cells[7].Value.ToString();
            txtRegionIDForZone.Text = dataGridViewZoneDetails.CurrentRow.Cells[8].Value.ToString();
            GlobalClass.PreviousRegionIdForZone = Convert.ToInt16(dataGridViewZoneDetails.CurrentRow.Cells[8].Value.ToString());

            if (txtZoneName.Enabled == false)
            {
                txtZoneName.Enabled = true;
            }
            if (cmbSelectDesignationForZone.Enabled == false)
            {
                cmbSelectDesignationForZone.Enabled = true;
            }
            if (cmbSelectEmployeeForZone.Enabled == false)
            {
                cmbSelectEmployeeForZone.Enabled = true;
            }
            if (txtZoneActivityStartDate.Enabled == false)
            {
                txtZoneActivityStartDate.Enabled = true;
            }
            if (dTPZoneActivityStartDate.Enabled == false)
            {
                dTPZoneActivityStartDate.Enabled = true;
            }
            if (txtZoneActivityEndDate.Text != "")
            {
                txtZoneActivityEndDate.Enabled = true;
                dTPZoneActivityEndDate.Enabled = true;
            }
            else
            {
                txtZoneActivityEndDate.Enabled = false;
                dTPZoneActivityEndDate.Enabled = false;
            }

            if (cmbZoneActive.Enabled == false)
            {
                cmbZoneActive.Enabled = true;
            }
            if (cmbSelectRegionForZone.Enabled == false)
            {
                cmbSelectRegionForZone.Enabled = true;
            }

            if (btnAddZone.Enabled == false)
            {
                btnAddZone.Enabled = true;
            }
            if (btnSaveZone.Text == "Save Zone")
            {
                btnSaveZone.Text = "Update Zone";
            }
        }

        private void chkTeam_CheckedChanged(object sender, EventArgs e)
        {
            if (chkTeam.Checked == true)
            {
                chkDivision.Checked = false;
                lblSelectRegionForZone.Text = "Select Team";
                cmbSelectRegionForZone.DataSource = objGroupDetailsManager.LoadTeam();
                cmbSelectRegionForZone.DisplayMember = "Team_Name";
                cmbSelectRegionForZone.ValueMember = "Team_Name";
                cmbSelectRegionForZone.Text = "Select Team";
                txtRegionIDForZone.Text = "";
                txtRegionIDForZone.ReadOnly = true;
            }
            else
            {
                lblSelectRegionForZone.Text = "Select Region";
                cmbSelectRegionForZone.DataSource = objRegionDetailsManager.LoadDistinctEnabledRegion();
                cmbSelectRegionForZone.DisplayMember = "Region_Name";
                cmbSelectRegionForZone.ValueMember = "Region_Name";
                cmbSelectRegionForZone.Text = "Select Region";
                txtRegionIDForZone.Text = "";
                txtRegionIDForZone.ReadOnly = true;
            }
        }

        private void chkDivision_CheckedChanged(object sender, EventArgs e)
        {
            if (chkDivision.Checked == true)
            {
                chkTeam.Checked = false;
                lblSelectRegionForZone.Text = "Select Division";
                cmbSelectRegionForZone.DataSource = objDivisionDetailsManager.LoadDistinctEnabledDivision();
                cmbSelectRegionForZone.DisplayMember = "Division_Name";
                cmbSelectRegionForZone.ValueMember = "Division_Name";
                cmbSelectRegionForZone.Text = "Select Division";
                txtRegionIDForZone.Text = "";
                txtRegionIDForZone.ReadOnly = true;
            }
            else
            {
                lblSelectRegionForZone.Text = "Select Region";
                cmbSelectRegionForZone.DataSource = objRegionDetailsManager.LoadDistinctEnabledRegion();
                cmbSelectRegionForZone.DisplayMember = "Region_Name";
                cmbSelectRegionForZone.ValueMember = "Region_Name";
                cmbSelectRegionForZone.Text = "Select Region";
                txtRegionIDForZone.Text = "";
                txtRegionIDForZone.ReadOnly = true;
            }
        }
    }
}
