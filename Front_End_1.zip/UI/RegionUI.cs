﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using SMSapplication.BLL;
using SMSapplication.DAL;
using SMSapplication.DAL.DAO;
using SMSapplication.DAL.Gateway;
using SMSapplication.UI;

namespace SMSapplication.UI
{
    public partial class RegionUI : Form
    {
        DivisionDetailsManager objDivisionDetailsManager = new DivisionDetailsManager();
        DesignationDetailsManager objDesignationDetailsManager = new DesignationDetailsManager();
        EmployeeDetailsManager objEmployeeDetailsManager = new EmployeeDetailsManager();
        GroupDetailsManager objGroupDetailsManager = new GroupDetailsManager();
        RegionDetailsManager objRegionDetailsManager = new RegionDetailsManager();
        

        private int regionId;
        private string regionName;
        private string empName;
        private string empDesignationCode;
        private string regionActivityStartDate;
        private string regionActivityEndDate;
        private string regionActive;
        private string divisionNameForRegion;
        private int divisionIdForRegion;

        public RegionUI()
        {
            InitializeComponent();
            RefreshRegion();
        }

        private void RegionUI_Load(object sender, EventArgs e)
        {
            RefreshRegion();
        }

        public void RefreshRegion()
        {
            ClearRegion();

            if (txtRegionName.Enabled == true)
            {
                txtRegionName.Enabled = false;
            }

            if (cmbSelectDesignationForRegion.Enabled == true)
            {
                cmbSelectDesignationForRegion.Enabled = false;
            }

            if (cmbSelectEmployeeForRegion.Enabled == true)
            {
                cmbSelectEmployeeForRegion.Enabled = false;
            }

            if (txtRegionActivityStartDate.Enabled == true)
            {
                txtRegionActivityStartDate.Enabled = false;
            }

            if (dTPRegionActivityStartDate.Enabled == true)
            {
                dTPRegionActivityStartDate.Enabled = false;
            }

            if (txtRegionActivityEndDate.Enabled == true)
            {
                txtRegionActivityEndDate.Enabled = false;
            }

            if (dTPRegionActivityEndDate.Enabled == true)
            {
                dTPRegionActivityEndDate.Enabled = false;
            }

            if (cmbSelectDivisionForRegion.Enabled == true)
            {
                cmbSelectDivisionForRegion.Enabled = false;
            }

            if (cmbRegionActive.Enabled == true)
            {
                cmbRegionActive.Enabled = false;
            }

            if (btnSaveRegion.Text == "Update Region")
            {
                btnSaveRegion.Text = "Save Region";
            }

            if (btnSaveRegion.Enabled == true)
            {
                btnSaveRegion.Enabled = false;
            }

            dataGridViewRegionDetails.DataSource = objRegionDetailsManager.ShowAllRegion();
            dataGridViewRegionDetails.Columns[0].Visible = false;
            DataGridViewRegionDetailsHeaderText();
            btnAddRegion.Focus();
        }

        public void DataGridViewRegionDetailsHeaderText()
        {
            dataGridViewRegionDetails.Columns[1].HeaderText = "Region Name";
            dataGridViewRegionDetails.Columns[2].HeaderText = "Employee Name";
            dataGridViewRegionDetails.Columns[3].HeaderText = "Designation Code";
            dataGridViewRegionDetails.Columns[4].HeaderText = "Activity Start Date";
            dataGridViewRegionDetails.Columns[5].HeaderText = "Activity End Date";
            dataGridViewRegionDetails.Columns[7].HeaderText = "Division Name";
            dataGridViewRegionDetails.Columns[8].HeaderText = "Division ID";
        }

        public void ClearRegion()
        {
            txtRegionName.Text = "";
            cmbSelectDesignationForRegion.DataSource = objDesignationDetailsManager.LoadDesignationCombo();
            cmbSelectDesignationForRegion.DisplayMember = "Designation_Code";
            cmbSelectDesignationForRegion.ValueMember = "Designation_Code";
            cmbSelectDesignationForRegion.Text = "Select Designation";
            cmbSelectEmployeeForRegion.Text = "Select Employee";
            txtRegionActivityStartDate.Text = "";
            txtRegionActivityEndDate.Text = "";

            cmbRegionActive.Text = "Select Active";
            if (btnSaveRegion.Text == "Update Region")
            {
                btnSaveRegion.Text = "Save Region";
            }

            if (lblSelectDivisionForRegion.Text == "Select Team")
            {
                cmbSelectDivisionForRegion.DataSource = objDivisionDetailsManager.LoadDistinctEnabledDivision();
                cmbSelectDivisionForRegion.DisplayMember = "Division_Name";
                cmbSelectDivisionForRegion.ValueMember = "Division_Name";
                cmbSelectDivisionForRegion.Text = "Select Division";
                txtDivisionIDForRegion.Text = "";
                txtDivisionIDForRegion.ReadOnly = true;
            }
            else
            {
                cmbSelectDivisionForRegion.DataSource = objDivisionDetailsManager.LoadDistinctEnabledDivision();
                cmbSelectDivisionForRegion.DisplayMember = "Division_Name";
                cmbSelectDivisionForRegion.ValueMember = "Division_Name";
                cmbSelectDivisionForRegion.Text = "Select Division";
                txtDivisionIDForRegion.Text = "";
                txtDivisionIDForRegion.ReadOnly = true;
            }

            chkTeam.Checked = false;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnAddRegion_Click(object sender, EventArgs e)
        {
            if (btnSaveRegion.Enabled == false)
            {
                btnSaveRegion.Enabled = true;
            }
            if (txtRegionName.Enabled == false)
            {
                txtRegionName.Enabled = true;
            }
            if (cmbSelectDesignationForRegion.Enabled == false)
            {
                cmbSelectDesignationForRegion.Enabled = true;
            }
            if (cmbSelectEmployeeForRegion.Enabled == false)
            {
                cmbSelectEmployeeForRegion.Enabled = true;
            }
            if (txtRegionActivityStartDate.Enabled == false)
            {
                txtRegionActivityStartDate.Enabled = true;
            }
            if (dTPRegionActivityStartDate.Enabled == false)
            {
                dTPRegionActivityStartDate.Enabled = true;
            }
            if (txtRegionActivityEndDate.Enabled == true)
            {
                txtRegionActivityEndDate.Enabled = false;
            }
            if (dTPRegionActivityEndDate.Enabled == true)
            {
                dTPRegionActivityEndDate.Enabled = false;
            }
            if (cmbRegionActive.Enabled == false)
            {
                cmbRegionActive.Enabled = true;
            }
            if (btnAddRegion.Enabled == false)
            {
                btnAddRegion.Enabled = true;
            }
            if (btnSaveRegion.Text == "Update Region")
            {
                btnSaveRegion.Text = "Save Region";
            }

            if (cmbSelectDivisionForRegion.Enabled == false)
            {
                cmbSelectDivisionForRegion.Enabled = true;
            }
            ClearRegion();
            txtRegionName.Focus();
        }

        private void btnSaveRegion_Click(object sender, EventArgs e)
        {
            if (txtRegionName.Text == "")
            {
                MessageBox.Show("Regoin Name can't be blank.");
                txtRegionName.Focus();
            }
            else if (cmbSelectDesignationForRegion.Text == "Select Designation" || cmbSelectDesignationForRegion.Text == "")
            {
                MessageBox.Show("Please select Designation.");
                cmbSelectDesignationForRegion.Focus();
            }
            else if (cmbSelectEmployeeForRegion.Text == "Select Employee" || cmbSelectEmployeeForRegion.Text == "")
            {
                MessageBox.Show("Please select Employee.");
                cmbSelectEmployeeForRegion.Focus();
            }
            else if (txtRegionActivityStartDate.Text == "")
            {
                MessageBox.Show("Activity Start Date can't be blank.");
                txtRegionActivityStartDate.Focus();
            }
            else if (cmbRegionActive.Text == "Select Active" || cmbRegionActive.Text == "")
            {
                MessageBox.Show("Please select Active for Division.");
                cmbRegionActive.Focus();
            }
            else if (cmbRegionActive.Text == "No" && txtRegionActivityEndDate.Text == "")
            {
                MessageBox.Show("Activity End Date can't be blank.");
                txtRegionActivityEndDate.Focus();
            }
            else if (txtRegionActivityEndDate.Text != "" && txtRegionActivityStartDate.Text != "" &&
                     Convert.ToDateTime(txtRegionActivityEndDate.Text) <
                     Convert.ToDateTime(txtRegionActivityStartDate.Text))
            {
                MessageBox.Show("Activity End Date can't be small than Activity Start Date.");
                txtRegionActivityEndDate.Focus();
            }
            else if (cmbSelectDivisionForRegion.Text == "Select Division" || cmbSelectDivisionForRegion.Text == "" || txtDivisionIDForRegion.Text == "" || cmbSelectDivisionForRegion.Text == "Select Team")
            {
                MessageBox.Show("Please select a value.");
                cmbSelectDivisionForRegion.Focus();
            }
            else
            {
                regionName = txtRegionName.Text;
                empDesignationCode = cmbSelectDesignationForRegion.Text;
                empName = cmbSelectEmployeeForRegion.Text;
                regionActivityStartDate = txtRegionActivityStartDate.Text;
                regionActive = cmbRegionActive.Text;
                regionActivityEndDate = txtRegionActivityEndDate.Text;
                divisionIdForRegion = Convert.ToInt16(txtDivisionIDForRegion.Text);
                divisionNameForRegion = cmbSelectDivisionForRegion.Text;
                regionId = GlobalClass.RegionIdForUpdateRegion;
            
                if (btnSaveRegion.Text == "Save Region")
                {
                    if (chkTeam.Checked == true)
                    {
                        if (lblSelectDivisionForRegion.Text == "Select Team" && lblSelectDivisionForRegion.Text != "Select Devision")
                        {
                            DataTable TeamDataTable = objGroupDetailsManager.GetTeamDetails(divisionNameForRegion);

                            string empNameFromTeam = TeamDataTable.Rows[0][0].ToString();
                            string empDesignationCodeFromTeam = TeamDataTable.Rows[0][1].ToString();
                            string empActivityStartDateFromTeam = TeamDataTable.Rows[0][2].ToString();
                            empActivityStartDateFromTeam = empActivityStartDateFromTeam.Replace("12:00:00 AM", "");
                            empActivityStartDateFromTeam = empActivityStartDateFromTeam.Trim();
                            divisionNameForRegion = divisionNameForRegion + " " + regionName;

                            objDivisionDetailsManager.InsertDivision(divisionNameForRegion, empDesignationCodeFromTeam, empNameFromTeam, empActivityStartDateFromTeam, regionActive, divisionIdForRegion);

                            divisionIdForRegion = Convert.ToInt16(objDivisionDetailsManager.GetDivisionID(divisionNameForRegion));

                            objRegionDetailsManager.InsertRegion(regionName, empDesignationCode, empName, regionActivityStartDate, regionActive, divisionIdForRegion, divisionNameForRegion);
                            //objRegionDetailsManager.InsertRegion(regionName, empDesignationCode, empName, regionActivityStartDate, regionActive, GlobalClass.DivisionIdForUpdateDivision, divisionNameForRegion);
                            btnAddRegion.Enabled = true;
                            btnSaveRegion.Enabled = false;

                            MessageBox.Show("Region Added Succesfully");
                        }
                    }
                    else
                    {
                        objRegionDetailsManager.InsertRegion(regionName, empDesignationCode, empName, regionActivityStartDate, regionActive, divisionIdForRegion, divisionNameForRegion);
                        btnAddRegion.Enabled = true;
                        btnSaveRegion.Enabled = false;

                        MessageBox.Show("Region Added Succesfully");                        
                    }
                }
                else if (btnSaveRegion.Text == "Update Region")
                {
                    if (chkTeam.Checked == true)
                    {
                        if (lblSelectDivisionForRegion.Text == "Select Team" && lblSelectDivisionForRegion.Text != "Select Devision")
                        {
                            DataTable TeamDataTable = objGroupDetailsManager.GetTeamDetails(divisionNameForRegion);

                            string empNameFromTeam = TeamDataTable.Rows[0][0].ToString();
                            string empDesignationCodeFromTeam = TeamDataTable.Rows[0][1].ToString();
                            string empActivityStartDateFromTeam = TeamDataTable.Rows[0][2].ToString();
                            empActivityStartDateFromTeam = empActivityStartDateFromTeam.Replace("12:00:00 AM", "");
                            empActivityStartDateFromTeam = empActivityStartDateFromTeam.Trim();
                            divisionNameForRegion = divisionNameForRegion + " " + regionName;
                            divisionIdForRegion = Convert.ToInt16(objDivisionDetailsManager.GetDivisionID(divisionNameForRegion));

                            objDivisionDetailsManager.UpdateDivision(GlobalClass.PreviousDivisionIdForRegion, divisionNameForRegion, empDesignationCodeFromTeam, empNameFromTeam, empActivityStartDateFromTeam, txtRegionActivityEndDate.Text, cmbRegionActive.Text, cmbSelectDivisionForRegion.Text, Convert.ToInt16(txtDivisionIDForRegion.Text));
                            objDivisionDetailsManager.UpdateTeamDivision(GlobalClass.PreviousDivisionIdForRegion, divisionNameForRegion, empDesignationCodeFromTeam, empNameFromTeam, empActivityStartDateFromTeam, txtRegionActivityEndDate.Text, cmbRegionActive.Text, cmbSelectDivisionForRegion.Text, Convert.ToInt16(txtDivisionIDForRegion.Text));
                            objDivisionDetailsManager.UpdateTeamDetailsByUpdateTeamName(GlobalClass.PreviousDivisionIdForRegion, divisionNameForRegion, empDesignationCodeFromTeam, empNameFromTeam, empActivityStartDateFromTeam, txtRegionActivityEndDate.Text, cmbRegionActive.Text, cmbSelectDivisionForRegion.Text, Convert.ToInt16(txtDivisionIDForRegion.Text));
                            //objDivisionDetailsManager.InsertDivision(divisionNameForRegion, empDesignationCodeFromTeam, empNameFromTeam, empActivityStartDateFromTeam, regionActive, divisionIdForRegion);
                            //divisionIdForRegion = Convert.ToInt16(objDivisionDetailsManager.GetDivisionID(divisionNameForRegion));
                            //objRegionDetailsManager.InsertRegion(regionName, empDesignationCode, empName, regionActivityStartDate, regionActive, divisionIdForRegion, divisionNameForRegion);
                            //objRegionDetailsManager.InsertRegion(regionName, empDesignationCode, empName, regionActivityStartDate, regionActive, GlobalClass.DivisionIdForUpdateDivision, divisionNameForRegion);
                            //btnAddRegion.Enabled = true;
                            //btnSaveRegion.Enabled = false;
                            //MessageBox.Show("Region Added Succesfully");

                            //////if (lblSelectDivisionForRegion.Text == "Select Team" && lblSelectDivisionForRegion.Text != "Select Devision")
                            //////{
                            //////    DataTable TeamDataTable = objGroupDetailsManager.GetTeamDetails(divisionNameForRegion);

                            //////    string empNameFromTeam = TeamDataTable.Rows[0][0].ToString();
                            //////    string empDesignationCodeFromTeam = TeamDataTable.Rows[0][1].ToString();
                            //////    string empActivityStartDateFromTeam = TeamDataTable.Rows[0][2].ToString();
                            //////    empActivityStartDateFromTeam = empActivityStartDateFromTeam.Replace("12:00:00 AM", "");
                            //////    empActivityStartDateFromTeam = empActivityStartDateFromTeam.Trim();
                            //////    divisionNameForRegion = divisionNameForRegion + " " + regionName;

                            //////    objDivisionDetailsManager.InsertDivision(divisionNameForRegion, empDesignationCodeFromTeam, empNameFromTeam, empActivityStartDateFromTeam, regionActive, divisionIdForRegion);

                            //////    divisionIdForRegion = Convert.ToInt16(objDivisionDetailsManager.GetDivisionID(divisionNameForRegion));

                            //////    objRegionDetailsManager.InsertRegion(regionName, empDesignationCode, empName, regionActivityStartDate, regionActive, divisionIdForRegion, divisionNameForRegion);
                            //////    //objRegionDetailsManager.InsertRegion(regionName, empDesignationCode, empName, regionActivityStartDate, regionActive, GlobalClass.DivisionIdForUpdateDivision, divisionNameForRegion);
                            //////    btnAddRegion.Enabled = true;
                            //////    btnSaveRegion.Enabled = false;

                            //////    MessageBox.Show("Region Added Succesfully");
                            //////}
                        }
                        
                        if (GlobalClass.PreviousRegionName != txtRegionName.Text && GlobalClass.PreviousEmployeeNameForRegion == cmbSelectEmployeeForRegion.Text)
                        {
                            if (MessageBox.Show("Do you want to Update " + GlobalClass.PreviousRegionName + " as " + txtRegionName.Text + " ? All Previous Data and Records of " + GlobalClass.PreviousRegionName + " will be updated as " + txtRegionName.Text + " from now on.", "Save!", MessageBoxButtons.YesNo) == DialogResult.Yes)
                            {
                                UpdateRegion();
                            }
                        }
                        else if (GlobalClass.PreviousRegionName == txtRegionName.Text && GlobalClass.PreviousEmployeeNameForRegion != cmbSelectEmployeeForRegion.Text)
                        {
                            if (MessageBox.Show("Do you want to Update Employee of " + GlobalClass.PreviousRegionName + " ? All Data and Records of " + GlobalClass.PreviousEmployeeNameForRegion + " for " + GlobalClass.PreviousRegionName + " will be Updated as " + cmbSelectEmployeeForRegion.Text + " from now on.", "Save!", MessageBoxButtons.YesNo) == DialogResult.Yes)
                            {
                                UpdateRegion();
                            }
                        }
                        else if (GlobalClass.PreviousRegionName != txtRegionName.Text && GlobalClass.PreviousEmployeeNameForRegion != cmbSelectEmployeeForRegion.Text)
                        {
                            if (MessageBox.Show("Do you want to Update " + GlobalClass.PreviousRegionName + " and Employee of " + GlobalClass.PreviousRegionName + " ? All Data and Records will be Updated as " + txtRegionName.Text + " and Employee for " + txtRegionName.Text + " as " + cmbSelectEmployeeForRegion.Text + " from now on.", "Save!", MessageBoxButtons.YesNo) == DialogResult.Yes)
                            {
                                UpdateRegion();
                            }
                        }
                        else if (GlobalClass.PreviousDivisionNameForRegion != cmbSelectDivisionForRegion.Text && GlobalClass.PreviousDivisionIdForRegion != Convert.ToInt16(txtDivisionIDForRegion.Text.ToString()))
                        {
                            if (MessageBox.Show("Do you want to Update " + GlobalClass.PreviousDivisionNameForRegion + " to " + cmbSelectDivisionForRegion.Text + " ? All Data and Records of " + GlobalClass.PreviousDivisionNameForRegion + " will be Updated as " + cmbSelectDivisionForRegion.Text + " from now on.", "Save!", MessageBoxButtons.YesNo) == DialogResult.Yes)
                            {
                                UpdateRegionByUpdatingDivision();
                            }
                        }
                        else
                        {
                            UpdateRegion();
                        }
                    }
                    else
                    {
                        if (GlobalClass.PreviousRegionName != txtRegionName.Text && GlobalClass.PreviousEmployeeNameForRegion == cmbSelectEmployeeForRegion.Text)
                        {
                            if (MessageBox.Show("Do you want to Update " + GlobalClass.PreviousRegionName + " as " + txtRegionName.Text + " ? All Previous Data and Records of " + GlobalClass.PreviousRegionName + " will be updated as " + txtRegionName.Text + " from now on.", "Save!", MessageBoxButtons.YesNo) == DialogResult.Yes)
                            {
                                UpdateRegion();
                            }
                        }
                        else if (GlobalClass.PreviousRegionName == txtRegionName.Text && GlobalClass.PreviousEmployeeNameForRegion != cmbSelectEmployeeForRegion.Text)
                        {
                            if (MessageBox.Show("Do you want to Update Employee of " + GlobalClass.PreviousRegionName + " ? All Data and Records of " + GlobalClass.PreviousEmployeeNameForRegion + " for " + GlobalClass.PreviousRegionName + " will be Updated as " + cmbSelectEmployeeForRegion.Text + " from now on.", "Save!", MessageBoxButtons.YesNo) == DialogResult.Yes)
                            {
                                UpdateRegion();
                            }
                        }
                        else if (GlobalClass.PreviousRegionName != txtRegionName.Text && GlobalClass.PreviousEmployeeNameForRegion != cmbSelectEmployeeForRegion.Text)
                        {
                            if (MessageBox.Show("Do you want to Update " + GlobalClass.PreviousRegionName + " and Employee of " + GlobalClass.PreviousRegionName + " ? All Data and Records will be Updated as " + txtRegionName.Text + " and Employee for " + txtRegionName.Text + " as " + cmbSelectEmployeeForRegion.Text + " from now on.", "Save!", MessageBoxButtons.YesNo) == DialogResult.Yes)
                            {
                                UpdateRegion();
                            }
                        }
                        else if (GlobalClass.PreviousDivisionNameForRegion != cmbSelectDivisionForRegion.Text && GlobalClass.PreviousDivisionIdForRegion != Convert.ToInt16(txtDivisionIDForRegion.Text.ToString()))
                        {
                            if (MessageBox.Show("Do you want to Update " + GlobalClass.PreviousDivisionNameForRegion + " to " + cmbSelectDivisionForRegion.Text + " ? All Data and Records of " + GlobalClass.PreviousDivisionNameForRegion + " will be Updated as " + cmbSelectDivisionForRegion.Text + " from now on.", "Save!", MessageBoxButtons.YesNo) == DialogResult.Yes)
                            {
                                UpdateRegionByUpdatingDivision();
                            }
                        }
                        else
                        {
                            UpdateRegion();
                        }
                    }
                }
                RefreshRegion();
            }
        }

        //private int checkTeam()
        //{
            
        //}

        private void UpdateRegion()
        {
            if (cmbRegionActive.Text == "No" && txtRegionActivityEndDate.Text != "")
            {
                objRegionDetailsManager.UpdateRegionWithEndDate(regionId,regionName,empDesignationCode,empName,regionActivityStartDate,regionActivityEndDate,regionActive,divisionNameForRegion,divisionIdForRegion);
                objRegionDetailsManager.UpdateTeamDetailsWithEndDate(regionId, regionName, empDesignationCode, empName, regionActivityStartDate, regionActivityEndDate, regionActive, divisionNameForRegion, divisionIdForRegion);
                objRegionDetailsManager.UpdateDivisionRegion(regionId, regionName, empDesignationCode, empName, regionActivityStartDate, regionActivityEndDate, regionActive, divisionNameForRegion, divisionIdForRegion);
                btnAddRegion.Enabled = true;
                btnSaveRegion.Enabled = false;
                MessageBox.Show("Region Updated Succesfully");
            }
            else
            {
                objRegionDetailsManager.UpdateRegion(regionId, regionName, empDesignationCode, empName, regionActivityStartDate, regionActivityEndDate, regionActive, divisionNameForRegion, divisionIdForRegion);
                objRegionDetailsManager.UpdateTeamDetails(regionId, regionName, empDesignationCode, empName, regionActivityStartDate, regionActivityEndDate, regionActive, divisionNameForRegion, divisionIdForRegion);
                objRegionDetailsManager.UpdateDivisionRegion(regionId, regionName, empDesignationCode, empName, regionActivityStartDate, regionActivityEndDate, regionActive, divisionNameForRegion, divisionIdForRegion);
                btnAddRegion.Enabled = true;
                btnSaveRegion.Enabled = false;
                MessageBox.Show("Region Updated Succesfully");
            }
        }

        private void UpdateRegionByUpdatingDivision()
        {
            UpdateRegion();
            objRegionDetailsManager.UpdateTeamDetailsByUpdateDivisionName(regionId, regionName, empDesignationCode, empName, regionActivityStartDate, regionActivityEndDate, regionActive, divisionNameForRegion, divisionIdForRegion);
        }

        private void cmbSelectDesignationForRegion_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (btnSaveRegion.Text == "Save Region")
            {
                if (cmbSelectDesignationForRegion.Text != "Select Designation")
                {
                    cmbSelectEmployeeForRegion.DataSource = objEmployeeDetailsManager.SearchEmployeeDesignation(cmbSelectDesignationForRegion.Text.ToString());
                    cmbSelectEmployeeForRegion.DisplayMember = "Employee_Name";
                    cmbSelectEmployeeForRegion.ValueMember = "Employee_Name";
                    cmbSelectEmployeeForRegion.Text = "Select Employee";
                }
            }
            else if (btnSaveRegion.Text == "Update Region")
            {
                if (cmbSelectDesignationForRegion.Text != "Select Designation")
                {
                    cmbSelectEmployeeForRegion.DataSource = objEmployeeDetailsManager.SearchEmployeeDesignation(cmbSelectDesignationForRegion.Text.ToString());
                    cmbSelectEmployeeForRegion.DisplayMember = "Employee_Name";
                    cmbSelectEmployeeForRegion.ValueMember = "Employee_Name";
                }
            }
        }

        private void cmbSelectDesignationForRegion_SelectedValueChanged(object sender, EventArgs e)
        {
            if (btnSaveRegion.Text == "Save Region")
            {
                if (cmbSelectDesignationForRegion.Text != "Select Designation")
                {
                    cmbSelectEmployeeForRegion.DataSource = objEmployeeDetailsManager.SearchEmployeeDesignation(cmbSelectDesignationForRegion.Text.ToString());
                    cmbSelectEmployeeForRegion.DisplayMember = "Employee_Name";
                    cmbSelectEmployeeForRegion.ValueMember = "Employee_Name";
                    cmbSelectEmployeeForRegion.Text = "Select Employee";
                }
            }
            else if (btnSaveRegion.Text == "Update Region")
            {
                if (cmbSelectDesignationForRegion.Text != "Select Designation")
                {
                    cmbSelectEmployeeForRegion.DataSource = objEmployeeDetailsManager.SearchEmployeeDesignation(cmbSelectDesignationForRegion.Text.ToString());
                    cmbSelectEmployeeForRegion.DisplayMember = "Employee_Name";
                    cmbSelectEmployeeForRegion.ValueMember = "Employee_Name";
                }
            }
        }

        private void dTPRegionActivityStartDate_CloseUp(object sender, EventArgs e)
        {
            txtRegionActivityStartDate.Text = dTPRegionActivityStartDate.Text.ToString();
            txtRegionActivityStartDate.Focus();
        }

        private void dTPRegionActivityEndDate_CloseUp(object sender, EventArgs e)
        {
            txtRegionActivityEndDate.Text = dTPRegionActivityEndDate.Text.ToString();
            txtRegionActivityEndDate.Focus();
        }

        private void cmbSelectDivisionForRegion_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (chkTeam.Checked == true)
            {
                txtDivisionIDForRegion.Text = objGroupDetailsManager.GetTeamID(cmbSelectDivisionForRegion.Text.ToString());
            }
            else
            {
                txtDivisionIDForRegion.Text = objDivisionDetailsManager.GetDivisionID(cmbSelectDivisionForRegion.Text.ToString());    
            }
        }

        private void cmbRegionActive_SelectedValueChanged(object sender, EventArgs e)
        {
            if (cmbRegionActive.Text == "No")
            {
                txtRegionActivityEndDate.Enabled = true;
                dTPRegionActivityEndDate.Enabled = true;
                txtRegionActivityEndDate.Focus();
            }
            else if (cmbRegionActive.Text == "Yes")
            {
                txtRegionActivityEndDate.Text = "";
                txtRegionActivityEndDate.Enabled = false;
                dTPRegionActivityEndDate.Enabled = false;
            }
        }

        private void btnRefreshRegion_Click(object sender, EventArgs e)
        {
            RefreshRegion();
        }

        private void dataGridViewRegionDetails_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (btnSaveRegion.Enabled == false)
            {
                btnSaveRegion.Enabled = true;
            }
            btnSaveRegion.Text = "Update Region";

            GlobalClass.RegionIdForUpdateRegion = Convert.ToInt16(dataGridViewRegionDetails.CurrentRow.Cells[0].Value.ToString());
            GlobalClass.PreviousRegionName = dataGridViewRegionDetails.CurrentRow.Cells[1].Value.ToString();
            txtRegionName.Text = dataGridViewRegionDetails.CurrentRow.Cells[1].Value.ToString();
            cmbSelectDesignationForRegion.Text = dataGridViewRegionDetails.CurrentRow.Cells[3].Value.ToString();
            GlobalClass.PreviousEmployeeNameForRegion = dataGridViewRegionDetails.CurrentRow.Cells[2].Value.ToString();
            cmbSelectEmployeeForRegion.Text = dataGridViewRegionDetails.CurrentRow.Cells[2].Value.ToString();
            txtRegionActivityStartDate.Text = dataGridViewRegionDetails.CurrentRow.Cells[4].Value.ToString();
            txtRegionActivityStartDate.Text = txtRegionActivityStartDate.Text.Replace("12:00:00 AM", "");
            txtRegionActivityStartDate.Text = txtRegionActivityStartDate.Text.Trim();
            txtRegionActivityEndDate.Text = dataGridViewRegionDetails.CurrentRow.Cells[5].Value.ToString();
            if (txtRegionActivityEndDate.Text != "")
            {
                txtRegionActivityEndDate.Text = txtRegionActivityEndDate.Text.Replace("12:00:00 AM", "");
                txtRegionActivityEndDate.Text = txtRegionActivityEndDate.Text.Trim();
            }
            cmbRegionActive.Text = dataGridViewRegionDetails.CurrentRow.Cells[6].Value.ToString();
            cmbSelectDivisionForRegion.Text = dataGridViewRegionDetails.CurrentRow.Cells[7].Value.ToString();
            GlobalClass.PreviousDivisionNameForRegion = dataGridViewRegionDetails.CurrentRow.Cells[7].Value.ToString();
            txtDivisionIDForRegion.Text = dataGridViewRegionDetails.CurrentRow.Cells[8].Value.ToString();
            GlobalClass.PreviousDivisionIdForRegion = Convert.ToInt16(dataGridViewRegionDetails.CurrentRow.Cells[8].Value.ToString());

            if (txtRegionName.Enabled == false)
            {
                txtRegionName.Enabled = true;
            }
            if (cmbSelectDesignationForRegion.Enabled == false)
            {
                cmbSelectDesignationForRegion.Enabled = true;
            }
            if (cmbSelectEmployeeForRegion.Enabled == false)
            {
                cmbSelectEmployeeForRegion.Enabled = true;
            }
            if (txtRegionActivityStartDate.Enabled == false)
            {
                txtRegionActivityStartDate.Enabled = true;
            }
            if (dTPRegionActivityStartDate.Enabled == false)
            {
                dTPRegionActivityStartDate.Enabled = true;
            }
            if (txtRegionActivityEndDate.Text != "")
            {
                txtRegionActivityEndDate.Enabled = true;
                dTPRegionActivityEndDate.Enabled = true;
            }
            else
            {
                txtRegionActivityEndDate.Enabled = false;
                dTPRegionActivityEndDate.Enabled = false;
            }

            if (cmbRegionActive.Enabled == false)
            {
                cmbRegionActive.Enabled = true;
            }
            if (cmbSelectDivisionForRegion.Enabled == false)
            {
                cmbSelectDivisionForRegion.Enabled = true;
            }

            if (btnAddRegion.Enabled == false)
            {
                btnAddRegion.Enabled = true;
            }
            if (btnSaveRegion.Text == "Save Region")
            {
                btnSaveRegion.Text = "Update Region";
            }
        }

        private void chkTeam_CheckedChanged(object sender, EventArgs e)
        {
            if (chkTeam.Checked == true)
            {
                lblSelectDivisionForRegion.Text = "Select Team";
                cmbSelectDivisionForRegion.DataSource = objGroupDetailsManager.LoadTeam();
                cmbSelectDivisionForRegion.DisplayMember = "Team_Name";
                cmbSelectDivisionForRegion.ValueMember = "Team_Name";
                cmbSelectDivisionForRegion.Text = "Select Team";
                txtDivisionIDForRegion.Text = "";
                txtDivisionIDForRegion.ReadOnly = true;
            }
            else
            {
                lblSelectDivisionForRegion.Text = "Select Division";
                cmbSelectDivisionForRegion.DataSource = objDivisionDetailsManager.LoadDistinctEnabledDivision();
                cmbSelectDivisionForRegion.DisplayMember = "Division_Name";
                cmbSelectDivisionForRegion.ValueMember = "Division_Name";
                cmbSelectDivisionForRegion.Text = "Select Division";
                txtDivisionIDForRegion.Text = "";
                txtDivisionIDForRegion.ReadOnly = true;
            }
        }
    }
}
