﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using SMSapplication.BLL;
using SMSapplication.DAL.DAO;
using SMSapplication.DAL.Gateway;

namespace SMSapplication.UI
{
    public partial class LoginUI : Form
    {
        UserDetails objUserDetails = new UserDetails();
        UserDetailsManager ObjUserDetailsManager = new UserDetailsManager();
        private UserDetailsGateway objUserDetailsGateway = new UserDetailsGateway();

        public LoginUI()
        {
            InitializeComponent();
        }

        private void LoginUI_Load(object sender, EventArgs e)
        {

        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (txtUserName.Text == "")
            {
                MessageBox.Show("User Name can't be blank");
                txtUserName.Focus();
            }
            else if(txtPassword.Text == "")
            {
                MessageBox.Show("Password can't be blank");
                txtPassword.Focus();
            }
            else
            {
                objUserDetails.UserName = txtUserName.Text;
                objUserDetails.Password = txtPassword.Text;

                GlobalClass.LoginUserName = txtUserName.Text;

                GlobalClass objGlobalClass = new GlobalClass();

                //string userPassEncrypt = objGlobalClass.Encrypt(txtPassword.Text);
                //string userPassDecrypt = objGlobalClass.Decrypt(txtPassword.Text);
                //MessageBox.Show(userPassEncrypt);
                //MessageBox.Show(userPassDecrypt);

                if (ObjUserDetailsManager.userLogInCheck(objUserDetails) == 1)
                {
                    //this.Dispose();
                    //closed 03 Mar 2016 by Tanvir
                    //SMSapplication smsApplication = new SMSapplication();
                    //smsApplication.ShowDialog();
                    //this.Close();
                    
                    SelectOptionUI objSelectOptionUi = new SelectOptionUI();
                    objSelectOptionUi.ShowDialog();
                    this.Dispose();
                    this.Close();
                }
                else
                {
                    //MessageBox.Show("User does't exit.");
                    clearAll();
                    txtUserName.Focus();
                }
            }
        }
        
        private void clearAll()
        {
            txtUserName.Clear();
            txtPassword.Clear();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
