﻿namespace SMSapplication.UI
{
    partial class DivisionReportUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DivisionReportUI));
            this.groupBoxDivisionReport = new System.Windows.Forms.GroupBox();
            this.radioButtonNonDivisionForDivisionReport = new System.Windows.Forms.RadioButton();
            this.chkBoxSR = new System.Windows.Forms.CheckBox();
            this.chkBoxTSM = new System.Windows.Forms.CheckBox();
            this.chkBoxASM = new System.Windows.Forms.CheckBox();
            this.chkBoxDM = new System.Windows.Forms.CheckBox();
            this.chkBoxAllDesignation = new System.Windows.Forms.CheckBox();
            this.radioButtonSelectedDivisionForDivisionReport = new System.Windows.Forms.RadioButton();
            this.cmbSelectDivisionForDivisionReport = new System.Windows.Forms.ComboBox();
            this.btnUserReport = new System.Windows.Forms.Button();
            this.radioButtonAllDivisionForDivisionReport = new System.Windows.Forms.RadioButton();
            this.groupBoxDivisionReport.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxDivisionReport
            // 
            this.groupBoxDivisionReport.Controls.Add(this.radioButtonNonDivisionForDivisionReport);
            this.groupBoxDivisionReport.Controls.Add(this.chkBoxSR);
            this.groupBoxDivisionReport.Controls.Add(this.chkBoxTSM);
            this.groupBoxDivisionReport.Controls.Add(this.chkBoxASM);
            this.groupBoxDivisionReport.Controls.Add(this.chkBoxDM);
            this.groupBoxDivisionReport.Controls.Add(this.chkBoxAllDesignation);
            this.groupBoxDivisionReport.Controls.Add(this.radioButtonSelectedDivisionForDivisionReport);
            this.groupBoxDivisionReport.Controls.Add(this.cmbSelectDivisionForDivisionReport);
            this.groupBoxDivisionReport.Controls.Add(this.btnUserReport);
            this.groupBoxDivisionReport.Controls.Add(this.radioButtonAllDivisionForDivisionReport);
            this.groupBoxDivisionReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxDivisionReport.Location = new System.Drawing.Point(6, 3);
            this.groupBoxDivisionReport.Name = "groupBoxDivisionReport";
            this.groupBoxDivisionReport.Size = new System.Drawing.Size(360, 155);
            this.groupBoxDivisionReport.TabIndex = 54;
            this.groupBoxDivisionReport.TabStop = false;
            this.groupBoxDivisionReport.Text = "Division Report Criteria";
            // 
            // radioButtonNonDivisionForDivisionReport
            // 
            this.radioButtonNonDivisionForDivisionReport.AutoSize = true;
            this.radioButtonNonDivisionForDivisionReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonNonDivisionForDivisionReport.Location = new System.Drawing.Point(139, 45);
            this.radioButtonNonDivisionForDivisionReport.Name = "radioButtonNonDivisionForDivisionReport";
            this.radioButtonNonDivisionForDivisionReport.Size = new System.Drawing.Size(162, 20);
            this.radioButtonNonDivisionForDivisionReport.TabIndex = 130;
            this.radioButtonNonDivisionForDivisionReport.TabStop = true;
            this.radioButtonNonDivisionForDivisionReport.Text = "Non-Active Division";
            this.radioButtonNonDivisionForDivisionReport.UseVisualStyleBackColor = true;
            this.radioButtonNonDivisionForDivisionReport.Click += new System.EventHandler(this.radioButtonNonDivisionForDivisionReport_Click);
            // 
            // chkBoxSR
            // 
            this.chkBoxSR.AutoSize = true;
            this.chkBoxSR.Location = new System.Drawing.Point(274, 95);
            this.chkBoxSR.Name = "chkBoxSR";
            this.chkBoxSR.Size = new System.Drawing.Size(48, 20);
            this.chkBoxSR.TabIndex = 129;
            this.chkBoxSR.Text = "SR";
            this.chkBoxSR.UseVisualStyleBackColor = true;
            this.chkBoxSR.Visible = false;
            // 
            // chkBoxTSM
            // 
            this.chkBoxTSM.AutoSize = true;
            this.chkBoxTSM.Location = new System.Drawing.Point(209, 95);
            this.chkBoxTSM.Name = "chkBoxTSM";
            this.chkBoxTSM.Size = new System.Drawing.Size(59, 20);
            this.chkBoxTSM.TabIndex = 128;
            this.chkBoxTSM.Text = "TSM";
            this.chkBoxTSM.UseVisualStyleBackColor = true;
            this.chkBoxTSM.Visible = false;
            // 
            // chkBoxASM
            // 
            this.chkBoxASM.AutoSize = true;
            this.chkBoxASM.Location = new System.Drawing.Point(144, 95);
            this.chkBoxASM.Name = "chkBoxASM";
            this.chkBoxASM.Size = new System.Drawing.Size(59, 20);
            this.chkBoxASM.TabIndex = 127;
            this.chkBoxASM.Text = "ASM";
            this.chkBoxASM.UseVisualStyleBackColor = true;
            this.chkBoxASM.Visible = false;
            // 
            // chkBoxDM
            // 
            this.chkBoxDM.AutoSize = true;
            this.chkBoxDM.Location = new System.Drawing.Point(88, 95);
            this.chkBoxDM.Name = "chkBoxDM";
            this.chkBoxDM.Size = new System.Drawing.Size(50, 20);
            this.chkBoxDM.TabIndex = 126;
            this.chkBoxDM.Text = "DM";
            this.chkBoxDM.UseVisualStyleBackColor = true;
            this.chkBoxDM.Visible = false;
            // 
            // chkBoxAllDesignation
            // 
            this.chkBoxAllDesignation.AutoSize = true;
            this.chkBoxAllDesignation.Location = new System.Drawing.Point(6, 95);
            this.chkBoxAllDesignation.Name = "chkBoxAllDesignation";
            this.chkBoxAllDesignation.Size = new System.Drawing.Size(85, 20);
            this.chkBoxAllDesignation.TabIndex = 125;
            this.chkBoxAllDesignation.Text = "All Desi.";
            this.chkBoxAllDesignation.UseVisualStyleBackColor = true;
            this.chkBoxAllDesignation.Visible = false;
            // 
            // radioButtonSelectedDivisionForDivisionReport
            // 
            this.radioButtonSelectedDivisionForDivisionReport.AutoSize = true;
            this.radioButtonSelectedDivisionForDivisionReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonSelectedDivisionForDivisionReport.Location = new System.Drawing.Point(6, 45);
            this.radioButtonSelectedDivisionForDivisionReport.Name = "radioButtonSelectedDivisionForDivisionReport";
            this.radioButtonSelectedDivisionForDivisionReport.Size = new System.Drawing.Size(129, 20);
            this.radioButtonSelectedDivisionForDivisionReport.TabIndex = 124;
            this.radioButtonSelectedDivisionForDivisionReport.TabStop = true;
            this.radioButtonSelectedDivisionForDivisionReport.Text = "Active Division";
            this.radioButtonSelectedDivisionForDivisionReport.UseVisualStyleBackColor = true;
            this.radioButtonSelectedDivisionForDivisionReport.CheckedChanged += new System.EventHandler(this.radioButtonSelectedDivisionForDivisionReport_CheckedChanged);
            this.radioButtonSelectedDivisionForDivisionReport.Click += new System.EventHandler(this.radioButtonSelectedDivisionForDivisionReport_Click);
            // 
            // cmbSelectDivisionForDivisionReport
            // 
            this.cmbSelectDivisionForDivisionReport.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSelectDivisionForDivisionReport.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectDivisionForDivisionReport.Enabled = false;
            this.cmbSelectDivisionForDivisionReport.FormattingEnabled = true;
            this.cmbSelectDivisionForDivisionReport.Location = new System.Drawing.Point(6, 70);
            this.cmbSelectDivisionForDivisionReport.Name = "cmbSelectDivisionForDivisionReport";
            this.cmbSelectDivisionForDivisionReport.Size = new System.Drawing.Size(209, 24);
            this.cmbSelectDivisionForDivisionReport.Sorted = true;
            this.cmbSelectDivisionForDivisionReport.TabIndex = 123;
            this.cmbSelectDivisionForDivisionReport.Text = "Select Division";
            // 
            // btnUserReport
            // 
            this.btnUserReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUserReport.Location = new System.Drawing.Point(6, 119);
            this.btnUserReport.Name = "btnUserReport";
            this.btnUserReport.Size = new System.Drawing.Size(347, 25);
            this.btnUserReport.TabIndex = 73;
            this.btnUserReport.Text = "Report";
            this.btnUserReport.UseVisualStyleBackColor = true;
            this.btnUserReport.Click += new System.EventHandler(this.btnUserReport_Click);
            // 
            // radioButtonAllDivisionForDivisionReport
            // 
            this.radioButtonAllDivisionForDivisionReport.AutoSize = true;
            this.radioButtonAllDivisionForDivisionReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonAllDivisionForDivisionReport.Location = new System.Drawing.Point(6, 20);
            this.radioButtonAllDivisionForDivisionReport.Name = "radioButtonAllDivisionForDivisionReport";
            this.radioButtonAllDivisionForDivisionReport.Size = new System.Drawing.Size(104, 20);
            this.radioButtonAllDivisionForDivisionReport.TabIndex = 66;
            this.radioButtonAllDivisionForDivisionReport.TabStop = true;
            this.radioButtonAllDivisionForDivisionReport.Text = "All Division";
            this.radioButtonAllDivisionForDivisionReport.UseVisualStyleBackColor = true;
            this.radioButtonAllDivisionForDivisionReport.CheckedChanged += new System.EventHandler(this.radioButtonAllDivisionForDivisionReport_CheckedChanged);
            // 
            // DivisionReportUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(372, 170);
            this.Controls.Add(this.groupBoxDivisionReport);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "DivisionReportUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Division Report";
            this.groupBoxDivisionReport.ResumeLayout(false);
            this.groupBoxDivisionReport.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxDivisionReport;
        private System.Windows.Forms.Button btnUserReport;
        private System.Windows.Forms.RadioButton radioButtonAllDivisionForDivisionReport;
        private System.Windows.Forms.ComboBox cmbSelectDivisionForDivisionReport;
        private System.Windows.Forms.RadioButton radioButtonSelectedDivisionForDivisionReport;
        private System.Windows.Forms.CheckBox chkBoxSR;
        private System.Windows.Forms.CheckBox chkBoxTSM;
        private System.Windows.Forms.CheckBox chkBoxASM;
        private System.Windows.Forms.CheckBox chkBoxDM;
        private System.Windows.Forms.CheckBox chkBoxAllDesignation;
        private System.Windows.Forms.RadioButton radioButtonNonDivisionForDivisionReport;
    }
}