﻿namespace SMSapplication.UI
{
    partial class ProductListUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProductListUI));
            this.dataGridViewProductList = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBoxSearchProduct = new System.Windows.Forms.GroupBox();
            this.btnSearchProduct = new System.Windows.Forms.Button();
            this.txtSearchCriteriaForProduct = new System.Windows.Forms.TextBox();
            this.radioBtnProductID = new System.Windows.Forms.RadioButton();
            this.radioBtnProductName = new System.Windows.Forms.RadioButton();
            this.radioBtnProductCode = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProductList)).BeginInit();
            this.groupBoxSearchProduct.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridViewProductList
            // 
            this.dataGridViewProductList.AllowUserToAddRows = false;
            this.dataGridViewProductList.AllowUserToDeleteRows = false;
            this.dataGridViewProductList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewProductList.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridViewProductList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewProductList.Location = new System.Drawing.Point(12, 86);
            this.dataGridViewProductList.MultiSelect = false;
            this.dataGridViewProductList.Name = "dataGridViewProductList";
            this.dataGridViewProductList.ReadOnly = true;
            this.dataGridViewProductList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewProductList.Size = new System.Drawing.Size(911, 281);
            this.dataGridViewProductList.TabIndex = 0;
            this.dataGridViewProductList.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewProductList_CellDoubleClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(417, 20);
            this.label1.TabIndex = 53;
            this.label1.Text = "Double Click to select a Product Code from the list.";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(700, 20);
            this.label2.TabIndex = 54;
            this.label2.Text = "or Search for a product and then Double Click to select the Product Code from the" +
                " list.";
            // 
            // groupBoxSearchProduct
            // 
            this.groupBoxSearchProduct.Controls.Add(this.btnSearchProduct);
            this.groupBoxSearchProduct.Controls.Add(this.txtSearchCriteriaForProduct);
            this.groupBoxSearchProduct.Controls.Add(this.radioBtnProductID);
            this.groupBoxSearchProduct.Controls.Add(this.radioBtnProductName);
            this.groupBoxSearchProduct.Controls.Add(this.radioBtnProductCode);
            this.groupBoxSearchProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxSearchProduct.Location = new System.Drawing.Point(12, 386);
            this.groupBoxSearchProduct.Name = "groupBoxSearchProduct";
            this.groupBoxSearchProduct.Size = new System.Drawing.Size(206, 173);
            this.groupBoxSearchProduct.TabIndex = 55;
            this.groupBoxSearchProduct.TabStop = false;
            this.groupBoxSearchProduct.Text = "Search Criteria for Product";
            // 
            // btnSearchProduct
            // 
            this.btnSearchProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearchProduct.Location = new System.Drawing.Point(14, 140);
            this.btnSearchProduct.Name = "btnSearchProduct";
            this.btnSearchProduct.Size = new System.Drawing.Size(173, 25);
            this.btnSearchProduct.TabIndex = 5;
            this.btnSearchProduct.Text = "Search";
            this.btnSearchProduct.UseVisualStyleBackColor = true;
            this.btnSearchProduct.Click += new System.EventHandler(this.btnSearchProduct_Click);
            // 
            // txtSearchCriteriaForProduct
            // 
            this.txtSearchCriteriaForProduct.Location = new System.Drawing.Point(14, 110);
            this.txtSearchCriteriaForProduct.Name = "txtSearchCriteriaForProduct";
            this.txtSearchCriteriaForProduct.Size = new System.Drawing.Size(173, 22);
            this.txtSearchCriteriaForProduct.TabIndex = 4;
            // 
            // radioBtnProductID
            // 
            this.radioBtnProductID.AutoSize = true;
            this.radioBtnProductID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioBtnProductID.Location = new System.Drawing.Point(14, 20);
            this.radioBtnProductID.Name = "radioBtnProductID";
            this.radioBtnProductID.Size = new System.Drawing.Size(107, 20);
            this.radioBtnProductID.TabIndex = 1;
            this.radioBtnProductID.TabStop = true;
            this.radioBtnProductID.Text = "By Product ID";
            this.radioBtnProductID.UseVisualStyleBackColor = true;
            this.radioBtnProductID.CheckedChanged += new System.EventHandler(this.radioBtnProductID_CheckedChanged);
            // 
            // radioBtnProductName
            // 
            this.radioBtnProductName.AutoSize = true;
            this.radioBtnProductName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioBtnProductName.Location = new System.Drawing.Point(14, 80);
            this.radioBtnProductName.Name = "radioBtnProductName";
            this.radioBtnProductName.Size = new System.Drawing.Size(131, 20);
            this.radioBtnProductName.TabIndex = 3;
            this.radioBtnProductName.TabStop = true;
            this.radioBtnProductName.Text = "By Product Name";
            this.radioBtnProductName.UseVisualStyleBackColor = true;
            this.radioBtnProductName.CheckedChanged += new System.EventHandler(this.radioBtnProductName_CheckedChanged);
            // 
            // radioBtnProductCode
            // 
            this.radioBtnProductCode.AutoSize = true;
            this.radioBtnProductCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioBtnProductCode.Location = new System.Drawing.Point(14, 50);
            this.radioBtnProductCode.Name = "radioBtnProductCode";
            this.radioBtnProductCode.Size = new System.Drawing.Size(127, 20);
            this.radioBtnProductCode.TabIndex = 2;
            this.radioBtnProductCode.TabStop = true;
            this.radioBtnProductCode.Text = "By Product Code";
            this.radioBtnProductCode.UseVisualStyleBackColor = true;
            this.radioBtnProductCode.CheckedChanged += new System.EventHandler(this.radioBtnProductCode_CheckedChanged);
            // 
            // ProductListUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(936, 574);
            this.Controls.Add(this.groupBoxSearchProduct);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridViewProductList);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ProductListUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Product List";
            this.Load += new System.EventHandler(this.ProductListUI_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProductList)).EndInit();
            this.groupBoxSearchProduct.ResumeLayout(false);
            this.groupBoxSearchProduct.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewProductList;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBoxSearchProduct;
        private System.Windows.Forms.Button btnSearchProduct;
        private System.Windows.Forms.TextBox txtSearchCriteriaForProduct;
        private System.Windows.Forms.RadioButton radioBtnProductID;
        private System.Windows.Forms.RadioButton radioBtnProductName;
        private System.Windows.Forms.RadioButton radioBtnProductCode;
    }
}