﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using SMSapplication.DAL;
using SMSapplication.DAL.DAO;

namespace SMSapplication.UI
{
    public partial class SMS_MDI : Form
    {
        private int childFormNumber = 0;
        public string dbBackupPath;
        public string dbBackipFolderName;
        public string getDate;
        public string getTime;
        public string backUpFileName;

        public SMS_MDI()
        {
            InitializeComponent();
        }

        private void ShowNewForm(object sender, EventArgs e)
        {
            Form childForm = new Form();
            childForm.MdiParent = this;
            childForm.Text = "Window " + childFormNumber++;
            childForm.Show();
        }

        private void OpenFile(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            openFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (openFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = openFileDialog.FileName;
            }
        }

        private void SaveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            saveFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (saveFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = saveFileDialog.FileName;
            }
        }

        private void ExitToolsStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CascadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.Cascade);
        }

        private void TileVerticalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileVertical);
        }

        private void TileHorizontalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void ArrangeIconsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.ArrangeIcons);
        }

        private void CloseAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form childForm in MdiChildren)
            {
                childForm.Close();
            }
        }

        private void exitApplication_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void logOffUser_Click(object sender, EventArgs e)
        {
            Application.Restart();
            //SMSapplication objSmSapplication = new SMSapplication();
            //objSmSapplication.ShowDialog();
        }

        private void databaseBackupToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                DateTime getCurrDate = DateTime.Now;
                dbBackupPath = Application.StartupPath.ToString();
                dbBackipFolderName = dbBackupPath + "\\DB_Backup\\";
                getDate = getCurrDate.ToString("MMddyyyy");//String.Format(getCurrDate.ToShortDateString(),"MMDDYYYY").ToString();
                getTime = getCurrDate.ToString("HHmmss"); //String.Format(getCurrDate.ToShortTimeString(), "HHMMSS").ToString();
                backUpFileName = dbBackipFolderName + GlobalClass.DatabaseName + "_" + getDate + "_" + getTime + ".bak";

                //tbSelectedFolder.Text += string.Format("\\GononetPosBackup-{0}.Bak", DateTime.Now.ToString("yyyyMMdd"));
                //if (GlobalClass.MakeDatabaseBackup(backUpFileName)) MessageBox.Show("Backup created");

                //string srcDir = dbBackipFolderName;45r

                //string[] bakList = Directory.GetFiles(srcDir, "*.bak");

                //if (Directory.Exists(srcDir))
                //{
                //    foreach (string f in bakList)
                //    {
                //        File.Delete(f);
                //    }
                //}

                SqlCommand cmd = new SqlCommand("SP_DB_Backup", DBConnection.SqlConnectionObject);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@DiskPath", backUpFileName);
                DBConnection.SqlConnectionObject.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("BackUp completed...");
                DBConnection.SqlConnectionObject.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void addEditDepartment_Click_1(object sender, EventArgs e)
        {
            DepartmentUI objDepartmentUi = new DepartmentUI();
            objDepartmentUi.ShowDialog();
        }

        private void addEditDesignation_Click_1(object sender, EventArgs e)
        {
            DesignationUI objDesignationUi = new DesignationUI();
            objDesignationUi.ShowDialog();
        }

        private void addEditEmployee_Click_1(object sender, EventArgs e)
        {
            EmployeeUI objEmployeeUi = new EmployeeUI();
            objEmployeeUi.ShowDialog();
        }

        private void addEditUser_Click(object sender, EventArgs e)
        {
            UserUI objUserUi = new UserUI();
            objUserUi.ShowDialog();
        }

        private void addEditTeam_Click(object sender, EventArgs e)
        {
            TeamUI objTeamUi = new TeamUI();
            objTeamUi.ShowDialog();
        }

        private void addEditDivision_Click(object sender, EventArgs e)
        {
            DivisionUI objDivisionUi = new DivisionUI();
            objDivisionUi.ShowDialog();
        }

        private void teamTransfer_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Development under process");
        }

        private void divisionTransfer_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Development under process");
        }

        private void regionTransfer_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Development under process");
        }

        private void zoneTransfer_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Development under process");
        }

        private void areaTransfer_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Development under process");
        }

        private void marketTransfer_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Development under process");
        }

        private void addEditRegion_Click(object sender, EventArgs e)
        {
            RegionUI objRegionUi = new RegionUI();
            objRegionUi.ShowDialog();
        }

        private void addEditZone_Click(object sender, EventArgs e)
        {
            ZoneUI objZoneUi = new ZoneUI();
            objZoneUi.ShowDialog();
        }

        private void addEditArea_Click(object sender, EventArgs e)
        {
            AreaUI objAreaUi = new AreaUI();
            objAreaUi.ShowDialog();
        }

        private void addEditMarket_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Development under process");
        }

        private void addEditProduct_Click_1(object sender, EventArgs e)
        {
            ProductUI objProductUi = new ProductUI();
            objProductUi.ShowDialog();
        }

        private void productPriceLog_Click_1(object sender, EventArgs e)
        {
            ProductPriceUpdateLogUI objProductPriceUpdateLogUi = new ProductPriceUpdateLogUI();
            objProductPriceUpdateLogUi.ShowDialog();
        }

        private void teamDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TeamDetailsUI objTeamDetailsUi = new TeamDetailsUI();
            objTeamDetailsUi.ShowDialog();
        }
    }
}
