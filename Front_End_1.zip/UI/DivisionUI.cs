﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using SMSapplication.BLL;
using SMSapplication.DAL;
using SMSapplication.DAL.DAO;
using SMSapplication.DAL.Gateway;
using SMSapplication.UI;

namespace SMSapplication.UI
{
    public partial class DivisionUI : Form
    {
        DivisionDetailsManager objDivisionDetailsManager = new DivisionDetailsManager();
        DesignationDetailsManager objDesignationDetailsManager = new DesignationDetailsManager();
        EmployeeDetailsManager objEmployeeDetailsManager = new EmployeeDetailsManager();
        GroupDetailsManager objGroupDetailsManager = new GroupDetailsManager();

        private int divisionId;
        private string divisionName;
        private string empName;
        private string empDesignationCode;
        private string divisionActivityStartDate;
        private string divisionActivityEndDate;
        private string divisionActive;
        private string teamNameForDivision;
        private int teamIdForDivision;
        
        public DivisionUI()
        {
            InitializeComponent();
            RefreshDivision();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnAddDivision_Click(object sender, EventArgs e)
        {
            if (btnSaveDivision.Enabled == false)
            {
                btnSaveDivision.Enabled = true;
            }
            if (txtDivisionName.Enabled == false)
            {
                txtDivisionName.Enabled = true;
            }
            if (cmbSelectDesignationForDivision.Enabled == false)
            {
                cmbSelectDesignationForDivision.Enabled = true;
            }
            if (cmbSelectEmployeeForDivision.Enabled == false)
            {
                cmbSelectEmployeeForDivision.Enabled = true;
            }
            if (txtDivisionActivityStartDate.Enabled == false)
            {
                txtDivisionActivityStartDate.Enabled = true;
            }
            if (dTPDivisionActivityStartDate.Enabled == false)
            {
                dTPDivisionActivityStartDate.Enabled = true;
            }
            if (txtDivisionActivityEndDate.Enabled == true)
            {
                txtDivisionActivityEndDate.Enabled = false;
            }
            if (dTPDivisionActivityEndDate.Enabled == true)
            {
                dTPDivisionActivityEndDate.Enabled = false;
            }
            if (cmbDivisionActive.Enabled == false)
            {
                cmbDivisionActive.Enabled = true;
            }
            if (btnAddDivision.Enabled == false)
            {
                btnAddDivision.Enabled = true;
            }
            if (btnSaveDivision.Text == "Update Division")
            {
                btnSaveDivision.Text = "Save Division";
            }

            if (cmbSelectTeamForDivision.Enabled == false)
            {
                cmbSelectTeamForDivision.Enabled = true;
            }
            ClearDivision();
            txtDivisionName.Focus();
        }

        public void ClearDivision()
        {
            txtDivisionName.Text = "";
            cmbSelectDesignationForDivision.DataSource = objDesignationDetailsManager.LoadDesignationCombo();
            cmbSelectDesignationForDivision.DisplayMember = "Designation_Code";
            cmbSelectDesignationForDivision.ValueMember = "Designation_Code";
            cmbSelectDesignationForDivision.Text = "Select Designation";
            cmbSelectEmployeeForDivision.Text = "Select Employee";
            txtDivisionActivityStartDate.Text = "";
            txtDivisionActivityEndDate.Text = "";

            cmbSelectTeamForDivision.DataSource = objGroupDetailsManager.LoadTeam();
            cmbSelectTeamForDivision.DisplayMember = "Team_Name";
            cmbSelectTeamForDivision.ValueMember = "Team_Name";
            cmbSelectTeamForDivision.Text = "Select Team";
            txtTeamIDForDivision.Text = "";
            txtTeamIDForDivision.ReadOnly = true;
            cmbDivisionActive.Text = "Select Active";
            if (btnSaveDivision.Text == "Update Division")
            {
                btnSaveDivision.Text = "Save Division";
            }
        }

        public void DataGridViewDivisionDetailsHeaderText()
        {
            dataGridViewDivisionDetails.Columns[1].HeaderText = "Division Name";
            dataGridViewDivisionDetails.Columns[2].HeaderText = "Employee Name";
            dataGridViewDivisionDetails.Columns[3].HeaderText = "Designation Code";
            dataGridViewDivisionDetails.Columns[4].HeaderText = "Activity Start Date";
            dataGridViewDivisionDetails.Columns[5].HeaderText = "Activity End Date";
            dataGridViewDivisionDetails.Columns[7].HeaderText = "Team Name";
            dataGridViewDivisionDetails.Columns[8].HeaderText = "Team ID";
        }

        public void RefreshDivision()
        {
            ClearDivision();
            
            if (txtDivisionName.Enabled == true)
            {
                txtDivisionName.Enabled = false;
            }

            if (cmbSelectDesignationForDivision.Enabled == true)
            {
                cmbSelectDesignationForDivision.Enabled = false;
            }

            if (cmbSelectEmployeeForDivision.Enabled == true)
            {
                cmbSelectEmployeeForDivision.Enabled = false;
            }

            if (txtDivisionActivityStartDate.Enabled == true)
            {
                txtDivisionActivityStartDate.Enabled = false;
            }

            if (dTPDivisionActivityStartDate.Enabled == true)
            {
                dTPDivisionActivityStartDate.Enabled = false;
            }

            if (txtDivisionActivityEndDate.Enabled == true)
            {
                txtDivisionActivityEndDate.Enabled = false;
            }

            if (dTPDivisionActivityEndDate.Enabled == true)
            {
                dTPDivisionActivityEndDate.Enabled = false;
            }

            if (cmbSelectTeamForDivision.Enabled == true)
            {
                cmbSelectTeamForDivision.Enabled = false;
            }

            if (cmbDivisionActive.Enabled == true)
            {
                cmbDivisionActive.Enabled = false;
            }

            if (btnSaveDivision.Text == "Update Division")
            {
                btnSaveDivision.Text = "Save Division";
            }

            if (btnSaveDivision.Enabled == true)
            {
                btnSaveDivision.Enabled = false;
            }

            dataGridViewDivisionDetails.DataSource = objDivisionDetailsManager.ShowAllDivision();
            dataGridViewDivisionDetails.Columns[0].Visible = false;
            DataGridViewDivisionDetailsHeaderText();
            btnAddDivision.Focus();
        }

        private void btnRefreshDivision_Click(object sender, EventArgs e)
        {
            RefreshDivision();
        }

        private void cmbSelectDesignationForDivision_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (btnSaveDivision.Text == "Save Division")
            {
                if (cmbSelectDesignationForDivision.Text != "Select Designation")
                {
                    cmbSelectEmployeeForDivision.DataSource = objEmployeeDetailsManager.SearchEmployeeDesignation(cmbSelectDesignationForDivision.Text.ToString());
                    cmbSelectEmployeeForDivision.DisplayMember = "Employee_Name";
                    cmbSelectEmployeeForDivision.ValueMember = "Employee_Name";
                    cmbSelectEmployeeForDivision.Text = "Select Employee";
                }
            }
            else if (btnSaveDivision.Text == "Update Division")
            {
                if (cmbSelectDesignationForDivision.Text != "Select Designation")
                {
                    cmbSelectEmployeeForDivision.DataSource = objEmployeeDetailsManager.SearchEmployeeDesignation(cmbSelectDesignationForDivision.Text.ToString());
                    cmbSelectEmployeeForDivision.DisplayMember = "Employee_Name";
                    cmbSelectEmployeeForDivision.ValueMember = "Employee_Name";
                }
            }
        }

        private void cmbSelectDesignationForDivision_SelectedValueChanged(object sender, EventArgs e)
        {
            if (btnSaveDivision.Text == "Save Division")
            {
                if (cmbSelectDesignationForDivision.Text != "Select Designation")
                {
                    cmbSelectEmployeeForDivision.DataSource = objEmployeeDetailsManager.SearchEmployeeDesignation(cmbSelectDesignationForDivision.Text.ToString());
                    cmbSelectEmployeeForDivision.DisplayMember = "Employee_Name";
                    cmbSelectEmployeeForDivision.ValueMember = "Employee_Name";
                    cmbSelectEmployeeForDivision.Text = "Select Employee";
                }
            }
            else if (btnSaveDivision.Text == "Update Division")
            {
                if (cmbSelectDesignationForDivision.Text != "Select Designation")
                {
                    cmbSelectEmployeeForDivision.DataSource = objEmployeeDetailsManager.SearchEmployeeDesignation(cmbSelectDesignationForDivision.Text.ToString());
                    cmbSelectEmployeeForDivision.DisplayMember = "Employee_Name";
                    cmbSelectEmployeeForDivision.ValueMember = "Employee_Name";
                }
            }
        }

        private void dTPDivisionActivityStartDate_CloseUp(object sender, EventArgs e)
        {
            txtDivisionActivityStartDate.Text = dTPDivisionActivityStartDate.Text.ToString();
            txtDivisionActivityStartDate.Focus();
        }

        private void dTPDivisionActivityEndDate_CloseUp(object sender, EventArgs e)
        {
            txtDivisionActivityEndDate.Text = dTPDivisionActivityEndDate.Text.ToString();
            txtDivisionActivityEndDate.Focus();
        }

        private void cmbSelectTeamForDivision_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtTeamIDForDivision.Text = objGroupDetailsManager.GetTeamID(cmbSelectTeamForDivision.Text);
        }

        private void cmbDivisionActive_SelectedValueChanged(object sender, EventArgs e)
        {
            if (cmbDivisionActive.Text == "No")
            {
                txtDivisionActivityEndDate.Enabled = true;
                dTPDivisionActivityEndDate.Enabled = true;
                txtDivisionActivityEndDate.Focus();
            }
            else if (cmbDivisionActive.Text == "Yes")
            {
                txtDivisionActivityEndDate.Text = "";
                txtDivisionActivityEndDate.Enabled = false;
                dTPDivisionActivityEndDate.Enabled = false;
            }
        }

        private void btnSaveDivision_Click(object sender, EventArgs e)
        {
            if (txtDivisionName.Text == "")
            {
                MessageBox.Show("Division Name can't be blank.");
                txtDivisionName.Focus();
            }
            else if (cmbSelectDesignationForDivision.Text == "Select Designation" || cmbSelectDesignationForDivision.Text == "")
            {
                MessageBox.Show("Please select Designation.");
                cmbSelectDesignationForDivision.Focus();
            }
            else if (cmbSelectEmployeeForDivision.Text == "Select Employee" || cmbSelectEmployeeForDivision.Text == "")
            {
                MessageBox.Show("Please select Employee.");
                cmbSelectEmployeeForDivision.Focus();
            }
            else if (txtDivisionActivityStartDate.Text == "")
            {
                MessageBox.Show("Activity Start Date can't be blank.");
                txtDivisionActivityStartDate.Focus();
            }
            else if (cmbDivisionActive.Text == "Select Active" || cmbDivisionActive.Text == "")
            {
                MessageBox.Show("Please select Active for Division.");
                cmbDivisionActive.Focus();
            }
            else if (cmbDivisionActive.Text == "No" && txtDivisionActivityEndDate.Text == "")
            {
                MessageBox.Show("Activity End Date can't be blank.");
                txtDivisionActivityEndDate.Focus();
            }
            else if (txtDivisionActivityEndDate.Text != "" && txtDivisionActivityStartDate.Text != "" && Convert.ToDateTime(txtDivisionActivityEndDate.Text) < Convert.ToDateTime(txtDivisionActivityStartDate.Text))
            {
                MessageBox.Show("Activity End Date can't be small than Activity Start Date.");
                txtDivisionActivityEndDate.Focus();
            }
            else if (cmbSelectTeamForDivision.Text == "Select Team" || cmbSelectTeamForDivision.Text == "" || txtTeamIDForDivision.Text == "")
            {
                MessageBox.Show("Please select Team for Division.");
                cmbSelectTeamForDivision.Focus();
            }
            else
            {
                divisionName = txtDivisionName.Text;
                empDesignationCode = cmbSelectDesignationForDivision.Text;
                empName = cmbSelectEmployeeForDivision.Text;
                divisionActivityStartDate = txtDivisionActivityStartDate.Text;
                divisionActivityEndDate = txtDivisionActivityEndDate.Text;
                divisionActive = cmbDivisionActive.Text;
                teamNameForDivision = cmbSelectTeamForDivision.Text;
                teamIdForDivision = Convert.ToInt16(txtTeamIDForDivision.Text.ToString());
                divisionId = GlobalClass.DivisionIdForUpdateDivision;

                if (btnSaveDivision.Text == "Save Division")
                {
                    // closed on 20 July 2016
                    //objDivisionDetailsManager.InsertDivision(divisionName, empDesignationCode, empName, divisionActivityStartDate, divisionActive, teamNameForDivision, teamIdForDivision);
                    // closed on 20 July 2016

                    objDivisionDetailsManager.InsertDivision(divisionName, empDesignationCode, empName, divisionActivityStartDate, divisionActive, teamIdForDivision);
                    btnAddDivision.Enabled = true;
                    btnSaveDivision.Enabled = false;
                    MessageBox.Show("Division Added Succesfully");
                }
                else if (btnSaveDivision.Text == "Update Division")
                {
                    if (GlobalClass.PreviousDivisionName != txtDivisionName.Text && GlobalClass.PreviousEmployeeNameForDivision == cmbSelectEmployeeForDivision.Text)
                    {
                        if (MessageBox.Show("Do you want to Update " + GlobalClass.PreviousDivisionName + " as " + txtDivisionName.Text + " ? All Previous Data and Records of " + GlobalClass.PreviousDivisionName + " will be updated as " + txtDivisionName.Text + " from now on.", "Save!", MessageBoxButtons.YesNo) == DialogResult.Yes)
                        {
                            UpdateDivision();
                        }
                    }
                    else if (GlobalClass.PreviousDivisionName == txtDivisionName.Text && GlobalClass.PreviousEmployeeNameForDivision != cmbSelectEmployeeForDivision.Text)
                    {
                        if (MessageBox.Show("Do you want to Update Employee of " + GlobalClass.PreviousDivisionName + " ? All Data and Records of " + GlobalClass.PreviousEmployeeNameForDivision + " for " + GlobalClass.PreviousDivisionName + " will be Updated as " + cmbSelectEmployeeForDivision.Text + " from now on.", "Save!", MessageBoxButtons.YesNo) == DialogResult.Yes)
                        {
                            UpdateDivision();
                        }
                    }
                    else if (GlobalClass.PreviousDivisionName != txtDivisionName.Text && GlobalClass.PreviousEmployeeNameForDivision != cmbSelectEmployeeForDivision.Text)
                    {
                        if (MessageBox.Show("Do you want to Update " + GlobalClass.PreviousDivisionName + " and Employee of " + GlobalClass.PreviousDivisionName + " ? All Data and Records will be Updated as " + txtDivisionName.Text + " and Employee for " + txtDivisionName.Text + " as " + cmbSelectEmployeeForDivision.Text + " from now on.", "Save!", MessageBoxButtons.YesNo) == DialogResult.Yes)
                        {
                            UpdateDivision();
                        }
                    }
                    else if (GlobalClass.PreviousTeamNameForDivision != cmbSelectTeamForDivision.Text && GlobalClass.PreviousTeamIdForDivision != Convert.ToInt16(txtTeamIDForDivision.Text.ToString()))
                    {
                        if (MessageBox.Show("Do you want to Update " + GlobalClass.PreviousTeamNameForDivision + " to " + cmbSelectTeamForDivision.Text + " ? All Data and Records of " + GlobalClass.PreviousTeamNameForDivision + " will be Updated as " + cmbSelectTeamForDivision.Text + " from now on.", "Save!", MessageBoxButtons.YesNo) == DialogResult.Yes)
                        {
                            UpdateDivisionByUpdatingTeam();
                        }
                    }
                    else
                    {
                        UpdateDivision();
                    }
                }
                RefreshDivision();
            }
        }

        private void UpdateDivision()
        {
            if (cmbDivisionActive.Text == "No" && txtDivisionActivityEndDate.Text != "")
            {
                objDivisionDetailsManager.UpdateDivisionWithEndDate(divisionId, divisionName, empDesignationCode, empName, divisionActivityStartDate, divisionActivityEndDate, divisionActive, teamNameForDivision, teamIdForDivision);
                objDivisionDetailsManager.UpdateTeamDetailsWithEndDate(divisionId, divisionName, empDesignationCode, empName, divisionActivityStartDate, divisionActivityEndDate, divisionActive, teamNameForDivision, teamIdForDivision);
                objDivisionDetailsManager.UpdateTeamDivision(divisionId, divisionName, empDesignationCode, empName, divisionActivityStartDate, divisionActivityEndDate, divisionActive, teamNameForDivision, teamIdForDivision);
                btnAddDivision.Enabled = true;
                btnSaveDivision.Enabled = false;
                MessageBox.Show("Division Updated Succesfully");
            }
            else
            {
                objDivisionDetailsManager.UpdateDivision(divisionId, divisionName, empDesignationCode, empName, divisionActivityStartDate, divisionActivityEndDate, divisionActive, teamNameForDivision, teamIdForDivision);
                objDivisionDetailsManager.UpdateTeamDetails(divisionId, divisionName, empDesignationCode, empName, divisionActivityStartDate, divisionActivityEndDate, divisionActive, teamNameForDivision, teamIdForDivision);
                objDivisionDetailsManager.UpdateTeamDivision(divisionId, divisionName, empDesignationCode, empName, divisionActivityStartDate, divisionActivityEndDate, divisionActive, teamNameForDivision, teamIdForDivision);
                btnAddDivision.Enabled = true;
                btnSaveDivision.Enabled = false;
                MessageBox.Show("Division Updated Succesfully");
            }
        }

        private void UpdateDivisionByUpdatingTeam()
        {
            UpdateDivision();
            objDivisionDetailsManager.UpdateTeamDetailsByUpdateTeamName(divisionId, divisionName, empDesignationCode, empName, divisionActivityStartDate, divisionActivityEndDate, divisionActive, teamNameForDivision, teamIdForDivision);

        }

        private void dataGridViewDivisionDetails_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (btnSaveDivision.Enabled == false)
            {
                btnSaveDivision.Enabled = true;
            }
            btnSaveDivision.Text = "Update Division";
            GlobalClass.DivisionIdForUpdateDivision = Convert.ToInt16(dataGridViewDivisionDetails.CurrentRow.Cells[0].Value.ToString());
            GlobalClass.PreviousDivisionName = dataGridViewDivisionDetails.CurrentRow.Cells[1].Value.ToString();
            txtDivisionName.Text = dataGridViewDivisionDetails.CurrentRow.Cells[1].Value.ToString();
            cmbSelectDesignationForDivision.Text = dataGridViewDivisionDetails.CurrentRow.Cells[3].Value.ToString();
            GlobalClass.PreviousEmployeeNameForDivision = dataGridViewDivisionDetails.CurrentRow.Cells[2].Value.ToString();
            cmbSelectEmployeeForDivision.Text = dataGridViewDivisionDetails.CurrentRow.Cells[2].Value.ToString();
            txtDivisionActivityStartDate.Text = dataGridViewDivisionDetails.CurrentRow.Cells[4].Value.ToString();
            txtDivisionActivityStartDate.Text = txtDivisionActivityStartDate.Text.Replace("12:00:00 AM", "");
            txtDivisionActivityStartDate.Text = txtDivisionActivityStartDate.Text.Trim();
            txtDivisionActivityEndDate.Text = dataGridViewDivisionDetails.CurrentRow.Cells[5].Value.ToString();
            if (txtDivisionActivityEndDate.Text != "")
            {
                txtDivisionActivityEndDate.Text = txtDivisionActivityEndDate.Text.Replace("12:00:00 AM", "");
                txtDivisionActivityEndDate.Text = txtDivisionActivityEndDate.Text.Trim();
            }
            cmbDivisionActive.Text = dataGridViewDivisionDetails.CurrentRow.Cells[6].Value.ToString();
            cmbSelectTeamForDivision.Text = dataGridViewDivisionDetails.CurrentRow.Cells[7].Value.ToString();
            GlobalClass.PreviousTeamNameForDivision = dataGridViewDivisionDetails.CurrentRow.Cells[7].Value.ToString();
            txtTeamIDForDivision.Text = dataGridViewDivisionDetails.CurrentRow.Cells[8].Value.ToString();
            GlobalClass.PreviousTeamIdForDivision = Convert.ToInt16(dataGridViewDivisionDetails.CurrentRow.Cells[8].Value.ToString());

            if (txtDivisionName.Enabled == false)
            {
                txtDivisionName.Enabled = true;
            }
            if (cmbSelectDesignationForDivision.Enabled == false)
            {
                cmbSelectDesignationForDivision.Enabled = true;
            }
            if (cmbSelectEmployeeForDivision.Enabled == false)
            {
                cmbSelectEmployeeForDivision.Enabled = true;
            }
            if (txtDivisionActivityStartDate.Enabled == false)
            {
                txtDivisionActivityStartDate.Enabled = true;
            }
            if (dTPDivisionActivityStartDate.Enabled == false)
            {
                dTPDivisionActivityStartDate.Enabled = true;
            }
            if (txtDivisionActivityEndDate.Text != "")
            {
                txtDivisionActivityEndDate.Enabled = true;
                dTPDivisionActivityEndDate.Enabled = true;
            }
            else
            {
                txtDivisionActivityEndDate.Enabled = false;
                dTPDivisionActivityEndDate.Enabled = false;
            }

            if (cmbDivisionActive.Enabled == false)
            {
                cmbDivisionActive.Enabled = true;
            }
            if (cmbSelectTeamForDivision.Enabled == false)
            {
                cmbSelectTeamForDivision.Enabled = true;
            }

            if (btnAddDivision.Enabled == false)
            {
                btnAddDivision.Enabled = true;
            }
            if (btnSaveDivision.Text == "Save Division")
            {
                btnSaveDivision.Text = "Update Division";
            }
        }

        private void DivisionUI_Load(object sender, EventArgs e)
        {
            RefreshDivision();
        }
    }
}
