﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using SMSapplication.BLL;
using SMSapplication.DAL;
using SMSapplication.DAL.DAO;
using SMSapplication.DAL.Gateway;
using SMSapplication.UI;

namespace SMSapplication.UI
{
    public partial class DesignationUI : Form
    {
        DesignationDetailsManager objDesignationDetailsManager = new DesignationDetailsManager();
        
        public DesignationUI()
        {
            InitializeComponent();
            RefreshDesi();
        }

        private void DesignationUI_Load(object sender, EventArgs e)
        {
            RefreshDesi();
        }

        public void DataGridViewDesignationListHeaderText()
        {
            dataGridViewDesignationList.Columns[1].HeaderText = "Designation Code";
            dataGridViewDesignationList.Columns[2].HeaderText = "Designation Details";
            //dataGridViewDesignationList.Columns[3].HeaderText = "Enable / Disable";
        }

        private void RefreshDesi()
        {
            ClearDesignationTab();

            if (txtDesignation.Enabled == true)
            {
                txtDesignation.Enabled = false;
            }
            if (txtDesignationDetails.Enabled == true)
            {
                txtDesignationDetails.Enabled = false;
            }
            if (cmbActiveDesignation.Enabled == true)
            {
                cmbActiveDesignation.Enabled = false;
            }
            if (btnSaveDesignation.Enabled == true)
            {
                btnSaveDesignation.Enabled = false;
            }
            if (btnAddDesignation.Enabled == false)
            {
                btnAddDesignation.Enabled = true;
            }
            if (btnSaveDesignation.Text == "Update Designation")
            {
                btnSaveDesignation.Text = "Save Designation";
            }
            dataGridViewDesignationList.DataSource = objDesignationDetailsManager.ShowAllDesignation();
            dataGridViewDesignationList.Columns[0].Visible = false;
            DataGridViewDesignationListHeaderText();
            btnAddDesignation.Focus();
        }

        public void ClearDesignationTab()
        {
            txtDesignation.Text = "";
            txtDesignationDetails.Text = "";
            cmbActiveDesignation.Text = "Select Active";
        }

        private void btnAddDesignation_Click(object sender, EventArgs e)
        {
            if (btnSaveDesignation.Enabled == false)
            {
                btnSaveDesignation.Enabled = true;
            }

            if (btnSaveDesignation.Text == "Update Designation")
            {
                btnSaveDesignation.Text = "Save Designation";
            }

            if (txtDesignation.Enabled == false)
            {
                txtDesignation.Enabled = true;
            }

            if (txtDesignationDetails.Enabled == false)
            {
                txtDesignationDetails.Enabled = true;
            }

            if (cmbActiveDesignation.Enabled == false)
            {
                cmbActiveDesignation.Enabled = true;
            }
            ClearDesignationTab();
            txtDesignation.Focus();
        }

        private void btnSaveDesignation_Click(object sender, EventArgs e)
        {
            string designation;
            string designationDetails;
            string activeDesignation;
            int designationID;

            designation = txtDesignation.Text;
            designationDetails = txtDesignationDetails.Text;
            activeDesignation = cmbActiveDesignation.Text;

            if (txtDesignation.Text == "")
            {
                MessageBox.Show("Designation Code can't be blank.");
                txtDesignation.Focus();
            }
            else if (txtDesignationDetails.Text == "")
            {
                MessageBox.Show("Designation Details can't be blank.");
                txtDesignationDetails.Focus();
            }
            else if (cmbActiveDesignation.Text == "" || cmbActiveDesignation.Text == "Select Active")
            {
                MessageBox.Show("Designation Activation can't be blank.");
                cmbActiveDesignation.Focus();
            }
            else
            {
                if (btnSaveDesignation.Text == "Save Designation")
                {
                    objDesignationDetailsManager.InsertDesignation(designation, designationDetails, activeDesignation);
                    dataGridViewDesignationList.Refresh();
                    dataGridViewDesignationList.DataSource = objDesignationDetailsManager.ShowAllDesignation();
                    dataGridViewDesignationList.Columns[0].Visible = false;
                    btnSaveDesignation.Enabled = false;
                    MessageBox.Show("Designation Added Succesfully");
                }
                else if (btnSaveDesignation.Text == "Update Designation")
                {
                    designationID = Convert.ToInt32(GlobalClass.DesignationIDforUpdateDesignation);
                    objDesignationDetailsManager.UpdateDesignation(designationID, designation, designationDetails, activeDesignation);
                    dataGridViewDesignationList.Refresh();
                    dataGridViewDesignationList.DataSource = objDesignationDetailsManager.ShowAllDesignation();
                    dataGridViewDesignationList.Columns[0].Visible = false;
                    btnSaveDesignation.Text = "Save Designation";
                    btnSaveDesignation.Enabled = false;
                    MessageBox.Show("Designation Updated Succesfully");
                }
            }

            ClearDesignationTab();

            if (txtDesignation.Enabled == true)
            {
                txtDesignation.Enabled = false;
            }
            if (txtDesignationDetails.Enabled == true)
            {
                txtDesignationDetails.Enabled = false;
            }
            if (cmbActiveDesignation.Enabled == true)
            {
                cmbActiveDesignation.Enabled = false;
            }
            if (btnSaveDesignation.Enabled == true)
            {
                btnSaveDesignation.Enabled = false;
            }
            if (btnAddDesignation.Enabled == false)
            {
                btnAddDesignation.Enabled = true;
            }
            if (btnSaveDesignation.Text == "Update Designation")
            {
                btnSaveDesignation.Text = "Save Designation";
            }

            DataGridViewDesignationListHeaderText();
        }

        private void dataGridViewDesignationList_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (btnSaveDesignation.Enabled == false)
            {
                btnSaveDesignation.Enabled = true;
            }
            btnSaveDesignation.Text = "Update Designation";
            GlobalClass.DesignationIDforUpdateDesignation = dataGridViewDesignationList.CurrentRow.Cells[0].Value.ToString();
            txtDesignation.Text = dataGridViewDesignationList.CurrentRow.Cells[1].Value.ToString();
            txtDesignationDetails.Text = dataGridViewDesignationList.CurrentRow.Cells[2].Value.ToString();
            cmbActiveDesignation.Text = dataGridViewDesignationList.CurrentRow.Cells[3].Value.ToString();

            if (btnSaveDesignation.Enabled == false)
            {
                btnSaveDesignation.Enabled = true;
            }

            if (btnSaveDesignation.Text == "Save Designation")
            {
                btnSaveDesignation.Text = "Update Designation";
            }

            if (txtDesignation.Enabled == false)
            {
                txtDesignation.Enabled = true;
            }

            if (txtDesignationDetails.Enabled == false)
            {
                txtDesignationDetails.Enabled = true;
            }

            if (cmbActiveDesignation.Enabled == false)
            {
                cmbActiveDesignation.Enabled = true;
            }
        }

        private void dataGridViewDesignationList_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (btnSaveDesignation.Enabled == false)
            {
                btnSaveDesignation.Enabled = true;
            }
            btnSaveDesignation.Text = "Update Designation";
            GlobalClass.DesignationIDforUpdateDesignation = dataGridViewDesignationList.CurrentRow.Cells[0].Value.ToString();
            txtDesignation.Text = dataGridViewDesignationList.CurrentRow.Cells[1].Value.ToString();
            txtDesignationDetails.Text = dataGridViewDesignationList.CurrentRow.Cells[2].Value.ToString();
            cmbActiveDesignation.Text = dataGridViewDesignationList.CurrentRow.Cells[3].Value.ToString();

            if (btnSaveDesignation.Enabled == false)
            {
                btnSaveDesignation.Enabled = true;
            }

            if (btnSaveDesignation.Text == "Save Designation")
            {
                btnSaveDesignation.Text = "Update Designation";
            }

            if (txtDesignation.Enabled == false)
            {
                txtDesignation.Enabled = true;
            }

            if (txtDesignationDetails.Enabled == false)
            {
                txtDesignationDetails.Enabled = true;
            }

            if (cmbActiveDesignation.Enabled == false)
            {
                cmbActiveDesignation.Enabled = true;
            }
        }

        private void btnDesignationReport_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Development Under Process .....");
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
