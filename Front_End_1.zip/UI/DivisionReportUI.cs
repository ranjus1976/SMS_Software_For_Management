﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using CrystalDecisions.Windows.Forms;
using SMSapplication.Reports;
using SMSapplication.BLL;
using SMSapplication.DAL.DAO;
using SMSapplication.DAL.Gateway;

namespace SMSapplication.UI
{
    public partial class DivisionReportUI : Form
    {
        DivisionDetailsManager objDivisionDetailsManager = new DivisionDetailsManager();
        DataTable dt = new DataTable();
        DataTable tmpDt = new DataTable();
        public DivisionReportUI()
        {
            InitializeComponent();
        }

        private void radioButtonAllDivisionForDivisionReport_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonAllDivisionForDivisionReport.Checked == true)
            {
                radioButtonSelectedDivisionForDivisionReport.Checked = false;
                cmbSelectDivisionForDivisionReport.Enabled = false;
            }
        }

        private void radioButtonSelectedDivisionForDivisionReport_CheckedChanged(object sender, EventArgs e)
        {
            //if (radioButtonSelectedDivisionForDivisionReport.Checked == true)
            //{
            //    radioButtonAllDivisionForDivisionReport.Checked = false;
            //    cmbSelectDivisionForDivisionReport.Enabled = true;
            //    cmbSelectDivisionForDivisionReport.DataSource = objDivisionDetailsManager.ShowDistinctDivision();
            //    cmbSelectDivisionForDivisionReport.DisplayMember = "Division_Name";
            //    cmbSelectDivisionForDivisionReport.ValueMember = "Division_Name";
            //    cmbSelectDivisionForDivisionReport.Text = "Select Division";
            //}
        }

        private void btnUserReport_Click(object sender, EventArgs e)
        {
            try
            {
                string reportPath = Application.StartupPath + "\\Reports\\DivisionReport.rpt";
                if (radioButtonAllDivisionForDivisionReport.Checked == true)
                {
                    dt = objDivisionDetailsManager.ShowAllDivisionForReport();
                }
                else if (radioButtonSelectedDivisionForDivisionReport.Checked == true)
                {
                    dt = objDivisionDetailsManager.ShowSelectedDivisionForReport(cmbSelectDivisionForDivisionReport.Text);
                }
                else if (radioButtonNonDivisionForDivisionReport.Checked == true)
                {
                    dt = objDivisionDetailsManager.ShowSelectedDivisionForReport(cmbSelectDivisionForDivisionReport.Text);
                }
                //else if (radioButtonAllProductForProductReport.Checked == true)
                //{
                //    dt = objProductDetailsManager.GetAllProductForProductReport();
                //}

                tmpDt = objDivisionDetailsManager.GetTempData();

                ReportDocument reportDocument = new ReportDocument();
                ReportViewer objViewer = new ReportViewer();
                reportDocument.Load(reportPath);
                reportDocument.SetDataSource(tmpDt);
                objViewer.CrystalReportViewer1.ReportSource = reportDocument;
                objViewer.CrystalReportViewer1.Refresh();
                objViewer.ShowDialog();
                this.Close();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void radioButtonSelectedDivisionForDivisionReport_Click(object sender, EventArgs e)
        {
            if (radioButtonSelectedDivisionForDivisionReport.Checked == true)
            {
                radioButtonAllDivisionForDivisionReport.Checked = false;
                radioButtonNonDivisionForDivisionReport.Checked = false;
                cmbSelectDivisionForDivisionReport.Enabled = true;
                cmbSelectDivisionForDivisionReport.DataSource = objDivisionDetailsManager.LoadDistinctEnabledDivision();
                cmbSelectDivisionForDivisionReport.DisplayMember = "Division_Name";
                cmbSelectDivisionForDivisionReport.ValueMember = "Division_Name";
                cmbSelectDivisionForDivisionReport.Text = "Select Division";
            }
        }

        private void radioButtonNonDivisionForDivisionReport_Click(object sender, EventArgs e)
        {
            if (radioButtonNonDivisionForDivisionReport.Checked == true)
            {
                radioButtonAllDivisionForDivisionReport.Checked = false;
                radioButtonSelectedDivisionForDivisionReport.Checked = false;
                cmbSelectDivisionForDivisionReport.Enabled = true;
                cmbSelectDivisionForDivisionReport.DataSource = objDivisionDetailsManager.LoadDistinctDisabledDivision();
                cmbSelectDivisionForDivisionReport.DisplayMember = "Division_Name";
                cmbSelectDivisionForDivisionReport.ValueMember = "Division_Name";
                cmbSelectDivisionForDivisionReport.Text = "Select Division";
            }
        }
    }
}
