﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.IO.Ports;
using System.Windows.Forms;
using Microsoft.SqlServer.Server;
using SMSapplication.BLL;
using SMSapplication.DAL.DAO;
using SMSapplication.DAL.Gateway;

namespace SMSapplication.UI
{
    public delegate void PassValueHandler(string productCode, string productID, string productName, decimal productSalesPrice);
    public delegate void PassValueHandler1(string productCode, string productID, string productName, decimal productCostPrice, decimal productSalesPrice);
    public partial class ProductListUI : Form
    {
        public event PassValueHandler PassValue;
        public event PassValueHandler1 PassValue1;
        ProductDetailsManager objProductDetailsManager = new ProductDetailsManager();
        ProductDetails objProductDetails = new ProductDetails();
        //SMSapplication objSmsApplication = new SMSapplication();
        
        public ProductListUI()
        {
            InitializeComponent();
        }

        private void ProductListUI_Load(object sender, EventArgs e)
        {
            try
            {
                dataGridViewProductList.DataSource = objProductDetailsManager.ShowAllProduct();
                dataGridViewProductList.Columns[4].Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dataGridViewProductList_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (GlobalClass.TabNameForProductListUi == "Sales Target")
                {
                    GlobalClass.ProductCodeForSalesTarget = dataGridViewProductList.CurrentRow.Cells[1].Value.ToString();
                    GlobalClass.ProductIdForSalesTarget = dataGridViewProductList.CurrentRow.Cells[0].Value.ToString();
                    GlobalClass.ProductNameForSalesTarget = dataGridViewProductList.CurrentRow.Cells[2].Value.ToString();
                    GlobalClass.ProductSalesPriceForSalesTarget = Convert.ToDecimal(dataGridViewProductList.CurrentRow.Cells[5].Value.ToString());
                    //objSmsApplication.getProductCodeFromProductListUIForSalesTarget = GlobalClass.ProductCodeForSalesTarget.ToString();
                    if (PassValue != null)
                    {
                        PassValue(GlobalClass.ProductCodeForSalesTarget.ToString(), GlobalClass.ProductIdForSalesTarget.ToString(), GlobalClass.ProductNameForSalesTarget.ToString(), Convert.ToDecimal(GlobalClass.ProductSalesPriceForSalesTarget.ToString()));
                    }
                    this.Close();
                }

                if (GlobalClass.TabNameForProductListUi == "Special Item Sale")
                {
                    GlobalClass.ProductCodeForSpecialSalesTarget = dataGridViewProductList.CurrentRow.Cells[1].Value.ToString();
                    GlobalClass.ProductIdForSpecialSalesTarget = dataGridViewProductList.CurrentRow.Cells[0].Value.ToString();
                    GlobalClass.ProductNameForSpecialSalesTarget = dataGridViewProductList.CurrentRow.Cells[2].Value.ToString();
                    GlobalClass.ProductCostPriceForSpecialSalesTarget = Convert.ToDecimal(dataGridViewProductList.CurrentRow.Cells[4].Value.ToString());
                    GlobalClass.ProductSalesPriceForSpecialSalesTarget = Convert.ToDecimal(dataGridViewProductList.CurrentRow.Cells[5].Value.ToString());
                    //objSmsApplication.getProductCodeFromProductListUIForSalesTarget = GlobalClass.ProductCodeForSalesTarget.ToString();
                    if (PassValue1 != null)
                    {
                        PassValue1(GlobalClass.ProductCodeForSpecialSalesTarget.ToString(), GlobalClass.ProductIdForSpecialSalesTarget.ToString(), GlobalClass.ProductNameForSpecialSalesTarget.ToString(), Convert.ToDecimal(GlobalClass.ProductCostPriceForSpecialSalesTarget.ToString()), Convert.ToDecimal(GlobalClass.ProductSalesPriceForSpecialSalesTarget.ToString()));
                    }
                    this.Close();
                }
                

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSearchProduct_Click(object sender, EventArgs e)
        {
            try
            {
                if (radioBtnProductID.Checked == true)
                {
                    dataGridViewProductList.Refresh();
                    dataGridViewProductList.DataSource = objProductDetailsManager.SearchProductById(Convert.ToInt32(txtSearchCriteriaForProduct.Text.ToString()));
                    if (dataGridViewProductList.RowCount > 0)
                    {
                        dataGridViewProductList.Columns[4].Visible = false;
                    }
                    else
                    {
                        MessageBox.Show("No data found.....");
                    }
                }

                if (radioBtnProductCode.Checked == true)
                {
                    dataGridViewProductList.Refresh();
                    dataGridViewProductList.DataSource = objProductDetailsManager.SearchProductByCode(txtSearchCriteriaForProduct.Text.ToString());
                    if (dataGridViewProductList.RowCount > 0)
                    {
                        dataGridViewProductList.Columns[4].Visible = false;
                    }
                    else
                    {
                        MessageBox.Show("No data found.....");
                    }
                }

                if (radioBtnProductName.Checked == true)
                {
                    dataGridViewProductList.Refresh();
                    dataGridViewProductList.DataSource = objProductDetailsManager.SearchProductByName(txtSearchCriteriaForProduct.Text.ToString());
                    if (dataGridViewProductList.RowCount > 0)
                    {
                        dataGridViewProductList.Columns[4].Visible = false;
                    }
                    else
                    {
                        MessageBox.Show("No data found.....");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void radioBtnProductID_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (radioBtnProductID.Checked == true)
                {
                    radioBtnProductCode.Checked = false;
                    radioBtnProductName.Checked = false;
                }
                txtSearchCriteriaForProduct.Text = "";
                txtSearchCriteriaForProduct.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void radioBtnProductCode_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (radioBtnProductCode.Checked == true)
                {
                    radioBtnProductID.Checked = false;
                    radioBtnProductName.Checked = false;
                }
                txtSearchCriteriaForProduct.Text = "";
                txtSearchCriteriaForProduct.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void radioBtnProductName_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (radioBtnProductName.Checked == true)
                {
                    radioBtnProductID.Checked = false;
                    radioBtnProductCode.Checked = false;
                }
                txtSearchCriteriaForProduct.Text = "";
                txtSearchCriteriaForProduct.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
