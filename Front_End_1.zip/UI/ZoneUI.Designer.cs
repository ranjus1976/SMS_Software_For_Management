﻿namespace SMSapplication.UI
{
    partial class ZoneUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ZoneUI));
            this.dataGridViewZoneDetails = new System.Windows.Forms.DataGridView();
            this.groupBoxZone = new System.Windows.Forms.GroupBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.txtRegionIDForZone = new System.Windows.Forms.TextBox();
            this.lblRegionIDForZone = new System.Windows.Forms.Label();
            this.cmbSelectRegionForZone = new System.Windows.Forms.ComboBox();
            this.lblSelectRegionForZone = new System.Windows.Forms.Label();
            this.btnRefreshZone = new System.Windows.Forms.Button();
            this.btnZoneReport = new System.Windows.Forms.Button();
            this.txtZoneActivityEndDate = new System.Windows.Forms.TextBox();
            this.btnSaveZone = new System.Windows.Forms.Button();
            this.btnAddZone = new System.Windows.Forms.Button();
            this.dTPZoneActivityEndDate = new System.Windows.Forms.DateTimePicker();
            this.lblZoneActivityEndDate = new System.Windows.Forms.Label();
            this.txtZoneActivityStartDate = new System.Windows.Forms.TextBox();
            this.dTPZoneActivityStartDate = new System.Windows.Forms.DateTimePicker();
            this.cmbSelectEmployeeForZone = new System.Windows.Forms.ComboBox();
            this.lblSelectEmployeeForZone = new System.Windows.Forms.Label();
            this.cmbSelectDesignationForZone = new System.Windows.Forms.ComboBox();
            this.lblZoneActivityStartDate = new System.Windows.Forms.Label();
            this.cmbZoneActive = new System.Windows.Forms.ComboBox();
            this.lblZoneActive = new System.Windows.Forms.Label();
            this.txtZoneName = new System.Windows.Forms.TextBox();
            this.lblSelectDesignation = new System.Windows.Forms.Label();
            this.lblZoneName = new System.Windows.Forms.Label();
            this.chkTeam = new System.Windows.Forms.CheckBox();
            this.chkDivision = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewZoneDetails)).BeginInit();
            this.groupBoxZone.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridViewZoneDetails
            // 
            this.dataGridViewZoneDetails.AllowUserToAddRows = false;
            this.dataGridViewZoneDetails.AllowUserToDeleteRows = false;
            this.dataGridViewZoneDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewZoneDetails.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridViewZoneDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewZoneDetails.Location = new System.Drawing.Point(6, 213);
            this.dataGridViewZoneDetails.MultiSelect = false;
            this.dataGridViewZoneDetails.Name = "dataGridViewZoneDetails";
            this.dataGridViewZoneDetails.ReadOnly = true;
            this.dataGridViewZoneDetails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewZoneDetails.Size = new System.Drawing.Size(822, 320);
            this.dataGridViewZoneDetails.TabIndex = 16;
            this.dataGridViewZoneDetails.TabStop = false;
            this.dataGridViewZoneDetails.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewZoneDetails_CellDoubleClick);
            // 
            // groupBoxZone
            // 
            this.groupBoxZone.Controls.Add(this.chkDivision);
            this.groupBoxZone.Controls.Add(this.chkTeam);
            this.groupBoxZone.Controls.Add(this.btnClose);
            this.groupBoxZone.Controls.Add(this.txtRegionIDForZone);
            this.groupBoxZone.Controls.Add(this.lblRegionIDForZone);
            this.groupBoxZone.Controls.Add(this.cmbSelectRegionForZone);
            this.groupBoxZone.Controls.Add(this.lblSelectRegionForZone);
            this.groupBoxZone.Controls.Add(this.btnRefreshZone);
            this.groupBoxZone.Controls.Add(this.btnZoneReport);
            this.groupBoxZone.Controls.Add(this.txtZoneActivityEndDate);
            this.groupBoxZone.Controls.Add(this.btnSaveZone);
            this.groupBoxZone.Controls.Add(this.btnAddZone);
            this.groupBoxZone.Controls.Add(this.dTPZoneActivityEndDate);
            this.groupBoxZone.Controls.Add(this.lblZoneActivityEndDate);
            this.groupBoxZone.Controls.Add(this.txtZoneActivityStartDate);
            this.groupBoxZone.Controls.Add(this.dTPZoneActivityStartDate);
            this.groupBoxZone.Controls.Add(this.cmbSelectEmployeeForZone);
            this.groupBoxZone.Controls.Add(this.lblSelectEmployeeForZone);
            this.groupBoxZone.Controls.Add(this.cmbSelectDesignationForZone);
            this.groupBoxZone.Controls.Add(this.lblZoneActivityStartDate);
            this.groupBoxZone.Controls.Add(this.cmbZoneActive);
            this.groupBoxZone.Controls.Add(this.lblZoneActive);
            this.groupBoxZone.Controls.Add(this.txtZoneName);
            this.groupBoxZone.Controls.Add(this.lblSelectDesignation);
            this.groupBoxZone.Controls.Add(this.lblZoneName);
            this.groupBoxZone.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxZone.Location = new System.Drawing.Point(6, 0);
            this.groupBoxZone.Name = "groupBoxZone";
            this.groupBoxZone.Size = new System.Drawing.Size(822, 208);
            this.groupBoxZone.TabIndex = 15;
            this.groupBoxZone.TabStop = false;
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Location = new System.Drawing.Point(657, 174);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(160, 25);
            this.btnClose.TabIndex = 11;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // txtRegionIDForZone
            // 
            this.txtRegionIDForZone.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtRegionIDForZone.Location = new System.Drawing.Point(573, 117);
            this.txtRegionIDForZone.Name = "txtRegionIDForZone";
            this.txtRegionIDForZone.ReadOnly = true;
            this.txtRegionIDForZone.Size = new System.Drawing.Size(240, 22);
            this.txtRegionIDForZone.TabIndex = 71;
            this.txtRegionIDForZone.TabStop = false;
            // 
            // lblRegionIDForZone
            // 
            this.lblRegionIDForZone.AutoSize = true;
            this.lblRegionIDForZone.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRegionIDForZone.Location = new System.Drawing.Point(433, 120);
            this.lblRegionIDForZone.Name = "lblRegionIDForZone";
            this.lblRegionIDForZone.Size = new System.Drawing.Size(85, 16);
            this.lblRegionIDForZone.TabIndex = 70;
            this.lblRegionIDForZone.Text = "Region ID :";
            // 
            // cmbSelectRegionForZone
            // 
            this.cmbSelectRegionForZone.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSelectRegionForZone.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectRegionForZone.Enabled = false;
            this.cmbSelectRegionForZone.FormattingEnabled = true;
            this.cmbSelectRegionForZone.Location = new System.Drawing.Point(574, 87);
            this.cmbSelectRegionForZone.Name = "cmbSelectRegionForZone";
            this.cmbSelectRegionForZone.Size = new System.Drawing.Size(240, 24);
            this.cmbSelectRegionForZone.TabIndex = 7;
            this.cmbSelectRegionForZone.Text = "Select Region";
            this.cmbSelectRegionForZone.SelectedIndexChanged += new System.EventHandler(this.cmbSelectRegionForZone_SelectedIndexChanged);
            // 
            // lblSelectRegionForZone
            // 
            this.lblSelectRegionForZone.AutoSize = true;
            this.lblSelectRegionForZone.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectRegionForZone.Location = new System.Drawing.Point(433, 90);
            this.lblSelectRegionForZone.Name = "lblSelectRegionForZone";
            this.lblSelectRegionForZone.Size = new System.Drawing.Size(114, 16);
            this.lblSelectRegionForZone.TabIndex = 68;
            this.lblSelectRegionForZone.Text = "Select Region :";
            // 
            // btnRefreshZone
            // 
            this.btnRefreshZone.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefreshZone.Location = new System.Drawing.Point(494, 174);
            this.btnRefreshZone.Name = "btnRefreshZone";
            this.btnRefreshZone.Size = new System.Drawing.Size(160, 25);
            this.btnRefreshZone.TabIndex = 10;
            this.btnRefreshZone.Text = "Refresh";
            this.btnRefreshZone.UseVisualStyleBackColor = true;
            this.btnRefreshZone.Click += new System.EventHandler(this.btnRefreshZone_Click);
            // 
            // btnZoneReport
            // 
            this.btnZoneReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnZoneReport.Location = new System.Drawing.Point(331, 174);
            this.btnZoneReport.Name = "btnZoneReport";
            this.btnZoneReport.Size = new System.Drawing.Size(160, 25);
            this.btnZoneReport.TabIndex = 9;
            this.btnZoneReport.Text = "Zone Report";
            this.btnZoneReport.UseVisualStyleBackColor = true;
            // 
            // txtZoneActivityEndDate
            // 
            this.txtZoneActivityEndDate.Enabled = false;
            this.txtZoneActivityEndDate.Location = new System.Drawing.Point(573, 57);
            this.txtZoneActivityEndDate.Name = "txtZoneActivityEndDate";
            this.txtZoneActivityEndDate.Size = new System.Drawing.Size(225, 22);
            this.txtZoneActivityEndDate.TabIndex = 6;
            // 
            // btnSaveZone
            // 
            this.btnSaveZone.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveZone.Location = new System.Drawing.Point(168, 174);
            this.btnSaveZone.Name = "btnSaveZone";
            this.btnSaveZone.Size = new System.Drawing.Size(160, 25);
            this.btnSaveZone.TabIndex = 8;
            this.btnSaveZone.Text = "Save Zone";
            this.btnSaveZone.UseVisualStyleBackColor = true;
            this.btnSaveZone.Click += new System.EventHandler(this.btnSaveZone_Click);
            // 
            // btnAddZone
            // 
            this.btnAddZone.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddZone.Location = new System.Drawing.Point(5, 174);
            this.btnAddZone.Name = "btnAddZone";
            this.btnAddZone.Size = new System.Drawing.Size(160, 25);
            this.btnAddZone.TabIndex = 0;
            this.btnAddZone.Text = "Add Zone";
            this.btnAddZone.UseVisualStyleBackColor = true;
            this.btnAddZone.Click += new System.EventHandler(this.btnAddZone_Click);
            // 
            // dTPZoneActivityEndDate
            // 
            this.dTPZoneActivityEndDate.Enabled = false;
            this.dTPZoneActivityEndDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dTPZoneActivityEndDate.Location = new System.Drawing.Point(798, 57);
            this.dTPZoneActivityEndDate.Name = "dTPZoneActivityEndDate";
            this.dTPZoneActivityEndDate.Size = new System.Drawing.Size(16, 22);
            this.dTPZoneActivityEndDate.TabIndex = 67;
            this.dTPZoneActivityEndDate.CloseUp += new System.EventHandler(this.dTPZoneActivityEndDate_CloseUp);
            // 
            // lblZoneActivityEndDate
            // 
            this.lblZoneActivityEndDate.AutoSize = true;
            this.lblZoneActivityEndDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblZoneActivityEndDate.Location = new System.Drawing.Point(433, 60);
            this.lblZoneActivityEndDate.Name = "lblZoneActivityEndDate";
            this.lblZoneActivityEndDate.Size = new System.Drawing.Size(134, 16);
            this.lblZoneActivityEndDate.TabIndex = 65;
            this.lblZoneActivityEndDate.Text = "Activity End Date :";
            // 
            // txtZoneActivityStartDate
            // 
            this.txtZoneActivityStartDate.Enabled = false;
            this.txtZoneActivityStartDate.Location = new System.Drawing.Point(151, 117);
            this.txtZoneActivityStartDate.Name = "txtZoneActivityStartDate";
            this.txtZoneActivityStartDate.Size = new System.Drawing.Size(225, 22);
            this.txtZoneActivityStartDate.TabIndex = 4;
            // 
            // dTPZoneActivityStartDate
            // 
            this.dTPZoneActivityStartDate.Enabled = false;
            this.dTPZoneActivityStartDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dTPZoneActivityStartDate.Location = new System.Drawing.Point(376, 117);
            this.dTPZoneActivityStartDate.Name = "dTPZoneActivityStartDate";
            this.dTPZoneActivityStartDate.Size = new System.Drawing.Size(16, 22);
            this.dTPZoneActivityStartDate.TabIndex = 64;
            this.dTPZoneActivityStartDate.CloseUp += new System.EventHandler(this.dTPZoneActivityStartDate_CloseUp);
            // 
            // cmbSelectEmployeeForZone
            // 
            this.cmbSelectEmployeeForZone.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSelectEmployeeForZone.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectEmployeeForZone.Enabled = false;
            this.cmbSelectEmployeeForZone.FormattingEnabled = true;
            this.cmbSelectEmployeeForZone.Location = new System.Drawing.Point(151, 87);
            this.cmbSelectEmployeeForZone.Name = "cmbSelectEmployeeForZone";
            this.cmbSelectEmployeeForZone.Size = new System.Drawing.Size(240, 24);
            this.cmbSelectEmployeeForZone.TabIndex = 3;
            this.cmbSelectEmployeeForZone.Text = "Select Employee";
            // 
            // lblSelectEmployeeForZone
            // 
            this.lblSelectEmployeeForZone.AutoSize = true;
            this.lblSelectEmployeeForZone.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectEmployeeForZone.Location = new System.Drawing.Point(4, 90);
            this.lblSelectEmployeeForZone.Name = "lblSelectEmployeeForZone";
            this.lblSelectEmployeeForZone.Size = new System.Drawing.Size(134, 16);
            this.lblSelectEmployeeForZone.TabIndex = 62;
            this.lblSelectEmployeeForZone.Text = "Select Employee :";
            // 
            // cmbSelectDesignationForZone
            // 
            this.cmbSelectDesignationForZone.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSelectDesignationForZone.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectDesignationForZone.Enabled = false;
            this.cmbSelectDesignationForZone.FormattingEnabled = true;
            this.cmbSelectDesignationForZone.Location = new System.Drawing.Point(151, 57);
            this.cmbSelectDesignationForZone.Name = "cmbSelectDesignationForZone";
            this.cmbSelectDesignationForZone.Size = new System.Drawing.Size(240, 24);
            this.cmbSelectDesignationForZone.TabIndex = 2;
            this.cmbSelectDesignationForZone.Text = "Select Designation";
            this.cmbSelectDesignationForZone.SelectedIndexChanged += new System.EventHandler(this.cmbSelectDesignationForZone_SelectedIndexChanged);
            this.cmbSelectDesignationForZone.SelectedValueChanged += new System.EventHandler(this.cmbSelectDesignationForZone_SelectedValueChanged);
            // 
            // lblZoneActivityStartDate
            // 
            this.lblZoneActivityStartDate.AutoSize = true;
            this.lblZoneActivityStartDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblZoneActivityStartDate.Location = new System.Drawing.Point(4, 120);
            this.lblZoneActivityStartDate.Name = "lblZoneActivityStartDate";
            this.lblZoneActivityStartDate.Size = new System.Drawing.Size(139, 16);
            this.lblZoneActivityStartDate.TabIndex = 59;
            this.lblZoneActivityStartDate.Text = "Activity Start Date :";
            // 
            // cmbZoneActive
            // 
            this.cmbZoneActive.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbZoneActive.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbZoneActive.Enabled = false;
            this.cmbZoneActive.FormattingEnabled = true;
            this.cmbZoneActive.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cmbZoneActive.Location = new System.Drawing.Point(573, 27);
            this.cmbZoneActive.Name = "cmbZoneActive";
            this.cmbZoneActive.Size = new System.Drawing.Size(240, 24);
            this.cmbZoneActive.TabIndex = 5;
            this.cmbZoneActive.Text = "Select Active";
            this.cmbZoneActive.SelectedValueChanged += new System.EventHandler(this.cmbZoneActive_SelectedValueChanged);
            // 
            // lblZoneActive
            // 
            this.lblZoneActive.AutoSize = true;
            this.lblZoneActive.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblZoneActive.Location = new System.Drawing.Point(433, 30);
            this.lblZoneActive.Name = "lblZoneActive";
            this.lblZoneActive.Size = new System.Drawing.Size(59, 16);
            this.lblZoneActive.TabIndex = 11;
            this.lblZoneActive.Text = "Active :";
            // 
            // txtZoneName
            // 
            this.txtZoneName.Enabled = false;
            this.txtZoneName.Location = new System.Drawing.Point(151, 27);
            this.txtZoneName.Name = "txtZoneName";
            this.txtZoneName.Size = new System.Drawing.Size(240, 22);
            this.txtZoneName.TabIndex = 1;
            // 
            // lblSelectDesignation
            // 
            this.lblSelectDesignation.AutoSize = true;
            this.lblSelectDesignation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectDesignation.Location = new System.Drawing.Point(4, 60);
            this.lblSelectDesignation.Name = "lblSelectDesignation";
            this.lblSelectDesignation.Size = new System.Drawing.Size(147, 16);
            this.lblSelectDesignation.TabIndex = 1;
            this.lblSelectDesignation.Text = "Select Designation :";
            // 
            // lblZoneName
            // 
            this.lblZoneName.AutoSize = true;
            this.lblZoneName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblZoneName.Location = new System.Drawing.Point(4, 30);
            this.lblZoneName.Name = "lblZoneName";
            this.lblZoneName.Size = new System.Drawing.Size(96, 16);
            this.lblZoneName.TabIndex = 0;
            this.lblZoneName.Text = "Zone Name :";
            // 
            // chkTeam
            // 
            this.chkTeam.AutoSize = true;
            this.chkTeam.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkTeam.Location = new System.Drawing.Point(574, 148);
            this.chkTeam.Name = "chkTeam";
            this.chkTeam.Size = new System.Drawing.Size(67, 20);
            this.chkTeam.TabIndex = 73;
            this.chkTeam.Text = "Team";
            this.chkTeam.UseVisualStyleBackColor = true;
            this.chkTeam.CheckedChanged += new System.EventHandler(this.chkTeam_CheckedChanged);
            // 
            // chkDivision
            // 
            this.chkDivision.AutoSize = true;
            this.chkDivision.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkDivision.Location = new System.Drawing.Point(647, 148);
            this.chkDivision.Name = "chkDivision";
            this.chkDivision.Size = new System.Drawing.Size(83, 20);
            this.chkDivision.TabIndex = 74;
            this.chkDivision.Text = "Division";
            this.chkDivision.UseVisualStyleBackColor = true;
            this.chkDivision.CheckedChanged += new System.EventHandler(this.chkDivision_CheckedChanged);
            // 
            // ZoneUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(834, 537);
            this.Controls.Add(this.dataGridViewZoneDetails);
            this.Controls.Add(this.groupBoxZone);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ZoneUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add / Edit Zone";
            this.Load += new System.EventHandler(this.ZoneUI_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewZoneDetails)).EndInit();
            this.groupBoxZone.ResumeLayout(false);
            this.groupBoxZone.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewZoneDetails;
        private System.Windows.Forms.GroupBox groupBoxZone;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.TextBox txtRegionIDForZone;
        private System.Windows.Forms.Label lblRegionIDForZone;
        private System.Windows.Forms.ComboBox cmbSelectRegionForZone;
        private System.Windows.Forms.Label lblSelectRegionForZone;
        private System.Windows.Forms.Button btnRefreshZone;
        private System.Windows.Forms.Button btnZoneReport;
        private System.Windows.Forms.TextBox txtZoneActivityEndDate;
        private System.Windows.Forms.Button btnSaveZone;
        private System.Windows.Forms.Button btnAddZone;
        private System.Windows.Forms.DateTimePicker dTPZoneActivityEndDate;
        private System.Windows.Forms.Label lblZoneActivityEndDate;
        private System.Windows.Forms.TextBox txtZoneActivityStartDate;
        private System.Windows.Forms.DateTimePicker dTPZoneActivityStartDate;
        private System.Windows.Forms.ComboBox cmbSelectEmployeeForZone;
        private System.Windows.Forms.Label lblSelectEmployeeForZone;
        private System.Windows.Forms.ComboBox cmbSelectDesignationForZone;
        private System.Windows.Forms.Label lblZoneActivityStartDate;
        private System.Windows.Forms.ComboBox cmbZoneActive;
        private System.Windows.Forms.Label lblZoneActive;
        private System.Windows.Forms.TextBox txtZoneName;
        private System.Windows.Forms.Label lblSelectDesignation;
        private System.Windows.Forms.Label lblZoneName;
        private System.Windows.Forms.CheckBox chkTeam;
        private System.Windows.Forms.CheckBox chkDivision;
    }
}