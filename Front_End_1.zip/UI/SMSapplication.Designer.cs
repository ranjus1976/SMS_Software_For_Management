namespace SMSapplication
{
    partial class SMSapplication
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SMSapplication));
            this.tabSMSapplication = new System.Windows.Forms.TabControl();
            this.tbPortSettings = new System.Windows.Forms.TabPage();
            this.gboPortSettings = new System.Windows.Forms.GroupBox();
            this.txtWriteTimeOut = new System.Windows.Forms.TextBox();
            this.txtReadTimeOut = new System.Windows.Forms.TextBox();
            this.cboParityBits = new System.Windows.Forms.ComboBox();
            this.cboStopBits = new System.Windows.Forms.ComboBox();
            this.cboDataBits = new System.Windows.Forms.ComboBox();
            this.cboBaudRate = new System.Windows.Forms.ComboBox();
            this.cboPortName = new System.Windows.Forms.ComboBox();
            this.lblWriteTimeout = new System.Windows.Forms.Label();
            this.lblReadTimeout = new System.Windows.Forms.Label();
            this.lblParityBits = new System.Windows.Forms.Label();
            this.lblStopBits = new System.Windows.Forms.Label();
            this.lblDataBits = new System.Windows.Forms.Label();
            this.lblBaudRate = new System.Windows.Forms.Label();
            this.lblPortName = new System.Windows.Forms.Label();
            this.tbSendSMS = new System.Windows.Forms.TabPage();
            this.gboSendSMS = new System.Windows.Forms.GroupBox();
            this.lblMaxSMSSize = new System.Windows.Forms.Label();
            this.lblMessage = new System.Windows.Forms.Label();
            this.btnSendSMS = new System.Windows.Forms.Button();
            this.lblMobileNo = new System.Windows.Forms.Label();
            this.txtSIM = new System.Windows.Forms.TextBox();
            this.txtMessage = new System.Windows.Forms.TextBox();
            this.tbReadSMS = new System.Windows.Forms.TabPage();
            this.gboReadSMS = new System.Windows.Forms.GroupBox();
            this.btnSMSMoveToDB = new System.Windows.Forms.Button();
            this.rbReadStoreUnSent = new System.Windows.Forms.RadioButton();
            this.rbReadStoreSent = new System.Windows.Forms.RadioButton();
            this.rbReadUnRead = new System.Windows.Forms.RadioButton();
            this.rbReadAll = new System.Windows.Forms.RadioButton();
            this.btnReadSMS = new System.Windows.Forms.Button();
            this.lvwMessages = new System.Windows.Forms.ListView();
            this.colIndex = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colSentTime = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colSender = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colMessage = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tbDeleteSMS = new System.Windows.Forms.TabPage();
            this.groupBoxSMSCount = new System.Windows.Forms.GroupBox();
            this.btnCountSMS = new System.Windows.Forms.Button();
            this.txtCountSMS = new System.Windows.Forms.TextBox();
            this.lblCountSMS = new System.Windows.Forms.Label();
            this.gboDeleteSMS = new System.Windows.Forms.GroupBox();
            this.rbDeleteReadSMS = new System.Windows.Forms.RadioButton();
            this.btnDeleteSMS = new System.Windows.Forms.Button();
            this.rbDeleteAllSMS = new System.Windows.Forms.RadioButton();
            this.tbUserCreate = new System.Windows.Forms.TabPage();
            this.btnRefreshUser = new System.Windows.Forms.Button();
            this.btnUserReport = new System.Windows.Forms.Button();
            this.btnAddUser = new System.Windows.Forms.Button();
            this.dataGridViewUserDetails = new System.Windows.Forms.DataGridView();
            this.groupBoxUser = new System.Windows.Forms.GroupBox();
            this.cmbActive = new System.Windows.Forms.ComboBox();
            this.lblActive = new System.Windows.Forms.Label();
            this.txtRoleID = new System.Windows.Forms.TextBox();
            this.cmbUserRole = new System.Windows.Forms.ComboBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.lblRoleID = new System.Windows.Forms.Label();
            this.lblUserRole = new System.Windows.Forms.Label();
            this.lblPassword = new System.Windows.Forms.Label();
            this.lblUserName = new System.Windows.Forms.Label();
            this.btnSaveUser = new System.Windows.Forms.Button();
            this.tbDepartment = new System.Windows.Forms.TabPage();
            this.btnRefreshDepartment = new System.Windows.Forms.Button();
            this.btnAddDepartment = new System.Windows.Forms.Button();
            this.dataGridViewDepartmentDetails = new System.Windows.Forms.DataGridView();
            this.groupBoxDepartment = new System.Windows.Forms.GroupBox();
            this.cmbActiveDepartment = new System.Windows.Forms.ComboBox();
            this.lblActiveDepartment = new System.Windows.Forms.Label();
            this.txtDepartment = new System.Windows.Forms.TextBox();
            this.lblDepartmentName = new System.Windows.Forms.Label();
            this.btnSaveDepartment = new System.Windows.Forms.Button();
            this.tbDesignation = new System.Windows.Forms.TabPage();
            this.btnRefreshDesignation = new System.Windows.Forms.Button();
            this.btnAddDesignation = new System.Windows.Forms.Button();
            this.dataGridViewDesignationList = new System.Windows.Forms.DataGridView();
            this.groupBoxDesignation = new System.Windows.Forms.GroupBox();
            this.cmbActiveDesignation = new System.Windows.Forms.ComboBox();
            this.lblDesignationActive = new System.Windows.Forms.Label();
            this.txtDesignationDetails = new System.Windows.Forms.TextBox();
            this.txtDesignation = new System.Windows.Forms.TextBox();
            this.lblDesignationDetails = new System.Windows.Forms.Label();
            this.lblDesignation = new System.Windows.Forms.Label();
            this.btnSaveDesignation = new System.Windows.Forms.Button();
            this.tbGroup = new System.Windows.Forms.TabPage();
            this.btnRefreshTeam = new System.Windows.Forms.Button();
            this.btnAddGroup = new System.Windows.Forms.Button();
            this.dataGridViewGroupDetails = new System.Windows.Forms.DataGridView();
            this.groupBoxGroup = new System.Windows.Forms.GroupBox();
            this.txtNumberOfDMD = new System.Windows.Forms.TextBox();
            this.txtNumberOfMD = new System.Windows.Forms.TextBox();
            this.lblNumberOfDMD = new System.Windows.Forms.Label();
            this.lblNumberOfMD = new System.Windows.Forms.Label();
            this.txtNumberOfSR = new System.Windows.Forms.TextBox();
            this.txtNumberOfTSM = new System.Windows.Forms.TextBox();
            this.txtNumberOfASM = new System.Windows.Forms.TextBox();
            this.txtNumberOfSM = new System.Windows.Forms.TextBox();
            this.txtNumberOfDM = new System.Windows.Forms.TextBox();
            this.txtNumberOfDGM = new System.Windows.Forms.TextBox();
            this.txtNumberOfGM = new System.Windows.Forms.TextBox();
            this.txtNumberOfDO = new System.Windows.Forms.TextBox();
            this.lblNumberOfDO = new System.Windows.Forms.Label();
            this.lblNumberOfSR = new System.Windows.Forms.Label();
            this.lblNumberOfTSM = new System.Windows.Forms.Label();
            this.lblNumberOfASM = new System.Windows.Forms.Label();
            this.lblNumberOfSM = new System.Windows.Forms.Label();
            this.lblNumberOfDM = new System.Windows.Forms.Label();
            this.lblNumberOfDGM = new System.Windows.Forms.Label();
            this.lblNumberOfGM = new System.Windows.Forms.Label();
            this.cmbGroupActive = new System.Windows.Forms.ComboBox();
            this.lblGroupActive = new System.Windows.Forms.Label();
            this.txtLocation = new System.Windows.Forms.TextBox();
            this.txtGroupName = new System.Windows.Forms.TextBox();
            this.lblLocation = new System.Windows.Forms.Label();
            this.lblGroupName = new System.Windows.Forms.Label();
            this.btnSaveGroup = new System.Windows.Forms.Button();
            this.tbEmployee = new System.Windows.Forms.TabPage();
            this.btnRefreshEmployee = new System.Windows.Forms.Button();
            this.groupBoxSearchEmployee = new System.Windows.Forms.GroupBox();
            this.radioBtnShowAllEmp = new System.Windows.Forms.RadioButton();
            this.btnSearchEmployee = new System.Windows.Forms.Button();
            this.cmbSearchCriteriaForEmployeeByDesignation = new System.Windows.Forms.ComboBox();
            this.txtSearchCriteriaForEmployee = new System.Windows.Forms.TextBox();
            this.radioBtnByGroupAndDesignation = new System.Windows.Forms.RadioButton();
            this.radioBtnByGroup = new System.Windows.Forms.RadioButton();
            this.radioBtnOfficialMobileNumber = new System.Windows.Forms.RadioButton();
            this.radioBtnEmployeeName = new System.Windows.Forms.RadioButton();
            this.btnAddEmployee = new System.Windows.Forms.Button();
            this.dataGridViewEmployeeList = new System.Windows.Forms.DataGridView();
            this.groupBoxEmployee = new System.Windows.Forms.GroupBox();
            this.txtDOB = new System.Windows.Forms.TextBox();
            this.txtQuitDate = new System.Windows.Forms.TextBox();
            this.dTPQuitDate = new System.Windows.Forms.DateTimePicker();
            this.lblQuitDate = new System.Windows.Forms.Label();
            this.cmbEmployeeActive = new System.Windows.Forms.ComboBox();
            this.lblEmployeeActive = new System.Windows.Forms.Label();
            this.cmbEmployeeGroup = new System.Windows.Forms.ComboBox();
            this.lblEmployeeGroupID = new System.Windows.Forms.Label();
            this.txtEmployeeGroupID = new System.Windows.Forms.TextBox();
            this.lblEmployeeGroupName = new System.Windows.Forms.Label();
            this.txtOfficialCellNo = new System.Windows.Forms.TextBox();
            this.lblOfficialCellNo = new System.Windows.Forms.Label();
            this.cmbEmployeeDepartment = new System.Windows.Forms.ComboBox();
            this.lblEmployeeDepartmentID = new System.Windows.Forms.Label();
            this.txtEmployeeDepartmentID = new System.Windows.Forms.TextBox();
            this.lblEmployeeDepartment = new System.Windows.Forms.Label();
            this.dTPDateOfBirth = new System.Windows.Forms.DateTimePicker();
            this.cmbEmployeeDesignation = new System.Windows.Forms.ComboBox();
            this.lblEmployeeDesignationID = new System.Windows.Forms.Label();
            this.txtEmployeeDesignationID = new System.Windows.Forms.TextBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.txtEmployeeName = new System.Windows.Forms.TextBox();
            this.lblEmployeeDesignation = new System.Windows.Forms.Label();
            this.lblDateOfBirth = new System.Windows.Forms.Label();
            this.lblAddress = new System.Windows.Forms.Label();
            this.lblEmployeeName = new System.Windows.Forms.Label();
            this.btnSaveEmployee = new System.Windows.Forms.Button();
            this.tbDivision = new System.Windows.Forms.TabPage();
            this.btnRefreshDivision = new System.Windows.Forms.Button();
            this.btnEnableDisableDivision = new System.Windows.Forms.Button();
            this.btnDivisionReport = new System.Windows.Forms.Button();
            this.dgvPreviousAddedEmpList = new System.Windows.Forms.DataGridView();
            this.cmbSelectDivisionForUpdate = new System.Windows.Forms.ComboBox();
            this.dgvLoadDistinctDivision = new System.Windows.Forms.DataGridView();
            this.btnAddOrEditDataOfPrevDivision = new System.Windows.Forms.Button();
            this.btnAddToTempDivision = new System.Windows.Forms.Button();
            this.dgvLoadTempDivision = new System.Windows.Forms.DataGridView();
            this.dgvLoadGroup = new System.Windows.Forms.DataGridView();
            this.dgvDivision = new System.Windows.Forms.DataGridView();
            this.btnAddDivision = new System.Windows.Forms.Button();
            this.btnSaveDivision = new System.Windows.Forms.Button();
            this.groupBoxDivision = new System.Windows.Forms.GroupBox();
            this.cmbSelectRSMForDivision = new System.Windows.Forms.ComboBox();
            this.lblSelectRSM = new System.Windows.Forms.Label();
            this.cmbActiveForDivision = new System.Windows.Forms.ComboBox();
            this.lblActiveForDivision = new System.Windows.Forms.Label();
            this.btnLoadGroup = new System.Windows.Forms.Button();
            this.cmbSelectSRForDivision = new System.Windows.Forms.ComboBox();
            this.lblSelectSR = new System.Windows.Forms.Label();
            this.cmbSelectTSMForDivision = new System.Windows.Forms.ComboBox();
            this.lblSelectTSM = new System.Windows.Forms.Label();
            this.cmbSelectSMForDivision = new System.Windows.Forms.ComboBox();
            this.lblSelectSM = new System.Windows.Forms.Label();
            this.cmbSelectASMForDivision = new System.Windows.Forms.ComboBox();
            this.lblSelectASM = new System.Windows.Forms.Label();
            this.cmbSelectDMForDivision = new System.Windows.Forms.ComboBox();
            this.lblSelectDM = new System.Windows.Forms.Label();
            this.cmbSelectDGMForDivision = new System.Windows.Forms.ComboBox();
            this.lblSelectDGM = new System.Windows.Forms.Label();
            this.cmbSelectGMForDivision = new System.Windows.Forms.ComboBox();
            this.lblSelectGM = new System.Windows.Forms.Label();
            this.cmbSelectDOForDivision = new System.Windows.Forms.ComboBox();
            this.lblSelectDO = new System.Windows.Forms.Label();
            this.txtDivisionName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lblTeamID = new System.Windows.Forms.Label();
            this.txtTeamIDForDivision = new System.Windows.Forms.TextBox();
            this.cmbSelectTeam = new System.Windows.Forms.ComboBox();
            this.lblSelectTeam = new System.Windows.Forms.Label();
            this.tbMarket = new System.Windows.Forms.TabPage();
            this.btnRefreshMarket = new System.Windows.Forms.Button();
            this.dataGridViewMarket = new System.Windows.Forms.DataGridView();
            this.btnAddMarket = new System.Windows.Forms.Button();
            this.btnSaveMarket = new System.Windows.Forms.Button();
            this.groupBoxMarket = new System.Windows.Forms.GroupBox();
            this.lblTeamIDForMarket = new System.Windows.Forms.Label();
            this.txtTeamIDForMarket = new System.Windows.Forms.TextBox();
            this.lblTeamNameForMarket = new System.Windows.Forms.Label();
            this.txtTeamNameForMarket = new System.Windows.Forms.TextBox();
            this.cmbSelectDivisionForMarket = new System.Windows.Forms.ComboBox();
            this.lblSelectDivisionForMarket = new System.Windows.Forms.Label();
            this.cmbMarketActive = new System.Windows.Forms.ComboBox();
            this.lblMarketActive = new System.Windows.Forms.Label();
            this.txtMonthlyNoOfVisit = new System.Windows.Forms.TextBox();
            this.txtTarget = new System.Windows.Forms.TextBox();
            this.txtTotalNoOfParty = new System.Windows.Forms.TextBox();
            this.lblNoOfVisit = new System.Windows.Forms.Label();
            this.lblTarget = new System.Windows.Forms.Label();
            this.lblTotalNoOfParty = new System.Windows.Forms.Label();
            this.txtMarketName = new System.Windows.Forms.TextBox();
            this.lblMarketName = new System.Windows.Forms.Label();
            this.txtMarketCode = new System.Windows.Forms.TextBox();
            this.lblMarketCode = new System.Windows.Forms.Label();
            this.tbMarketSetup = new System.Windows.Forms.TabPage();
            this.btnRefreshMarketSetup = new System.Windows.Forms.Button();
            this.dgvLoadMarketBySelectedDivision = new System.Windows.Forms.DataGridView();
            this.dataGridViewMarketSetup = new System.Windows.Forms.DataGridView();
            this.btnAddMarketSetup = new System.Windows.Forms.Button();
            this.btnSaveMarketSetup = new System.Windows.Forms.Button();
            this.groupBoxMarketSetup = new System.Windows.Forms.GroupBox();
            this.cmbSelectMarketForMarketSetup = new System.Windows.Forms.ComboBox();
            this.lblSelectMarket = new System.Windows.Forms.Label();
            this.txtEmpDesigForMarketSetup = new System.Windows.Forms.TextBox();
            this.txtEmpIDForMarketSetup = new System.Windows.Forms.TextBox();
            this.lblEmpIDForMarketSetup = new System.Windows.Forms.Label();
            this.cmbSelectDevisionForMarketSetup = new System.Windows.Forms.ComboBox();
            this.lblSelectDevisionForMarketSetup = new System.Windows.Forms.Label();
            this.cmbSelectEmployeeForMarketSetup = new System.Windows.Forms.ComboBox();
            this.lblSelectEmployeeForMarketSetup = new System.Windows.Forms.Label();
            this.cmbSelectGroupForMarketSetup = new System.Windows.Forms.ComboBox();
            this.lblGroupIDForMarketSetup = new System.Windows.Forms.Label();
            this.txtGroupIDForMarketSetup = new System.Windows.Forms.TextBox();
            this.lblSelectGroupForMarketSetup = new System.Windows.Forms.Label();
            this.txtEmpCellNoForMarketSetup = new System.Windows.Forms.TextBox();
            this.lblEmpDesigForMarketSetup = new System.Windows.Forms.Label();
            this.lblEmpCellNoForMarketSetup = new System.Windows.Forms.Label();
            this.tbProduct = new System.Windows.Forms.TabPage();
            this.btnRefreshProduct = new System.Windows.Forms.Button();
            this.btnProductReport = new System.Windows.Forms.Button();
            this.dataGridViewProduct = new System.Windows.Forms.DataGridView();
            this.btnAddProduct = new System.Windows.Forms.Button();
            this.btnSaveProduct = new System.Windows.Forms.Button();
            this.groupBoxProduct = new System.Windows.Forms.GroupBox();
            this.cmbProductActive = new System.Windows.Forms.ComboBox();
            this.lblProductActive = new System.Windows.Forms.Label();
            this.cmbPackSize = new System.Windows.Forms.ComboBox();
            this.txtUnitCostPrice = new System.Windows.Forms.TextBox();
            this.lblUnitSalePrice = new System.Windows.Forms.Label();
            this.txtUnitSalePrice = new System.Windows.Forms.TextBox();
            this.lblUnitCostPrice = new System.Windows.Forms.Label();
            this.lblPackSize = new System.Windows.Forms.Label();
            this.txtProductName = new System.Windows.Forms.TextBox();
            this.lblProductName = new System.Windows.Forms.Label();
            this.txtProductCode = new System.Windows.Forms.TextBox();
            this.lblProductCode = new System.Windows.Forms.Label();
            this.tbProductPriceUpdateLog = new System.Windows.Forms.TabPage();
            this.groupBoxProductPriceLogSearch = new System.Windows.Forms.GroupBox();
            this.btnRefreshProductPriceLog = new System.Windows.Forms.Button();
            this.radioBtnPriceUpdateLogShowAll = new System.Windows.Forms.RadioButton();
            this.btnPriceUpdateLogSearch = new System.Windows.Forms.Button();
            this.txtPriceUpdateLogSearchCriteria = new System.Windows.Forms.TextBox();
            this.radioBtnPriceUpdateLogSearchByPName = new System.Windows.Forms.RadioButton();
            this.radioBtnPriceUpdateLogSearchByPCode = new System.Windows.Forms.RadioButton();
            this.dgvProductPriceUpdateLog = new System.Windows.Forms.DataGridView();
            this.tbSalesTarget = new System.Windows.Forms.TabPage();
            this.btnRefreshSalesTarget = new System.Windows.Forms.Button();
            this.txtEmpDivNameForSalesTarget = new System.Windows.Forms.TextBox();
            this.dgvPrevAddedSalesTargetDetails = new System.Windows.Forms.DataGridView();
            this.dgvProductListForSalesTarget = new System.Windows.Forms.DataGridView();
            this.btnSaveList = new System.Windows.Forms.Button();
            this.btnAddToList = new System.Windows.Forms.Button();
            this.groupBoxTargetSearch = new System.Windows.Forms.GroupBox();
            this.radioButtonByProductCodeForSalesTarget = new System.Windows.Forms.RadioButton();
            this.txtSearchDateTo = new System.Windows.Forms.TextBox();
            this.dtpSearchDateTo = new System.Windows.Forms.DateTimePicker();
            this.lblSearchDateTo = new System.Windows.Forms.Label();
            this.txtSearchDateFrom = new System.Windows.Forms.TextBox();
            this.dtpSearchDateFrom = new System.Windows.Forms.DateTimePicker();
            this.lblSearchDateFrom = new System.Windows.Forms.Label();
            this.radioButtonByDesignationForSalesTarget = new System.Windows.Forms.RadioButton();
            this.radioButtonShowAllForSalesTarget = new System.Windows.Forms.RadioButton();
            this.btnSearchForSalesTarget = new System.Windows.Forms.Button();
            this.cmbSearchCriteriaByDesigForSalesTarget = new System.Windows.Forms.ComboBox();
            this.txtSearchCriteriaForSalesTarget = new System.Windows.Forms.TextBox();
            this.radioButtonByGroupAndDesigForSalesTarget = new System.Windows.Forms.RadioButton();
            this.radioButtonByGroupForSalesTarget = new System.Windows.Forms.RadioButton();
            this.radioButtonByMobileForSalesTarget = new System.Windows.Forms.RadioButton();
            this.radioButtonByNameForSalesTarget = new System.Windows.Forms.RadioButton();
            this.btnAddTarget = new System.Windows.Forms.Button();
            this.groupBoxSalesTarget = new System.Windows.Forms.GroupBox();
            this.txtProductPriceForSalesTarget = new System.Windows.Forms.TextBox();
            this.txtProductNameForSalesTarget = new System.Windows.Forms.TextBox();
            this.txtProductIDForSalesTarget = new System.Windows.Forms.TextBox();
            this.btnBrowseProductCodeForSalesTarget = new System.Windows.Forms.Button();
            this.lblProductCodeForSalesTarget = new System.Windows.Forms.Label();
            this.lblProductPriceForSalesTarget = new System.Windows.Forms.Label();
            this.txtProductCodeForSalesTarget = new System.Windows.Forms.TextBox();
            this.lblProductNameForSalesTarget = new System.Windows.Forms.Label();
            this.lblProductIDForSalesTarget = new System.Windows.Forms.Label();
            this.txtEmpMobileNoForSalesTarget = new System.Windows.Forms.TextBox();
            this.lblEmpMobileNoForSalesTarget = new System.Windows.Forms.Label();
            this.cmbSelectEmployeeForSalesTarget = new System.Windows.Forms.ComboBox();
            this.cmbSelectDesignationForSalesTarget = new System.Windows.Forms.ComboBox();
            this.cmbSelectGroupForSalesTarget = new System.Windows.Forms.ComboBox();
            this.lblSelectGroupForSalesTarget = new System.Windows.Forms.Label();
            this.txtTargetUnitForSalesTarget = new System.Windows.Forms.TextBox();
            this.txtFromDate = new System.Windows.Forms.TextBox();
            this.txtToDate = new System.Windows.Forms.TextBox();
            this.dTPToDate = new System.Windows.Forms.DateTimePicker();
            this.lblEmployeeDesignationForSalesTarget = new System.Windows.Forms.Label();
            this.txtEmployeeIDForSalesTarget = new System.Windows.Forms.TextBox();
            this.lblEmployeeIDForSalesTarget = new System.Windows.Forms.Label();
            this.lblSelectEmployeeForSalesTarget = new System.Windows.Forms.Label();
            this.lblTargetAmountForSalesTarget = new System.Windows.Forms.Label();
            this.txtTargetAmountForSalesTarget = new System.Windows.Forms.TextBox();
            this.lblTargetUnitForSalesTarget = new System.Windows.Forms.Label();
            this.dTPFromDate = new System.Windows.Forms.DateTimePicker();
            this.lblToDate = new System.Windows.Forms.Label();
            this.lblFromDate = new System.Windows.Forms.Label();
            this.btnSaveTarget = new System.Windows.Forms.Button();
            this.dgvSalesTargetDetails = new System.Windows.Forms.DataGridView();
            this.dataGridViewSalesTarget = new System.Windows.Forms.DataGridView();
            this.tbSpecialItemSaleTarget = new System.Windows.Forms.TabPage();
            this.groupBoxSpecialItemSearch = new System.Windows.Forms.GroupBox();
            this.radioButtonSpecialItemSearchByProductCode = new System.Windows.Forms.RadioButton();
            this.txtSpecialItemSearchToDate = new System.Windows.Forms.TextBox();
            this.dtPSpecialItemSearchToDate = new System.Windows.Forms.DateTimePicker();
            this.lblSpecialItemSearchToDate = new System.Windows.Forms.Label();
            this.txtSpecialItemSearchFromDate = new System.Windows.Forms.TextBox();
            this.dtPSpecialItemSearchFromDate = new System.Windows.Forms.DateTimePicker();
            this.lblSpecialItemSearchFromDate = new System.Windows.Forms.Label();
            this.radioButtonSpecialItemSearchByDesignation = new System.Windows.Forms.RadioButton();
            this.radioButtonSpecialItemShowAll = new System.Windows.Forms.RadioButton();
            this.btnSpecialItemSearch = new System.Windows.Forms.Button();
            this.cmbSpecialItemSearchByEmpDesignation = new System.Windows.Forms.ComboBox();
            this.txtSpecialItemSearchCriteria = new System.Windows.Forms.TextBox();
            this.radioButtonSpecialItemSearchByGroupNameAndDesignation = new System.Windows.Forms.RadioButton();
            this.radioButtonSpecialItemSearchByGroupName = new System.Windows.Forms.RadioButton();
            this.radioButtonSpecialItemSearchByEmpMobileNo = new System.Windows.Forms.RadioButton();
            this.radioButtonSpecialItemSearchByEmpName = new System.Windows.Forms.RadioButton();
            this.btnSpecialItemSaleAddTarget = new System.Windows.Forms.Button();
            this.btnSpecialItemSaleSaveTarget = new System.Windows.Forms.Button();
            this.dgvSpecialItemSalesTarget = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtSpecialItemSaleProductSpecialPrice = new System.Windows.Forms.TextBox();
            this.lblSpecialItemSaleProductSpecialPrice = new System.Windows.Forms.Label();
            this.txtSpecialItemSaleProductSalePrice = new System.Windows.Forms.TextBox();
            this.lblSpecialItemSaleProductSalePrice = new System.Windows.Forms.Label();
            this.txtSpecialItemSaleEmployeeMobileNo = new System.Windows.Forms.TextBox();
            this.lblSpecialItemSaleEmployeeMobileNo = new System.Windows.Forms.Label();
            this.cmbSpecialItemSaleSelectEmployee = new System.Windows.Forms.ComboBox();
            this.cmbSpecialItemSaleSelectDesignation = new System.Windows.Forms.ComboBox();
            this.cmbSpecialItemSaleSelectGroup = new System.Windows.Forms.ComboBox();
            this.lblSpecialItemSaleSelectGroup = new System.Windows.Forms.Label();
            this.txtSpecialItemSaleTargetUnit = new System.Windows.Forms.TextBox();
            this.txtSpecialItemSaleProductCostPrice = new System.Windows.Forms.TextBox();
            this.txtSpecialItemSaleProductName = new System.Windows.Forms.TextBox();
            this.txtSpecialItemSaleProductID = new System.Windows.Forms.TextBox();
            this.btnSpecialItemSaleProductCodeBrowse = new System.Windows.Forms.Button();
            this.lblSpecialItemSaleProductCode = new System.Windows.Forms.Label();
            this.txtSpecialItemSaleFromDate = new System.Windows.Forms.TextBox();
            this.txtSpecialItemSaleToDate = new System.Windows.Forms.TextBox();
            this.dtPSpecialItemSaleToDate = new System.Windows.Forms.DateTimePicker();
            this.lblSpecialItemSaleSelectDesignation = new System.Windows.Forms.Label();
            this.txtSpecialItemSaleEmployeeID = new System.Windows.Forms.TextBox();
            this.lblSpecialItemSaleEmployeeID = new System.Windows.Forms.Label();
            this.lblSpecialItemSaleSelectEmployee = new System.Windows.Forms.Label();
            this.lblSpecialItemSaleTargetAmount = new System.Windows.Forms.Label();
            this.txtSpecialItemSaleTargetAmount = new System.Windows.Forms.TextBox();
            this.lblSpecialItemSaleTargetUnit = new System.Windows.Forms.Label();
            this.dtPSpecialItemSaleFromDate = new System.Windows.Forms.DateTimePicker();
            this.lblSpecialItemSaleProductCostPrice = new System.Windows.Forms.Label();
            this.txtSpecialItemSaleProductCode = new System.Windows.Forms.TextBox();
            this.lblSpecialItemSaleProductName = new System.Windows.Forms.Label();
            this.lblSpecialItemSaleProductID = new System.Windows.Forms.Label();
            this.lblSpecialItemSaleToDate = new System.Windows.Forms.Label();
            this.lblSpecialItemSaleFromDate = new System.Windows.Forms.Label();
            this.tbSalesDetails = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnRefreshSalesDetails = new System.Windows.Forms.Button();
            this.radioBtnSalesDetailsSearchByProductCode = new System.Windows.Forms.RadioButton();
            this.txtSalesDetailsToDate = new System.Windows.Forms.TextBox();
            this.dtPSalesDetailsToDate = new System.Windows.Forms.DateTimePicker();
            this.lblSalesDetailsToDate = new System.Windows.Forms.Label();
            this.txtSalesDetailsFormDate = new System.Windows.Forms.TextBox();
            this.dtPSalesDetailsFormDate = new System.Windows.Forms.DateTimePicker();
            this.lblSalesDetailsFormDate = new System.Windows.Forms.Label();
            this.radioBtnSalesDetailsSearchByDesignation = new System.Windows.Forms.RadioButton();
            this.radioBtnSalesDetailsShowAll = new System.Windows.Forms.RadioButton();
            this.btnSalesDetailsSearch = new System.Windows.Forms.Button();
            this.cmbSalesDetailsDesignation = new System.Windows.Forms.ComboBox();
            this.txtSalesDetailsSearchCriteria = new System.Windows.Forms.TextBox();
            this.radioBtnSalesDetailsSearchByGroupAndDesignation = new System.Windows.Forms.RadioButton();
            this.radioBtnSalesDetailsSearchByGroup = new System.Windows.Forms.RadioButton();
            this.radioBtnSalesDetailsSearchByMobile = new System.Windows.Forms.RadioButton();
            this.radioBtnSalesDetailsSearchByEmp = new System.Windows.Forms.RadioButton();
            this.dgvSalesDetails = new System.Windows.Forms.DataGridView();
            this.tbReports = new System.Windows.Forms.TabPage();
            this.groupBoxSelectOptionForReports = new System.Windows.Forms.GroupBox();
            this.radioButtonDivisionReport = new System.Windows.Forms.RadioButton();
            this.radioButtonProductReport = new System.Windows.Forms.RadioButton();
            this.btnLoadTSM = new System.Windows.Forms.Button();
            this.btnLoadSR = new System.Windows.Forms.Button();
            this.btnLoadSM = new System.Windows.Forms.Button();
            this.btnLoadASM = new System.Windows.Forms.Button();
            this.radioButtonUserReport = new System.Windows.Forms.RadioButton();
            this.btnReportShow = new System.Windows.Forms.Button();
            this.radioBtnSalesTargetReport = new System.Windows.Forms.RadioButton();
            this.btnOK = new System.Windows.Forms.Button();
            this.gboConnectionStatus = new System.Windows.Forms.GroupBox();
            this.btnDBBackup = new System.Windows.Forms.Button();
            this.btnExitApplication = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.lblConnectionStatus = new System.Windows.Forms.Label();
            this.btnDisconnect = new System.Windows.Forms.Button();
            this.statusBar1 = new System.Windows.Forms.StatusBar();
            this.reset_Focus_Timer = new System.Windows.Forms.Timer(this.components);
            this.txtStartTime = new System.Windows.Forms.TextBox();
            this.lblStartTime = new System.Windows.Forms.Label();
            this.lblEndTime = new System.Windows.Forms.Label();
            this.txtEndTime = new System.Windows.Forms.TextBox();
            this.checkBoxSMSRead = new System.Windows.Forms.CheckBox();
            this.checkBoxSMSSend = new System.Windows.Forms.CheckBox();
            this.Auto_Read_Timer = new System.Windows.Forms.Timer(this.components);
            this.tabSMSapplication.SuspendLayout();
            this.tbPortSettings.SuspendLayout();
            this.gboPortSettings.SuspendLayout();
            this.tbSendSMS.SuspendLayout();
            this.gboSendSMS.SuspendLayout();
            this.tbReadSMS.SuspendLayout();
            this.gboReadSMS.SuspendLayout();
            this.tbDeleteSMS.SuspendLayout();
            this.groupBoxSMSCount.SuspendLayout();
            this.gboDeleteSMS.SuspendLayout();
            this.tbUserCreate.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewUserDetails)).BeginInit();
            this.groupBoxUser.SuspendLayout();
            this.tbDepartment.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDepartmentDetails)).BeginInit();
            this.groupBoxDepartment.SuspendLayout();
            this.tbDesignation.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDesignationList)).BeginInit();
            this.groupBoxDesignation.SuspendLayout();
            this.tbGroup.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewGroupDetails)).BeginInit();
            this.groupBoxGroup.SuspendLayout();
            this.tbEmployee.SuspendLayout();
            this.groupBoxSearchEmployee.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEmployeeList)).BeginInit();
            this.groupBoxEmployee.SuspendLayout();
            this.tbDivision.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPreviousAddedEmpList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLoadDistinctDivision)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLoadTempDivision)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLoadGroup)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDivision)).BeginInit();
            this.groupBoxDivision.SuspendLayout();
            this.tbMarket.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMarket)).BeginInit();
            this.groupBoxMarket.SuspendLayout();
            this.tbMarketSetup.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLoadMarketBySelectedDivision)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMarketSetup)).BeginInit();
            this.groupBoxMarketSetup.SuspendLayout();
            this.tbProduct.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProduct)).BeginInit();
            this.groupBoxProduct.SuspendLayout();
            this.tbProductPriceUpdateLog.SuspendLayout();
            this.groupBoxProductPriceLogSearch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProductPriceUpdateLog)).BeginInit();
            this.tbSalesTarget.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPrevAddedSalesTargetDetails)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProductListForSalesTarget)).BeginInit();
            this.groupBoxTargetSearch.SuspendLayout();
            this.groupBoxSalesTarget.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSalesTargetDetails)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSalesTarget)).BeginInit();
            this.tbSpecialItemSaleTarget.SuspendLayout();
            this.groupBoxSpecialItemSearch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSpecialItemSalesTarget)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.tbSalesDetails.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSalesDetails)).BeginInit();
            this.tbReports.SuspendLayout();
            this.groupBoxSelectOptionForReports.SuspendLayout();
            this.gboConnectionStatus.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabSMSapplication
            // 
            this.tabSMSapplication.Controls.Add(this.tbPortSettings);
            this.tabSMSapplication.Controls.Add(this.tbSendSMS);
            this.tabSMSapplication.Controls.Add(this.tbReadSMS);
            this.tabSMSapplication.Controls.Add(this.tbDeleteSMS);
            this.tabSMSapplication.Controls.Add(this.tbUserCreate);
            this.tabSMSapplication.Controls.Add(this.tbDepartment);
            this.tabSMSapplication.Controls.Add(this.tbDesignation);
            this.tabSMSapplication.Controls.Add(this.tbGroup);
            this.tabSMSapplication.Controls.Add(this.tbEmployee);
            this.tabSMSapplication.Controls.Add(this.tbDivision);
            this.tabSMSapplication.Controls.Add(this.tbMarket);
            this.tabSMSapplication.Controls.Add(this.tbMarketSetup);
            this.tabSMSapplication.Controls.Add(this.tbProduct);
            this.tabSMSapplication.Controls.Add(this.tbProductPriceUpdateLog);
            this.tabSMSapplication.Controls.Add(this.tbSalesTarget);
            this.tabSMSapplication.Controls.Add(this.tbSpecialItemSaleTarget);
            this.tabSMSapplication.Controls.Add(this.tbSalesDetails);
            this.tabSMSapplication.Controls.Add(this.tbReports);
            this.tabSMSapplication.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabSMSapplication.Location = new System.Drawing.Point(2, 3);
            this.tabSMSapplication.Name = "tabSMSapplication";
            this.tabSMSapplication.SelectedIndex = 0;
            this.tabSMSapplication.ShowToolTips = true;
            this.tabSMSapplication.Size = new System.Drawing.Size(1345, 640);
            this.tabSMSapplication.TabIndex = 0;
            this.tabSMSapplication.Click += new System.EventHandler(this.tabSMSapplication_Click);
            // 
            // tbPortSettings
            // 
            this.tbPortSettings.Controls.Add(this.gboPortSettings);
            this.tbPortSettings.Location = new System.Drawing.Point(4, 25);
            this.tbPortSettings.Name = "tbPortSettings";
            this.tbPortSettings.Padding = new System.Windows.Forms.Padding(3);
            this.tbPortSettings.Size = new System.Drawing.Size(1337, 611);
            this.tbPortSettings.TabIndex = 0;
            this.tbPortSettings.Text = "Port Settings";
            this.tbPortSettings.UseVisualStyleBackColor = true;
            // 
            // gboPortSettings
            // 
            this.gboPortSettings.Controls.Add(this.txtWriteTimeOut);
            this.gboPortSettings.Controls.Add(this.txtReadTimeOut);
            this.gboPortSettings.Controls.Add(this.cboParityBits);
            this.gboPortSettings.Controls.Add(this.cboStopBits);
            this.gboPortSettings.Controls.Add(this.cboDataBits);
            this.gboPortSettings.Controls.Add(this.cboBaudRate);
            this.gboPortSettings.Controls.Add(this.cboPortName);
            this.gboPortSettings.Controls.Add(this.lblWriteTimeout);
            this.gboPortSettings.Controls.Add(this.lblReadTimeout);
            this.gboPortSettings.Controls.Add(this.lblParityBits);
            this.gboPortSettings.Controls.Add(this.lblStopBits);
            this.gboPortSettings.Controls.Add(this.lblDataBits);
            this.gboPortSettings.Controls.Add(this.lblBaudRate);
            this.gboPortSettings.Controls.Add(this.lblPortName);
            this.gboPortSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gboPortSettings.Location = new System.Drawing.Point(6, 3);
            this.gboPortSettings.Name = "gboPortSettings";
            this.gboPortSettings.Size = new System.Drawing.Size(305, 233);
            this.gboPortSettings.TabIndex = 0;
            this.gboPortSettings.TabStop = false;
            // 
            // txtWriteTimeOut
            // 
            this.txtWriteTimeOut.Enabled = false;
            this.txtWriteTimeOut.Location = new System.Drawing.Point(157, 185);
            this.txtWriteTimeOut.MaxLength = 5;
            this.txtWriteTimeOut.Name = "txtWriteTimeOut";
            this.txtWriteTimeOut.Size = new System.Drawing.Size(121, 22);
            this.txtWriteTimeOut.TabIndex = 13;
            this.txtWriteTimeOut.Text = "300";
            // 
            // txtReadTimeOut
            // 
            this.txtReadTimeOut.Enabled = false;
            this.txtReadTimeOut.Location = new System.Drawing.Point(157, 159);
            this.txtReadTimeOut.MaxLength = 5;
            this.txtReadTimeOut.Name = "txtReadTimeOut";
            this.txtReadTimeOut.Size = new System.Drawing.Size(121, 22);
            this.txtReadTimeOut.TabIndex = 12;
            this.txtReadTimeOut.Text = "300";
            // 
            // cboParityBits
            // 
            this.cboParityBits.Enabled = false;
            this.cboParityBits.FormattingEnabled = true;
            this.cboParityBits.Items.AddRange(new object[] {
            "Even",
            "Odd",
            "None"});
            this.cboParityBits.Location = new System.Drawing.Point(157, 132);
            this.cboParityBits.Name = "cboParityBits";
            this.cboParityBits.Size = new System.Drawing.Size(121, 24);
            this.cboParityBits.TabIndex = 11;
            this.cboParityBits.Text = "None";
            // 
            // cboStopBits
            // 
            this.cboStopBits.Enabled = false;
            this.cboStopBits.FormattingEnabled = true;
            this.cboStopBits.Items.AddRange(new object[] {
            "1",
            "1.5",
            "2"});
            this.cboStopBits.Location = new System.Drawing.Point(157, 105);
            this.cboStopBits.Name = "cboStopBits";
            this.cboStopBits.Size = new System.Drawing.Size(121, 24);
            this.cboStopBits.TabIndex = 10;
            this.cboStopBits.Text = "1";
            // 
            // cboDataBits
            // 
            this.cboDataBits.Enabled = false;
            this.cboDataBits.FormattingEnabled = true;
            this.cboDataBits.Items.AddRange(new object[] {
            "5",
            "6",
            "7",
            "8"});
            this.cboDataBits.Location = new System.Drawing.Point(157, 78);
            this.cboDataBits.Name = "cboDataBits";
            this.cboDataBits.Size = new System.Drawing.Size(121, 24);
            this.cboDataBits.TabIndex = 9;
            this.cboDataBits.Text = "8";
            // 
            // cboBaudRate
            // 
            this.cboBaudRate.Enabled = false;
            this.cboBaudRate.FormattingEnabled = true;
            this.cboBaudRate.Items.AddRange(new object[] {
            "110",
            "300",
            "1200",
            "2400",
            "4800",
            "9600",
            "19200",
            "38400",
            "57600",
            "115200",
            "230400",
            "460800",
            "921600"});
            this.cboBaudRate.Location = new System.Drawing.Point(157, 50);
            this.cboBaudRate.Name = "cboBaudRate";
            this.cboBaudRate.Size = new System.Drawing.Size(121, 24);
            this.cboBaudRate.TabIndex = 8;
            this.cboBaudRate.Text = "9600";
            // 
            // cboPortName
            // 
            this.cboPortName.FormattingEnabled = true;
            this.cboPortName.Location = new System.Drawing.Point(157, 24);
            this.cboPortName.Name = "cboPortName";
            this.cboPortName.Size = new System.Drawing.Size(121, 24);
            this.cboPortName.TabIndex = 7;
            this.cboPortName.Text = "COM1";
            // 
            // lblWriteTimeout
            // 
            this.lblWriteTimeout.AutoSize = true;
            this.lblWriteTimeout.Location = new System.Drawing.Point(11, 188);
            this.lblWriteTimeout.Name = "lblWriteTimeout";
            this.lblWriteTimeout.Size = new System.Drawing.Size(91, 16);
            this.lblWriteTimeout.TabIndex = 6;
            this.lblWriteTimeout.Text = "Write Timeout";
            // 
            // lblReadTimeout
            // 
            this.lblReadTimeout.AutoSize = true;
            this.lblReadTimeout.Location = new System.Drawing.Point(11, 162);
            this.lblReadTimeout.Name = "lblReadTimeout";
            this.lblReadTimeout.Size = new System.Drawing.Size(94, 16);
            this.lblReadTimeout.TabIndex = 5;
            this.lblReadTimeout.Text = "Read Timeout";
            // 
            // lblParityBits
            // 
            this.lblParityBits.AutoSize = true;
            this.lblParityBits.Location = new System.Drawing.Point(11, 135);
            this.lblParityBits.Name = "lblParityBits";
            this.lblParityBits.Size = new System.Drawing.Size(67, 16);
            this.lblParityBits.TabIndex = 4;
            this.lblParityBits.Text = "Parity Bits";
            // 
            // lblStopBits
            // 
            this.lblStopBits.AutoSize = true;
            this.lblStopBits.Location = new System.Drawing.Point(11, 108);
            this.lblStopBits.Name = "lblStopBits";
            this.lblStopBits.Size = new System.Drawing.Size(61, 16);
            this.lblStopBits.TabIndex = 3;
            this.lblStopBits.Text = "Stop Bits";
            // 
            // lblDataBits
            // 
            this.lblDataBits.AutoSize = true;
            this.lblDataBits.Location = new System.Drawing.Point(11, 81);
            this.lblDataBits.Name = "lblDataBits";
            this.lblDataBits.Size = new System.Drawing.Size(62, 16);
            this.lblDataBits.TabIndex = 2;
            this.lblDataBits.Text = "Data Bits";
            // 
            // lblBaudRate
            // 
            this.lblBaudRate.AutoSize = true;
            this.lblBaudRate.Location = new System.Drawing.Point(11, 53);
            this.lblBaudRate.Name = "lblBaudRate";
            this.lblBaudRate.Size = new System.Drawing.Size(72, 16);
            this.lblBaudRate.TabIndex = 1;
            this.lblBaudRate.Text = "Baud Rate";
            // 
            // lblPortName
            // 
            this.lblPortName.AutoSize = true;
            this.lblPortName.Location = new System.Drawing.Point(11, 27);
            this.lblPortName.Name = "lblPortName";
            this.lblPortName.Size = new System.Drawing.Size(72, 16);
            this.lblPortName.TabIndex = 0;
            this.lblPortName.Text = "Port Name";
            // 
            // tbSendSMS
            // 
            this.tbSendSMS.Controls.Add(this.gboSendSMS);
            this.tbSendSMS.Location = new System.Drawing.Point(4, 25);
            this.tbSendSMS.Name = "tbSendSMS";
            this.tbSendSMS.Padding = new System.Windows.Forms.Padding(3);
            this.tbSendSMS.Size = new System.Drawing.Size(1337, 611);
            this.tbSendSMS.TabIndex = 1;
            this.tbSendSMS.Text = "Send SMS";
            this.tbSendSMS.UseVisualStyleBackColor = true;
            // 
            // gboSendSMS
            // 
            this.gboSendSMS.Controls.Add(this.lblMaxSMSSize);
            this.gboSendSMS.Controls.Add(this.lblMessage);
            this.gboSendSMS.Controls.Add(this.btnSendSMS);
            this.gboSendSMS.Controls.Add(this.lblMobileNo);
            this.gboSendSMS.Controls.Add(this.txtSIM);
            this.gboSendSMS.Controls.Add(this.txtMessage);
            this.gboSendSMS.Location = new System.Drawing.Point(6, 3);
            this.gboSendSMS.Name = "gboSendSMS";
            this.gboSendSMS.Size = new System.Drawing.Size(441, 257);
            this.gboSendSMS.TabIndex = 43;
            this.gboSendSMS.TabStop = false;
            // 
            // lblMaxSMSSize
            // 
            this.lblMaxSMSSize.AutoSize = true;
            this.lblMaxSMSSize.Location = new System.Drawing.Point(101, 222);
            this.lblMaxSMSSize.Name = "lblMaxSMSSize";
            this.lblMaxSMSSize.Size = new System.Drawing.Size(102, 16);
            this.lblMaxSMSSize.TabIndex = 44;
            this.lblMaxSMSSize.Text = "( Max 160 Char )";
            // 
            // lblMessage
            // 
            this.lblMessage.AutoSize = true;
            this.lblMessage.Location = new System.Drawing.Point(25, 78);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(65, 16);
            this.lblMessage.TabIndex = 43;
            this.lblMessage.Text = "Message";
            // 
            // btnSendSMS
            // 
            this.btnSendSMS.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSendSMS.Location = new System.Drawing.Point(306, 218);
            this.btnSendSMS.Name = "btnSendSMS";
            this.btnSendSMS.Size = new System.Drawing.Size(121, 25);
            this.btnSendSMS.TabIndex = 3;
            this.btnSendSMS.Text = "Send";
            this.btnSendSMS.UseVisualStyleBackColor = true;
            this.btnSendSMS.Click += new System.EventHandler(this.btnSendSMS_Click);
            // 
            // lblMobileNo
            // 
            this.lblMobileNo.AutoSize = true;
            this.lblMobileNo.Location = new System.Drawing.Point(25, 47);
            this.lblMobileNo.Name = "lblMobileNo";
            this.lblMobileNo.Size = new System.Drawing.Size(76, 16);
            this.lblMobileNo.TabIndex = 42;
            this.lblMobileNo.Text = "Mobile No :";
            // 
            // txtSIM
            // 
            this.txtSIM.Location = new System.Drawing.Point(104, 44);
            this.txtSIM.MaxLength = 15;
            this.txtSIM.Name = "txtSIM";
            this.txtSIM.Size = new System.Drawing.Size(118, 22);
            this.txtSIM.TabIndex = 1;
            // 
            // txtMessage
            // 
            this.txtMessage.Location = new System.Drawing.Point(104, 78);
            this.txtMessage.MaxLength = 160;
            this.txtMessage.Multiline = true;
            this.txtMessage.Name = "txtMessage";
            this.txtMessage.Size = new System.Drawing.Size(323, 134);
            this.txtMessage.TabIndex = 2;
            this.txtMessage.Text = "Please send your report. Ignore this SMS if you already send the report. Thank Yo" +
                "u.";
            // 
            // tbReadSMS
            // 
            this.tbReadSMS.Controls.Add(this.gboReadSMS);
            this.tbReadSMS.Location = new System.Drawing.Point(4, 25);
            this.tbReadSMS.Name = "tbReadSMS";
            this.tbReadSMS.Padding = new System.Windows.Forms.Padding(3);
            this.tbReadSMS.Size = new System.Drawing.Size(1337, 611);
            this.tbReadSMS.TabIndex = 2;
            this.tbReadSMS.Text = "Read SMS";
            this.tbReadSMS.UseVisualStyleBackColor = true;
            // 
            // gboReadSMS
            // 
            this.gboReadSMS.Controls.Add(this.btnSMSMoveToDB);
            this.gboReadSMS.Controls.Add(this.rbReadStoreUnSent);
            this.gboReadSMS.Controls.Add(this.rbReadStoreSent);
            this.gboReadSMS.Controls.Add(this.rbReadUnRead);
            this.gboReadSMS.Controls.Add(this.rbReadAll);
            this.gboReadSMS.Controls.Add(this.btnReadSMS);
            this.gboReadSMS.Controls.Add(this.lvwMessages);
            this.gboReadSMS.Location = new System.Drawing.Point(6, 3);
            this.gboReadSMS.Name = "gboReadSMS";
            this.gboReadSMS.Size = new System.Drawing.Size(1310, 581);
            this.gboReadSMS.TabIndex = 43;
            this.gboReadSMS.TabStop = false;
            // 
            // btnSMSMoveToDB
            // 
            this.btnSMSMoveToDB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSMSMoveToDB.Location = new System.Drawing.Point(155, 524);
            this.btnSMSMoveToDB.Name = "btnSMSMoveToDB";
            this.btnSMSMoveToDB.Size = new System.Drawing.Size(142, 25);
            this.btnSMSMoveToDB.TabIndex = 9;
            this.btnSMSMoveToDB.Text = "SMS Move to DB";
            this.btnSMSMoveToDB.UseVisualStyleBackColor = true;
            this.btnSMSMoveToDB.Click += new System.EventHandler(this.btnSMSMoveToDB_Click);
            // 
            // rbReadStoreUnSent
            // 
            this.rbReadStoreUnSent.AutoSize = true;
            this.rbReadStoreUnSent.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbReadStoreUnSent.Location = new System.Drawing.Point(177, 44);
            this.rbReadStoreUnSent.Name = "rbReadStoreUnSent";
            this.rbReadStoreUnSent.Size = new System.Drawing.Size(195, 20);
            this.rbReadStoreUnSent.TabIndex = 7;
            this.rbReadStoreUnSent.Text = "Read Store UnSent SMS";
            this.rbReadStoreUnSent.UseVisualStyleBackColor = true;
            // 
            // rbReadStoreSent
            // 
            this.rbReadStoreSent.AutoSize = true;
            this.rbReadStoreSent.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbReadStoreSent.Location = new System.Drawing.Point(177, 21);
            this.rbReadStoreSent.Name = "rbReadStoreSent";
            this.rbReadStoreSent.Size = new System.Drawing.Size(176, 20);
            this.rbReadStoreSent.TabIndex = 5;
            this.rbReadStoreSent.Text = "Read Store Sent SMS";
            this.rbReadStoreSent.UseVisualStyleBackColor = true;
            // 
            // rbReadUnRead
            // 
            this.rbReadUnRead.AutoSize = true;
            this.rbReadUnRead.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbReadUnRead.Location = new System.Drawing.Point(10, 44);
            this.rbReadUnRead.Name = "rbReadUnRead";
            this.rbReadUnRead.Size = new System.Drawing.Size(161, 20);
            this.rbReadUnRead.TabIndex = 6;
            this.rbReadUnRead.Text = "Read UnRead SMS";
            this.rbReadUnRead.UseVisualStyleBackColor = true;
            // 
            // rbReadAll
            // 
            this.rbReadAll.AutoSize = true;
            this.rbReadAll.Checked = true;
            this.rbReadAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbReadAll.Location = new System.Drawing.Point(10, 21);
            this.rbReadAll.Name = "rbReadAll";
            this.rbReadAll.Size = new System.Drawing.Size(122, 20);
            this.rbReadAll.TabIndex = 4;
            this.rbReadAll.TabStop = true;
            this.rbReadAll.Text = "Read All SMS";
            this.rbReadAll.UseVisualStyleBackColor = true;
            // 
            // btnReadSMS
            // 
            this.btnReadSMS.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReadSMS.Location = new System.Drawing.Point(10, 524);
            this.btnReadSMS.Name = "btnReadSMS";
            this.btnReadSMS.Size = new System.Drawing.Size(142, 25);
            this.btnReadSMS.TabIndex = 8;
            this.btnReadSMS.Text = "Read";
            this.btnReadSMS.UseVisualStyleBackColor = true;
            this.btnReadSMS.Click += new System.EventHandler(this.btnReadSMS_Click);
            // 
            // lvwMessages
            // 
            this.lvwMessages.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lvwMessages.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colIndex,
            this.colSentTime,
            this.colSender,
            this.colMessage});
            this.lvwMessages.FullRowSelect = true;
            this.lvwMessages.GridLines = true;
            this.lvwMessages.Location = new System.Drawing.Point(10, 70);
            this.lvwMessages.MultiSelect = false;
            this.lvwMessages.Name = "lvwMessages";
            this.lvwMessages.Size = new System.Drawing.Size(1280, 437);
            this.lvwMessages.TabIndex = 38;
            this.lvwMessages.UseCompatibleStateImageBehavior = false;
            this.lvwMessages.View = System.Windows.Forms.View.Details;
            // 
            // colIndex
            // 
            this.colIndex.Text = "Index";
            this.colIndex.Width = 50;
            // 
            // colSentTime
            // 
            this.colSentTime.Text = "SentTime";
            this.colSentTime.Width = 160;
            // 
            // colSender
            // 
            this.colSender.Text = "Sender";
            this.colSender.Width = 200;
            // 
            // colMessage
            // 
            this.colMessage.Text = "Message";
            this.colMessage.Width = 1000;
            // 
            // tbDeleteSMS
            // 
            this.tbDeleteSMS.Controls.Add(this.groupBoxSMSCount);
            this.tbDeleteSMS.Controls.Add(this.gboDeleteSMS);
            this.tbDeleteSMS.Location = new System.Drawing.Point(4, 25);
            this.tbDeleteSMS.Name = "tbDeleteSMS";
            this.tbDeleteSMS.Padding = new System.Windows.Forms.Padding(3);
            this.tbDeleteSMS.Size = new System.Drawing.Size(1337, 611);
            this.tbDeleteSMS.TabIndex = 3;
            this.tbDeleteSMS.Text = "Delete SMS";
            this.tbDeleteSMS.UseVisualStyleBackColor = true;
            // 
            // groupBoxSMSCount
            // 
            this.groupBoxSMSCount.Controls.Add(this.btnCountSMS);
            this.groupBoxSMSCount.Controls.Add(this.txtCountSMS);
            this.groupBoxSMSCount.Controls.Add(this.lblCountSMS);
            this.groupBoxSMSCount.Location = new System.Drawing.Point(6, 3);
            this.groupBoxSMSCount.Name = "groupBoxSMSCount";
            this.groupBoxSMSCount.Size = new System.Drawing.Size(314, 61);
            this.groupBoxSMSCount.TabIndex = 45;
            this.groupBoxSMSCount.TabStop = false;
            // 
            // btnCountSMS
            // 
            this.btnCountSMS.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCountSMS.Location = new System.Drawing.Point(177, 19);
            this.btnCountSMS.Name = "btnCountSMS";
            this.btnCountSMS.Size = new System.Drawing.Size(131, 25);
            this.btnCountSMS.TabIndex = 10;
            this.btnCountSMS.Text = "Count";
            this.btnCountSMS.UseVisualStyleBackColor = true;
            this.btnCountSMS.Click += new System.EventHandler(this.btnCountSMS_Click);
            // 
            // txtCountSMS
            // 
            this.txtCountSMS.Location = new System.Drawing.Point(96, 20);
            this.txtCountSMS.Name = "txtCountSMS";
            this.txtCountSMS.ReadOnly = true;
            this.txtCountSMS.Size = new System.Drawing.Size(34, 22);
            this.txtCountSMS.TabIndex = 1;
            // 
            // lblCountSMS
            // 
            this.lblCountSMS.AutoSize = true;
            this.lblCountSMS.Location = new System.Drawing.Point(13, 23);
            this.lblCountSMS.Name = "lblCountSMS";
            this.lblCountSMS.Size = new System.Drawing.Size(74, 16);
            this.lblCountSMS.TabIndex = 0;
            this.lblCountSMS.Text = "Count SMS";
            // 
            // gboDeleteSMS
            // 
            this.gboDeleteSMS.Controls.Add(this.rbDeleteReadSMS);
            this.gboDeleteSMS.Controls.Add(this.btnDeleteSMS);
            this.gboDeleteSMS.Controls.Add(this.rbDeleteAllSMS);
            this.gboDeleteSMS.Location = new System.Drawing.Point(6, 80);
            this.gboDeleteSMS.Name = "gboDeleteSMS";
            this.gboDeleteSMS.Size = new System.Drawing.Size(314, 85);
            this.gboDeleteSMS.TabIndex = 44;
            this.gboDeleteSMS.TabStop = false;
            // 
            // rbDeleteReadSMS
            // 
            this.rbDeleteReadSMS.AutoSize = true;
            this.rbDeleteReadSMS.Checked = true;
            this.rbDeleteReadSMS.Location = new System.Drawing.Point(16, 49);
            this.rbDeleteReadSMS.Name = "rbDeleteReadSMS";
            this.rbDeleteReadSMS.Size = new System.Drawing.Size(138, 20);
            this.rbDeleteReadSMS.TabIndex = 12;
            this.rbDeleteReadSMS.TabStop = true;
            this.rbDeleteReadSMS.Text = "Delete Read SMS ";
            this.rbDeleteReadSMS.UseVisualStyleBackColor = true;
            // 
            // btnDeleteSMS
            // 
            this.btnDeleteSMS.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteSMS.Location = new System.Drawing.Point(177, 32);
            this.btnDeleteSMS.Name = "btnDeleteSMS";
            this.btnDeleteSMS.Size = new System.Drawing.Size(131, 25);
            this.btnDeleteSMS.TabIndex = 13;
            this.btnDeleteSMS.Text = "Delete";
            this.btnDeleteSMS.UseVisualStyleBackColor = true;
            this.btnDeleteSMS.Click += new System.EventHandler(this.btnDeleteSMS_Click);
            // 
            // rbDeleteAllSMS
            // 
            this.rbDeleteAllSMS.AutoSize = true;
            this.rbDeleteAllSMS.Location = new System.Drawing.Point(16, 21);
            this.rbDeleteAllSMS.Name = "rbDeleteAllSMS";
            this.rbDeleteAllSMS.Size = new System.Drawing.Size(116, 20);
            this.rbDeleteAllSMS.TabIndex = 11;
            this.rbDeleteAllSMS.Text = "Delete All SMS";
            this.rbDeleteAllSMS.UseVisualStyleBackColor = true;
            // 
            // tbUserCreate
            // 
            this.tbUserCreate.Controls.Add(this.btnRefreshUser);
            this.tbUserCreate.Controls.Add(this.btnUserReport);
            this.tbUserCreate.Controls.Add(this.btnAddUser);
            this.tbUserCreate.Controls.Add(this.dataGridViewUserDetails);
            this.tbUserCreate.Controls.Add(this.groupBoxUser);
            this.tbUserCreate.Controls.Add(this.btnSaveUser);
            this.tbUserCreate.Location = new System.Drawing.Point(4, 25);
            this.tbUserCreate.Name = "tbUserCreate";
            this.tbUserCreate.Padding = new System.Windows.Forms.Padding(3);
            this.tbUserCreate.Size = new System.Drawing.Size(1337, 611);
            this.tbUserCreate.TabIndex = 4;
            this.tbUserCreate.Text = "User";
            this.tbUserCreate.UseVisualStyleBackColor = true;
            // 
            // btnRefreshUser
            // 
            this.btnRefreshUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefreshUser.Location = new System.Drawing.Point(6, 260);
            this.btnRefreshUser.Name = "btnRefreshUser";
            this.btnRefreshUser.Size = new System.Drawing.Size(362, 25);
            this.btnRefreshUser.TabIndex = 75;
            this.btnRefreshUser.Text = "Refresh";
            this.btnRefreshUser.UseVisualStyleBackColor = true;
            this.btnRefreshUser.Click += new System.EventHandler(this.btnRefreshUser_Click);
            // 
            // btnUserReport
            // 
            this.btnUserReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUserReport.Location = new System.Drawing.Point(6, 230);
            this.btnUserReport.Name = "btnUserReport";
            this.btnUserReport.Size = new System.Drawing.Size(362, 25);
            this.btnUserReport.TabIndex = 74;
            this.btnUserReport.Text = "User Report";
            this.btnUserReport.UseVisualStyleBackColor = true;
            this.btnUserReport.Click += new System.EventHandler(this.btnUserReport_Click);
            // 
            // btnAddUser
            // 
            this.btnAddUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddUser.Location = new System.Drawing.Point(6, 200);
            this.btnAddUser.Name = "btnAddUser";
            this.btnAddUser.Size = new System.Drawing.Size(180, 25);
            this.btnAddUser.TabIndex = 19;
            this.btnAddUser.Text = "Add User";
            this.btnAddUser.UseVisualStyleBackColor = true;
            this.btnAddUser.Click += new System.EventHandler(this.btnAddUser_Click);
            // 
            // dataGridViewUserDetails
            // 
            this.dataGridViewUserDetails.AllowUserToAddRows = false;
            this.dataGridViewUserDetails.AllowUserToDeleteRows = false;
            this.dataGridViewUserDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridViewUserDetails.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridViewUserDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewUserDetails.Location = new System.Drawing.Point(372, 10);
            this.dataGridViewUserDetails.MultiSelect = false;
            this.dataGridViewUserDetails.Name = "dataGridViewUserDetails";
            this.dataGridViewUserDetails.ReadOnly = true;
            this.dataGridViewUserDetails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewUserDetails.Size = new System.Drawing.Size(960, 595);
            this.dataGridViewUserDetails.TabIndex = 2;
            this.dataGridViewUserDetails.TabStop = false;
            this.dataGridViewUserDetails.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewUserDetails_CellContentDoubleClick);
            this.dataGridViewUserDetails.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewUserDetails_CellDoubleClick);
            // 
            // groupBoxUser
            // 
            this.groupBoxUser.Controls.Add(this.cmbActive);
            this.groupBoxUser.Controls.Add(this.lblActive);
            this.groupBoxUser.Controls.Add(this.txtRoleID);
            this.groupBoxUser.Controls.Add(this.cmbUserRole);
            this.groupBoxUser.Controls.Add(this.txtPassword);
            this.groupBoxUser.Controls.Add(this.txtUserName);
            this.groupBoxUser.Controls.Add(this.lblRoleID);
            this.groupBoxUser.Controls.Add(this.lblUserRole);
            this.groupBoxUser.Controls.Add(this.lblPassword);
            this.groupBoxUser.Controls.Add(this.lblUserName);
            this.groupBoxUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxUser.Location = new System.Drawing.Point(6, 3);
            this.groupBoxUser.Name = "groupBoxUser";
            this.groupBoxUser.Size = new System.Drawing.Size(360, 190);
            this.groupBoxUser.TabIndex = 1;
            this.groupBoxUser.TabStop = false;
            // 
            // cmbActive
            // 
            this.cmbActive.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbActive.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbActive.Enabled = false;
            this.cmbActive.FormattingEnabled = true;
            this.cmbActive.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cmbActive.Location = new System.Drawing.Point(110, 147);
            this.cmbActive.Name = "cmbActive";
            this.cmbActive.Size = new System.Drawing.Size(240, 24);
            this.cmbActive.TabIndex = 18;
            this.cmbActive.Text = "Select Active";
            this.cmbActive.Click += new System.EventHandler(this.cmbActive_Click);
            // 
            // lblActive
            // 
            this.lblActive.AutoSize = true;
            this.lblActive.Location = new System.Drawing.Point(4, 150);
            this.lblActive.Name = "lblActive";
            this.lblActive.Size = new System.Drawing.Size(51, 16);
            this.lblActive.TabIndex = 9;
            this.lblActive.Text = "Active :";
            // 
            // txtRoleID
            // 
            this.txtRoleID.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtRoleID.Location = new System.Drawing.Point(110, 117);
            this.txtRoleID.Name = "txtRoleID";
            this.txtRoleID.ReadOnly = true;
            this.txtRoleID.Size = new System.Drawing.Size(240, 22);
            this.txtRoleID.TabIndex = 17;
            this.txtRoleID.TabStop = false;
            // 
            // cmbUserRole
            // 
            this.cmbUserRole.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbUserRole.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbUserRole.Enabled = false;
            this.cmbUserRole.FormattingEnabled = true;
            this.cmbUserRole.Location = new System.Drawing.Point(110, 87);
            this.cmbUserRole.Name = "cmbUserRole";
            this.cmbUserRole.Size = new System.Drawing.Size(240, 24);
            this.cmbUserRole.Sorted = true;
            this.cmbUserRole.TabIndex = 16;
            this.cmbUserRole.Text = "Select User Role";
            this.cmbUserRole.SelectedIndexChanged += new System.EventHandler(this.cmbUserRole_SelectedIndexChanged);
            this.cmbUserRole.SelectedValueChanged += new System.EventHandler(this.cmbUserRole_SelectedValueChanged);
            // 
            // txtPassword
            // 
            this.txtPassword.Enabled = false;
            this.txtPassword.Location = new System.Drawing.Point(110, 57);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new System.Drawing.Size(240, 22);
            this.txtPassword.TabIndex = 15;
            // 
            // txtUserName
            // 
            this.txtUserName.Enabled = false;
            this.txtUserName.Location = new System.Drawing.Point(110, 27);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(240, 22);
            this.txtUserName.TabIndex = 14;
            // 
            // lblRoleID
            // 
            this.lblRoleID.AutoSize = true;
            this.lblRoleID.Location = new System.Drawing.Point(4, 120);
            this.lblRoleID.Name = "lblRoleID";
            this.lblRoleID.Size = new System.Drawing.Size(59, 16);
            this.lblRoleID.TabIndex = 3;
            this.lblRoleID.Text = "Role ID :";
            // 
            // lblUserRole
            // 
            this.lblUserRole.AutoSize = true;
            this.lblUserRole.Location = new System.Drawing.Point(4, 90);
            this.lblUserRole.Name = "lblUserRole";
            this.lblUserRole.Size = new System.Drawing.Size(75, 16);
            this.lblUserRole.TabIndex = 2;
            this.lblUserRole.Text = "User Role :";
            // 
            // lblPassword
            // 
            this.lblPassword.AutoSize = true;
            this.lblPassword.Location = new System.Drawing.Point(4, 60);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(74, 16);
            this.lblPassword.TabIndex = 1;
            this.lblPassword.Text = "Password :";
            // 
            // lblUserName
            // 
            this.lblUserName.AutoSize = true;
            this.lblUserName.Location = new System.Drawing.Point(4, 30);
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.Size = new System.Drawing.Size(83, 16);
            this.lblUserName.TabIndex = 0;
            this.lblUserName.Text = "User Name :";
            // 
            // btnSaveUser
            // 
            this.btnSaveUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveUser.Location = new System.Drawing.Point(188, 200);
            this.btnSaveUser.Name = "btnSaveUser";
            this.btnSaveUser.Size = new System.Drawing.Size(180, 25);
            this.btnSaveUser.TabIndex = 20;
            this.btnSaveUser.Text = "Save User";
            this.btnSaveUser.UseVisualStyleBackColor = true;
            this.btnSaveUser.Click += new System.EventHandler(this.btnSaveUser_Click);
            // 
            // tbDepartment
            // 
            this.tbDepartment.Controls.Add(this.btnRefreshDepartment);
            this.tbDepartment.Controls.Add(this.btnAddDepartment);
            this.tbDepartment.Controls.Add(this.dataGridViewDepartmentDetails);
            this.tbDepartment.Controls.Add(this.groupBoxDepartment);
            this.tbDepartment.Controls.Add(this.btnSaveDepartment);
            this.tbDepartment.Location = new System.Drawing.Point(4, 25);
            this.tbDepartment.Name = "tbDepartment";
            this.tbDepartment.Size = new System.Drawing.Size(1337, 611);
            this.tbDepartment.TabIndex = 9;
            this.tbDepartment.Text = "Department";
            this.tbDepartment.UseVisualStyleBackColor = true;
            // 
            // btnRefreshDepartment
            // 
            this.btnRefreshDepartment.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefreshDepartment.Location = new System.Drawing.Point(6, 130);
            this.btnRefreshDepartment.Name = "btnRefreshDepartment";
            this.btnRefreshDepartment.Size = new System.Drawing.Size(362, 25);
            this.btnRefreshDepartment.TabIndex = 76;
            this.btnRefreshDepartment.Text = "Refresh";
            this.btnRefreshDepartment.UseVisualStyleBackColor = true;
            this.btnRefreshDepartment.Click += new System.EventHandler(this.btnRefreshDepartment_Click);
            // 
            // btnAddDepartment
            // 
            this.btnAddDepartment.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddDepartment.Location = new System.Drawing.Point(6, 100);
            this.btnAddDepartment.Name = "btnAddDepartment";
            this.btnAddDepartment.Size = new System.Drawing.Size(180, 25);
            this.btnAddDepartment.TabIndex = 28;
            this.btnAddDepartment.Text = "Add Department";
            this.btnAddDepartment.UseVisualStyleBackColor = true;
            this.btnAddDepartment.Click += new System.EventHandler(this.btnAddDepartment_Click);
            // 
            // dataGridViewDepartmentDetails
            // 
            this.dataGridViewDepartmentDetails.AllowUserToAddRows = false;
            this.dataGridViewDepartmentDetails.AllowUserToDeleteRows = false;
            this.dataGridViewDepartmentDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridViewDepartmentDetails.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridViewDepartmentDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDepartmentDetails.Location = new System.Drawing.Point(372, 10);
            this.dataGridViewDepartmentDetails.MultiSelect = false;
            this.dataGridViewDepartmentDetails.Name = "dataGridViewDepartmentDetails";
            this.dataGridViewDepartmentDetails.ReadOnly = true;
            this.dataGridViewDepartmentDetails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewDepartmentDetails.Size = new System.Drawing.Size(960, 595);
            this.dataGridViewDepartmentDetails.TabIndex = 15;
            this.dataGridViewDepartmentDetails.TabStop = false;
            this.dataGridViewDepartmentDetails.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewDepartmentDetails_CellContentDoubleClick);
            this.dataGridViewDepartmentDetails.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewDepartmentDetails_CellDoubleClick);
            // 
            // groupBoxDepartment
            // 
            this.groupBoxDepartment.Controls.Add(this.cmbActiveDepartment);
            this.groupBoxDepartment.Controls.Add(this.lblActiveDepartment);
            this.groupBoxDepartment.Controls.Add(this.txtDepartment);
            this.groupBoxDepartment.Controls.Add(this.lblDepartmentName);
            this.groupBoxDepartment.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxDepartment.Location = new System.Drawing.Point(6, 3);
            this.groupBoxDepartment.Name = "groupBoxDepartment";
            this.groupBoxDepartment.Size = new System.Drawing.Size(360, 90);
            this.groupBoxDepartment.TabIndex = 14;
            this.groupBoxDepartment.TabStop = false;
            // 
            // cmbActiveDepartment
            // 
            this.cmbActiveDepartment.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbActiveDepartment.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbActiveDepartment.Enabled = false;
            this.cmbActiveDepartment.FormattingEnabled = true;
            this.cmbActiveDepartment.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cmbActiveDepartment.Location = new System.Drawing.Point(110, 57);
            this.cmbActiveDepartment.Name = "cmbActiveDepartment";
            this.cmbActiveDepartment.Size = new System.Drawing.Size(240, 24);
            this.cmbActiveDepartment.TabIndex = 27;
            this.cmbActiveDepartment.Text = "Select Active";
            // 
            // lblActiveDepartment
            // 
            this.lblActiveDepartment.AutoSize = true;
            this.lblActiveDepartment.Location = new System.Drawing.Point(4, 60);
            this.lblActiveDepartment.Name = "lblActiveDepartment";
            this.lblActiveDepartment.Size = new System.Drawing.Size(51, 16);
            this.lblActiveDepartment.TabIndex = 11;
            this.lblActiveDepartment.Text = "Active :";
            // 
            // txtDepartment
            // 
            this.txtDepartment.Enabled = false;
            this.txtDepartment.Location = new System.Drawing.Point(110, 27);
            this.txtDepartment.Name = "txtDepartment";
            this.txtDepartment.Size = new System.Drawing.Size(240, 22);
            this.txtDepartment.TabIndex = 26;
            // 
            // lblDepartmentName
            // 
            this.lblDepartmentName.AutoSize = true;
            this.lblDepartmentName.Location = new System.Drawing.Point(4, 30);
            this.lblDepartmentName.Name = "lblDepartmentName";
            this.lblDepartmentName.Size = new System.Drawing.Size(86, 16);
            this.lblDepartmentName.TabIndex = 0;
            this.lblDepartmentName.Text = "Dept. Name :";
            // 
            // btnSaveDepartment
            // 
            this.btnSaveDepartment.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveDepartment.Location = new System.Drawing.Point(188, 100);
            this.btnSaveDepartment.Name = "btnSaveDepartment";
            this.btnSaveDepartment.Size = new System.Drawing.Size(180, 25);
            this.btnSaveDepartment.TabIndex = 29;
            this.btnSaveDepartment.Text = "Save Department";
            this.btnSaveDepartment.UseVisualStyleBackColor = true;
            this.btnSaveDepartment.Click += new System.EventHandler(this.btnSaveDepartment_Click);
            // 
            // tbDesignation
            // 
            this.tbDesignation.Controls.Add(this.btnRefreshDesignation);
            this.tbDesignation.Controls.Add(this.btnAddDesignation);
            this.tbDesignation.Controls.Add(this.dataGridViewDesignationList);
            this.tbDesignation.Controls.Add(this.groupBoxDesignation);
            this.tbDesignation.Controls.Add(this.btnSaveDesignation);
            this.tbDesignation.Location = new System.Drawing.Point(4, 25);
            this.tbDesignation.Name = "tbDesignation";
            this.tbDesignation.Size = new System.Drawing.Size(1337, 611);
            this.tbDesignation.TabIndex = 8;
            this.tbDesignation.Text = "Designation";
            this.tbDesignation.UseVisualStyleBackColor = true;
            // 
            // btnRefreshDesignation
            // 
            this.btnRefreshDesignation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefreshDesignation.Location = new System.Drawing.Point(6, 160);
            this.btnRefreshDesignation.Name = "btnRefreshDesignation";
            this.btnRefreshDesignation.Size = new System.Drawing.Size(362, 25);
            this.btnRefreshDesignation.TabIndex = 76;
            this.btnRefreshDesignation.Text = "Refresh";
            this.btnRefreshDesignation.UseVisualStyleBackColor = true;
            this.btnRefreshDesignation.Click += new System.EventHandler(this.btnRefreshDesignation_Click);
            // 
            // btnAddDesignation
            // 
            this.btnAddDesignation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddDesignation.Location = new System.Drawing.Point(6, 130);
            this.btnAddDesignation.Name = "btnAddDesignation";
            this.btnAddDesignation.Size = new System.Drawing.Size(180, 25);
            this.btnAddDesignation.TabIndex = 33;
            this.btnAddDesignation.Text = "Add Designation";
            this.btnAddDesignation.UseVisualStyleBackColor = true;
            this.btnAddDesignation.Click += new System.EventHandler(this.btnAddDesignation_Click);
            // 
            // dataGridViewDesignationList
            // 
            this.dataGridViewDesignationList.AllowUserToAddRows = false;
            this.dataGridViewDesignationList.AllowUserToDeleteRows = false;
            this.dataGridViewDesignationList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridViewDesignationList.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridViewDesignationList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDesignationList.Location = new System.Drawing.Point(372, 10);
            this.dataGridViewDesignationList.MultiSelect = false;
            this.dataGridViewDesignationList.Name = "dataGridViewDesignationList";
            this.dataGridViewDesignationList.ReadOnly = true;
            this.dataGridViewDesignationList.RowHeadersWidth = 40;
            this.dataGridViewDesignationList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewDesignationList.Size = new System.Drawing.Size(960, 595);
            this.dataGridViewDesignationList.TabIndex = 15;
            this.dataGridViewDesignationList.TabStop = false;
            this.dataGridViewDesignationList.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewDesignationList_CellDoubleClick);
            // 
            // groupBoxDesignation
            // 
            this.groupBoxDesignation.Controls.Add(this.cmbActiveDesignation);
            this.groupBoxDesignation.Controls.Add(this.lblDesignationActive);
            this.groupBoxDesignation.Controls.Add(this.txtDesignationDetails);
            this.groupBoxDesignation.Controls.Add(this.txtDesignation);
            this.groupBoxDesignation.Controls.Add(this.lblDesignationDetails);
            this.groupBoxDesignation.Controls.Add(this.lblDesignation);
            this.groupBoxDesignation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxDesignation.Location = new System.Drawing.Point(6, 3);
            this.groupBoxDesignation.Name = "groupBoxDesignation";
            this.groupBoxDesignation.Size = new System.Drawing.Size(360, 120);
            this.groupBoxDesignation.TabIndex = 14;
            this.groupBoxDesignation.TabStop = false;
            // 
            // cmbActiveDesignation
            // 
            this.cmbActiveDesignation.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbActiveDesignation.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbActiveDesignation.Enabled = false;
            this.cmbActiveDesignation.FormattingEnabled = true;
            this.cmbActiveDesignation.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cmbActiveDesignation.Location = new System.Drawing.Point(110, 87);
            this.cmbActiveDesignation.Name = "cmbActiveDesignation";
            this.cmbActiveDesignation.Size = new System.Drawing.Size(240, 24);
            this.cmbActiveDesignation.TabIndex = 32;
            this.cmbActiveDesignation.Text = "Select Active";
            // 
            // lblDesignationActive
            // 
            this.lblDesignationActive.AutoSize = true;
            this.lblDesignationActive.Location = new System.Drawing.Point(4, 90);
            this.lblDesignationActive.Name = "lblDesignationActive";
            this.lblDesignationActive.Size = new System.Drawing.Size(51, 16);
            this.lblDesignationActive.TabIndex = 11;
            this.lblDesignationActive.Text = "Active :";
            // 
            // txtDesignationDetails
            // 
            this.txtDesignationDetails.Enabled = false;
            this.txtDesignationDetails.Location = new System.Drawing.Point(110, 57);
            this.txtDesignationDetails.Name = "txtDesignationDetails";
            this.txtDesignationDetails.Size = new System.Drawing.Size(240, 22);
            this.txtDesignationDetails.TabIndex = 31;
            // 
            // txtDesignation
            // 
            this.txtDesignation.Enabled = false;
            this.txtDesignation.Location = new System.Drawing.Point(110, 24);
            this.txtDesignation.Name = "txtDesignation";
            this.txtDesignation.Size = new System.Drawing.Size(240, 22);
            this.txtDesignation.TabIndex = 30;
            this.txtDesignation.Leave += new System.EventHandler(this.txtDesignation_Leave);
            // 
            // lblDesignationDetails
            // 
            this.lblDesignationDetails.AutoSize = true;
            this.lblDesignationDetails.Location = new System.Drawing.Point(4, 60);
            this.lblDesignationDetails.Name = "lblDesignationDetails";
            this.lblDesignationDetails.Size = new System.Drawing.Size(98, 16);
            this.lblDesignationDetails.TabIndex = 1;
            this.lblDesignationDetails.Text = "Desig. Details :";
            // 
            // lblDesignation
            // 
            this.lblDesignation.AutoSize = true;
            this.lblDesignation.Location = new System.Drawing.Point(4, 30);
            this.lblDesignation.Name = "lblDesignation";
            this.lblDesignation.Size = new System.Drawing.Size(86, 16);
            this.lblDesignation.TabIndex = 0;
            this.lblDesignation.Text = "Designation :";
            // 
            // btnSaveDesignation
            // 
            this.btnSaveDesignation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveDesignation.Location = new System.Drawing.Point(188, 130);
            this.btnSaveDesignation.Name = "btnSaveDesignation";
            this.btnSaveDesignation.Size = new System.Drawing.Size(180, 25);
            this.btnSaveDesignation.TabIndex = 34;
            this.btnSaveDesignation.Text = "Save Designation";
            this.btnSaveDesignation.UseVisualStyleBackColor = true;
            this.btnSaveDesignation.Click += new System.EventHandler(this.btnSaveDesignation_Click);
            // 
            // tbGroup
            // 
            this.tbGroup.Controls.Add(this.btnRefreshTeam);
            this.tbGroup.Controls.Add(this.btnAddGroup);
            this.tbGroup.Controls.Add(this.dataGridViewGroupDetails);
            this.tbGroup.Controls.Add(this.groupBoxGroup);
            this.tbGroup.Controls.Add(this.btnSaveGroup);
            this.tbGroup.Location = new System.Drawing.Point(4, 25);
            this.tbGroup.Name = "tbGroup";
            this.tbGroup.Size = new System.Drawing.Size(1337, 611);
            this.tbGroup.TabIndex = 6;
            this.tbGroup.Text = "Team";
            this.tbGroup.UseVisualStyleBackColor = true;
            // 
            // btnRefreshTeam
            // 
            this.btnRefreshTeam.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefreshTeam.Location = new System.Drawing.Point(6, 460);
            this.btnRefreshTeam.Name = "btnRefreshTeam";
            this.btnRefreshTeam.Size = new System.Drawing.Size(362, 25);
            this.btnRefreshTeam.TabIndex = 76;
            this.btnRefreshTeam.Text = "Refresh";
            this.btnRefreshTeam.UseVisualStyleBackColor = true;
            this.btnRefreshTeam.Click += new System.EventHandler(this.btnRefreshTeam_Click);
            // 
            // btnAddGroup
            // 
            this.btnAddGroup.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddGroup.Location = new System.Drawing.Point(6, 430);
            this.btnAddGroup.Name = "btnAddGroup";
            this.btnAddGroup.Size = new System.Drawing.Size(180, 25);
            this.btnAddGroup.TabIndex = 34;
            this.btnAddGroup.Text = "Add Group";
            this.btnAddGroup.UseVisualStyleBackColor = true;
            this.btnAddGroup.Click += new System.EventHandler(this.btnAddGroup_Click);
            // 
            // dataGridViewGroupDetails
            // 
            this.dataGridViewGroupDetails.AllowUserToAddRows = false;
            this.dataGridViewGroupDetails.AllowUserToDeleteRows = false;
            this.dataGridViewGroupDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridViewGroupDetails.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridViewGroupDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewGroupDetails.Location = new System.Drawing.Point(372, 10);
            this.dataGridViewGroupDetails.MultiSelect = false;
            this.dataGridViewGroupDetails.Name = "dataGridViewGroupDetails";
            this.dataGridViewGroupDetails.ReadOnly = true;
            this.dataGridViewGroupDetails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewGroupDetails.Size = new System.Drawing.Size(960, 595);
            this.dataGridViewGroupDetails.TabIndex = 11;
            this.dataGridViewGroupDetails.TabStop = false;
            this.dataGridViewGroupDetails.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewGroupDetails_CellContentDoubleClick);
            this.dataGridViewGroupDetails.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewGroupDetails_CellDoubleClick);
            // 
            // groupBoxGroup
            // 
            this.groupBoxGroup.Controls.Add(this.txtNumberOfDMD);
            this.groupBoxGroup.Controls.Add(this.txtNumberOfMD);
            this.groupBoxGroup.Controls.Add(this.lblNumberOfDMD);
            this.groupBoxGroup.Controls.Add(this.lblNumberOfMD);
            this.groupBoxGroup.Controls.Add(this.txtNumberOfSR);
            this.groupBoxGroup.Controls.Add(this.txtNumberOfTSM);
            this.groupBoxGroup.Controls.Add(this.txtNumberOfASM);
            this.groupBoxGroup.Controls.Add(this.txtNumberOfSM);
            this.groupBoxGroup.Controls.Add(this.txtNumberOfDM);
            this.groupBoxGroup.Controls.Add(this.txtNumberOfDGM);
            this.groupBoxGroup.Controls.Add(this.txtNumberOfGM);
            this.groupBoxGroup.Controls.Add(this.txtNumberOfDO);
            this.groupBoxGroup.Controls.Add(this.lblNumberOfDO);
            this.groupBoxGroup.Controls.Add(this.lblNumberOfSR);
            this.groupBoxGroup.Controls.Add(this.lblNumberOfTSM);
            this.groupBoxGroup.Controls.Add(this.lblNumberOfASM);
            this.groupBoxGroup.Controls.Add(this.lblNumberOfSM);
            this.groupBoxGroup.Controls.Add(this.lblNumberOfDM);
            this.groupBoxGroup.Controls.Add(this.lblNumberOfDGM);
            this.groupBoxGroup.Controls.Add(this.lblNumberOfGM);
            this.groupBoxGroup.Controls.Add(this.cmbGroupActive);
            this.groupBoxGroup.Controls.Add(this.lblGroupActive);
            this.groupBoxGroup.Controls.Add(this.txtLocation);
            this.groupBoxGroup.Controls.Add(this.txtGroupName);
            this.groupBoxGroup.Controls.Add(this.lblLocation);
            this.groupBoxGroup.Controls.Add(this.lblGroupName);
            this.groupBoxGroup.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxGroup.Location = new System.Drawing.Point(6, 3);
            this.groupBoxGroup.Name = "groupBoxGroup";
            this.groupBoxGroup.Size = new System.Drawing.Size(360, 420);
            this.groupBoxGroup.TabIndex = 10;
            this.groupBoxGroup.TabStop = false;
            // 
            // txtNumberOfDMD
            // 
            this.txtNumberOfDMD.AcceptsTab = true;
            this.txtNumberOfDMD.Enabled = false;
            this.txtNumberOfDMD.Location = new System.Drawing.Point(110, 147);
            this.txtNumberOfDMD.Name = "txtNumberOfDMD";
            this.txtNumberOfDMD.Size = new System.Drawing.Size(240, 22);
            this.txtNumberOfDMD.TabIndex = 25;
            this.txtNumberOfDMD.Text = "1";
            this.txtNumberOfDMD.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtNumberOfMD
            // 
            this.txtNumberOfMD.Enabled = false;
            this.txtNumberOfMD.Location = new System.Drawing.Point(110, 117);
            this.txtNumberOfMD.Name = "txtNumberOfMD";
            this.txtNumberOfMD.Size = new System.Drawing.Size(240, 22);
            this.txtNumberOfMD.TabIndex = 24;
            this.txtNumberOfMD.Text = "1";
            this.txtNumberOfMD.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblNumberOfDMD
            // 
            this.lblNumberOfDMD.AutoSize = true;
            this.lblNumberOfDMD.Location = new System.Drawing.Point(4, 150);
            this.lblNumberOfDMD.Name = "lblNumberOfDMD";
            this.lblNumberOfDMD.Size = new System.Drawing.Size(85, 16);
            this.lblNumberOfDMD.TabIndex = 60;
            this.lblNumberOfDMD.Text = "No. Of DMD :";
            // 
            // lblNumberOfMD
            // 
            this.lblNumberOfMD.AutoSize = true;
            this.lblNumberOfMD.Location = new System.Drawing.Point(4, 120);
            this.lblNumberOfMD.Name = "lblNumberOfMD";
            this.lblNumberOfMD.Size = new System.Drawing.Size(75, 16);
            this.lblNumberOfMD.TabIndex = 59;
            this.lblNumberOfMD.Text = "No. Of MD :";
            // 
            // txtNumberOfSR
            // 
            this.txtNumberOfSR.Location = new System.Drawing.Point(110, 387);
            this.txtNumberOfSR.Name = "txtNumberOfSR";
            this.txtNumberOfSR.Size = new System.Drawing.Size(240, 22);
            this.txtNumberOfSR.TabIndex = 33;
            this.txtNumberOfSR.Text = "72";
            this.txtNumberOfSR.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtNumberOfTSM
            // 
            this.txtNumberOfTSM.Location = new System.Drawing.Point(110, 357);
            this.txtNumberOfTSM.Name = "txtNumberOfTSM";
            this.txtNumberOfTSM.Size = new System.Drawing.Size(240, 22);
            this.txtNumberOfTSM.TabIndex = 32;
            this.txtNumberOfTSM.Text = "12";
            this.txtNumberOfTSM.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtNumberOfASM
            // 
            this.txtNumberOfASM.Location = new System.Drawing.Point(110, 327);
            this.txtNumberOfASM.Name = "txtNumberOfASM";
            this.txtNumberOfASM.Size = new System.Drawing.Size(240, 22);
            this.txtNumberOfASM.TabIndex = 31;
            this.txtNumberOfASM.Text = "4";
            this.txtNumberOfASM.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtNumberOfSM
            // 
            this.txtNumberOfSM.Location = new System.Drawing.Point(110, 297);
            this.txtNumberOfSM.Name = "txtNumberOfSM";
            this.txtNumberOfSM.Size = new System.Drawing.Size(240, 22);
            this.txtNumberOfSM.TabIndex = 30;
            this.txtNumberOfSM.Text = "4";
            this.txtNumberOfSM.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtNumberOfDM
            // 
            this.txtNumberOfDM.Location = new System.Drawing.Point(110, 267);
            this.txtNumberOfDM.Name = "txtNumberOfDM";
            this.txtNumberOfDM.Size = new System.Drawing.Size(240, 22);
            this.txtNumberOfDM.TabIndex = 29;
            this.txtNumberOfDM.Text = "2";
            this.txtNumberOfDM.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtNumberOfDGM
            // 
            this.txtNumberOfDGM.Location = new System.Drawing.Point(110, 237);
            this.txtNumberOfDGM.Name = "txtNumberOfDGM";
            this.txtNumberOfDGM.Size = new System.Drawing.Size(240, 22);
            this.txtNumberOfDGM.TabIndex = 28;
            this.txtNumberOfDGM.Text = "1";
            this.txtNumberOfDGM.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtNumberOfGM
            // 
            this.txtNumberOfGM.Location = new System.Drawing.Point(110, 207);
            this.txtNumberOfGM.Name = "txtNumberOfGM";
            this.txtNumberOfGM.Size = new System.Drawing.Size(240, 22);
            this.txtNumberOfGM.TabIndex = 27;
            this.txtNumberOfGM.Text = "1";
            this.txtNumberOfGM.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtNumberOfDO
            // 
            this.txtNumberOfDO.Location = new System.Drawing.Point(110, 177);
            this.txtNumberOfDO.Name = "txtNumberOfDO";
            this.txtNumberOfDO.Size = new System.Drawing.Size(240, 22);
            this.txtNumberOfDO.TabIndex = 26;
            this.txtNumberOfDO.Text = "1";
            this.txtNumberOfDO.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblNumberOfDO
            // 
            this.lblNumberOfDO.AutoSize = true;
            this.lblNumberOfDO.Location = new System.Drawing.Point(4, 180);
            this.lblNumberOfDO.Name = "lblNumberOfDO";
            this.lblNumberOfDO.Size = new System.Drawing.Size(74, 16);
            this.lblNumberOfDO.TabIndex = 43;
            this.lblNumberOfDO.Text = "No. Of DO :";
            // 
            // lblNumberOfSR
            // 
            this.lblNumberOfSR.AutoSize = true;
            this.lblNumberOfSR.Location = new System.Drawing.Point(4, 390);
            this.lblNumberOfSR.Name = "lblNumberOfSR";
            this.lblNumberOfSR.Size = new System.Drawing.Size(73, 16);
            this.lblNumberOfSR.TabIndex = 58;
            this.lblNumberOfSR.Text = "No. Of SR :";
            // 
            // lblNumberOfTSM
            // 
            this.lblNumberOfTSM.AutoSize = true;
            this.lblNumberOfTSM.Location = new System.Drawing.Point(4, 360);
            this.lblNumberOfTSM.Name = "lblNumberOfTSM";
            this.lblNumberOfTSM.Size = new System.Drawing.Size(83, 16);
            this.lblNumberOfTSM.TabIndex = 57;
            this.lblNumberOfTSM.Text = "No. Of TSM :";
            // 
            // lblNumberOfASM
            // 
            this.lblNumberOfASM.AutoSize = true;
            this.lblNumberOfASM.Location = new System.Drawing.Point(4, 330);
            this.lblNumberOfASM.Name = "lblNumberOfASM";
            this.lblNumberOfASM.Size = new System.Drawing.Size(83, 16);
            this.lblNumberOfASM.TabIndex = 56;
            this.lblNumberOfASM.Text = "No. Of ASM :";
            // 
            // lblNumberOfSM
            // 
            this.lblNumberOfSM.AutoSize = true;
            this.lblNumberOfSM.Location = new System.Drawing.Point(4, 300);
            this.lblNumberOfSM.Name = "lblNumberOfSM";
            this.lblNumberOfSM.Size = new System.Drawing.Size(74, 16);
            this.lblNumberOfSM.TabIndex = 47;
            this.lblNumberOfSM.Text = "No. Of SM :";
            // 
            // lblNumberOfDM
            // 
            this.lblNumberOfDM.AutoSize = true;
            this.lblNumberOfDM.Location = new System.Drawing.Point(4, 270);
            this.lblNumberOfDM.Name = "lblNumberOfDM";
            this.lblNumberOfDM.Size = new System.Drawing.Size(75, 16);
            this.lblNumberOfDM.TabIndex = 46;
            this.lblNumberOfDM.Text = "No. Of DM :";
            // 
            // lblNumberOfDGM
            // 
            this.lblNumberOfDGM.AutoSize = true;
            this.lblNumberOfDGM.Location = new System.Drawing.Point(4, 240);
            this.lblNumberOfDGM.Name = "lblNumberOfDGM";
            this.lblNumberOfDGM.Size = new System.Drawing.Size(85, 16);
            this.lblNumberOfDGM.TabIndex = 45;
            this.lblNumberOfDGM.Text = "No. Of DGM :";
            // 
            // lblNumberOfGM
            // 
            this.lblNumberOfGM.AutoSize = true;
            this.lblNumberOfGM.Location = new System.Drawing.Point(4, 210);
            this.lblNumberOfGM.Name = "lblNumberOfGM";
            this.lblNumberOfGM.Size = new System.Drawing.Size(75, 16);
            this.lblNumberOfGM.TabIndex = 44;
            this.lblNumberOfGM.Text = "No. Of GM :";
            // 
            // cmbGroupActive
            // 
            this.cmbGroupActive.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbGroupActive.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbGroupActive.Enabled = false;
            this.cmbGroupActive.FormattingEnabled = true;
            this.cmbGroupActive.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cmbGroupActive.Location = new System.Drawing.Point(110, 87);
            this.cmbGroupActive.Name = "cmbGroupActive";
            this.cmbGroupActive.Size = new System.Drawing.Size(240, 24);
            this.cmbGroupActive.TabIndex = 23;
            this.cmbGroupActive.Text = "Select Active";
            // 
            // lblGroupActive
            // 
            this.lblGroupActive.AutoSize = true;
            this.lblGroupActive.Location = new System.Drawing.Point(4, 90);
            this.lblGroupActive.Name = "lblGroupActive";
            this.lblGroupActive.Size = new System.Drawing.Size(51, 16);
            this.lblGroupActive.TabIndex = 11;
            this.lblGroupActive.Text = "Active :";
            // 
            // txtLocation
            // 
            this.txtLocation.Enabled = false;
            this.txtLocation.Location = new System.Drawing.Point(110, 57);
            this.txtLocation.Name = "txtLocation";
            this.txtLocation.Size = new System.Drawing.Size(240, 22);
            this.txtLocation.TabIndex = 22;
            // 
            // txtGroupName
            // 
            this.txtGroupName.Enabled = false;
            this.txtGroupName.Location = new System.Drawing.Point(110, 27);
            this.txtGroupName.Name = "txtGroupName";
            this.txtGroupName.Size = new System.Drawing.Size(240, 22);
            this.txtGroupName.TabIndex = 21;
            // 
            // lblLocation
            // 
            this.lblLocation.AutoSize = true;
            this.lblLocation.Location = new System.Drawing.Point(4, 60);
            this.lblLocation.Name = "lblLocation";
            this.lblLocation.Size = new System.Drawing.Size(65, 16);
            this.lblLocation.TabIndex = 1;
            this.lblLocation.Text = "Location :";
            // 
            // lblGroupName
            // 
            this.lblGroupName.AutoSize = true;
            this.lblGroupName.Location = new System.Drawing.Point(4, 30);
            this.lblGroupName.Name = "lblGroupName";
            this.lblGroupName.Size = new System.Drawing.Size(90, 16);
            this.lblGroupName.TabIndex = 0;
            this.lblGroupName.Text = "Team Name :";
            // 
            // btnSaveGroup
            // 
            this.btnSaveGroup.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveGroup.Location = new System.Drawing.Point(188, 430);
            this.btnSaveGroup.Name = "btnSaveGroup";
            this.btnSaveGroup.Size = new System.Drawing.Size(180, 25);
            this.btnSaveGroup.TabIndex = 35;
            this.btnSaveGroup.Text = "Save Group";
            this.btnSaveGroup.UseVisualStyleBackColor = true;
            this.btnSaveGroup.Click += new System.EventHandler(this.btnSaveGroup_Click);
            // 
            // tbEmployee
            // 
            this.tbEmployee.Controls.Add(this.btnRefreshEmployee);
            this.tbEmployee.Controls.Add(this.groupBoxSearchEmployee);
            this.tbEmployee.Controls.Add(this.btnAddEmployee);
            this.tbEmployee.Controls.Add(this.dataGridViewEmployeeList);
            this.tbEmployee.Controls.Add(this.groupBoxEmployee);
            this.tbEmployee.Controls.Add(this.btnSaveEmployee);
            this.tbEmployee.Location = new System.Drawing.Point(4, 25);
            this.tbEmployee.Name = "tbEmployee";
            this.tbEmployee.Size = new System.Drawing.Size(1337, 611);
            this.tbEmployee.TabIndex = 5;
            this.tbEmployee.Text = "Employee";
            this.tbEmployee.UseVisualStyleBackColor = true;
            // 
            // btnRefreshEmployee
            // 
            this.btnRefreshEmployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefreshEmployee.Location = new System.Drawing.Point(290, 445);
            this.btnRefreshEmployee.Name = "btnRefreshEmployee";
            this.btnRefreshEmployee.Size = new System.Drawing.Size(76, 25);
            this.btnRefreshEmployee.TabIndex = 77;
            this.btnRefreshEmployee.Text = "Refresh";
            this.btnRefreshEmployee.UseVisualStyleBackColor = true;
            this.btnRefreshEmployee.Click += new System.EventHandler(this.btnRefreshEmployee_Click);
            // 
            // groupBoxSearchEmployee
            // 
            this.groupBoxSearchEmployee.Controls.Add(this.radioBtnShowAllEmp);
            this.groupBoxSearchEmployee.Controls.Add(this.btnSearchEmployee);
            this.groupBoxSearchEmployee.Controls.Add(this.cmbSearchCriteriaForEmployeeByDesignation);
            this.groupBoxSearchEmployee.Controls.Add(this.txtSearchCriteriaForEmployee);
            this.groupBoxSearchEmployee.Controls.Add(this.radioBtnByGroupAndDesignation);
            this.groupBoxSearchEmployee.Controls.Add(this.radioBtnByGroup);
            this.groupBoxSearchEmployee.Controls.Add(this.radioBtnOfficialMobileNumber);
            this.groupBoxSearchEmployee.Controls.Add(this.radioBtnEmployeeName);
            this.groupBoxSearchEmployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxSearchEmployee.Location = new System.Drawing.Point(6, 476);
            this.groupBoxSearchEmployee.Name = "groupBoxSearchEmployee";
            this.groupBoxSearchEmployee.Size = new System.Drawing.Size(321, 132);
            this.groupBoxSearchEmployee.TabIndex = 47;
            this.groupBoxSearchEmployee.TabStop = false;
            this.groupBoxSearchEmployee.Text = "Search";
            // 
            // radioBtnShowAllEmp
            // 
            this.radioBtnShowAllEmp.AutoSize = true;
            this.radioBtnShowAllEmp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioBtnShowAllEmp.Location = new System.Drawing.Point(219, 45);
            this.radioBtnShowAllEmp.Name = "radioBtnShowAllEmp";
            this.radioBtnShowAllEmp.Size = new System.Drawing.Size(77, 20);
            this.radioBtnShowAllEmp.TabIndex = 51;
            this.radioBtnShowAllEmp.TabStop = true;
            this.radioBtnShowAllEmp.Text = "Show All";
            this.radioBtnShowAllEmp.UseVisualStyleBackColor = true;
            this.radioBtnShowAllEmp.CheckedChanged += new System.EventHandler(this.radioBtnShowAllEmp_CheckedChanged);
            // 
            // btnSearchEmployee
            // 
            this.btnSearchEmployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearchEmployee.Location = new System.Drawing.Point(14, 101);
            this.btnSearchEmployee.Name = "btnSearchEmployee";
            this.btnSearchEmployee.Size = new System.Drawing.Size(287, 25);
            this.btnSearchEmployee.TabIndex = 54;
            this.btnSearchEmployee.Text = "Search";
            this.btnSearchEmployee.UseVisualStyleBackColor = true;
            this.btnSearchEmployee.Click += new System.EventHandler(this.btnSearchEmployee_Click);
            // 
            // cmbSearchCriteriaForEmployeeByDesignation
            // 
            this.cmbSearchCriteriaForEmployeeByDesignation.Enabled = false;
            this.cmbSearchCriteriaForEmployeeByDesignation.FormattingEnabled = true;
            this.cmbSearchCriteriaForEmployeeByDesignation.Location = new System.Drawing.Point(193, 71);
            this.cmbSearchCriteriaForEmployeeByDesignation.Name = "cmbSearchCriteriaForEmployeeByDesignation";
            this.cmbSearchCriteriaForEmployeeByDesignation.Size = new System.Drawing.Size(108, 24);
            this.cmbSearchCriteriaForEmployeeByDesignation.TabIndex = 53;
            // 
            // txtSearchCriteriaForEmployee
            // 
            this.txtSearchCriteriaForEmployee.Location = new System.Drawing.Point(14, 73);
            this.txtSearchCriteriaForEmployee.Name = "txtSearchCriteriaForEmployee";
            this.txtSearchCriteriaForEmployee.Size = new System.Drawing.Size(173, 22);
            this.txtSearchCriteriaForEmployee.TabIndex = 52;
            // 
            // radioBtnByGroupAndDesignation
            // 
            this.radioBtnByGroupAndDesignation.AutoSize = true;
            this.radioBtnByGroupAndDesignation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioBtnByGroupAndDesignation.Location = new System.Drawing.Point(14, 45);
            this.radioBtnByGroupAndDesignation.Name = "radioBtnByGroupAndDesignation";
            this.radioBtnByGroupAndDesignation.Size = new System.Drawing.Size(182, 20);
            this.radioBtnByGroupAndDesignation.TabIndex = 50;
            this.radioBtnByGroupAndDesignation.TabStop = true;
            this.radioBtnByGroupAndDesignation.Text = "By Team and Designation";
            this.radioBtnByGroupAndDesignation.UseVisualStyleBackColor = true;
            this.radioBtnByGroupAndDesignation.CheckedChanged += new System.EventHandler(this.radioBtnByGroupAndDesignation_CheckedChanged);
            // 
            // radioBtnByGroup
            // 
            this.radioBtnByGroup.AutoSize = true;
            this.radioBtnByGroup.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioBtnByGroup.Location = new System.Drawing.Point(219, 21);
            this.radioBtnByGroup.Name = "radioBtnByGroup";
            this.radioBtnByGroup.Size = new System.Drawing.Size(81, 20);
            this.radioBtnByGroup.TabIndex = 49;
            this.radioBtnByGroup.TabStop = true;
            this.radioBtnByGroup.Text = "By Team";
            this.radioBtnByGroup.UseVisualStyleBackColor = true;
            this.radioBtnByGroup.CheckedChanged += new System.EventHandler(this.radioBtnByGroup_CheckedChanged);
            // 
            // radioBtnOfficialMobileNumber
            // 
            this.radioBtnOfficialMobileNumber.AutoSize = true;
            this.radioBtnOfficialMobileNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioBtnOfficialMobileNumber.Location = new System.Drawing.Point(110, 21);
            this.radioBtnOfficialMobileNumber.Name = "radioBtnOfficialMobileNumber";
            this.radioBtnOfficialMobileNumber.Size = new System.Drawing.Size(86, 20);
            this.radioBtnOfficialMobileNumber.TabIndex = 48;
            this.radioBtnOfficialMobileNumber.TabStop = true;
            this.radioBtnOfficialMobileNumber.Text = "By Mobile";
            this.radioBtnOfficialMobileNumber.UseVisualStyleBackColor = true;
            this.radioBtnOfficialMobileNumber.CheckedChanged += new System.EventHandler(this.radioBtnOfficialMobileNumber_CheckedChanged);
            // 
            // radioBtnEmployeeName
            // 
            this.radioBtnEmployeeName.AutoSize = true;
            this.radioBtnEmployeeName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioBtnEmployeeName.Location = new System.Drawing.Point(14, 21);
            this.radioBtnEmployeeName.Name = "radioBtnEmployeeName";
            this.radioBtnEmployeeName.Size = new System.Drawing.Size(82, 20);
            this.radioBtnEmployeeName.TabIndex = 47;
            this.radioBtnEmployeeName.TabStop = true;
            this.radioBtnEmployeeName.Text = "By Name";
            this.radioBtnEmployeeName.UseVisualStyleBackColor = true;
            this.radioBtnEmployeeName.CheckedChanged += new System.EventHandler(this.radioBtnEmployeeName_CheckedChanged);
            // 
            // btnAddEmployee
            // 
            this.btnAddEmployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddEmployee.Location = new System.Drawing.Point(6, 445);
            this.btnAddEmployee.Name = "btnAddEmployee";
            this.btnAddEmployee.Size = new System.Drawing.Size(141, 25);
            this.btnAddEmployee.TabIndex = 45;
            this.btnAddEmployee.Text = "Add Employee";
            this.btnAddEmployee.UseVisualStyleBackColor = true;
            this.btnAddEmployee.Click += new System.EventHandler(this.btnAddEmployee_Click);
            // 
            // dataGridViewEmployeeList
            // 
            this.dataGridViewEmployeeList.AllowUserToAddRows = false;
            this.dataGridViewEmployeeList.AllowUserToDeleteRows = false;
            this.dataGridViewEmployeeList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridViewEmployeeList.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridViewEmployeeList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewEmployeeList.Location = new System.Drawing.Point(372, 10);
            this.dataGridViewEmployeeList.MultiSelect = false;
            this.dataGridViewEmployeeList.Name = "dataGridViewEmployeeList";
            this.dataGridViewEmployeeList.ReadOnly = true;
            this.dataGridViewEmployeeList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewEmployeeList.Size = new System.Drawing.Size(960, 595);
            this.dataGridViewEmployeeList.TabIndex = 22;
            this.dataGridViewEmployeeList.TabStop = false;
            this.dataGridViewEmployeeList.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewEmployeeList_CellDoubleClick);
            // 
            // groupBoxEmployee
            // 
            this.groupBoxEmployee.Controls.Add(this.txtDOB);
            this.groupBoxEmployee.Controls.Add(this.txtQuitDate);
            this.groupBoxEmployee.Controls.Add(this.dTPQuitDate);
            this.groupBoxEmployee.Controls.Add(this.lblQuitDate);
            this.groupBoxEmployee.Controls.Add(this.cmbEmployeeActive);
            this.groupBoxEmployee.Controls.Add(this.lblEmployeeActive);
            this.groupBoxEmployee.Controls.Add(this.cmbEmployeeGroup);
            this.groupBoxEmployee.Controls.Add(this.lblEmployeeGroupID);
            this.groupBoxEmployee.Controls.Add(this.txtEmployeeGroupID);
            this.groupBoxEmployee.Controls.Add(this.lblEmployeeGroupName);
            this.groupBoxEmployee.Controls.Add(this.txtOfficialCellNo);
            this.groupBoxEmployee.Controls.Add(this.lblOfficialCellNo);
            this.groupBoxEmployee.Controls.Add(this.cmbEmployeeDepartment);
            this.groupBoxEmployee.Controls.Add(this.lblEmployeeDepartmentID);
            this.groupBoxEmployee.Controls.Add(this.txtEmployeeDepartmentID);
            this.groupBoxEmployee.Controls.Add(this.lblEmployeeDepartment);
            this.groupBoxEmployee.Controls.Add(this.dTPDateOfBirth);
            this.groupBoxEmployee.Controls.Add(this.cmbEmployeeDesignation);
            this.groupBoxEmployee.Controls.Add(this.lblEmployeeDesignationID);
            this.groupBoxEmployee.Controls.Add(this.txtEmployeeDesignationID);
            this.groupBoxEmployee.Controls.Add(this.txtAddress);
            this.groupBoxEmployee.Controls.Add(this.txtEmployeeName);
            this.groupBoxEmployee.Controls.Add(this.lblEmployeeDesignation);
            this.groupBoxEmployee.Controls.Add(this.lblDateOfBirth);
            this.groupBoxEmployee.Controls.Add(this.lblAddress);
            this.groupBoxEmployee.Controls.Add(this.lblEmployeeName);
            this.groupBoxEmployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxEmployee.Location = new System.Drawing.Point(6, 3);
            this.groupBoxEmployee.Name = "groupBoxEmployee";
            this.groupBoxEmployee.Size = new System.Drawing.Size(360, 435);
            this.groupBoxEmployee.TabIndex = 21;
            this.groupBoxEmployee.TabStop = false;
            // 
            // txtDOB
            // 
            this.txtDOB.Enabled = false;
            this.txtDOB.Location = new System.Drawing.Point(110, 132);
            this.txtDOB.Name = "txtDOB";
            this.txtDOB.Size = new System.Drawing.Size(225, 22);
            this.txtDOB.TabIndex = 37;
            // 
            // txtQuitDate
            // 
            this.txtQuitDate.Enabled = false;
            this.txtQuitDate.Location = new System.Drawing.Point(110, 402);
            this.txtQuitDate.Name = "txtQuitDate";
            this.txtQuitDate.Size = new System.Drawing.Size(225, 22);
            this.txtQuitDate.TabIndex = 44;
            // 
            // dTPQuitDate
            // 
            this.dTPQuitDate.Enabled = false;
            this.dTPQuitDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dTPQuitDate.Location = new System.Drawing.Point(334, 402);
            this.dTPQuitDate.Name = "dTPQuitDate";
            this.dTPQuitDate.Size = new System.Drawing.Size(16, 22);
            this.dTPQuitDate.TabIndex = 44;
            this.dTPQuitDate.TabStop = false;
            this.dTPQuitDate.CloseUp += new System.EventHandler(this.dTPQuitDate_CloseUp_1);
            // 
            // lblQuitDate
            // 
            this.lblQuitDate.AutoSize = true;
            this.lblQuitDate.Location = new System.Drawing.Point(4, 405);
            this.lblQuitDate.Name = "lblQuitDate";
            this.lblQuitDate.Size = new System.Drawing.Size(69, 16);
            this.lblQuitDate.TabIndex = 55;
            this.lblQuitDate.Text = "Quit Date :";
            // 
            // cmbEmployeeActive
            // 
            this.cmbEmployeeActive.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbEmployeeActive.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbEmployeeActive.Enabled = false;
            this.cmbEmployeeActive.FormattingEnabled = true;
            this.cmbEmployeeActive.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cmbEmployeeActive.Location = new System.Drawing.Point(110, 372);
            this.cmbEmployeeActive.Name = "cmbEmployeeActive";
            this.cmbEmployeeActive.Size = new System.Drawing.Size(240, 24);
            this.cmbEmployeeActive.TabIndex = 43;
            this.cmbEmployeeActive.Text = "Select Active";
            this.cmbEmployeeActive.SelectedValueChanged += new System.EventHandler(this.cmbEmployeeActive_SelectedValueChanged_1);
            this.cmbEmployeeActive.Leave += new System.EventHandler(this.cmbEmployeeActive_Leave);
            // 
            // lblEmployeeActive
            // 
            this.lblEmployeeActive.AutoSize = true;
            this.lblEmployeeActive.Location = new System.Drawing.Point(4, 375);
            this.lblEmployeeActive.Name = "lblEmployeeActive";
            this.lblEmployeeActive.Size = new System.Drawing.Size(51, 16);
            this.lblEmployeeActive.TabIndex = 48;
            this.lblEmployeeActive.Text = "Active :";
            // 
            // cmbEmployeeGroup
            // 
            this.cmbEmployeeGroup.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbEmployeeGroup.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbEmployeeGroup.Enabled = false;
            this.cmbEmployeeGroup.FormattingEnabled = true;
            this.cmbEmployeeGroup.Location = new System.Drawing.Point(110, 310);
            this.cmbEmployeeGroup.Name = "cmbEmployeeGroup";
            this.cmbEmployeeGroup.Size = new System.Drawing.Size(240, 24);
            this.cmbEmployeeGroup.Sorted = true;
            this.cmbEmployeeGroup.TabIndex = 41;
            this.cmbEmployeeGroup.Text = "Select Team";
            this.cmbEmployeeGroup.SelectedIndexChanged += new System.EventHandler(this.cmbEmployeeGroup_SelectedIndexChanged);
            this.cmbEmployeeGroup.SelectedValueChanged += new System.EventHandler(this.cmbEmployeeGroup_SelectedValueChanged);
            // 
            // lblEmployeeGroupID
            // 
            this.lblEmployeeGroupID.AutoSize = true;
            this.lblEmployeeGroupID.Location = new System.Drawing.Point(4, 345);
            this.lblEmployeeGroupID.Name = "lblEmployeeGroupID";
            this.lblEmployeeGroupID.Size = new System.Drawing.Size(66, 16);
            this.lblEmployeeGroupID.TabIndex = 46;
            this.lblEmployeeGroupID.Text = "Team ID :";
            // 
            // txtEmployeeGroupID
            // 
            this.txtEmployeeGroupID.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtEmployeeGroupID.Location = new System.Drawing.Point(110, 340);
            this.txtEmployeeGroupID.Name = "txtEmployeeGroupID";
            this.txtEmployeeGroupID.ReadOnly = true;
            this.txtEmployeeGroupID.Size = new System.Drawing.Size(240, 22);
            this.txtEmployeeGroupID.TabIndex = 47;
            this.txtEmployeeGroupID.TabStop = false;
            // 
            // lblEmployeeGroupName
            // 
            this.lblEmployeeGroupName.AutoSize = true;
            this.lblEmployeeGroupName.Location = new System.Drawing.Point(4, 315);
            this.lblEmployeeGroupName.Name = "lblEmployeeGroupName";
            this.lblEmployeeGroupName.Size = new System.Drawing.Size(84, 16);
            this.lblEmployeeGroupName.TabIndex = 44;
            this.lblEmployeeGroupName.Text = "Emp. Team :";
            // 
            // txtOfficialCellNo
            // 
            this.txtOfficialCellNo.Enabled = false;
            this.txtOfficialCellNo.Location = new System.Drawing.Point(110, 282);
            this.txtOfficialCellNo.Name = "txtOfficialCellNo";
            this.txtOfficialCellNo.Size = new System.Drawing.Size(240, 22);
            this.txtOfficialCellNo.TabIndex = 40;
            // 
            // lblOfficialCellNo
            // 
            this.lblOfficialCellNo.AutoSize = true;
            this.lblOfficialCellNo.Location = new System.Drawing.Point(4, 285);
            this.lblOfficialCellNo.Name = "lblOfficialCellNo";
            this.lblOfficialCellNo.Size = new System.Drawing.Size(101, 16);
            this.lblOfficialCellNo.TabIndex = 42;
            this.lblOfficialCellNo.Text = "Official Cell No :";
            // 
            // cmbEmployeeDepartment
            // 
            this.cmbEmployeeDepartment.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbEmployeeDepartment.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbEmployeeDepartment.Enabled = false;
            this.cmbEmployeeDepartment.FormattingEnabled = true;
            this.cmbEmployeeDepartment.Location = new System.Drawing.Point(110, 220);
            this.cmbEmployeeDepartment.Name = "cmbEmployeeDepartment";
            this.cmbEmployeeDepartment.Size = new System.Drawing.Size(240, 24);
            this.cmbEmployeeDepartment.TabIndex = 39;
            this.cmbEmployeeDepartment.Text = "Select Department";
            this.cmbEmployeeDepartment.SelectedIndexChanged += new System.EventHandler(this.cmbEmployeeDepartment_SelectedIndexChanged);
            this.cmbEmployeeDepartment.SelectedValueChanged += new System.EventHandler(this.cmbEmployeeDepartment_SelectedValueChanged);
            this.cmbEmployeeDepartment.Click += new System.EventHandler(this.cmbEmployeeDepartment_Click);
            // 
            // lblEmployeeDepartmentID
            // 
            this.lblEmployeeDepartmentID.AutoSize = true;
            this.lblEmployeeDepartmentID.Location = new System.Drawing.Point(4, 255);
            this.lblEmployeeDepartmentID.Name = "lblEmployeeDepartmentID";
            this.lblEmployeeDepartmentID.Size = new System.Drawing.Size(100, 16);
            this.lblEmployeeDepartmentID.TabIndex = 40;
            this.lblEmployeeDepartmentID.Text = "Department ID :";
            // 
            // txtEmployeeDepartmentID
            // 
            this.txtEmployeeDepartmentID.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtEmployeeDepartmentID.Location = new System.Drawing.Point(110, 250);
            this.txtEmployeeDepartmentID.Name = "txtEmployeeDepartmentID";
            this.txtEmployeeDepartmentID.ReadOnly = true;
            this.txtEmployeeDepartmentID.Size = new System.Drawing.Size(240, 22);
            this.txtEmployeeDepartmentID.TabIndex = 41;
            this.txtEmployeeDepartmentID.TabStop = false;
            // 
            // lblEmployeeDepartment
            // 
            this.lblEmployeeDepartment.AutoSize = true;
            this.lblEmployeeDepartment.Location = new System.Drawing.Point(4, 225);
            this.lblEmployeeDepartment.Name = "lblEmployeeDepartment";
            this.lblEmployeeDepartment.Size = new System.Drawing.Size(84, 16);
            this.lblEmployeeDepartment.TabIndex = 39;
            this.lblEmployeeDepartment.Text = "Department :";
            // 
            // dTPDateOfBirth
            // 
            this.dTPDateOfBirth.Enabled = false;
            this.dTPDateOfBirth.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dTPDateOfBirth.Location = new System.Drawing.Point(334, 132);
            this.dTPDateOfBirth.Name = "dTPDateOfBirth";
            this.dTPDateOfBirth.Size = new System.Drawing.Size(16, 22);
            this.dTPDateOfBirth.TabIndex = 37;
            this.dTPDateOfBirth.CloseUp += new System.EventHandler(this.dTPDateOfBirth_CloseUp_1);
            // 
            // cmbEmployeeDesignation
            // 
            this.cmbEmployeeDesignation.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbEmployeeDesignation.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbEmployeeDesignation.Enabled = false;
            this.cmbEmployeeDesignation.FormattingEnabled = true;
            this.cmbEmployeeDesignation.Location = new System.Drawing.Point(110, 160);
            this.cmbEmployeeDesignation.Name = "cmbEmployeeDesignation";
            this.cmbEmployeeDesignation.Size = new System.Drawing.Size(240, 24);
            this.cmbEmployeeDesignation.TabIndex = 38;
            this.cmbEmployeeDesignation.Text = "Select Designation";
            this.cmbEmployeeDesignation.SelectedIndexChanged += new System.EventHandler(this.cmbEmployeeDesignation_SelectedIndexChanged);
            this.cmbEmployeeDesignation.SelectedValueChanged += new System.EventHandler(this.cmbEmployeeDesignation_SelectedValueChanged);
            this.cmbEmployeeDesignation.Leave += new System.EventHandler(this.cmbEmployeeDesignation_Leave);
            // 
            // lblEmployeeDesignationID
            // 
            this.lblEmployeeDesignationID.AutoSize = true;
            this.lblEmployeeDesignationID.Location = new System.Drawing.Point(4, 195);
            this.lblEmployeeDesignationID.Name = "lblEmployeeDesignationID";
            this.lblEmployeeDesignationID.Size = new System.Drawing.Size(102, 16);
            this.lblEmployeeDesignationID.TabIndex = 9;
            this.lblEmployeeDesignationID.Text = "Designation ID :";
            // 
            // txtEmployeeDesignationID
            // 
            this.txtEmployeeDesignationID.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtEmployeeDesignationID.Location = new System.Drawing.Point(110, 190);
            this.txtEmployeeDesignationID.Name = "txtEmployeeDesignationID";
            this.txtEmployeeDesignationID.ReadOnly = true;
            this.txtEmployeeDesignationID.Size = new System.Drawing.Size(240, 22);
            this.txtEmployeeDesignationID.TabIndex = 17;
            this.txtEmployeeDesignationID.TabStop = false;
            // 
            // txtAddress
            // 
            this.txtAddress.Enabled = false;
            this.txtAddress.Location = new System.Drawing.Point(110, 57);
            this.txtAddress.Multiline = true;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(240, 67);
            this.txtAddress.TabIndex = 36;
            // 
            // txtEmployeeName
            // 
            this.txtEmployeeName.Enabled = false;
            this.txtEmployeeName.Location = new System.Drawing.Point(110, 27);
            this.txtEmployeeName.Name = "txtEmployeeName";
            this.txtEmployeeName.Size = new System.Drawing.Size(240, 22);
            this.txtEmployeeName.TabIndex = 35;
            // 
            // lblEmployeeDesignation
            // 
            this.lblEmployeeDesignation.AutoSize = true;
            this.lblEmployeeDesignation.Location = new System.Drawing.Point(4, 165);
            this.lblEmployeeDesignation.Name = "lblEmployeeDesignation";
            this.lblEmployeeDesignation.Size = new System.Drawing.Size(86, 16);
            this.lblEmployeeDesignation.TabIndex = 3;
            this.lblEmployeeDesignation.Text = "Designation :";
            // 
            // lblDateOfBirth
            // 
            this.lblDateOfBirth.AutoSize = true;
            this.lblDateOfBirth.Location = new System.Drawing.Point(4, 135);
            this.lblDateOfBirth.Name = "lblDateOfBirth";
            this.lblDateOfBirth.Size = new System.Drawing.Size(86, 16);
            this.lblDateOfBirth.TabIndex = 2;
            this.lblDateOfBirth.Text = "Date of Birth :";
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.Location = new System.Drawing.Point(4, 60);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(65, 16);
            this.lblAddress.TabIndex = 1;
            this.lblAddress.Text = "Address :";
            // 
            // lblEmployeeName
            // 
            this.lblEmployeeName.AutoSize = true;
            this.lblEmployeeName.Location = new System.Drawing.Point(4, 30);
            this.lblEmployeeName.Name = "lblEmployeeName";
            this.lblEmployeeName.Size = new System.Drawing.Size(85, 16);
            this.lblEmployeeName.TabIndex = 0;
            this.lblEmployeeName.Text = "Emp. Name :";
            // 
            // btnSaveEmployee
            // 
            this.btnSaveEmployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveEmployee.Location = new System.Drawing.Point(148, 445);
            this.btnSaveEmployee.Name = "btnSaveEmployee";
            this.btnSaveEmployee.Size = new System.Drawing.Size(141, 25);
            this.btnSaveEmployee.TabIndex = 46;
            this.btnSaveEmployee.Text = "Save Employee";
            this.btnSaveEmployee.UseVisualStyleBackColor = true;
            this.btnSaveEmployee.Click += new System.EventHandler(this.btnSaveEmployee_Click);
            // 
            // tbDivision
            // 
            this.tbDivision.Controls.Add(this.btnRefreshDivision);
            this.tbDivision.Controls.Add(this.btnEnableDisableDivision);
            this.tbDivision.Controls.Add(this.btnDivisionReport);
            this.tbDivision.Controls.Add(this.dgvPreviousAddedEmpList);
            this.tbDivision.Controls.Add(this.cmbSelectDivisionForUpdate);
            this.tbDivision.Controls.Add(this.dgvLoadDistinctDivision);
            this.tbDivision.Controls.Add(this.btnAddOrEditDataOfPrevDivision);
            this.tbDivision.Controls.Add(this.btnAddToTempDivision);
            this.tbDivision.Controls.Add(this.dgvLoadTempDivision);
            this.tbDivision.Controls.Add(this.dgvLoadGroup);
            this.tbDivision.Controls.Add(this.dgvDivision);
            this.tbDivision.Controls.Add(this.btnAddDivision);
            this.tbDivision.Controls.Add(this.btnSaveDivision);
            this.tbDivision.Controls.Add(this.groupBoxDivision);
            this.tbDivision.Location = new System.Drawing.Point(4, 25);
            this.tbDivision.Name = "tbDivision";
            this.tbDivision.Size = new System.Drawing.Size(1337, 611);
            this.tbDivision.TabIndex = 17;
            this.tbDivision.Text = "Division";
            this.tbDivision.UseVisualStyleBackColor = true;
            // 
            // btnRefreshDivision
            // 
            this.btnRefreshDivision.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefreshDivision.Location = new System.Drawing.Point(4, 521);
            this.btnRefreshDivision.Name = "btnRefreshDivision";
            this.btnRefreshDivision.Size = new System.Drawing.Size(362, 25);
            this.btnRefreshDivision.TabIndex = 130;
            this.btnRefreshDivision.Text = "Refresh";
            this.btnRefreshDivision.UseVisualStyleBackColor = true;
            this.btnRefreshDivision.Click += new System.EventHandler(this.btnRefreshDivision_Click);
            // 
            // btnEnableDisableDivision
            // 
            this.btnEnableDisableDivision.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEnableDisableDivision.Location = new System.Drawing.Point(4, 490);
            this.btnEnableDisableDivision.Name = "btnEnableDisableDivision";
            this.btnEnableDisableDivision.Size = new System.Drawing.Size(362, 25);
            this.btnEnableDisableDivision.TabIndex = 128;
            this.btnEnableDisableDivision.Text = "Enable / Disable Division";
            this.btnEnableDisableDivision.UseVisualStyleBackColor = true;
            this.btnEnableDisableDivision.Click += new System.EventHandler(this.btnEnableDisableDivision_Click);
            // 
            // btnDivisionReport
            // 
            this.btnDivisionReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDivisionReport.Location = new System.Drawing.Point(4, 463);
            this.btnDivisionReport.Name = "btnDivisionReport";
            this.btnDivisionReport.Size = new System.Drawing.Size(362, 25);
            this.btnDivisionReport.TabIndex = 127;
            this.btnDivisionReport.Text = "Division Report";
            this.btnDivisionReport.UseVisualStyleBackColor = true;
            this.btnDivisionReport.Click += new System.EventHandler(this.btnDivisionReport_Click);
            // 
            // dgvPreviousAddedEmpList
            // 
            this.dgvPreviousAddedEmpList.AllowUserToAddRows = false;
            this.dgvPreviousAddedEmpList.AllowUserToDeleteRows = false;
            this.dgvPreviousAddedEmpList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvPreviousAddedEmpList.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dgvPreviousAddedEmpList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPreviousAddedEmpList.Location = new System.Drawing.Point(372, 56);
            this.dgvPreviousAddedEmpList.MultiSelect = false;
            this.dgvPreviousAddedEmpList.Name = "dgvPreviousAddedEmpList";
            this.dgvPreviousAddedEmpList.ReadOnly = true;
            this.dgvPreviousAddedEmpList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvPreviousAddedEmpList.Size = new System.Drawing.Size(960, 124);
            this.dgvPreviousAddedEmpList.TabIndex = 126;
            this.dgvPreviousAddedEmpList.Visible = false;
            // 
            // cmbSelectDivisionForUpdate
            // 
            this.cmbSelectDivisionForUpdate.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSelectDivisionForUpdate.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectDivisionForUpdate.FormattingEnabled = true;
            this.cmbSelectDivisionForUpdate.Location = new System.Drawing.Point(6, 432);
            this.cmbSelectDivisionForUpdate.Name = "cmbSelectDivisionForUpdate";
            this.cmbSelectDivisionForUpdate.Size = new System.Drawing.Size(170, 24);
            this.cmbSelectDivisionForUpdate.Sorted = true;
            this.cmbSelectDivisionForUpdate.TabIndex = 122;
            this.cmbSelectDivisionForUpdate.Text = "Select Division";
            this.cmbSelectDivisionForUpdate.ValueMemberChanged += new System.EventHandler(this.cmbSelectDivisionForUpdate_ValueMemberChanged);
            this.cmbSelectDivisionForUpdate.TextChanged += new System.EventHandler(this.cmbSelectDivisionForUpdate_TextChanged);
            // 
            // dgvLoadDistinctDivision
            // 
            this.dgvLoadDistinctDivision.AllowUserToAddRows = false;
            this.dgvLoadDistinctDivision.AllowUserToDeleteRows = false;
            this.dgvLoadDistinctDivision.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvLoadDistinctDivision.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dgvLoadDistinctDivision.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLoadDistinctDivision.Location = new System.Drawing.Point(372, 220);
            this.dgvLoadDistinctDivision.MultiSelect = false;
            this.dgvLoadDistinctDivision.Name = "dgvLoadDistinctDivision";
            this.dgvLoadDistinctDivision.ReadOnly = true;
            this.dgvLoadDistinctDivision.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvLoadDistinctDivision.Size = new System.Drawing.Size(960, 100);
            this.dgvLoadDistinctDivision.TabIndex = 125;
            this.dgvLoadDistinctDivision.TabStop = false;
            this.dgvLoadDistinctDivision.Visible = false;
            this.dgvLoadDistinctDivision.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvLoadDistinctDivision_CellDoubleClick);
            // 
            // btnAddOrEditDataOfPrevDivision
            // 
            this.btnAddOrEditDataOfPrevDivision.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddOrEditDataOfPrevDivision.Location = new System.Drawing.Point(176, 432);
            this.btnAddOrEditDataOfPrevDivision.Name = "btnAddOrEditDataOfPrevDivision";
            this.btnAddOrEditDataOfPrevDivision.Size = new System.Drawing.Size(190, 25);
            this.btnAddOrEditDataOfPrevDivision.TabIndex = 124;
            this.btnAddOrEditDataOfPrevDivision.Text = "Update Div. by Add Emp.";
            this.btnAddOrEditDataOfPrevDivision.UseVisualStyleBackColor = true;
            this.btnAddOrEditDataOfPrevDivision.Click += new System.EventHandler(this.btnAddOrEditDataOfPrevDivision_Click);
            // 
            // btnAddToTempDivision
            // 
            this.btnAddToTempDivision.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddToTempDivision.Location = new System.Drawing.Point(135, 401);
            this.btnAddToTempDivision.Name = "btnAddToTempDivision";
            this.btnAddToTempDivision.Size = new System.Drawing.Size(100, 25);
            this.btnAddToTempDivision.TabIndex = 72;
            this.btnAddToTempDivision.Text = "Add to List";
            this.btnAddToTempDivision.UseVisualStyleBackColor = true;
            this.btnAddToTempDivision.Click += new System.EventHandler(this.btnAddToTempDivision_Click);
            // 
            // dgvLoadTempDivision
            // 
            this.dgvLoadTempDivision.AllowUserToAddRows = false;
            this.dgvLoadTempDivision.AllowUserToDeleteRows = false;
            this.dgvLoadTempDivision.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvLoadTempDivision.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dgvLoadTempDivision.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLoadTempDivision.Location = new System.Drawing.Point(372, 490);
            this.dgvLoadTempDivision.MultiSelect = false;
            this.dgvLoadTempDivision.Name = "dgvLoadTempDivision";
            this.dgvLoadTempDivision.ReadOnly = true;
            this.dgvLoadTempDivision.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvLoadTempDivision.Size = new System.Drawing.Size(960, 100);
            this.dgvLoadTempDivision.TabIndex = 71;
            this.dgvLoadTempDivision.TabStop = false;
            this.dgvLoadTempDivision.Visible = false;
            // 
            // dgvLoadGroup
            // 
            this.dgvLoadGroup.AllowUserToAddRows = false;
            this.dgvLoadGroup.AllowUserToDeleteRows = false;
            this.dgvLoadGroup.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvLoadGroup.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dgvLoadGroup.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLoadGroup.Location = new System.Drawing.Point(372, 381);
            this.dgvLoadGroup.MultiSelect = false;
            this.dgvLoadGroup.Name = "dgvLoadGroup";
            this.dgvLoadGroup.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvLoadGroup.Size = new System.Drawing.Size(960, 100);
            this.dgvLoadGroup.TabIndex = 70;
            this.dgvLoadGroup.Visible = false;
            // 
            // dgvDivision
            // 
            this.dgvDivision.AllowUserToAddRows = false;
            this.dgvDivision.AllowUserToDeleteRows = false;
            this.dgvDivision.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvDivision.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dgvDivision.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDivision.Location = new System.Drawing.Point(372, 10);
            this.dgvDivision.MultiSelect = false;
            this.dgvDivision.Name = "dgvDivision";
            this.dgvDivision.ReadOnly = true;
            this.dgvDivision.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDivision.Size = new System.Drawing.Size(960, 595);
            this.dgvDivision.TabIndex = 52;
            this.dgvDivision.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDivision_CellDoubleClick);
            // 
            // btnAddDivision
            // 
            this.btnAddDivision.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddDivision.Location = new System.Drawing.Point(4, 401);
            this.btnAddDivision.Name = "btnAddDivision";
            this.btnAddDivision.Size = new System.Drawing.Size(130, 25);
            this.btnAddDivision.TabIndex = 46;
            this.btnAddDivision.Text = "Add Division";
            this.btnAddDivision.UseVisualStyleBackColor = true;
            this.btnAddDivision.Click += new System.EventHandler(this.btnAddDivision_Click);
            // 
            // btnSaveDivision
            // 
            this.btnSaveDivision.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveDivision.Location = new System.Drawing.Point(236, 401);
            this.btnSaveDivision.Name = "btnSaveDivision";
            this.btnSaveDivision.Size = new System.Drawing.Size(130, 25);
            this.btnSaveDivision.TabIndex = 47;
            this.btnSaveDivision.Text = "Save Division";
            this.btnSaveDivision.UseVisualStyleBackColor = true;
            this.btnSaveDivision.Click += new System.EventHandler(this.btnSaveDivision_Click);
            // 
            // groupBoxDivision
            // 
            this.groupBoxDivision.Controls.Add(this.cmbSelectRSMForDivision);
            this.groupBoxDivision.Controls.Add(this.lblSelectRSM);
            this.groupBoxDivision.Controls.Add(this.cmbActiveForDivision);
            this.groupBoxDivision.Controls.Add(this.lblActiveForDivision);
            this.groupBoxDivision.Controls.Add(this.btnLoadGroup);
            this.groupBoxDivision.Controls.Add(this.cmbSelectSRForDivision);
            this.groupBoxDivision.Controls.Add(this.lblSelectSR);
            this.groupBoxDivision.Controls.Add(this.cmbSelectTSMForDivision);
            this.groupBoxDivision.Controls.Add(this.lblSelectTSM);
            this.groupBoxDivision.Controls.Add(this.cmbSelectSMForDivision);
            this.groupBoxDivision.Controls.Add(this.lblSelectSM);
            this.groupBoxDivision.Controls.Add(this.cmbSelectASMForDivision);
            this.groupBoxDivision.Controls.Add(this.lblSelectASM);
            this.groupBoxDivision.Controls.Add(this.cmbSelectDMForDivision);
            this.groupBoxDivision.Controls.Add(this.lblSelectDM);
            this.groupBoxDivision.Controls.Add(this.cmbSelectDGMForDivision);
            this.groupBoxDivision.Controls.Add(this.lblSelectDGM);
            this.groupBoxDivision.Controls.Add(this.cmbSelectGMForDivision);
            this.groupBoxDivision.Controls.Add(this.lblSelectGM);
            this.groupBoxDivision.Controls.Add(this.cmbSelectDOForDivision);
            this.groupBoxDivision.Controls.Add(this.lblSelectDO);
            this.groupBoxDivision.Controls.Add(this.txtDivisionName);
            this.groupBoxDivision.Controls.Add(this.label2);
            this.groupBoxDivision.Controls.Add(this.lblTeamID);
            this.groupBoxDivision.Controls.Add(this.txtTeamIDForDivision);
            this.groupBoxDivision.Controls.Add(this.cmbSelectTeam);
            this.groupBoxDivision.Controls.Add(this.lblSelectTeam);
            this.groupBoxDivision.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxDivision.Location = new System.Drawing.Point(6, 3);
            this.groupBoxDivision.Name = "groupBoxDivision";
            this.groupBoxDivision.Size = new System.Drawing.Size(360, 391);
            this.groupBoxDivision.TabIndex = 11;
            this.groupBoxDivision.TabStop = false;
            // 
            // cmbSelectRSMForDivision
            // 
            this.cmbSelectRSMForDivision.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSelectRSMForDivision.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectRSMForDivision.Enabled = false;
            this.cmbSelectRSMForDivision.FormattingEnabled = true;
            this.cmbSelectRSMForDivision.Location = new System.Drawing.Point(110, 357);
            this.cmbSelectRSMForDivision.Name = "cmbSelectRSMForDivision";
            this.cmbSelectRSMForDivision.Size = new System.Drawing.Size(240, 24);
            this.cmbSelectRSMForDivision.Sorted = true;
            this.cmbSelectRSMForDivision.TabIndex = 121;
            this.cmbSelectRSMForDivision.Text = "Select RSM";
            this.cmbSelectRSMForDivision.Visible = false;
            // 
            // lblSelectRSM
            // 
            this.lblSelectRSM.AutoSize = true;
            this.lblSelectRSM.Location = new System.Drawing.Point(4, 357);
            this.lblSelectRSM.Name = "lblSelectRSM";
            this.lblSelectRSM.Size = new System.Drawing.Size(85, 16);
            this.lblSelectRSM.TabIndex = 120;
            this.lblSelectRSM.Text = "Select RSM :";
            this.lblSelectRSM.Visible = false;
            // 
            // cmbActiveForDivision
            // 
            this.cmbActiveForDivision.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbActiveForDivision.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbActiveForDivision.Enabled = false;
            this.cmbActiveForDivision.FormattingEnabled = true;
            this.cmbActiveForDivision.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cmbActiveForDivision.Location = new System.Drawing.Point(110, 105);
            this.cmbActiveForDivision.Name = "cmbActiveForDivision";
            this.cmbActiveForDivision.Size = new System.Drawing.Size(240, 24);
            this.cmbActiveForDivision.TabIndex = 47;
            this.cmbActiveForDivision.Text = "Select Active";
            // 
            // lblActiveForDivision
            // 
            this.lblActiveForDivision.AutoSize = true;
            this.lblActiveForDivision.Location = new System.Drawing.Point(4, 105);
            this.lblActiveForDivision.Name = "lblActiveForDivision";
            this.lblActiveForDivision.Size = new System.Drawing.Size(51, 16);
            this.lblActiveForDivision.TabIndex = 119;
            this.lblActiveForDivision.Text = "Active :";
            // 
            // btnLoadGroup
            // 
            this.btnLoadGroup.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoadGroup.Location = new System.Drawing.Point(255, 51);
            this.btnLoadGroup.Name = "btnLoadGroup";
            this.btnLoadGroup.Size = new System.Drawing.Size(95, 25);
            this.btnLoadGroup.TabIndex = 48;
            this.btnLoadGroup.Text = "Load Team";
            this.btnLoadGroup.UseVisualStyleBackColor = true;
            this.btnLoadGroup.Click += new System.EventHandler(this.btnLoadGroup_Click);
            // 
            // cmbSelectSRForDivision
            // 
            this.cmbSelectSRForDivision.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSelectSRForDivision.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectSRForDivision.Enabled = false;
            this.cmbSelectSRForDivision.FormattingEnabled = true;
            this.cmbSelectSRForDivision.Location = new System.Drawing.Point(110, 329);
            this.cmbSelectSRForDivision.Name = "cmbSelectSRForDivision";
            this.cmbSelectSRForDivision.Size = new System.Drawing.Size(240, 24);
            this.cmbSelectSRForDivision.Sorted = true;
            this.cmbSelectSRForDivision.TabIndex = 113;
            this.cmbSelectSRForDivision.Text = "Select SR";
            this.cmbSelectSRForDivision.Visible = false;
            // 
            // lblSelectSR
            // 
            this.lblSelectSR.AutoSize = true;
            this.lblSelectSR.Location = new System.Drawing.Point(4, 329);
            this.lblSelectSR.Name = "lblSelectSR";
            this.lblSelectSR.Size = new System.Drawing.Size(74, 16);
            this.lblSelectSR.TabIndex = 112;
            this.lblSelectSR.Text = "Select SR :";
            this.lblSelectSR.Visible = false;
            // 
            // cmbSelectTSMForDivision
            // 
            this.cmbSelectTSMForDivision.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSelectTSMForDivision.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectTSMForDivision.Enabled = false;
            this.cmbSelectTSMForDivision.FormattingEnabled = true;
            this.cmbSelectTSMForDivision.Location = new System.Drawing.Point(110, 301);
            this.cmbSelectTSMForDivision.Name = "cmbSelectTSMForDivision";
            this.cmbSelectTSMForDivision.Size = new System.Drawing.Size(240, 24);
            this.cmbSelectTSMForDivision.Sorted = true;
            this.cmbSelectTSMForDivision.TabIndex = 109;
            this.cmbSelectTSMForDivision.Text = "Select TSM";
            this.cmbSelectTSMForDivision.Visible = false;
            // 
            // lblSelectTSM
            // 
            this.lblSelectTSM.AutoSize = true;
            this.lblSelectTSM.Location = new System.Drawing.Point(4, 301);
            this.lblSelectTSM.Name = "lblSelectTSM";
            this.lblSelectTSM.Size = new System.Drawing.Size(84, 16);
            this.lblSelectTSM.TabIndex = 108;
            this.lblSelectTSM.Text = "Select TSM :";
            this.lblSelectTSM.Visible = false;
            // 
            // cmbSelectSMForDivision
            // 
            this.cmbSelectSMForDivision.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSelectSMForDivision.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectSMForDivision.Enabled = false;
            this.cmbSelectSMForDivision.FormattingEnabled = true;
            this.cmbSelectSMForDivision.Location = new System.Drawing.Point(110, 245);
            this.cmbSelectSMForDivision.Name = "cmbSelectSMForDivision";
            this.cmbSelectSMForDivision.Size = new System.Drawing.Size(240, 24);
            this.cmbSelectSMForDivision.Sorted = true;
            this.cmbSelectSMForDivision.TabIndex = 105;
            this.cmbSelectSMForDivision.Text = "Select SM";
            this.cmbSelectSMForDivision.Visible = false;
            // 
            // lblSelectSM
            // 
            this.lblSelectSM.AutoSize = true;
            this.lblSelectSM.Location = new System.Drawing.Point(4, 245);
            this.lblSelectSM.Name = "lblSelectSM";
            this.lblSelectSM.Size = new System.Drawing.Size(75, 16);
            this.lblSelectSM.TabIndex = 104;
            this.lblSelectSM.Text = "Select SM :";
            this.lblSelectSM.Visible = false;
            // 
            // cmbSelectASMForDivision
            // 
            this.cmbSelectASMForDivision.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSelectASMForDivision.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectASMForDivision.Enabled = false;
            this.cmbSelectASMForDivision.FormattingEnabled = true;
            this.cmbSelectASMForDivision.Location = new System.Drawing.Point(110, 273);
            this.cmbSelectASMForDivision.Name = "cmbSelectASMForDivision";
            this.cmbSelectASMForDivision.Size = new System.Drawing.Size(240, 24);
            this.cmbSelectASMForDivision.Sorted = true;
            this.cmbSelectASMForDivision.TabIndex = 101;
            this.cmbSelectASMForDivision.Text = "Select ASM";
            this.cmbSelectASMForDivision.Visible = false;
            // 
            // lblSelectASM
            // 
            this.lblSelectASM.AutoSize = true;
            this.lblSelectASM.Location = new System.Drawing.Point(4, 273);
            this.lblSelectASM.Name = "lblSelectASM";
            this.lblSelectASM.Size = new System.Drawing.Size(84, 16);
            this.lblSelectASM.TabIndex = 100;
            this.lblSelectASM.Text = "Select ASM :";
            this.lblSelectASM.Visible = false;
            // 
            // cmbSelectDMForDivision
            // 
            this.cmbSelectDMForDivision.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSelectDMForDivision.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectDMForDivision.Enabled = false;
            this.cmbSelectDMForDivision.FormattingEnabled = true;
            this.cmbSelectDMForDivision.Location = new System.Drawing.Point(110, 217);
            this.cmbSelectDMForDivision.Name = "cmbSelectDMForDivision";
            this.cmbSelectDMForDivision.Size = new System.Drawing.Size(240, 24);
            this.cmbSelectDMForDivision.Sorted = true;
            this.cmbSelectDMForDivision.TabIndex = 97;
            this.cmbSelectDMForDivision.Text = "Select DM";
            this.cmbSelectDMForDivision.Visible = false;
            // 
            // lblSelectDM
            // 
            this.lblSelectDM.AutoSize = true;
            this.lblSelectDM.Location = new System.Drawing.Point(4, 217);
            this.lblSelectDM.Name = "lblSelectDM";
            this.lblSelectDM.Size = new System.Drawing.Size(76, 16);
            this.lblSelectDM.TabIndex = 96;
            this.lblSelectDM.Text = "Select DM :";
            this.lblSelectDM.Visible = false;
            // 
            // cmbSelectDGMForDivision
            // 
            this.cmbSelectDGMForDivision.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSelectDGMForDivision.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectDGMForDivision.Enabled = false;
            this.cmbSelectDGMForDivision.FormattingEnabled = true;
            this.cmbSelectDGMForDivision.Location = new System.Drawing.Point(110, 189);
            this.cmbSelectDGMForDivision.Name = "cmbSelectDGMForDivision";
            this.cmbSelectDGMForDivision.Size = new System.Drawing.Size(240, 24);
            this.cmbSelectDGMForDivision.Sorted = true;
            this.cmbSelectDGMForDivision.TabIndex = 93;
            this.cmbSelectDGMForDivision.Text = "Select DGM";
            this.cmbSelectDGMForDivision.Visible = false;
            // 
            // lblSelectDGM
            // 
            this.lblSelectDGM.AutoSize = true;
            this.lblSelectDGM.Location = new System.Drawing.Point(4, 189);
            this.lblSelectDGM.Name = "lblSelectDGM";
            this.lblSelectDGM.Size = new System.Drawing.Size(86, 16);
            this.lblSelectDGM.TabIndex = 92;
            this.lblSelectDGM.Text = "Select DGM :";
            this.lblSelectDGM.Visible = false;
            // 
            // cmbSelectGMForDivision
            // 
            this.cmbSelectGMForDivision.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSelectGMForDivision.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectGMForDivision.Enabled = false;
            this.cmbSelectGMForDivision.FormattingEnabled = true;
            this.cmbSelectGMForDivision.Location = new System.Drawing.Point(110, 161);
            this.cmbSelectGMForDivision.Name = "cmbSelectGMForDivision";
            this.cmbSelectGMForDivision.Size = new System.Drawing.Size(240, 24);
            this.cmbSelectGMForDivision.Sorted = true;
            this.cmbSelectGMForDivision.TabIndex = 89;
            this.cmbSelectGMForDivision.Text = "Select GM";
            this.cmbSelectGMForDivision.Visible = false;
            // 
            // lblSelectGM
            // 
            this.lblSelectGM.AutoSize = true;
            this.lblSelectGM.Location = new System.Drawing.Point(4, 161);
            this.lblSelectGM.Name = "lblSelectGM";
            this.lblSelectGM.Size = new System.Drawing.Size(76, 16);
            this.lblSelectGM.TabIndex = 88;
            this.lblSelectGM.Text = "Select GM :";
            this.lblSelectGM.Visible = false;
            // 
            // cmbSelectDOForDivision
            // 
            this.cmbSelectDOForDivision.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSelectDOForDivision.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectDOForDivision.Enabled = false;
            this.cmbSelectDOForDivision.FormattingEnabled = true;
            this.cmbSelectDOForDivision.Location = new System.Drawing.Point(110, 133);
            this.cmbSelectDOForDivision.Name = "cmbSelectDOForDivision";
            this.cmbSelectDOForDivision.Size = new System.Drawing.Size(240, 24);
            this.cmbSelectDOForDivision.Sorted = true;
            this.cmbSelectDOForDivision.TabIndex = 85;
            this.cmbSelectDOForDivision.Text = "Select DO";
            this.cmbSelectDOForDivision.Visible = false;
            // 
            // lblSelectDO
            // 
            this.lblSelectDO.AutoSize = true;
            this.lblSelectDO.Location = new System.Drawing.Point(4, 133);
            this.lblSelectDO.Name = "lblSelectDO";
            this.lblSelectDO.Size = new System.Drawing.Size(75, 16);
            this.lblSelectDO.TabIndex = 84;
            this.lblSelectDO.Text = "Select DO :";
            this.lblSelectDO.Visible = false;
            // 
            // txtDivisionName
            // 
            this.txtDivisionName.Enabled = false;
            this.txtDivisionName.Location = new System.Drawing.Point(110, 79);
            this.txtDivisionName.Name = "txtDivisionName";
            this.txtDivisionName.Size = new System.Drawing.Size(240, 22);
            this.txtDivisionName.TabIndex = 46;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(4, 82);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 16);
            this.label2.TabIndex = 50;
            this.label2.Text = "Division Name :";
            // 
            // lblTeamID
            // 
            this.lblTeamID.AutoSize = true;
            this.lblTeamID.Location = new System.Drawing.Point(4, 52);
            this.lblTeamID.Name = "lblTeamID";
            this.lblTeamID.Size = new System.Drawing.Size(66, 16);
            this.lblTeamID.TabIndex = 48;
            this.lblTeamID.Text = "Team ID :";
            // 
            // txtTeamIDForDivision
            // 
            this.txtTeamIDForDivision.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtTeamIDForDivision.Location = new System.Drawing.Point(110, 52);
            this.txtTeamIDForDivision.Name = "txtTeamIDForDivision";
            this.txtTeamIDForDivision.ReadOnly = true;
            this.txtTeamIDForDivision.Size = new System.Drawing.Size(144, 22);
            this.txtTeamIDForDivision.TabIndex = 49;
            this.txtTeamIDForDivision.TabStop = false;
            // 
            // cmbSelectTeam
            // 
            this.cmbSelectTeam.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSelectTeam.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectTeam.Enabled = false;
            this.cmbSelectTeam.FormattingEnabled = true;
            this.cmbSelectTeam.Location = new System.Drawing.Point(110, 27);
            this.cmbSelectTeam.Name = "cmbSelectTeam";
            this.cmbSelectTeam.Size = new System.Drawing.Size(240, 24);
            this.cmbSelectTeam.Sorted = true;
            this.cmbSelectTeam.TabIndex = 45;
            this.cmbSelectTeam.Text = "Select Team";
            this.cmbSelectTeam.SelectedIndexChanged += new System.EventHandler(this.cmbSelectTeam_SelectedIndexChanged);
            this.cmbSelectTeam.SelectedValueChanged += new System.EventHandler(this.cmbSelectTeam_SelectedValueChanged);
            this.cmbSelectTeam.TextChanged += new System.EventHandler(this.cmbSelectTeam_TextChanged);
            // 
            // lblSelectTeam
            // 
            this.lblSelectTeam.AutoSize = true;
            this.lblSelectTeam.Location = new System.Drawing.Point(4, 30);
            this.lblSelectTeam.Name = "lblSelectTeam";
            this.lblSelectTeam.Size = new System.Drawing.Size(91, 16);
            this.lblSelectTeam.TabIndex = 46;
            this.lblSelectTeam.Text = "Select Team :";
            // 
            // tbMarket
            // 
            this.tbMarket.Controls.Add(this.btnRefreshMarket);
            this.tbMarket.Controls.Add(this.dataGridViewMarket);
            this.tbMarket.Controls.Add(this.btnAddMarket);
            this.tbMarket.Controls.Add(this.btnSaveMarket);
            this.tbMarket.Controls.Add(this.groupBoxMarket);
            this.tbMarket.Location = new System.Drawing.Point(4, 25);
            this.tbMarket.Name = "tbMarket";
            this.tbMarket.Size = new System.Drawing.Size(1337, 611);
            this.tbMarket.TabIndex = 10;
            this.tbMarket.Text = "Market";
            this.tbMarket.ToolTipText = "Market";
            this.tbMarket.UseVisualStyleBackColor = true;
            // 
            // btnRefreshMarket
            // 
            this.btnRefreshMarket.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefreshMarket.Location = new System.Drawing.Point(6, 325);
            this.btnRefreshMarket.Name = "btnRefreshMarket";
            this.btnRefreshMarket.Size = new System.Drawing.Size(360, 25);
            this.btnRefreshMarket.TabIndex = 78;
            this.btnRefreshMarket.Text = "Refresh";
            this.btnRefreshMarket.UseVisualStyleBackColor = true;
            this.btnRefreshMarket.Click += new System.EventHandler(this.btnRefreshMarket_Click);
            // 
            // dataGridViewMarket
            // 
            this.dataGridViewMarket.AllowUserToAddRows = false;
            this.dataGridViewMarket.AllowUserToDeleteRows = false;
            this.dataGridViewMarket.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridViewMarket.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridViewMarket.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewMarket.Location = new System.Drawing.Point(372, 10);
            this.dataGridViewMarket.MultiSelect = false;
            this.dataGridViewMarket.Name = "dataGridViewMarket";
            this.dataGridViewMarket.ReadOnly = true;
            this.dataGridViewMarket.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewMarket.Size = new System.Drawing.Size(960, 595);
            this.dataGridViewMarket.TabIndex = 47;
            this.dataGridViewMarket.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewMarket_CellDoubleClick);
            // 
            // btnAddMarket
            // 
            this.btnAddMarket.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddMarket.Location = new System.Drawing.Point(4, 295);
            this.btnAddMarket.Name = "btnAddMarket";
            this.btnAddMarket.Size = new System.Drawing.Size(180, 25);
            this.btnAddMarket.TabIndex = 44;
            this.btnAddMarket.Text = "Add Market";
            this.btnAddMarket.UseVisualStyleBackColor = true;
            this.btnAddMarket.Click += new System.EventHandler(this.btnAddMarket_Click);
            // 
            // btnSaveMarket
            // 
            this.btnSaveMarket.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveMarket.Location = new System.Drawing.Point(186, 295);
            this.btnSaveMarket.Name = "btnSaveMarket";
            this.btnSaveMarket.Size = new System.Drawing.Size(180, 25);
            this.btnSaveMarket.TabIndex = 45;
            this.btnSaveMarket.Text = "Save Market";
            this.btnSaveMarket.UseVisualStyleBackColor = true;
            this.btnSaveMarket.Click += new System.EventHandler(this.btnSaveMarket_Click);
            // 
            // groupBoxMarket
            // 
            this.groupBoxMarket.Controls.Add(this.lblTeamIDForMarket);
            this.groupBoxMarket.Controls.Add(this.txtTeamIDForMarket);
            this.groupBoxMarket.Controls.Add(this.lblTeamNameForMarket);
            this.groupBoxMarket.Controls.Add(this.txtTeamNameForMarket);
            this.groupBoxMarket.Controls.Add(this.cmbSelectDivisionForMarket);
            this.groupBoxMarket.Controls.Add(this.lblSelectDivisionForMarket);
            this.groupBoxMarket.Controls.Add(this.cmbMarketActive);
            this.groupBoxMarket.Controls.Add(this.lblMarketActive);
            this.groupBoxMarket.Controls.Add(this.txtMonthlyNoOfVisit);
            this.groupBoxMarket.Controls.Add(this.txtTarget);
            this.groupBoxMarket.Controls.Add(this.txtTotalNoOfParty);
            this.groupBoxMarket.Controls.Add(this.lblNoOfVisit);
            this.groupBoxMarket.Controls.Add(this.lblTarget);
            this.groupBoxMarket.Controls.Add(this.lblTotalNoOfParty);
            this.groupBoxMarket.Controls.Add(this.txtMarketName);
            this.groupBoxMarket.Controls.Add(this.lblMarketName);
            this.groupBoxMarket.Controls.Add(this.txtMarketCode);
            this.groupBoxMarket.Controls.Add(this.lblMarketCode);
            this.groupBoxMarket.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxMarket.Location = new System.Drawing.Point(6, 3);
            this.groupBoxMarket.Name = "groupBoxMarket";
            this.groupBoxMarket.Size = new System.Drawing.Size(360, 285);
            this.groupBoxMarket.TabIndex = 22;
            this.groupBoxMarket.TabStop = false;
            // 
            // lblTeamIDForMarket
            // 
            this.lblTeamIDForMarket.AutoSize = true;
            this.lblTeamIDForMarket.Location = new System.Drawing.Point(4, 227);
            this.lblTeamIDForMarket.Name = "lblTeamIDForMarket";
            this.lblTeamIDForMarket.Size = new System.Drawing.Size(66, 16);
            this.lblTeamIDForMarket.TabIndex = 71;
            this.lblTeamIDForMarket.Text = "Team ID :";
            // 
            // txtTeamIDForMarket
            // 
            this.txtTeamIDForMarket.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtTeamIDForMarket.Location = new System.Drawing.Point(110, 224);
            this.txtTeamIDForMarket.Name = "txtTeamIDForMarket";
            this.txtTeamIDForMarket.ReadOnly = true;
            this.txtTeamIDForMarket.Size = new System.Drawing.Size(240, 22);
            this.txtTeamIDForMarket.TabIndex = 72;
            this.txtTeamIDForMarket.TabStop = false;
            // 
            // lblTeamNameForMarket
            // 
            this.lblTeamNameForMarket.AutoSize = true;
            this.lblTeamNameForMarket.Location = new System.Drawing.Point(4, 205);
            this.lblTeamNameForMarket.Name = "lblTeamNameForMarket";
            this.lblTeamNameForMarket.Size = new System.Drawing.Size(90, 16);
            this.lblTeamNameForMarket.TabIndex = 69;
            this.lblTeamNameForMarket.Text = "Team Name :";
            // 
            // txtTeamNameForMarket
            // 
            this.txtTeamNameForMarket.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtTeamNameForMarket.Location = new System.Drawing.Point(110, 202);
            this.txtTeamNameForMarket.Name = "txtTeamNameForMarket";
            this.txtTeamNameForMarket.ReadOnly = true;
            this.txtTeamNameForMarket.Size = new System.Drawing.Size(240, 22);
            this.txtTeamNameForMarket.TabIndex = 70;
            this.txtTeamNameForMarket.TabStop = false;
            // 
            // cmbSelectDivisionForMarket
            // 
            this.cmbSelectDivisionForMarket.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSelectDivisionForMarket.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectDivisionForMarket.Enabled = false;
            this.cmbSelectDivisionForMarket.FormattingEnabled = true;
            this.cmbSelectDivisionForMarket.Location = new System.Drawing.Point(110, 177);
            this.cmbSelectDivisionForMarket.Name = "cmbSelectDivisionForMarket";
            this.cmbSelectDivisionForMarket.Size = new System.Drawing.Size(240, 24);
            this.cmbSelectDivisionForMarket.Sorted = true;
            this.cmbSelectDivisionForMarket.TabIndex = 41;
            this.cmbSelectDivisionForMarket.Text = "Select Division";
            this.cmbSelectDivisionForMarket.SelectionChangeCommitted += new System.EventHandler(this.cmbSelectDivisionForMarket_SelectionChangeCommitted);
            this.cmbSelectDivisionForMarket.SelectedValueChanged += new System.EventHandler(this.cmbSelectDivisionForMarket_SelectedValueChanged);
            this.cmbSelectDivisionForMarket.TextChanged += new System.EventHandler(this.cmbSelectDivisionForMarket_TextChanged);
            // 
            // lblSelectDivisionForMarket
            // 
            this.lblSelectDivisionForMarket.AutoSize = true;
            this.lblSelectDivisionForMarket.Location = new System.Drawing.Point(4, 180);
            this.lblSelectDivisionForMarket.Name = "lblSelectDivisionForMarket";
            this.lblSelectDivisionForMarket.Size = new System.Drawing.Size(103, 16);
            this.lblSelectDivisionForMarket.TabIndex = 68;
            this.lblSelectDivisionForMarket.Text = "Select Division :";
            // 
            // cmbMarketActive
            // 
            this.cmbMarketActive.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbMarketActive.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbMarketActive.Enabled = false;
            this.cmbMarketActive.FormattingEnabled = true;
            this.cmbMarketActive.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cmbMarketActive.Location = new System.Drawing.Point(110, 252);
            this.cmbMarketActive.Name = "cmbMarketActive";
            this.cmbMarketActive.Size = new System.Drawing.Size(240, 24);
            this.cmbMarketActive.TabIndex = 42;
            this.cmbMarketActive.Text = "Select Active";
            // 
            // lblMarketActive
            // 
            this.lblMarketActive.AutoSize = true;
            this.lblMarketActive.Location = new System.Drawing.Point(4, 255);
            this.lblMarketActive.Name = "lblMarketActive";
            this.lblMarketActive.Size = new System.Drawing.Size(51, 16);
            this.lblMarketActive.TabIndex = 60;
            this.lblMarketActive.Text = "Active :";
            // 
            // txtMonthlyNoOfVisit
            // 
            this.txtMonthlyNoOfVisit.Enabled = false;
            this.txtMonthlyNoOfVisit.Location = new System.Drawing.Point(110, 147);
            this.txtMonthlyNoOfVisit.Name = "txtMonthlyNoOfVisit";
            this.txtMonthlyNoOfVisit.Size = new System.Drawing.Size(240, 22);
            this.txtMonthlyNoOfVisit.TabIndex = 40;
            // 
            // txtTarget
            // 
            this.txtTarget.Enabled = false;
            this.txtTarget.Location = new System.Drawing.Point(110, 117);
            this.txtTarget.Name = "txtTarget";
            this.txtTarget.Size = new System.Drawing.Size(240, 22);
            this.txtTarget.TabIndex = 39;
            // 
            // txtTotalNoOfParty
            // 
            this.txtTotalNoOfParty.Enabled = false;
            this.txtTotalNoOfParty.Location = new System.Drawing.Point(110, 87);
            this.txtTotalNoOfParty.Name = "txtTotalNoOfParty";
            this.txtTotalNoOfParty.Size = new System.Drawing.Size(240, 22);
            this.txtTotalNoOfParty.TabIndex = 38;
            // 
            // lblNoOfVisit
            // 
            this.lblNoOfVisit.AutoSize = true;
            this.lblNoOfVisit.Location = new System.Drawing.Point(4, 150);
            this.lblNoOfVisit.Name = "lblNoOfVisit";
            this.lblNoOfVisit.Size = new System.Drawing.Size(88, 16);
            this.lblNoOfVisit.TabIndex = 59;
            this.lblNoOfVisit.Text = "Monthly Visit :";
            // 
            // lblTarget
            // 
            this.lblTarget.AutoSize = true;
            this.lblTarget.Location = new System.Drawing.Point(4, 120);
            this.lblTarget.Name = "lblTarget";
            this.lblTarget.Size = new System.Drawing.Size(54, 16);
            this.lblTarget.TabIndex = 58;
            this.lblTarget.Text = "Target :";
            // 
            // lblTotalNoOfParty
            // 
            this.lblTotalNoOfParty.AutoSize = true;
            this.lblTotalNoOfParty.Location = new System.Drawing.Point(4, 90);
            this.lblTotalNoOfParty.Name = "lblTotalNoOfParty";
            this.lblTotalNoOfParty.Size = new System.Drawing.Size(79, 16);
            this.lblTotalNoOfParty.TabIndex = 57;
            this.lblTotalNoOfParty.Text = "Total Party :";
            // 
            // txtMarketName
            // 
            this.txtMarketName.Enabled = false;
            this.txtMarketName.Location = new System.Drawing.Point(110, 57);
            this.txtMarketName.Name = "txtMarketName";
            this.txtMarketName.Size = new System.Drawing.Size(240, 22);
            this.txtMarketName.TabIndex = 37;
            // 
            // lblMarketName
            // 
            this.lblMarketName.AutoSize = true;
            this.lblMarketName.Location = new System.Drawing.Point(4, 60);
            this.lblMarketName.Name = "lblMarketName";
            this.lblMarketName.Size = new System.Drawing.Size(95, 16);
            this.lblMarketName.TabIndex = 55;
            this.lblMarketName.Text = "Market Name :";
            // 
            // txtMarketCode
            // 
            this.txtMarketCode.Enabled = false;
            this.txtMarketCode.Location = new System.Drawing.Point(110, 27);
            this.txtMarketCode.Name = "txtMarketCode";
            this.txtMarketCode.Size = new System.Drawing.Size(240, 22);
            this.txtMarketCode.TabIndex = 36;
            this.txtMarketCode.Leave += new System.EventHandler(this.txtMarketCode_Leave);
            // 
            // lblMarketCode
            // 
            this.lblMarketCode.AutoSize = true;
            this.lblMarketCode.Location = new System.Drawing.Point(4, 30);
            this.lblMarketCode.Name = "lblMarketCode";
            this.lblMarketCode.Size = new System.Drawing.Size(91, 16);
            this.lblMarketCode.TabIndex = 53;
            this.lblMarketCode.Text = "Market Code :";
            // 
            // tbMarketSetup
            // 
            this.tbMarketSetup.Controls.Add(this.btnRefreshMarketSetup);
            this.tbMarketSetup.Controls.Add(this.dgvLoadMarketBySelectedDivision);
            this.tbMarketSetup.Controls.Add(this.dataGridViewMarketSetup);
            this.tbMarketSetup.Controls.Add(this.btnAddMarketSetup);
            this.tbMarketSetup.Controls.Add(this.btnSaveMarketSetup);
            this.tbMarketSetup.Controls.Add(this.groupBoxMarketSetup);
            this.tbMarketSetup.Location = new System.Drawing.Point(4, 25);
            this.tbMarketSetup.Name = "tbMarketSetup";
            this.tbMarketSetup.Size = new System.Drawing.Size(1337, 611);
            this.tbMarketSetup.TabIndex = 16;
            this.tbMarketSetup.Text = "Market Setup";
            this.tbMarketSetup.UseVisualStyleBackColor = true;
            // 
            // btnRefreshMarketSetup
            // 
            this.btnRefreshMarketSetup.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefreshMarketSetup.Location = new System.Drawing.Point(6, 285);
            this.btnRefreshMarketSetup.Name = "btnRefreshMarketSetup";
            this.btnRefreshMarketSetup.Size = new System.Drawing.Size(362, 25);
            this.btnRefreshMarketSetup.TabIndex = 128;
            this.btnRefreshMarketSetup.Text = "Refresh";
            this.btnRefreshMarketSetup.UseVisualStyleBackColor = true;
            this.btnRefreshMarketSetup.Click += new System.EventHandler(this.btnRefreshMarketSetup_Click);
            // 
            // dgvLoadMarketBySelectedDivision
            // 
            this.dgvLoadMarketBySelectedDivision.AllowUserToAddRows = false;
            this.dgvLoadMarketBySelectedDivision.AllowUserToDeleteRows = false;
            this.dgvLoadMarketBySelectedDivision.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvLoadMarketBySelectedDivision.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dgvLoadMarketBySelectedDivision.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLoadMarketBySelectedDivision.Location = new System.Drawing.Point(372, 243);
            this.dgvLoadMarketBySelectedDivision.MultiSelect = false;
            this.dgvLoadMarketBySelectedDivision.Name = "dgvLoadMarketBySelectedDivision";
            this.dgvLoadMarketBySelectedDivision.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvLoadMarketBySelectedDivision.Size = new System.Drawing.Size(960, 124);
            this.dgvLoadMarketBySelectedDivision.TabIndex = 127;
            this.dgvLoadMarketBySelectedDivision.Visible = false;
            // 
            // dataGridViewMarketSetup
            // 
            this.dataGridViewMarketSetup.AllowUserToAddRows = false;
            this.dataGridViewMarketSetup.AllowUserToDeleteRows = false;
            this.dataGridViewMarketSetup.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridViewMarketSetup.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridViewMarketSetup.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewMarketSetup.Location = new System.Drawing.Point(372, 10);
            this.dataGridViewMarketSetup.MultiSelect = false;
            this.dataGridViewMarketSetup.Name = "dataGridViewMarketSetup";
            this.dataGridViewMarketSetup.ReadOnly = true;
            this.dataGridViewMarketSetup.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewMarketSetup.Size = new System.Drawing.Size(960, 595);
            this.dataGridViewMarketSetup.TabIndex = 48;
            this.dataGridViewMarketSetup.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewMarketSetup_CellDoubleClick);
            // 
            // btnAddMarketSetup
            // 
            this.btnAddMarketSetup.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddMarketSetup.Location = new System.Drawing.Point(6, 255);
            this.btnAddMarketSetup.Name = "btnAddMarketSetup";
            this.btnAddMarketSetup.Size = new System.Drawing.Size(180, 25);
            this.btnAddMarketSetup.TabIndex = 46;
            this.btnAddMarketSetup.Text = "Add Market Setup";
            this.btnAddMarketSetup.UseVisualStyleBackColor = true;
            this.btnAddMarketSetup.Click += new System.EventHandler(this.btnAddMarketSetup_Click);
            // 
            // btnSaveMarketSetup
            // 
            this.btnSaveMarketSetup.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveMarketSetup.Location = new System.Drawing.Point(188, 255);
            this.btnSaveMarketSetup.Name = "btnSaveMarketSetup";
            this.btnSaveMarketSetup.Size = new System.Drawing.Size(180, 25);
            this.btnSaveMarketSetup.TabIndex = 47;
            this.btnSaveMarketSetup.Text = "Save Market Setup";
            this.btnSaveMarketSetup.UseVisualStyleBackColor = true;
            this.btnSaveMarketSetup.Click += new System.EventHandler(this.btnSaveMarketSetup_Click);
            // 
            // groupBoxMarketSetup
            // 
            this.groupBoxMarketSetup.Controls.Add(this.cmbSelectMarketForMarketSetup);
            this.groupBoxMarketSetup.Controls.Add(this.lblSelectMarket);
            this.groupBoxMarketSetup.Controls.Add(this.txtEmpDesigForMarketSetup);
            this.groupBoxMarketSetup.Controls.Add(this.txtEmpIDForMarketSetup);
            this.groupBoxMarketSetup.Controls.Add(this.lblEmpIDForMarketSetup);
            this.groupBoxMarketSetup.Controls.Add(this.cmbSelectDevisionForMarketSetup);
            this.groupBoxMarketSetup.Controls.Add(this.lblSelectDevisionForMarketSetup);
            this.groupBoxMarketSetup.Controls.Add(this.cmbSelectEmployeeForMarketSetup);
            this.groupBoxMarketSetup.Controls.Add(this.lblSelectEmployeeForMarketSetup);
            this.groupBoxMarketSetup.Controls.Add(this.cmbSelectGroupForMarketSetup);
            this.groupBoxMarketSetup.Controls.Add(this.lblGroupIDForMarketSetup);
            this.groupBoxMarketSetup.Controls.Add(this.txtGroupIDForMarketSetup);
            this.groupBoxMarketSetup.Controls.Add(this.lblSelectGroupForMarketSetup);
            this.groupBoxMarketSetup.Controls.Add(this.txtEmpCellNoForMarketSetup);
            this.groupBoxMarketSetup.Controls.Add(this.lblEmpDesigForMarketSetup);
            this.groupBoxMarketSetup.Controls.Add(this.lblEmpCellNoForMarketSetup);
            this.groupBoxMarketSetup.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxMarketSetup.Location = new System.Drawing.Point(6, 3);
            this.groupBoxMarketSetup.Name = "groupBoxMarketSetup";
            this.groupBoxMarketSetup.Size = new System.Drawing.Size(360, 245);
            this.groupBoxMarketSetup.TabIndex = 22;
            this.groupBoxMarketSetup.TabStop = false;
            // 
            // cmbSelectMarketForMarketSetup
            // 
            this.cmbSelectMarketForMarketSetup.AllowDrop = true;
            this.cmbSelectMarketForMarketSetup.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSelectMarketForMarketSetup.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectMarketForMarketSetup.Enabled = false;
            this.cmbSelectMarketForMarketSetup.FormattingEnabled = true;
            this.cmbSelectMarketForMarketSetup.Location = new System.Drawing.Point(110, 27);
            this.cmbSelectMarketForMarketSetup.Name = "cmbSelectMarketForMarketSetup";
            this.cmbSelectMarketForMarketSetup.Size = new System.Drawing.Size(240, 24);
            this.cmbSelectMarketForMarketSetup.Sorted = true;
            this.cmbSelectMarketForMarketSetup.TabIndex = 72;
            this.cmbSelectMarketForMarketSetup.Text = "Select Market";
            // 
            // lblSelectMarket
            // 
            this.lblSelectMarket.AutoSize = true;
            this.lblSelectMarket.Location = new System.Drawing.Point(4, 30);
            this.lblSelectMarket.Name = "lblSelectMarket";
            this.lblSelectMarket.Size = new System.Drawing.Size(96, 16);
            this.lblSelectMarket.TabIndex = 73;
            this.lblSelectMarket.Text = "Select Market :";
            // 
            // txtEmpDesigForMarketSetup
            // 
            this.txtEmpDesigForMarketSetup.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtEmpDesigForMarketSetup.Enabled = false;
            this.txtEmpDesigForMarketSetup.Location = new System.Drawing.Point(110, 192);
            this.txtEmpDesigForMarketSetup.Name = "txtEmpDesigForMarketSetup";
            this.txtEmpDesigForMarketSetup.ReadOnly = true;
            this.txtEmpDesigForMarketSetup.Size = new System.Drawing.Size(240, 22);
            this.txtEmpDesigForMarketSetup.TabIndex = 71;
            // 
            // txtEmpIDForMarketSetup
            // 
            this.txtEmpIDForMarketSetup.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtEmpIDForMarketSetup.Enabled = false;
            this.txtEmpIDForMarketSetup.Location = new System.Drawing.Point(110, 169);
            this.txtEmpIDForMarketSetup.Name = "txtEmpIDForMarketSetup";
            this.txtEmpIDForMarketSetup.ReadOnly = true;
            this.txtEmpIDForMarketSetup.Size = new System.Drawing.Size(240, 22);
            this.txtEmpIDForMarketSetup.TabIndex = 70;
            // 
            // lblEmpIDForMarketSetup
            // 
            this.lblEmpIDForMarketSetup.AutoSize = true;
            this.lblEmpIDForMarketSetup.Location = new System.Drawing.Point(4, 169);
            this.lblEmpIDForMarketSetup.Name = "lblEmpIDForMarketSetup";
            this.lblEmpIDForMarketSetup.Size = new System.Drawing.Size(61, 16);
            this.lblEmpIDForMarketSetup.TabIndex = 69;
            this.lblEmpIDForMarketSetup.Text = "Emp. ID :";
            // 
            // cmbSelectDevisionForMarketSetup
            // 
            this.cmbSelectDevisionForMarketSetup.AllowDrop = true;
            this.cmbSelectDevisionForMarketSetup.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSelectDevisionForMarketSetup.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectDevisionForMarketSetup.Enabled = false;
            this.cmbSelectDevisionForMarketSetup.FormattingEnabled = true;
            this.cmbSelectDevisionForMarketSetup.Location = new System.Drawing.Point(110, 112);
            this.cmbSelectDevisionForMarketSetup.Name = "cmbSelectDevisionForMarketSetup";
            this.cmbSelectDevisionForMarketSetup.Size = new System.Drawing.Size(240, 24);
            this.cmbSelectDevisionForMarketSetup.Sorted = true;
            this.cmbSelectDevisionForMarketSetup.TabIndex = 65;
            this.cmbSelectDevisionForMarketSetup.Text = "Select Division";
            this.cmbSelectDevisionForMarketSetup.SelectedIndexChanged += new System.EventHandler(this.cmbSelectDevisionForMarketSetup_SelectedIndexChanged);
            this.cmbSelectDevisionForMarketSetup.SelectionChangeCommitted += new System.EventHandler(this.cmbSelectDevisionForMarketSetup_SelectionChangeCommitted);
            this.cmbSelectDevisionForMarketSetup.SelectedValueChanged += new System.EventHandler(this.cmbSelectDevisionForMarketSetup_SelectedValueChanged);
            this.cmbSelectDevisionForMarketSetup.TextChanged += new System.EventHandler(this.cmbSelectDevisionForMarketSetup_TextChanged);
            // 
            // lblSelectDevisionForMarketSetup
            // 
            this.lblSelectDevisionForMarketSetup.AutoSize = true;
            this.lblSelectDevisionForMarketSetup.Location = new System.Drawing.Point(4, 115);
            this.lblSelectDevisionForMarketSetup.Name = "lblSelectDevisionForMarketSetup";
            this.lblSelectDevisionForMarketSetup.Size = new System.Drawing.Size(103, 16);
            this.lblSelectDevisionForMarketSetup.TabIndex = 66;
            this.lblSelectDevisionForMarketSetup.Text = "Select Division :";
            // 
            // cmbSelectEmployeeForMarketSetup
            // 
            this.cmbSelectEmployeeForMarketSetup.AllowDrop = true;
            this.cmbSelectEmployeeForMarketSetup.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSelectEmployeeForMarketSetup.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectEmployeeForMarketSetup.Enabled = false;
            this.cmbSelectEmployeeForMarketSetup.FormattingEnabled = true;
            this.cmbSelectEmployeeForMarketSetup.Location = new System.Drawing.Point(110, 144);
            this.cmbSelectEmployeeForMarketSetup.Name = "cmbSelectEmployeeForMarketSetup";
            this.cmbSelectEmployeeForMarketSetup.Size = new System.Drawing.Size(240, 24);
            this.cmbSelectEmployeeForMarketSetup.Sorted = true;
            this.cmbSelectEmployeeForMarketSetup.TabIndex = 64;
            this.cmbSelectEmployeeForMarketSetup.Text = "Select Employee";
            this.cmbSelectEmployeeForMarketSetup.SelectedIndexChanged += new System.EventHandler(this.cmbSelectEmployeeForMarketSetup_SelectedIndexChanged);
            this.cmbSelectEmployeeForMarketSetup.SelectedValueChanged += new System.EventHandler(this.cmbSelectEmployeeForMarketSetup_SelectedValueChanged);
            // 
            // lblSelectEmployeeForMarketSetup
            // 
            this.lblSelectEmployeeForMarketSetup.AutoSize = true;
            this.lblSelectEmployeeForMarketSetup.Location = new System.Drawing.Point(4, 147);
            this.lblSelectEmployeeForMarketSetup.Name = "lblSelectEmployeeForMarketSetup";
            this.lblSelectEmployeeForMarketSetup.Size = new System.Drawing.Size(86, 16);
            this.lblSelectEmployeeForMarketSetup.TabIndex = 63;
            this.lblSelectEmployeeForMarketSetup.Text = "Select Emp. :";
            // 
            // cmbSelectGroupForMarketSetup
            // 
            this.cmbSelectGroupForMarketSetup.AllowDrop = true;
            this.cmbSelectGroupForMarketSetup.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSelectGroupForMarketSetup.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectGroupForMarketSetup.Enabled = false;
            this.cmbSelectGroupForMarketSetup.FormattingEnabled = true;
            this.cmbSelectGroupForMarketSetup.Location = new System.Drawing.Point(110, 57);
            this.cmbSelectGroupForMarketSetup.Name = "cmbSelectGroupForMarketSetup";
            this.cmbSelectGroupForMarketSetup.Size = new System.Drawing.Size(240, 24);
            this.cmbSelectGroupForMarketSetup.Sorted = true;
            this.cmbSelectGroupForMarketSetup.TabIndex = 41;
            this.cmbSelectGroupForMarketSetup.Text = "Select Team";
            this.cmbSelectGroupForMarketSetup.SelectedIndexChanged += new System.EventHandler(this.cmbSelectGroupForMarketSetup_SelectedIndexChanged);
            this.cmbSelectGroupForMarketSetup.SelectedValueChanged += new System.EventHandler(this.cmbSelectGroupForMarketSetup_SelectedValueChanged);
            this.cmbSelectGroupForMarketSetup.Leave += new System.EventHandler(this.cmbSelectGroupForMarketSetup_Leave);
            // 
            // lblGroupIDForMarketSetup
            // 
            this.lblGroupIDForMarketSetup.AutoSize = true;
            this.lblGroupIDForMarketSetup.Location = new System.Drawing.Point(4, 82);
            this.lblGroupIDForMarketSetup.Name = "lblGroupIDForMarketSetup";
            this.lblGroupIDForMarketSetup.Size = new System.Drawing.Size(66, 16);
            this.lblGroupIDForMarketSetup.TabIndex = 46;
            this.lblGroupIDForMarketSetup.Text = "Team ID :";
            // 
            // txtGroupIDForMarketSetup
            // 
            this.txtGroupIDForMarketSetup.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtGroupIDForMarketSetup.Location = new System.Drawing.Point(110, 82);
            this.txtGroupIDForMarketSetup.Name = "txtGroupIDForMarketSetup";
            this.txtGroupIDForMarketSetup.ReadOnly = true;
            this.txtGroupIDForMarketSetup.Size = new System.Drawing.Size(240, 22);
            this.txtGroupIDForMarketSetup.TabIndex = 47;
            this.txtGroupIDForMarketSetup.TabStop = false;
            this.txtGroupIDForMarketSetup.TextChanged += new System.EventHandler(this.txtGroupIDForMarketSetup_TextChanged);
            // 
            // lblSelectGroupForMarketSetup
            // 
            this.lblSelectGroupForMarketSetup.AutoSize = true;
            this.lblSelectGroupForMarketSetup.Location = new System.Drawing.Point(4, 60);
            this.lblSelectGroupForMarketSetup.Name = "lblSelectGroupForMarketSetup";
            this.lblSelectGroupForMarketSetup.Size = new System.Drawing.Size(91, 16);
            this.lblSelectGroupForMarketSetup.TabIndex = 44;
            this.lblSelectGroupForMarketSetup.Text = "Select Team :";
            // 
            // txtEmpCellNoForMarketSetup
            // 
            this.txtEmpCellNoForMarketSetup.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtEmpCellNoForMarketSetup.Enabled = false;
            this.txtEmpCellNoForMarketSetup.Location = new System.Drawing.Point(110, 215);
            this.txtEmpCellNoForMarketSetup.Name = "txtEmpCellNoForMarketSetup";
            this.txtEmpCellNoForMarketSetup.ReadOnly = true;
            this.txtEmpCellNoForMarketSetup.Size = new System.Drawing.Size(240, 22);
            this.txtEmpCellNoForMarketSetup.TabIndex = 35;
            // 
            // lblEmpDesigForMarketSetup
            // 
            this.lblEmpDesigForMarketSetup.AutoSize = true;
            this.lblEmpDesigForMarketSetup.Location = new System.Drawing.Point(4, 192);
            this.lblEmpDesigForMarketSetup.Name = "lblEmpDesigForMarketSetup";
            this.lblEmpDesigForMarketSetup.Size = new System.Drawing.Size(87, 16);
            this.lblEmpDesigForMarketSetup.TabIndex = 3;
            this.lblEmpDesigForMarketSetup.Text = "Emp. Desig. :";
            // 
            // lblEmpCellNoForMarketSetup
            // 
            this.lblEmpCellNoForMarketSetup.AutoSize = true;
            this.lblEmpCellNoForMarketSetup.Location = new System.Drawing.Point(4, 215);
            this.lblEmpCellNoForMarketSetup.Name = "lblEmpCellNoForMarketSetup";
            this.lblEmpCellNoForMarketSetup.Size = new System.Drawing.Size(92, 16);
            this.lblEmpCellNoForMarketSetup.TabIndex = 0;
            this.lblEmpCellNoForMarketSetup.Text = "Emp. Cell No :";
            // 
            // tbProduct
            // 
            this.tbProduct.Controls.Add(this.btnRefreshProduct);
            this.tbProduct.Controls.Add(this.btnProductReport);
            this.tbProduct.Controls.Add(this.dataGridViewProduct);
            this.tbProduct.Controls.Add(this.btnAddProduct);
            this.tbProduct.Controls.Add(this.btnSaveProduct);
            this.tbProduct.Controls.Add(this.groupBoxProduct);
            this.tbProduct.Location = new System.Drawing.Point(4, 25);
            this.tbProduct.Name = "tbProduct";
            this.tbProduct.Size = new System.Drawing.Size(1337, 611);
            this.tbProduct.TabIndex = 7;
            this.tbProduct.Text = "Product";
            this.tbProduct.UseVisualStyleBackColor = true;
            // 
            // btnRefreshProduct
            // 
            this.btnRefreshProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefreshProduct.Location = new System.Drawing.Point(6, 285);
            this.btnRefreshProduct.Name = "btnRefreshProduct";
            this.btnRefreshProduct.Size = new System.Drawing.Size(360, 25);
            this.btnRefreshProduct.TabIndex = 129;
            this.btnRefreshProduct.Text = "Refresh";
            this.btnRefreshProduct.UseVisualStyleBackColor = true;
            this.btnRefreshProduct.Click += new System.EventHandler(this.btnRefreshProduct_Click);
            // 
            // btnProductReport
            // 
            this.btnProductReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProductReport.Location = new System.Drawing.Point(6, 255);
            this.btnProductReport.Name = "btnProductReport";
            this.btnProductReport.Size = new System.Drawing.Size(362, 25);
            this.btnProductReport.TabIndex = 128;
            this.btnProductReport.Text = "Product Report";
            this.btnProductReport.UseVisualStyleBackColor = true;
            this.btnProductReport.Click += new System.EventHandler(this.btnProductReport_Click);
            // 
            // dataGridViewProduct
            // 
            this.dataGridViewProduct.AllowUserToAddRows = false;
            this.dataGridViewProduct.AllowUserToDeleteRows = false;
            this.dataGridViewProduct.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridViewProduct.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridViewProduct.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewProduct.Location = new System.Drawing.Point(372, 10);
            this.dataGridViewProduct.MultiSelect = false;
            this.dataGridViewProduct.Name = "dataGridViewProduct";
            this.dataGridViewProduct.ReadOnly = true;
            this.dataGridViewProduct.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewProduct.Size = new System.Drawing.Size(960, 595);
            this.dataGridViewProduct.TabIndex = 51;
            this.dataGridViewProduct.TabStop = false;
            this.dataGridViewProduct.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewProduct_CellDoubleClick);
            // 
            // btnAddProduct
            // 
            this.btnAddProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddProduct.Location = new System.Drawing.Point(6, 225);
            this.btnAddProduct.Name = "btnAddProduct";
            this.btnAddProduct.Size = new System.Drawing.Size(180, 25);
            this.btnAddProduct.TabIndex = 52;
            this.btnAddProduct.Text = "Add Product";
            this.btnAddProduct.UseVisualStyleBackColor = true;
            this.btnAddProduct.Click += new System.EventHandler(this.btnAddProduct_Click);
            // 
            // btnSaveProduct
            // 
            this.btnSaveProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveProduct.Location = new System.Drawing.Point(188, 225);
            this.btnSaveProduct.Name = "btnSaveProduct";
            this.btnSaveProduct.Size = new System.Drawing.Size(180, 25);
            this.btnSaveProduct.TabIndex = 53;
            this.btnSaveProduct.Text = "Save Product";
            this.btnSaveProduct.UseVisualStyleBackColor = true;
            this.btnSaveProduct.Click += new System.EventHandler(this.btnSaveProduct_Click);
            // 
            // groupBoxProduct
            // 
            this.groupBoxProduct.Controls.Add(this.cmbProductActive);
            this.groupBoxProduct.Controls.Add(this.lblProductActive);
            this.groupBoxProduct.Controls.Add(this.cmbPackSize);
            this.groupBoxProduct.Controls.Add(this.txtUnitCostPrice);
            this.groupBoxProduct.Controls.Add(this.lblUnitSalePrice);
            this.groupBoxProduct.Controls.Add(this.txtUnitSalePrice);
            this.groupBoxProduct.Controls.Add(this.lblUnitCostPrice);
            this.groupBoxProduct.Controls.Add(this.lblPackSize);
            this.groupBoxProduct.Controls.Add(this.txtProductName);
            this.groupBoxProduct.Controls.Add(this.lblProductName);
            this.groupBoxProduct.Controls.Add(this.txtProductCode);
            this.groupBoxProduct.Controls.Add(this.lblProductCode);
            this.groupBoxProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxProduct.Location = new System.Drawing.Point(6, 3);
            this.groupBoxProduct.Name = "groupBoxProduct";
            this.groupBoxProduct.Size = new System.Drawing.Size(360, 215);
            this.groupBoxProduct.TabIndex = 48;
            this.groupBoxProduct.TabStop = false;
            // 
            // cmbProductActive
            // 
            this.cmbProductActive.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbProductActive.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbProductActive.Enabled = false;
            this.cmbProductActive.FormattingEnabled = true;
            this.cmbProductActive.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cmbProductActive.Location = new System.Drawing.Point(110, 177);
            this.cmbProductActive.Name = "cmbProductActive";
            this.cmbProductActive.Size = new System.Drawing.Size(240, 24);
            this.cmbProductActive.TabIndex = 51;
            this.cmbProductActive.Text = "Select Active";
            // 
            // lblProductActive
            // 
            this.lblProductActive.AutoSize = true;
            this.lblProductActive.Location = new System.Drawing.Point(4, 180);
            this.lblProductActive.Name = "lblProductActive";
            this.lblProductActive.Size = new System.Drawing.Size(51, 16);
            this.lblProductActive.TabIndex = 60;
            this.lblProductActive.Text = "Active :";
            // 
            // cmbPackSize
            // 
            this.cmbPackSize.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbPackSize.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbPackSize.Enabled = false;
            this.cmbPackSize.FormattingEnabled = true;
            this.cmbPackSize.Items.AddRange(new object[] {
            "ml",
            "gm",
            "pcs"});
            this.cmbPackSize.Location = new System.Drawing.Point(110, 87);
            this.cmbPackSize.Name = "cmbPackSize";
            this.cmbPackSize.Size = new System.Drawing.Size(240, 24);
            this.cmbPackSize.TabIndex = 48;
            this.cmbPackSize.Text = "Select Pack Size";
            // 
            // txtUnitCostPrice
            // 
            this.txtUnitCostPrice.Enabled = false;
            this.txtUnitCostPrice.Location = new System.Drawing.Point(110, 117);
            this.txtUnitCostPrice.Name = "txtUnitCostPrice";
            this.txtUnitCostPrice.Size = new System.Drawing.Size(240, 22);
            this.txtUnitCostPrice.TabIndex = 49;
            // 
            // lblUnitSalePrice
            // 
            this.lblUnitSalePrice.AutoSize = true;
            this.lblUnitSalePrice.Location = new System.Drawing.Point(4, 150);
            this.lblUnitSalePrice.Name = "lblUnitSalePrice";
            this.lblUnitSalePrice.Size = new System.Drawing.Size(102, 16);
            this.lblUnitSalePrice.TabIndex = 58;
            this.lblUnitSalePrice.Text = "Unit Sale Price :";
            // 
            // txtUnitSalePrice
            // 
            this.txtUnitSalePrice.Enabled = false;
            this.txtUnitSalePrice.Location = new System.Drawing.Point(110, 147);
            this.txtUnitSalePrice.Name = "txtUnitSalePrice";
            this.txtUnitSalePrice.Size = new System.Drawing.Size(240, 22);
            this.txtUnitSalePrice.TabIndex = 50;
            // 
            // lblUnitCostPrice
            // 
            this.lblUnitCostPrice.AutoSize = true;
            this.lblUnitCostPrice.Location = new System.Drawing.Point(4, 120);
            this.lblUnitCostPrice.Name = "lblUnitCostPrice";
            this.lblUnitCostPrice.Size = new System.Drawing.Size(101, 16);
            this.lblUnitCostPrice.TabIndex = 59;
            this.lblUnitCostPrice.Text = "Unit Cost Price :";
            // 
            // lblPackSize
            // 
            this.lblPackSize.AutoSize = true;
            this.lblPackSize.Location = new System.Drawing.Point(4, 90);
            this.lblPackSize.Name = "lblPackSize";
            this.lblPackSize.Size = new System.Drawing.Size(74, 16);
            this.lblPackSize.TabIndex = 57;
            this.lblPackSize.Text = "Pack Size :";
            // 
            // txtProductName
            // 
            this.txtProductName.Enabled = false;
            this.txtProductName.Location = new System.Drawing.Point(110, 57);
            this.txtProductName.Name = "txtProductName";
            this.txtProductName.Size = new System.Drawing.Size(240, 22);
            this.txtProductName.TabIndex = 47;
            // 
            // lblProductName
            // 
            this.lblProductName.AutoSize = true;
            this.lblProductName.Location = new System.Drawing.Point(4, 60);
            this.lblProductName.Name = "lblProductName";
            this.lblProductName.Size = new System.Drawing.Size(100, 16);
            this.lblProductName.TabIndex = 55;
            this.lblProductName.Text = "Product Name :";
            // 
            // txtProductCode
            // 
            this.txtProductCode.Enabled = false;
            this.txtProductCode.Location = new System.Drawing.Point(110, 27);
            this.txtProductCode.MaxLength = 5;
            this.txtProductCode.Name = "txtProductCode";
            this.txtProductCode.Size = new System.Drawing.Size(240, 22);
            this.txtProductCode.TabIndex = 46;
            this.txtProductCode.Leave += new System.EventHandler(this.txtProductCode_Leave);
            // 
            // lblProductCode
            // 
            this.lblProductCode.AutoSize = true;
            this.lblProductCode.Location = new System.Drawing.Point(4, 30);
            this.lblProductCode.Name = "lblProductCode";
            this.lblProductCode.Size = new System.Drawing.Size(96, 16);
            this.lblProductCode.TabIndex = 53;
            this.lblProductCode.Text = "Product Code :";
            // 
            // tbProductPriceUpdateLog
            // 
            this.tbProductPriceUpdateLog.Controls.Add(this.groupBoxProductPriceLogSearch);
            this.tbProductPriceUpdateLog.Controls.Add(this.dgvProductPriceUpdateLog);
            this.tbProductPriceUpdateLog.Location = new System.Drawing.Point(4, 25);
            this.tbProductPriceUpdateLog.Name = "tbProductPriceUpdateLog";
            this.tbProductPriceUpdateLog.Size = new System.Drawing.Size(1337, 611);
            this.tbProductPriceUpdateLog.TabIndex = 11;
            this.tbProductPriceUpdateLog.Text = "Product Price Log";
            this.tbProductPriceUpdateLog.UseVisualStyleBackColor = true;
            // 
            // groupBoxProductPriceLogSearch
            // 
            this.groupBoxProductPriceLogSearch.Controls.Add(this.btnRefreshProductPriceLog);
            this.groupBoxProductPriceLogSearch.Controls.Add(this.radioBtnPriceUpdateLogShowAll);
            this.groupBoxProductPriceLogSearch.Controls.Add(this.btnPriceUpdateLogSearch);
            this.groupBoxProductPriceLogSearch.Controls.Add(this.txtPriceUpdateLogSearchCriteria);
            this.groupBoxProductPriceLogSearch.Controls.Add(this.radioBtnPriceUpdateLogSearchByPName);
            this.groupBoxProductPriceLogSearch.Controls.Add(this.radioBtnPriceUpdateLogSearchByPCode);
            this.groupBoxProductPriceLogSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxProductPriceLogSearch.Location = new System.Drawing.Point(7, 3);
            this.groupBoxProductPriceLogSearch.Name = "groupBoxProductPriceLogSearch";
            this.groupBoxProductPriceLogSearch.Size = new System.Drawing.Size(1325, 105);
            this.groupBoxProductPriceLogSearch.TabIndex = 53;
            this.groupBoxProductPriceLogSearch.TabStop = false;
            this.groupBoxProductPriceLogSearch.Text = "Search";
            // 
            // btnRefreshProductPriceLog
            // 
            this.btnRefreshProductPriceLog.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefreshProductPriceLog.Location = new System.Drawing.Point(280, 45);
            this.btnRefreshProductPriceLog.Name = "btnRefreshProductPriceLog";
            this.btnRefreshProductPriceLog.Size = new System.Drawing.Size(91, 25);
            this.btnRefreshProductPriceLog.TabIndex = 78;
            this.btnRefreshProductPriceLog.Text = "Refresh";
            this.btnRefreshProductPriceLog.UseVisualStyleBackColor = true;
            this.btnRefreshProductPriceLog.Click += new System.EventHandler(this.btnRefreshProductPriceLog_Click);
            // 
            // radioBtnPriceUpdateLogShowAll
            // 
            this.radioBtnPriceUpdateLogShowAll.AutoSize = true;
            this.radioBtnPriceUpdateLogShowAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioBtnPriceUpdateLogShowAll.Location = new System.Drawing.Point(292, 20);
            this.radioBtnPriceUpdateLogShowAll.Name = "radioBtnPriceUpdateLogShowAll";
            this.radioBtnPriceUpdateLogShowAll.Size = new System.Drawing.Size(77, 20);
            this.radioBtnPriceUpdateLogShowAll.TabIndex = 51;
            this.radioBtnPriceUpdateLogShowAll.TabStop = true;
            this.radioBtnPriceUpdateLogShowAll.Text = "Show All";
            this.radioBtnPriceUpdateLogShowAll.UseVisualStyleBackColor = true;
            this.radioBtnPriceUpdateLogShowAll.CheckedChanged += new System.EventHandler(this.radioBtnPriceUpdateLogShowAll_CheckedChanged);
            // 
            // btnPriceUpdateLogSearch
            // 
            this.btnPriceUpdateLogSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPriceUpdateLogSearch.Location = new System.Drawing.Point(184, 45);
            this.btnPriceUpdateLogSearch.Name = "btnPriceUpdateLogSearch";
            this.btnPriceUpdateLogSearch.Size = new System.Drawing.Size(91, 25);
            this.btnPriceUpdateLogSearch.TabIndex = 54;
            this.btnPriceUpdateLogSearch.Text = "Search";
            this.btnPriceUpdateLogSearch.UseVisualStyleBackColor = true;
            this.btnPriceUpdateLogSearch.Click += new System.EventHandler(this.btnPriceUpdateLogSearch_Click);
            // 
            // txtPriceUpdateLogSearchCriteria
            // 
            this.txtPriceUpdateLogSearchCriteria.Enabled = false;
            this.txtPriceUpdateLogSearchCriteria.Location = new System.Drawing.Point(6, 46);
            this.txtPriceUpdateLogSearchCriteria.Name = "txtPriceUpdateLogSearchCriteria";
            this.txtPriceUpdateLogSearchCriteria.Size = new System.Drawing.Size(173, 22);
            this.txtPriceUpdateLogSearchCriteria.TabIndex = 52;
            // 
            // radioBtnPriceUpdateLogSearchByPName
            // 
            this.radioBtnPriceUpdateLogSearchByPName.AutoSize = true;
            this.radioBtnPriceUpdateLogSearchByPName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioBtnPriceUpdateLogSearchByPName.Location = new System.Drawing.Point(145, 20);
            this.radioBtnPriceUpdateLogSearchByPName.Name = "radioBtnPriceUpdateLogSearchByPName";
            this.radioBtnPriceUpdateLogSearchByPName.Size = new System.Drawing.Size(131, 20);
            this.radioBtnPriceUpdateLogSearchByPName.TabIndex = 49;
            this.radioBtnPriceUpdateLogSearchByPName.TabStop = true;
            this.radioBtnPriceUpdateLogSearchByPName.Text = "By Product Name";
            this.radioBtnPriceUpdateLogSearchByPName.UseVisualStyleBackColor = true;
            this.radioBtnPriceUpdateLogSearchByPName.CheckedChanged += new System.EventHandler(this.radioBtnPriceUpdateLogSearchByPName_CheckedChanged);
            // 
            // radioBtnPriceUpdateLogSearchByPCode
            // 
            this.radioBtnPriceUpdateLogSearchByPCode.AutoSize = true;
            this.radioBtnPriceUpdateLogSearchByPCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioBtnPriceUpdateLogSearchByPCode.Location = new System.Drawing.Point(6, 20);
            this.radioBtnPriceUpdateLogSearchByPCode.Name = "radioBtnPriceUpdateLogSearchByPCode";
            this.radioBtnPriceUpdateLogSearchByPCode.Size = new System.Drawing.Size(127, 20);
            this.radioBtnPriceUpdateLogSearchByPCode.TabIndex = 47;
            this.radioBtnPriceUpdateLogSearchByPCode.TabStop = true;
            this.radioBtnPriceUpdateLogSearchByPCode.Text = "By Product Code";
            this.radioBtnPriceUpdateLogSearchByPCode.UseVisualStyleBackColor = true;
            this.radioBtnPriceUpdateLogSearchByPCode.CheckedChanged += new System.EventHandler(this.radioBtnPriceUpdateLogSearchByPCode_CheckedChanged);
            // 
            // dgvProductPriceUpdateLog
            // 
            this.dgvProductPriceUpdateLog.AllowUserToAddRows = false;
            this.dgvProductPriceUpdateLog.AllowUserToDeleteRows = false;
            this.dgvProductPriceUpdateLog.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvProductPriceUpdateLog.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dgvProductPriceUpdateLog.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProductPriceUpdateLog.Location = new System.Drawing.Point(6, 116);
            this.dgvProductPriceUpdateLog.MultiSelect = false;
            this.dgvProductPriceUpdateLog.Name = "dgvProductPriceUpdateLog";
            this.dgvProductPriceUpdateLog.ReadOnly = true;
            this.dgvProductPriceUpdateLog.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvProductPriceUpdateLog.Size = new System.Drawing.Size(1325, 490);
            this.dgvProductPriceUpdateLog.TabIndex = 52;
            this.dgvProductPriceUpdateLog.TabStop = false;
            // 
            // tbSalesTarget
            // 
            this.tbSalesTarget.Controls.Add(this.btnRefreshSalesTarget);
            this.tbSalesTarget.Controls.Add(this.txtEmpDivNameForSalesTarget);
            this.tbSalesTarget.Controls.Add(this.dgvPrevAddedSalesTargetDetails);
            this.tbSalesTarget.Controls.Add(this.dgvProductListForSalesTarget);
            this.tbSalesTarget.Controls.Add(this.btnSaveList);
            this.tbSalesTarget.Controls.Add(this.btnAddToList);
            this.tbSalesTarget.Controls.Add(this.groupBoxTargetSearch);
            this.tbSalesTarget.Controls.Add(this.btnAddTarget);
            this.tbSalesTarget.Controls.Add(this.groupBoxSalesTarget);
            this.tbSalesTarget.Controls.Add(this.btnSaveTarget);
            this.tbSalesTarget.Controls.Add(this.dgvSalesTargetDetails);
            this.tbSalesTarget.Controls.Add(this.dataGridViewSalesTarget);
            this.tbSalesTarget.Location = new System.Drawing.Point(4, 25);
            this.tbSalesTarget.Name = "tbSalesTarget";
            this.tbSalesTarget.Size = new System.Drawing.Size(1337, 611);
            this.tbSalesTarget.TabIndex = 12;
            this.tbSalesTarget.Text = "Sales Target";
            this.tbSalesTarget.UseVisualStyleBackColor = true;
            // 
            // btnRefreshSalesTarget
            // 
            this.btnRefreshSalesTarget.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefreshSalesTarget.Location = new System.Drawing.Point(7, 420);
            this.btnRefreshSalesTarget.Name = "btnRefreshSalesTarget";
            this.btnRefreshSalesTarget.Size = new System.Drawing.Size(360, 25);
            this.btnRefreshSalesTarget.TabIndex = 80;
            this.btnRefreshSalesTarget.Text = "Refresh";
            this.btnRefreshSalesTarget.UseVisualStyleBackColor = true;
            this.btnRefreshSalesTarget.Click += new System.EventHandler(this.btnRefreshSalesTarget_Click);
            // 
            // txtEmpDivNameForSalesTarget
            // 
            this.txtEmpDivNameForSalesTarget.Location = new System.Drawing.Point(7, 441);
            this.txtEmpDivNameForSalesTarget.Name = "txtEmpDivNameForSalesTarget";
            this.txtEmpDivNameForSalesTarget.Size = new System.Drawing.Size(120, 22);
            this.txtEmpDivNameForSalesTarget.TabIndex = 79;
            this.txtEmpDivNameForSalesTarget.Visible = false;
            // 
            // dgvPrevAddedSalesTargetDetails
            // 
            this.dgvPrevAddedSalesTargetDetails.AllowUserToAddRows = false;
            this.dgvPrevAddedSalesTargetDetails.AllowUserToDeleteRows = false;
            this.dgvPrevAddedSalesTargetDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvPrevAddedSalesTargetDetails.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dgvPrevAddedSalesTargetDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPrevAddedSalesTargetDetails.Location = new System.Drawing.Point(372, 146);
            this.dgvPrevAddedSalesTargetDetails.MultiSelect = false;
            this.dgvPrevAddedSalesTargetDetails.Name = "dgvPrevAddedSalesTargetDetails";
            this.dgvPrevAddedSalesTargetDetails.ReadOnly = true;
            this.dgvPrevAddedSalesTargetDetails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPrevAddedSalesTargetDetails.Size = new System.Drawing.Size(960, 100);
            this.dgvPrevAddedSalesTargetDetails.TabIndex = 71;
            this.dgvPrevAddedSalesTargetDetails.TabStop = false;
            this.dgvPrevAddedSalesTargetDetails.Visible = false;
            // 
            // dgvProductListForSalesTarget
            // 
            this.dgvProductListForSalesTarget.AllowUserToAddRows = false;
            this.dgvProductListForSalesTarget.AllowUserToDeleteRows = false;
            this.dgvProductListForSalesTarget.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvProductListForSalesTarget.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dgvProductListForSalesTarget.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProductListForSalesTarget.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dgvProductListForSalesTarget.Location = new System.Drawing.Point(372, 311);
            this.dgvProductListForSalesTarget.MultiSelect = false;
            this.dgvProductListForSalesTarget.Name = "dgvProductListForSalesTarget";
            this.dgvProductListForSalesTarget.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvProductListForSalesTarget.Size = new System.Drawing.Size(960, 100);
            this.dgvProductListForSalesTarget.TabIndex = 70;
            this.dgvProductListForSalesTarget.Visible = false;
            this.dgvProductListForSalesTarget.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dgvProductListForSalesTarget_KeyPress);
            // 
            // btnSaveList
            // 
            this.btnSaveList.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveList.Location = new System.Drawing.Point(132, 440);
            this.btnSaveList.Name = "btnSaveList";
            this.btnSaveList.Size = new System.Drawing.Size(120, 25);
            this.btnSaveList.TabIndex = 68;
            this.btnSaveList.Text = "Save List";
            this.btnSaveList.UseVisualStyleBackColor = true;
            this.btnSaveList.Visible = false;
            this.btnSaveList.Click += new System.EventHandler(this.btnSaveList_Click);
            // 
            // btnAddToList
            // 
            this.btnAddToList.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddToList.Location = new System.Drawing.Point(127, 390);
            this.btnAddToList.Name = "btnAddToList";
            this.btnAddToList.Size = new System.Drawing.Size(120, 25);
            this.btnAddToList.TabIndex = 67;
            this.btnAddToList.Text = "Add To List";
            this.btnAddToList.UseVisualStyleBackColor = true;
            this.btnAddToList.Click += new System.EventHandler(this.btnAddToList_Click);
            // 
            // groupBoxTargetSearch
            // 
            this.groupBoxTargetSearch.Controls.Add(this.radioButtonByProductCodeForSalesTarget);
            this.groupBoxTargetSearch.Controls.Add(this.txtSearchDateTo);
            this.groupBoxTargetSearch.Controls.Add(this.dtpSearchDateTo);
            this.groupBoxTargetSearch.Controls.Add(this.lblSearchDateTo);
            this.groupBoxTargetSearch.Controls.Add(this.txtSearchDateFrom);
            this.groupBoxTargetSearch.Controls.Add(this.dtpSearchDateFrom);
            this.groupBoxTargetSearch.Controls.Add(this.lblSearchDateFrom);
            this.groupBoxTargetSearch.Controls.Add(this.radioButtonByDesignationForSalesTarget);
            this.groupBoxTargetSearch.Controls.Add(this.radioButtonShowAllForSalesTarget);
            this.groupBoxTargetSearch.Controls.Add(this.btnSearchForSalesTarget);
            this.groupBoxTargetSearch.Controls.Add(this.cmbSearchCriteriaByDesigForSalesTarget);
            this.groupBoxTargetSearch.Controls.Add(this.txtSearchCriteriaForSalesTarget);
            this.groupBoxTargetSearch.Controls.Add(this.radioButtonByGroupAndDesigForSalesTarget);
            this.groupBoxTargetSearch.Controls.Add(this.radioButtonByGroupForSalesTarget);
            this.groupBoxTargetSearch.Controls.Add(this.radioButtonByMobileForSalesTarget);
            this.groupBoxTargetSearch.Controls.Add(this.radioButtonByNameForSalesTarget);
            this.groupBoxTargetSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxTargetSearch.Location = new System.Drawing.Point(7, 462);
            this.groupBoxTargetSearch.Name = "groupBoxTargetSearch";
            this.groupBoxTargetSearch.Size = new System.Drawing.Size(360, 130);
            this.groupBoxTargetSearch.TabIndex = 52;
            this.groupBoxTargetSearch.TabStop = false;
            this.groupBoxTargetSearch.Text = "Search";
            // 
            // radioButtonByProductCodeForSalesTarget
            // 
            this.radioButtonByProductCodeForSalesTarget.AutoSize = true;
            this.radioButtonByProductCodeForSalesTarget.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonByProductCodeForSalesTarget.Location = new System.Drawing.Point(172, 73);
            this.radioButtonByProductCodeForSalesTarget.Name = "radioButtonByProductCodeForSalesTarget";
            this.radioButtonByProductCodeForSalesTarget.Size = new System.Drawing.Size(108, 20);
            this.radioButtonByProductCodeForSalesTarget.TabIndex = 81;
            this.radioButtonByProductCodeForSalesTarget.TabStop = true;
            this.radioButtonByProductCodeForSalesTarget.Text = "Product Code";
            this.radioButtonByProductCodeForSalesTarget.UseVisualStyleBackColor = true;
            this.radioButtonByProductCodeForSalesTarget.CheckedChanged += new System.EventHandler(this.radioButtonByProductCode_CheckedChanged);
            // 
            // txtSearchDateTo
            // 
            this.txtSearchDateTo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearchDateTo.Location = new System.Drawing.Point(227, 19);
            this.txtSearchDateTo.Name = "txtSearchDateTo";
            this.txtSearchDateTo.Size = new System.Drawing.Size(108, 22);
            this.txtSearchDateTo.TabIndex = 79;
            // 
            // dtpSearchDateTo
            // 
            this.dtpSearchDateTo.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpSearchDateTo.Location = new System.Drawing.Point(335, 19);
            this.dtpSearchDateTo.Name = "dtpSearchDateTo";
            this.dtpSearchDateTo.Size = new System.Drawing.Size(16, 22);
            this.dtpSearchDateTo.TabIndex = 80;
            this.dtpSearchDateTo.CloseUp += new System.EventHandler(this.dtpSearchDateTo_CloseUp);
            // 
            // lblSearchDateTo
            // 
            this.lblSearchDateTo.AutoSize = true;
            this.lblSearchDateTo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchDateTo.Location = new System.Drawing.Point(193, 22);
            this.lblSearchDateTo.Name = "lblSearchDateTo";
            this.lblSearchDateTo.Size = new System.Drawing.Size(31, 16);
            this.lblSearchDateTo.TabIndex = 78;
            this.lblSearchDateTo.Text = "To :";
            // 
            // txtSearchDateFrom
            // 
            this.txtSearchDateFrom.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearchDateFrom.Location = new System.Drawing.Point(54, 19);
            this.txtSearchDateFrom.Name = "txtSearchDateFrom";
            this.txtSearchDateFrom.Size = new System.Drawing.Size(108, 22);
            this.txtSearchDateFrom.TabIndex = 76;
            // 
            // dtpSearchDateFrom
            // 
            this.dtpSearchDateFrom.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpSearchDateFrom.Location = new System.Drawing.Point(162, 19);
            this.dtpSearchDateFrom.Name = "dtpSearchDateFrom";
            this.dtpSearchDateFrom.Size = new System.Drawing.Size(16, 22);
            this.dtpSearchDateFrom.TabIndex = 77;
            this.dtpSearchDateFrom.CloseUp += new System.EventHandler(this.dtpSearchDateFrom_CloseUp);
            // 
            // lblSearchDateFrom
            // 
            this.lblSearchDateFrom.AutoSize = true;
            this.lblSearchDateFrom.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchDateFrom.Location = new System.Drawing.Point(8, 22);
            this.lblSearchDateFrom.Name = "lblSearchDateFrom";
            this.lblSearchDateFrom.Size = new System.Drawing.Size(45, 16);
            this.lblSearchDateFrom.TabIndex = 75;
            this.lblSearchDateFrom.Text = "From :";
            // 
            // radioButtonByDesignationForSalesTarget
            // 
            this.radioButtonByDesignationForSalesTarget.AutoSize = true;
            this.radioButtonByDesignationForSalesTarget.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonByDesignationForSalesTarget.Location = new System.Drawing.Point(261, 48);
            this.radioButtonByDesignationForSalesTarget.Name = "radioButtonByDesignationForSalesTarget";
            this.radioButtonByDesignationForSalesTarget.Size = new System.Drawing.Size(98, 20);
            this.radioButtonByDesignationForSalesTarget.TabIndex = 74;
            this.radioButtonByDesignationForSalesTarget.TabStop = true;
            this.radioButtonByDesignationForSalesTarget.Text = "Designation";
            this.radioButtonByDesignationForSalesTarget.UseVisualStyleBackColor = true;
            this.radioButtonByDesignationForSalesTarget.CheckedChanged += new System.EventHandler(this.radioButtonByDesignationForSalesTarget_CheckedChanged);
            // 
            // radioButtonShowAllForSalesTarget
            // 
            this.radioButtonShowAllForSalesTarget.AutoSize = true;
            this.radioButtonShowAllForSalesTarget.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonShowAllForSalesTarget.Location = new System.Drawing.Point(280, 73);
            this.radioButtonShowAllForSalesTarget.Name = "radioButtonShowAllForSalesTarget";
            this.radioButtonShowAllForSalesTarget.Size = new System.Drawing.Size(77, 20);
            this.radioButtonShowAllForSalesTarget.TabIndex = 70;
            this.radioButtonShowAllForSalesTarget.TabStop = true;
            this.radioButtonShowAllForSalesTarget.Text = "Show All";
            this.radioButtonShowAllForSalesTarget.UseVisualStyleBackColor = true;
            this.radioButtonShowAllForSalesTarget.CheckedChanged += new System.EventHandler(this.radioButtonShowAllForSalesTarget_CheckedChanged);
            // 
            // btnSearchForSalesTarget
            // 
            this.btnSearchForSalesTarget.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearchForSalesTarget.Location = new System.Drawing.Point(272, 96);
            this.btnSearchForSalesTarget.Name = "btnSearchForSalesTarget";
            this.btnSearchForSalesTarget.Size = new System.Drawing.Size(79, 25);
            this.btnSearchForSalesTarget.TabIndex = 73;
            this.btnSearchForSalesTarget.Text = "Search";
            this.btnSearchForSalesTarget.UseVisualStyleBackColor = true;
            this.btnSearchForSalesTarget.Click += new System.EventHandler(this.btnSearchForSalesTarget_Click);
            // 
            // cmbSearchCriteriaByDesigForSalesTarget
            // 
            this.cmbSearchCriteriaByDesigForSalesTarget.Enabled = false;
            this.cmbSearchCriteriaByDesigForSalesTarget.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSearchCriteriaByDesigForSalesTarget.FormattingEnabled = true;
            this.cmbSearchCriteriaByDesigForSalesTarget.Location = new System.Drawing.Point(189, 97);
            this.cmbSearchCriteriaByDesigForSalesTarget.Name = "cmbSearchCriteriaByDesigForSalesTarget";
            this.cmbSearchCriteriaByDesigForSalesTarget.Size = new System.Drawing.Size(75, 24);
            this.cmbSearchCriteriaByDesigForSalesTarget.TabIndex = 72;
            // 
            // txtSearchCriteriaForSalesTarget
            // 
            this.txtSearchCriteriaForSalesTarget.Enabled = false;
            this.txtSearchCriteriaForSalesTarget.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearchCriteriaForSalesTarget.Location = new System.Drawing.Point(6, 99);
            this.txtSearchCriteriaForSalesTarget.Name = "txtSearchCriteriaForSalesTarget";
            this.txtSearchCriteriaForSalesTarget.Size = new System.Drawing.Size(177, 22);
            this.txtSearchCriteriaForSalesTarget.TabIndex = 71;
            // 
            // radioButtonByGroupAndDesigForSalesTarget
            // 
            this.radioButtonByGroupAndDesigForSalesTarget.AutoSize = true;
            this.radioButtonByGroupAndDesigForSalesTarget.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonByGroupAndDesigForSalesTarget.Location = new System.Drawing.Point(6, 73);
            this.radioButtonByGroupAndDesigForSalesTarget.Name = "radioButtonByGroupAndDesigForSalesTarget";
            this.radioButtonByGroupAndDesigForSalesTarget.Size = new System.Drawing.Size(163, 20);
            this.radioButtonByGroupAndDesigForSalesTarget.TabIndex = 69;
            this.radioButtonByGroupAndDesigForSalesTarget.TabStop = true;
            this.radioButtonByGroupAndDesigForSalesTarget.Text = "Team and Designation";
            this.radioButtonByGroupAndDesigForSalesTarget.UseVisualStyleBackColor = true;
            this.radioButtonByGroupAndDesigForSalesTarget.CheckedChanged += new System.EventHandler(this.radioButtonByGroupAndDesigForSalesTarget_CheckedChanged);
            // 
            // radioButtonByGroupForSalesTarget
            // 
            this.radioButtonByGroupForSalesTarget.AutoSize = true;
            this.radioButtonByGroupForSalesTarget.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonByGroupForSalesTarget.Location = new System.Drawing.Point(183, 48);
            this.radioButtonByGroupForSalesTarget.Name = "radioButtonByGroupForSalesTarget";
            this.radioButtonByGroupForSalesTarget.Size = new System.Drawing.Size(62, 20);
            this.radioButtonByGroupForSalesTarget.TabIndex = 68;
            this.radioButtonByGroupForSalesTarget.TabStop = true;
            this.radioButtonByGroupForSalesTarget.Text = "Team";
            this.radioButtonByGroupForSalesTarget.UseVisualStyleBackColor = true;
            this.radioButtonByGroupForSalesTarget.CheckedChanged += new System.EventHandler(this.radioButtonByGroupForSalesTarget_CheckedChanged);
            // 
            // radioButtonByMobileForSalesTarget
            // 
            this.radioButtonByMobileForSalesTarget.AutoSize = true;
            this.radioButtonByMobileForSalesTarget.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonByMobileForSalesTarget.Location = new System.Drawing.Point(100, 48);
            this.radioButtonByMobileForSalesTarget.Name = "radioButtonByMobileForSalesTarget";
            this.radioButtonByMobileForSalesTarget.Size = new System.Drawing.Size(67, 20);
            this.radioButtonByMobileForSalesTarget.TabIndex = 67;
            this.radioButtonByMobileForSalesTarget.TabStop = true;
            this.radioButtonByMobileForSalesTarget.Text = "Mobile";
            this.radioButtonByMobileForSalesTarget.UseVisualStyleBackColor = true;
            this.radioButtonByMobileForSalesTarget.CheckedChanged += new System.EventHandler(this.radioButtonByMobileForSalesTarget_CheckedChanged);
            // 
            // radioButtonByNameForSalesTarget
            // 
            this.radioButtonByNameForSalesTarget.AutoSize = true;
            this.radioButtonByNameForSalesTarget.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonByNameForSalesTarget.Location = new System.Drawing.Point(6, 48);
            this.radioButtonByNameForSalesTarget.Name = "radioButtonByNameForSalesTarget";
            this.radioButtonByNameForSalesTarget.Size = new System.Drawing.Size(88, 20);
            this.radioButtonByNameForSalesTarget.TabIndex = 66;
            this.radioButtonByNameForSalesTarget.TabStop = true;
            this.radioButtonByNameForSalesTarget.Text = "Employee";
            this.radioButtonByNameForSalesTarget.UseVisualStyleBackColor = true;
            this.radioButtonByNameForSalesTarget.CheckedChanged += new System.EventHandler(this.radioButtonByNameForSalesTarget_CheckedChanged);
            // 
            // btnAddTarget
            // 
            this.btnAddTarget.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddTarget.Location = new System.Drawing.Point(7, 390);
            this.btnAddTarget.Name = "btnAddTarget";
            this.btnAddTarget.Size = new System.Drawing.Size(120, 25);
            this.btnAddTarget.TabIndex = 64;
            this.btnAddTarget.Text = "Add Target";
            this.btnAddTarget.UseVisualStyleBackColor = true;
            this.btnAddTarget.Click += new System.EventHandler(this.btnAddTarget_Click);
            // 
            // groupBoxSalesTarget
            // 
            this.groupBoxSalesTarget.Controls.Add(this.txtProductPriceForSalesTarget);
            this.groupBoxSalesTarget.Controls.Add(this.txtProductNameForSalesTarget);
            this.groupBoxSalesTarget.Controls.Add(this.txtProductIDForSalesTarget);
            this.groupBoxSalesTarget.Controls.Add(this.btnBrowseProductCodeForSalesTarget);
            this.groupBoxSalesTarget.Controls.Add(this.lblProductCodeForSalesTarget);
            this.groupBoxSalesTarget.Controls.Add(this.lblProductPriceForSalesTarget);
            this.groupBoxSalesTarget.Controls.Add(this.txtProductCodeForSalesTarget);
            this.groupBoxSalesTarget.Controls.Add(this.lblProductNameForSalesTarget);
            this.groupBoxSalesTarget.Controls.Add(this.lblProductIDForSalesTarget);
            this.groupBoxSalesTarget.Controls.Add(this.txtEmpMobileNoForSalesTarget);
            this.groupBoxSalesTarget.Controls.Add(this.lblEmpMobileNoForSalesTarget);
            this.groupBoxSalesTarget.Controls.Add(this.cmbSelectEmployeeForSalesTarget);
            this.groupBoxSalesTarget.Controls.Add(this.cmbSelectDesignationForSalesTarget);
            this.groupBoxSalesTarget.Controls.Add(this.cmbSelectGroupForSalesTarget);
            this.groupBoxSalesTarget.Controls.Add(this.lblSelectGroupForSalesTarget);
            this.groupBoxSalesTarget.Controls.Add(this.txtTargetUnitForSalesTarget);
            this.groupBoxSalesTarget.Controls.Add(this.txtFromDate);
            this.groupBoxSalesTarget.Controls.Add(this.txtToDate);
            this.groupBoxSalesTarget.Controls.Add(this.dTPToDate);
            this.groupBoxSalesTarget.Controls.Add(this.lblEmployeeDesignationForSalesTarget);
            this.groupBoxSalesTarget.Controls.Add(this.txtEmployeeIDForSalesTarget);
            this.groupBoxSalesTarget.Controls.Add(this.lblEmployeeIDForSalesTarget);
            this.groupBoxSalesTarget.Controls.Add(this.lblSelectEmployeeForSalesTarget);
            this.groupBoxSalesTarget.Controls.Add(this.lblTargetAmountForSalesTarget);
            this.groupBoxSalesTarget.Controls.Add(this.txtTargetAmountForSalesTarget);
            this.groupBoxSalesTarget.Controls.Add(this.lblTargetUnitForSalesTarget);
            this.groupBoxSalesTarget.Controls.Add(this.dTPFromDate);
            this.groupBoxSalesTarget.Controls.Add(this.lblToDate);
            this.groupBoxSalesTarget.Controls.Add(this.lblFromDate);
            this.groupBoxSalesTarget.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxSalesTarget.Location = new System.Drawing.Point(6, 3);
            this.groupBoxSalesTarget.Name = "groupBoxSalesTarget";
            this.groupBoxSalesTarget.Size = new System.Drawing.Size(360, 380);
            this.groupBoxSalesTarget.TabIndex = 48;
            this.groupBoxSalesTarget.TabStop = false;
            // 
            // txtProductPriceForSalesTarget
            // 
            this.txtProductPriceForSalesTarget.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtProductPriceForSalesTarget.Location = new System.Drawing.Point(110, 292);
            this.txtProductPriceForSalesTarget.Name = "txtProductPriceForSalesTarget";
            this.txtProductPriceForSalesTarget.ReadOnly = true;
            this.txtProductPriceForSalesTarget.Size = new System.Drawing.Size(240, 22);
            this.txtProductPriceForSalesTarget.TabIndex = 78;
            this.txtProductPriceForSalesTarget.TabStop = false;
            this.txtProductPriceForSalesTarget.TextChanged += new System.EventHandler(this.txtProductPriceForSalesTarget_TextChanged_1);
            // 
            // txtProductNameForSalesTarget
            // 
            this.txtProductNameForSalesTarget.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtProductNameForSalesTarget.Location = new System.Drawing.Point(110, 268);
            this.txtProductNameForSalesTarget.Name = "txtProductNameForSalesTarget";
            this.txtProductNameForSalesTarget.ReadOnly = true;
            this.txtProductNameForSalesTarget.Size = new System.Drawing.Size(240, 22);
            this.txtProductNameForSalesTarget.TabIndex = 76;
            this.txtProductNameForSalesTarget.TabStop = false;
            // 
            // txtProductIDForSalesTarget
            // 
            this.txtProductIDForSalesTarget.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtProductIDForSalesTarget.Location = new System.Drawing.Point(110, 244);
            this.txtProductIDForSalesTarget.Name = "txtProductIDForSalesTarget";
            this.txtProductIDForSalesTarget.ReadOnly = true;
            this.txtProductIDForSalesTarget.Size = new System.Drawing.Size(240, 22);
            this.txtProductIDForSalesTarget.TabIndex = 74;
            this.txtProductIDForSalesTarget.TabStop = false;
            // 
            // btnBrowseProductCodeForSalesTarget
            // 
            this.btnBrowseProductCodeForSalesTarget.BackColor = System.Drawing.Color.Transparent;
            this.btnBrowseProductCodeForSalesTarget.Enabled = false;
            this.btnBrowseProductCodeForSalesTarget.Location = new System.Drawing.Point(245, 221);
            this.btnBrowseProductCodeForSalesTarget.Name = "btnBrowseProductCodeForSalesTarget";
            this.btnBrowseProductCodeForSalesTarget.Size = new System.Drawing.Size(105, 23);
            this.btnBrowseProductCodeForSalesTarget.TabIndex = 77;
            this.btnBrowseProductCodeForSalesTarget.Text = "Product List";
            this.btnBrowseProductCodeForSalesTarget.UseVisualStyleBackColor = false;
            this.btnBrowseProductCodeForSalesTarget.Click += new System.EventHandler(this.btnBrowseProductCodeForSalesTarget_Click_1);
            // 
            // lblProductCodeForSalesTarget
            // 
            this.lblProductCodeForSalesTarget.AutoSize = true;
            this.lblProductCodeForSalesTarget.Location = new System.Drawing.Point(4, 224);
            this.lblProductCodeForSalesTarget.Name = "lblProductCodeForSalesTarget";
            this.lblProductCodeForSalesTarget.Size = new System.Drawing.Size(96, 16);
            this.lblProductCodeForSalesTarget.TabIndex = 73;
            this.lblProductCodeForSalesTarget.Text = "Product Code :";
            // 
            // lblProductPriceForSalesTarget
            // 
            this.lblProductPriceForSalesTarget.AutoSize = true;
            this.lblProductPriceForSalesTarget.Location = new System.Drawing.Point(4, 295);
            this.lblProductPriceForSalesTarget.Name = "lblProductPriceForSalesTarget";
            this.lblProductPriceForSalesTarget.Size = new System.Drawing.Size(94, 16);
            this.lblProductPriceForSalesTarget.TabIndex = 72;
            this.lblProductPriceForSalesTarget.Text = "Product Price :";
            // 
            // txtProductCodeForSalesTarget
            // 
            this.txtProductCodeForSalesTarget.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtProductCodeForSalesTarget.Enabled = false;
            this.txtProductCodeForSalesTarget.Location = new System.Drawing.Point(110, 221);
            this.txtProductCodeForSalesTarget.Name = "txtProductCodeForSalesTarget";
            this.txtProductCodeForSalesTarget.ReadOnly = true;
            this.txtProductCodeForSalesTarget.Size = new System.Drawing.Size(133, 22);
            this.txtProductCodeForSalesTarget.TabIndex = 75;
            this.txtProductCodeForSalesTarget.TabStop = false;
            // 
            // lblProductNameForSalesTarget
            // 
            this.lblProductNameForSalesTarget.AutoSize = true;
            this.lblProductNameForSalesTarget.Location = new System.Drawing.Point(4, 271);
            this.lblProductNameForSalesTarget.Name = "lblProductNameForSalesTarget";
            this.lblProductNameForSalesTarget.Size = new System.Drawing.Size(100, 16);
            this.lblProductNameForSalesTarget.TabIndex = 71;
            this.lblProductNameForSalesTarget.Text = "Product Name :";
            // 
            // lblProductIDForSalesTarget
            // 
            this.lblProductIDForSalesTarget.AutoSize = true;
            this.lblProductIDForSalesTarget.Location = new System.Drawing.Point(4, 247);
            this.lblProductIDForSalesTarget.Name = "lblProductIDForSalesTarget";
            this.lblProductIDForSalesTarget.Size = new System.Drawing.Size(76, 16);
            this.lblProductIDForSalesTarget.TabIndex = 70;
            this.lblProductIDForSalesTarget.Text = "Product ID :";
            // 
            // txtEmpMobileNoForSalesTarget
            // 
            this.txtEmpMobileNoForSalesTarget.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtEmpMobileNoForSalesTarget.Location = new System.Drawing.Point(110, 193);
            this.txtEmpMobileNoForSalesTarget.Name = "txtEmpMobileNoForSalesTarget";
            this.txtEmpMobileNoForSalesTarget.ReadOnly = true;
            this.txtEmpMobileNoForSalesTarget.Size = new System.Drawing.Size(240, 22);
            this.txtEmpMobileNoForSalesTarget.TabIndex = 69;
            this.txtEmpMobileNoForSalesTarget.TabStop = false;
            // 
            // lblEmpMobileNoForSalesTarget
            // 
            this.lblEmpMobileNoForSalesTarget.AutoSize = true;
            this.lblEmpMobileNoForSalesTarget.Location = new System.Drawing.Point(4, 196);
            this.lblEmpMobileNoForSalesTarget.Name = "lblEmpMobileNoForSalesTarget";
            this.lblEmpMobileNoForSalesTarget.Size = new System.Drawing.Size(76, 16);
            this.lblEmpMobileNoForSalesTarget.TabIndex = 68;
            this.lblEmpMobileNoForSalesTarget.Text = "Mobile No :";
            // 
            // cmbSelectEmployeeForSalesTarget
            // 
            this.cmbSelectEmployeeForSalesTarget.AllowDrop = true;
            this.cmbSelectEmployeeForSalesTarget.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSelectEmployeeForSalesTarget.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectEmployeeForSalesTarget.Enabled = false;
            this.cmbSelectEmployeeForSalesTarget.FormattingEnabled = true;
            this.cmbSelectEmployeeForSalesTarget.Location = new System.Drawing.Point(110, 145);
            this.cmbSelectEmployeeForSalesTarget.Name = "cmbSelectEmployeeForSalesTarget";
            this.cmbSelectEmployeeForSalesTarget.Size = new System.Drawing.Size(240, 24);
            this.cmbSelectEmployeeForSalesTarget.Sorted = true;
            this.cmbSelectEmployeeForSalesTarget.TabIndex = 62;
            this.cmbSelectEmployeeForSalesTarget.Text = "Select Employee";
            this.cmbSelectEmployeeForSalesTarget.SelectedIndexChanged += new System.EventHandler(this.cmbSelectEmployeeForSalesTarget_SelectedIndexChanged);
            this.cmbSelectEmployeeForSalesTarget.SelectedValueChanged += new System.EventHandler(this.cmbSelectEmployeeForSalesTarget_SelectedValueChanged);
            this.cmbSelectEmployeeForSalesTarget.TextChanged += new System.EventHandler(this.cmbSelectEmployeeForSalesTarget_TextChanged);
            // 
            // cmbSelectDesignationForSalesTarget
            // 
            this.cmbSelectDesignationForSalesTarget.AllowDrop = true;
            this.cmbSelectDesignationForSalesTarget.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSelectDesignationForSalesTarget.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectDesignationForSalesTarget.Enabled = false;
            this.cmbSelectDesignationForSalesTarget.FormattingEnabled = true;
            this.cmbSelectDesignationForSalesTarget.Location = new System.Drawing.Point(110, 115);
            this.cmbSelectDesignationForSalesTarget.Name = "cmbSelectDesignationForSalesTarget";
            this.cmbSelectDesignationForSalesTarget.Size = new System.Drawing.Size(240, 24);
            this.cmbSelectDesignationForSalesTarget.TabIndex = 61;
            this.cmbSelectDesignationForSalesTarget.Text = "Select Designation";
            this.cmbSelectDesignationForSalesTarget.SelectedIndexChanged += new System.EventHandler(this.cmbSelectDesignationForSalesTarget_SelectedIndexChanged);
            // 
            // cmbSelectGroupForSalesTarget
            // 
            this.cmbSelectGroupForSalesTarget.AllowDrop = true;
            this.cmbSelectGroupForSalesTarget.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSelectGroupForSalesTarget.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectGroupForSalesTarget.Enabled = false;
            this.cmbSelectGroupForSalesTarget.FormattingEnabled = true;
            this.cmbSelectGroupForSalesTarget.Location = new System.Drawing.Point(110, 85);
            this.cmbSelectGroupForSalesTarget.Name = "cmbSelectGroupForSalesTarget";
            this.cmbSelectGroupForSalesTarget.Size = new System.Drawing.Size(240, 24);
            this.cmbSelectGroupForSalesTarget.Sorted = true;
            this.cmbSelectGroupForSalesTarget.TabIndex = 60;
            this.cmbSelectGroupForSalesTarget.Text = "Select Team";
            // 
            // lblSelectGroupForSalesTarget
            // 
            this.lblSelectGroupForSalesTarget.AutoSize = true;
            this.lblSelectGroupForSalesTarget.Location = new System.Drawing.Point(4, 88);
            this.lblSelectGroupForSalesTarget.Name = "lblSelectGroupForSalesTarget";
            this.lblSelectGroupForSalesTarget.Size = new System.Drawing.Size(91, 16);
            this.lblSelectGroupForSalesTarget.TabIndex = 65;
            this.lblSelectGroupForSalesTarget.Text = "Select Team :";
            // 
            // txtTargetUnitForSalesTarget
            // 
            this.txtTargetUnitForSalesTarget.Enabled = false;
            this.txtTargetUnitForSalesTarget.Location = new System.Drawing.Point(110, 320);
            this.txtTargetUnitForSalesTarget.Name = "txtTargetUnitForSalesTarget";
            this.txtTargetUnitForSalesTarget.Size = new System.Drawing.Size(240, 22);
            this.txtTargetUnitForSalesTarget.TabIndex = 63;
            this.txtTargetUnitForSalesTarget.TextChanged += new System.EventHandler(this.txtTargetUnitForSalesTarget_TextChanged);
            // 
            // txtFromDate
            // 
            this.txtFromDate.Enabled = false;
            this.txtFromDate.Location = new System.Drawing.Point(110, 27);
            this.txtFromDate.Name = "txtFromDate";
            this.txtFromDate.Size = new System.Drawing.Size(225, 22);
            this.txtFromDate.TabIndex = 54;
            // 
            // txtToDate
            // 
            this.txtToDate.Enabled = false;
            this.txtToDate.Location = new System.Drawing.Point(110, 57);
            this.txtToDate.Name = "txtToDate";
            this.txtToDate.Size = new System.Drawing.Size(225, 22);
            this.txtToDate.TabIndex = 56;
            // 
            // dTPToDate
            // 
            this.dTPToDate.Enabled = false;
            this.dTPToDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dTPToDate.Location = new System.Drawing.Point(334, 57);
            this.dTPToDate.Name = "dTPToDate";
            this.dTPToDate.Size = new System.Drawing.Size(16, 22);
            this.dTPToDate.TabIndex = 57;
            this.dTPToDate.TabStop = false;
            this.dTPToDate.CloseUp += new System.EventHandler(this.dTPToDate_CloseUp);
            // 
            // lblEmployeeDesignationForSalesTarget
            // 
            this.lblEmployeeDesignationForSalesTarget.AutoSize = true;
            this.lblEmployeeDesignationForSalesTarget.Location = new System.Drawing.Point(4, 118);
            this.lblEmployeeDesignationForSalesTarget.Name = "lblEmployeeDesignationForSalesTarget";
            this.lblEmployeeDesignationForSalesTarget.Size = new System.Drawing.Size(86, 16);
            this.lblEmployeeDesignationForSalesTarget.TabIndex = 46;
            this.lblEmployeeDesignationForSalesTarget.Text = "Designation :";
            // 
            // txtEmployeeIDForSalesTarget
            // 
            this.txtEmployeeIDForSalesTarget.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtEmployeeIDForSalesTarget.Location = new System.Drawing.Point(110, 170);
            this.txtEmployeeIDForSalesTarget.Name = "txtEmployeeIDForSalesTarget";
            this.txtEmployeeIDForSalesTarget.ReadOnly = true;
            this.txtEmployeeIDForSalesTarget.Size = new System.Drawing.Size(240, 22);
            this.txtEmployeeIDForSalesTarget.TabIndex = 47;
            this.txtEmployeeIDForSalesTarget.TabStop = false;
            this.txtEmployeeIDForSalesTarget.TextChanged += new System.EventHandler(this.txtEmployeeIDForSalesTarget_TextChanged);
            // 
            // lblEmployeeIDForSalesTarget
            // 
            this.lblEmployeeIDForSalesTarget.AutoSize = true;
            this.lblEmployeeIDForSalesTarget.Location = new System.Drawing.Point(4, 173);
            this.lblEmployeeIDForSalesTarget.Name = "lblEmployeeIDForSalesTarget";
            this.lblEmployeeIDForSalesTarget.Size = new System.Drawing.Size(92, 16);
            this.lblEmployeeIDForSalesTarget.TabIndex = 44;
            this.lblEmployeeIDForSalesTarget.Text = "Employee ID :";
            // 
            // lblSelectEmployeeForSalesTarget
            // 
            this.lblSelectEmployeeForSalesTarget.AutoSize = true;
            this.lblSelectEmployeeForSalesTarget.Location = new System.Drawing.Point(4, 148);
            this.lblSelectEmployeeForSalesTarget.Name = "lblSelectEmployeeForSalesTarget";
            this.lblSelectEmployeeForSalesTarget.Size = new System.Drawing.Size(86, 16);
            this.lblSelectEmployeeForSalesTarget.TabIndex = 42;
            this.lblSelectEmployeeForSalesTarget.Text = "Select Emp. :";
            // 
            // lblTargetAmountForSalesTarget
            // 
            this.lblTargetAmountForSalesTarget.AutoSize = true;
            this.lblTargetAmountForSalesTarget.Location = new System.Drawing.Point(4, 351);
            this.lblTargetAmountForSalesTarget.Name = "lblTargetAmountForSalesTarget";
            this.lblTargetAmountForSalesTarget.Size = new System.Drawing.Size(102, 16);
            this.lblTargetAmountForSalesTarget.TabIndex = 40;
            this.lblTargetAmountForSalesTarget.Text = "Target Amount :";
            // 
            // txtTargetAmountForSalesTarget
            // 
            this.txtTargetAmountForSalesTarget.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtTargetAmountForSalesTarget.Location = new System.Drawing.Point(110, 348);
            this.txtTargetAmountForSalesTarget.Name = "txtTargetAmountForSalesTarget";
            this.txtTargetAmountForSalesTarget.ReadOnly = true;
            this.txtTargetAmountForSalesTarget.Size = new System.Drawing.Size(240, 22);
            this.txtTargetAmountForSalesTarget.TabIndex = 41;
            this.txtTargetAmountForSalesTarget.TabStop = false;
            // 
            // lblTargetUnitForSalesTarget
            // 
            this.lblTargetUnitForSalesTarget.AutoSize = true;
            this.lblTargetUnitForSalesTarget.Location = new System.Drawing.Point(4, 323);
            this.lblTargetUnitForSalesTarget.Name = "lblTargetUnitForSalesTarget";
            this.lblTargetUnitForSalesTarget.Size = new System.Drawing.Size(80, 16);
            this.lblTargetUnitForSalesTarget.TabIndex = 39;
            this.lblTargetUnitForSalesTarget.Text = "Target Unit :";
            // 
            // dTPFromDate
            // 
            this.dTPFromDate.Enabled = false;
            this.dTPFromDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dTPFromDate.Location = new System.Drawing.Point(334, 27);
            this.dTPFromDate.Name = "dTPFromDate";
            this.dTPFromDate.Size = new System.Drawing.Size(16, 22);
            this.dTPFromDate.TabIndex = 55;
            this.dTPFromDate.CloseUp += new System.EventHandler(this.dTPFromDate_CloseUp);
            // 
            // lblToDate
            // 
            this.lblToDate.AutoSize = true;
            this.lblToDate.Location = new System.Drawing.Point(4, 60);
            this.lblToDate.Name = "lblToDate";
            this.lblToDate.Size = new System.Drawing.Size(63, 16);
            this.lblToDate.TabIndex = 1;
            this.lblToDate.Text = "To Date :";
            // 
            // lblFromDate
            // 
            this.lblFromDate.AutoSize = true;
            this.lblFromDate.Location = new System.Drawing.Point(4, 30);
            this.lblFromDate.Name = "lblFromDate";
            this.lblFromDate.Size = new System.Drawing.Size(77, 16);
            this.lblFromDate.TabIndex = 0;
            this.lblFromDate.Text = "From Date :";
            // 
            // btnSaveTarget
            // 
            this.btnSaveTarget.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveTarget.Location = new System.Drawing.Point(247, 390);
            this.btnSaveTarget.Name = "btnSaveTarget";
            this.btnSaveTarget.Size = new System.Drawing.Size(120, 25);
            this.btnSaveTarget.TabIndex = 65;
            this.btnSaveTarget.Text = "Save Target";
            this.btnSaveTarget.UseVisualStyleBackColor = true;
            this.btnSaveTarget.Click += new System.EventHandler(this.btnSaveTarget_Click);
            // 
            // dgvSalesTargetDetails
            // 
            this.dgvSalesTargetDetails.AllowUserToAddRows = false;
            this.dgvSalesTargetDetails.AllowUserToDeleteRows = false;
            this.dgvSalesTargetDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvSalesTargetDetails.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dgvSalesTargetDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSalesTargetDetails.Location = new System.Drawing.Point(372, 10);
            this.dgvSalesTargetDetails.MultiSelect = false;
            this.dgvSalesTargetDetails.Name = "dgvSalesTargetDetails";
            this.dgvSalesTargetDetails.ReadOnly = true;
            this.dgvSalesTargetDetails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSalesTargetDetails.Size = new System.Drawing.Size(960, 100);
            this.dgvSalesTargetDetails.TabIndex = 66;
            this.dgvSalesTargetDetails.TabStop = false;
            this.dgvSalesTargetDetails.Visible = false;
            this.dgvSalesTargetDetails.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvSalesTargetDetails_CellDoubleClick);
            // 
            // dataGridViewSalesTarget
            // 
            this.dataGridViewSalesTarget.AllowUserToAddRows = false;
            this.dataGridViewSalesTarget.AllowUserToDeleteRows = false;
            this.dataGridViewSalesTarget.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridViewSalesTarget.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridViewSalesTarget.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSalesTarget.Location = new System.Drawing.Point(372, 10);
            this.dataGridViewSalesTarget.MultiSelect = false;
            this.dataGridViewSalesTarget.Name = "dataGridViewSalesTarget";
            this.dataGridViewSalesTarget.ReadOnly = true;
            this.dataGridViewSalesTarget.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewSalesTarget.Size = new System.Drawing.Size(960, 580);
            this.dataGridViewSalesTarget.TabIndex = 49;
            this.dataGridViewSalesTarget.TabStop = false;
            this.dataGridViewSalesTarget.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewSalesTarget_CellDoubleClick);
            // 
            // tbSpecialItemSaleTarget
            // 
            this.tbSpecialItemSaleTarget.Controls.Add(this.groupBoxSpecialItemSearch);
            this.tbSpecialItemSaleTarget.Controls.Add(this.btnSpecialItemSaleAddTarget);
            this.tbSpecialItemSaleTarget.Controls.Add(this.btnSpecialItemSaleSaveTarget);
            this.tbSpecialItemSaleTarget.Controls.Add(this.dgvSpecialItemSalesTarget);
            this.tbSpecialItemSaleTarget.Controls.Add(this.groupBox1);
            this.tbSpecialItemSaleTarget.Location = new System.Drawing.Point(4, 25);
            this.tbSpecialItemSaleTarget.Name = "tbSpecialItemSaleTarget";
            this.tbSpecialItemSaleTarget.Size = new System.Drawing.Size(1337, 611);
            this.tbSpecialItemSaleTarget.TabIndex = 13;
            this.tbSpecialItemSaleTarget.Text = "Special Item Sale";
            this.tbSpecialItemSaleTarget.UseVisualStyleBackColor = true;
            // 
            // groupBoxSpecialItemSearch
            // 
            this.groupBoxSpecialItemSearch.Controls.Add(this.radioButtonSpecialItemSearchByProductCode);
            this.groupBoxSpecialItemSearch.Controls.Add(this.txtSpecialItemSearchToDate);
            this.groupBoxSpecialItemSearch.Controls.Add(this.dtPSpecialItemSearchToDate);
            this.groupBoxSpecialItemSearch.Controls.Add(this.lblSpecialItemSearchToDate);
            this.groupBoxSpecialItemSearch.Controls.Add(this.txtSpecialItemSearchFromDate);
            this.groupBoxSpecialItemSearch.Controls.Add(this.dtPSpecialItemSearchFromDate);
            this.groupBoxSpecialItemSearch.Controls.Add(this.lblSpecialItemSearchFromDate);
            this.groupBoxSpecialItemSearch.Controls.Add(this.radioButtonSpecialItemSearchByDesignation);
            this.groupBoxSpecialItemSearch.Controls.Add(this.radioButtonSpecialItemShowAll);
            this.groupBoxSpecialItemSearch.Controls.Add(this.btnSpecialItemSearch);
            this.groupBoxSpecialItemSearch.Controls.Add(this.cmbSpecialItemSearchByEmpDesignation);
            this.groupBoxSpecialItemSearch.Controls.Add(this.txtSpecialItemSearchCriteria);
            this.groupBoxSpecialItemSearch.Controls.Add(this.radioButtonSpecialItemSearchByGroupNameAndDesignation);
            this.groupBoxSpecialItemSearch.Controls.Add(this.radioButtonSpecialItemSearchByGroupName);
            this.groupBoxSpecialItemSearch.Controls.Add(this.radioButtonSpecialItemSearchByEmpMobileNo);
            this.groupBoxSpecialItemSearch.Controls.Add(this.radioButtonSpecialItemSearchByEmpName);
            this.groupBoxSpecialItemSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxSpecialItemSearch.Location = new System.Drawing.Point(7, 471);
            this.groupBoxSpecialItemSearch.Name = "groupBoxSpecialItemSearch";
            this.groupBoxSpecialItemSearch.Size = new System.Drawing.Size(360, 135);
            this.groupBoxSpecialItemSearch.TabIndex = 68;
            this.groupBoxSpecialItemSearch.TabStop = false;
            this.groupBoxSpecialItemSearch.Text = "Search";
            // 
            // radioButtonSpecialItemSearchByProductCode
            // 
            this.radioButtonSpecialItemSearchByProductCode.AutoSize = true;
            this.radioButtonSpecialItemSearchByProductCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonSpecialItemSearchByProductCode.Location = new System.Drawing.Point(172, 72);
            this.radioButtonSpecialItemSearchByProductCode.Name = "radioButtonSpecialItemSearchByProductCode";
            this.radioButtonSpecialItemSearchByProductCode.Size = new System.Drawing.Size(108, 20);
            this.radioButtonSpecialItemSearchByProductCode.TabIndex = 81;
            this.radioButtonSpecialItemSearchByProductCode.TabStop = true;
            this.radioButtonSpecialItemSearchByProductCode.Text = "Product Code";
            this.radioButtonSpecialItemSearchByProductCode.UseVisualStyleBackColor = true;
            // 
            // txtSpecialItemSearchToDate
            // 
            this.txtSpecialItemSearchToDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSpecialItemSearchToDate.Location = new System.Drawing.Point(227, 21);
            this.txtSpecialItemSearchToDate.Name = "txtSpecialItemSearchToDate";
            this.txtSpecialItemSearchToDate.Size = new System.Drawing.Size(108, 22);
            this.txtSpecialItemSearchToDate.TabIndex = 79;
            // 
            // dtPSpecialItemSearchToDate
            // 
            this.dtPSpecialItemSearchToDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtPSpecialItemSearchToDate.Location = new System.Drawing.Point(335, 21);
            this.dtPSpecialItemSearchToDate.Name = "dtPSpecialItemSearchToDate";
            this.dtPSpecialItemSearchToDate.Size = new System.Drawing.Size(16, 22);
            this.dtPSpecialItemSearchToDate.TabIndex = 80;
            // 
            // lblSpecialItemSearchToDate
            // 
            this.lblSpecialItemSearchToDate.AutoSize = true;
            this.lblSpecialItemSearchToDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSpecialItemSearchToDate.Location = new System.Drawing.Point(193, 24);
            this.lblSpecialItemSearchToDate.Name = "lblSpecialItemSearchToDate";
            this.lblSpecialItemSearchToDate.Size = new System.Drawing.Size(31, 16);
            this.lblSpecialItemSearchToDate.TabIndex = 78;
            this.lblSpecialItemSearchToDate.Text = "To :";
            // 
            // txtSpecialItemSearchFromDate
            // 
            this.txtSpecialItemSearchFromDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSpecialItemSearchFromDate.Location = new System.Drawing.Point(54, 21);
            this.txtSpecialItemSearchFromDate.Name = "txtSpecialItemSearchFromDate";
            this.txtSpecialItemSearchFromDate.Size = new System.Drawing.Size(108, 22);
            this.txtSpecialItemSearchFromDate.TabIndex = 76;
            // 
            // dtPSpecialItemSearchFromDate
            // 
            this.dtPSpecialItemSearchFromDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtPSpecialItemSearchFromDate.Location = new System.Drawing.Point(162, 21);
            this.dtPSpecialItemSearchFromDate.Name = "dtPSpecialItemSearchFromDate";
            this.dtPSpecialItemSearchFromDate.Size = new System.Drawing.Size(16, 22);
            this.dtPSpecialItemSearchFromDate.TabIndex = 77;
            // 
            // lblSpecialItemSearchFromDate
            // 
            this.lblSpecialItemSearchFromDate.AutoSize = true;
            this.lblSpecialItemSearchFromDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSpecialItemSearchFromDate.Location = new System.Drawing.Point(8, 24);
            this.lblSpecialItemSearchFromDate.Name = "lblSpecialItemSearchFromDate";
            this.lblSpecialItemSearchFromDate.Size = new System.Drawing.Size(45, 16);
            this.lblSpecialItemSearchFromDate.TabIndex = 75;
            this.lblSpecialItemSearchFromDate.Text = "From :";
            // 
            // radioButtonSpecialItemSearchByDesignation
            // 
            this.radioButtonSpecialItemSearchByDesignation.AutoSize = true;
            this.radioButtonSpecialItemSearchByDesignation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonSpecialItemSearchByDesignation.Location = new System.Drawing.Point(261, 47);
            this.radioButtonSpecialItemSearchByDesignation.Name = "radioButtonSpecialItemSearchByDesignation";
            this.radioButtonSpecialItemSearchByDesignation.Size = new System.Drawing.Size(98, 20);
            this.radioButtonSpecialItemSearchByDesignation.TabIndex = 74;
            this.radioButtonSpecialItemSearchByDesignation.TabStop = true;
            this.radioButtonSpecialItemSearchByDesignation.Text = "Designation";
            this.radioButtonSpecialItemSearchByDesignation.UseVisualStyleBackColor = true;
            // 
            // radioButtonSpecialItemShowAll
            // 
            this.radioButtonSpecialItemShowAll.AutoSize = true;
            this.radioButtonSpecialItemShowAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonSpecialItemShowAll.Location = new System.Drawing.Point(280, 72);
            this.radioButtonSpecialItemShowAll.Name = "radioButtonSpecialItemShowAll";
            this.radioButtonSpecialItemShowAll.Size = new System.Drawing.Size(77, 20);
            this.radioButtonSpecialItemShowAll.TabIndex = 70;
            this.radioButtonSpecialItemShowAll.TabStop = true;
            this.radioButtonSpecialItemShowAll.Text = "Show All";
            this.radioButtonSpecialItemShowAll.UseVisualStyleBackColor = true;
            // 
            // btnSpecialItemSearch
            // 
            this.btnSpecialItemSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSpecialItemSearch.Location = new System.Drawing.Point(272, 99);
            this.btnSpecialItemSearch.Name = "btnSpecialItemSearch";
            this.btnSpecialItemSearch.Size = new System.Drawing.Size(79, 25);
            this.btnSpecialItemSearch.TabIndex = 73;
            this.btnSpecialItemSearch.Text = "Search";
            this.btnSpecialItemSearch.UseVisualStyleBackColor = true;
            // 
            // cmbSpecialItemSearchByEmpDesignation
            // 
            this.cmbSpecialItemSearchByEmpDesignation.Enabled = false;
            this.cmbSpecialItemSearchByEmpDesignation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSpecialItemSearchByEmpDesignation.FormattingEnabled = true;
            this.cmbSpecialItemSearchByEmpDesignation.Location = new System.Drawing.Point(189, 100);
            this.cmbSpecialItemSearchByEmpDesignation.Name = "cmbSpecialItemSearchByEmpDesignation";
            this.cmbSpecialItemSearchByEmpDesignation.Size = new System.Drawing.Size(75, 24);
            this.cmbSpecialItemSearchByEmpDesignation.TabIndex = 72;
            // 
            // txtSpecialItemSearchCriteria
            // 
            this.txtSpecialItemSearchCriteria.Enabled = false;
            this.txtSpecialItemSearchCriteria.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSpecialItemSearchCriteria.Location = new System.Drawing.Point(6, 102);
            this.txtSpecialItemSearchCriteria.Name = "txtSpecialItemSearchCriteria";
            this.txtSpecialItemSearchCriteria.Size = new System.Drawing.Size(177, 22);
            this.txtSpecialItemSearchCriteria.TabIndex = 71;
            // 
            // radioButtonSpecialItemSearchByGroupNameAndDesignation
            // 
            this.radioButtonSpecialItemSearchByGroupNameAndDesignation.AutoSize = true;
            this.radioButtonSpecialItemSearchByGroupNameAndDesignation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonSpecialItemSearchByGroupNameAndDesignation.Location = new System.Drawing.Point(6, 72);
            this.radioButtonSpecialItemSearchByGroupNameAndDesignation.Name = "radioButtonSpecialItemSearchByGroupNameAndDesignation";
            this.radioButtonSpecialItemSearchByGroupNameAndDesignation.Size = new System.Drawing.Size(163, 20);
            this.radioButtonSpecialItemSearchByGroupNameAndDesignation.TabIndex = 69;
            this.radioButtonSpecialItemSearchByGroupNameAndDesignation.TabStop = true;
            this.radioButtonSpecialItemSearchByGroupNameAndDesignation.Text = "Team and Designation";
            this.radioButtonSpecialItemSearchByGroupNameAndDesignation.UseVisualStyleBackColor = true;
            // 
            // radioButtonSpecialItemSearchByGroupName
            // 
            this.radioButtonSpecialItemSearchByGroupName.AutoSize = true;
            this.radioButtonSpecialItemSearchByGroupName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonSpecialItemSearchByGroupName.Location = new System.Drawing.Point(183, 47);
            this.radioButtonSpecialItemSearchByGroupName.Name = "radioButtonSpecialItemSearchByGroupName";
            this.radioButtonSpecialItemSearchByGroupName.Size = new System.Drawing.Size(62, 20);
            this.radioButtonSpecialItemSearchByGroupName.TabIndex = 68;
            this.radioButtonSpecialItemSearchByGroupName.TabStop = true;
            this.radioButtonSpecialItemSearchByGroupName.Text = "Team";
            this.radioButtonSpecialItemSearchByGroupName.UseVisualStyleBackColor = true;
            // 
            // radioButtonSpecialItemSearchByEmpMobileNo
            // 
            this.radioButtonSpecialItemSearchByEmpMobileNo.AutoSize = true;
            this.radioButtonSpecialItemSearchByEmpMobileNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonSpecialItemSearchByEmpMobileNo.Location = new System.Drawing.Point(100, 47);
            this.radioButtonSpecialItemSearchByEmpMobileNo.Name = "radioButtonSpecialItemSearchByEmpMobileNo";
            this.radioButtonSpecialItemSearchByEmpMobileNo.Size = new System.Drawing.Size(67, 20);
            this.radioButtonSpecialItemSearchByEmpMobileNo.TabIndex = 67;
            this.radioButtonSpecialItemSearchByEmpMobileNo.TabStop = true;
            this.radioButtonSpecialItemSearchByEmpMobileNo.Text = "Mobile";
            this.radioButtonSpecialItemSearchByEmpMobileNo.UseVisualStyleBackColor = true;
            // 
            // radioButtonSpecialItemSearchByEmpName
            // 
            this.radioButtonSpecialItemSearchByEmpName.AutoSize = true;
            this.radioButtonSpecialItemSearchByEmpName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonSpecialItemSearchByEmpName.Location = new System.Drawing.Point(6, 47);
            this.radioButtonSpecialItemSearchByEmpName.Name = "radioButtonSpecialItemSearchByEmpName";
            this.radioButtonSpecialItemSearchByEmpName.Size = new System.Drawing.Size(88, 20);
            this.radioButtonSpecialItemSearchByEmpName.TabIndex = 66;
            this.radioButtonSpecialItemSearchByEmpName.TabStop = true;
            this.radioButtonSpecialItemSearchByEmpName.Text = "Employee";
            this.radioButtonSpecialItemSearchByEmpName.UseVisualStyleBackColor = true;
            // 
            // btnSpecialItemSaleAddTarget
            // 
            this.btnSpecialItemSaleAddTarget.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSpecialItemSaleAddTarget.Location = new System.Drawing.Point(7, 440);
            this.btnSpecialItemSaleAddTarget.Name = "btnSpecialItemSaleAddTarget";
            this.btnSpecialItemSaleAddTarget.Size = new System.Drawing.Size(180, 25);
            this.btnSpecialItemSaleAddTarget.TabIndex = 66;
            this.btnSpecialItemSaleAddTarget.Text = "Add Special Target";
            this.btnSpecialItemSaleAddTarget.UseVisualStyleBackColor = true;
            this.btnSpecialItemSaleAddTarget.Click += new System.EventHandler(this.btnSpecialItemSaleAddTarget_Click);
            // 
            // btnSpecialItemSaleSaveTarget
            // 
            this.btnSpecialItemSaleSaveTarget.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSpecialItemSaleSaveTarget.Location = new System.Drawing.Point(187, 440);
            this.btnSpecialItemSaleSaveTarget.Name = "btnSpecialItemSaleSaveTarget";
            this.btnSpecialItemSaleSaveTarget.Size = new System.Drawing.Size(180, 25);
            this.btnSpecialItemSaleSaveTarget.TabIndex = 67;
            this.btnSpecialItemSaleSaveTarget.Text = "Save Special Target";
            this.btnSpecialItemSaleSaveTarget.UseVisualStyleBackColor = true;
            // 
            // dgvSpecialItemSalesTarget
            // 
            this.dgvSpecialItemSalesTarget.AllowUserToAddRows = false;
            this.dgvSpecialItemSalesTarget.AllowUserToDeleteRows = false;
            this.dgvSpecialItemSalesTarget.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvSpecialItemSalesTarget.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dgvSpecialItemSalesTarget.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSpecialItemSalesTarget.Location = new System.Drawing.Point(372, 10);
            this.dgvSpecialItemSalesTarget.MultiSelect = false;
            this.dgvSpecialItemSalesTarget.Name = "dgvSpecialItemSalesTarget";
            this.dgvSpecialItemSalesTarget.ReadOnly = true;
            this.dgvSpecialItemSalesTarget.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSpecialItemSalesTarget.Size = new System.Drawing.Size(960, 595);
            this.dgvSpecialItemSalesTarget.TabIndex = 50;
            this.dgvSpecialItemSalesTarget.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtSpecialItemSaleProductSpecialPrice);
            this.groupBox1.Controls.Add(this.lblSpecialItemSaleProductSpecialPrice);
            this.groupBox1.Controls.Add(this.txtSpecialItemSaleProductSalePrice);
            this.groupBox1.Controls.Add(this.lblSpecialItemSaleProductSalePrice);
            this.groupBox1.Controls.Add(this.txtSpecialItemSaleEmployeeMobileNo);
            this.groupBox1.Controls.Add(this.lblSpecialItemSaleEmployeeMobileNo);
            this.groupBox1.Controls.Add(this.cmbSpecialItemSaleSelectEmployee);
            this.groupBox1.Controls.Add(this.cmbSpecialItemSaleSelectDesignation);
            this.groupBox1.Controls.Add(this.cmbSpecialItemSaleSelectGroup);
            this.groupBox1.Controls.Add(this.lblSpecialItemSaleSelectGroup);
            this.groupBox1.Controls.Add(this.txtSpecialItemSaleTargetUnit);
            this.groupBox1.Controls.Add(this.txtSpecialItemSaleProductCostPrice);
            this.groupBox1.Controls.Add(this.txtSpecialItemSaleProductName);
            this.groupBox1.Controls.Add(this.txtSpecialItemSaleProductID);
            this.groupBox1.Controls.Add(this.btnSpecialItemSaleProductCodeBrowse);
            this.groupBox1.Controls.Add(this.lblSpecialItemSaleProductCode);
            this.groupBox1.Controls.Add(this.txtSpecialItemSaleFromDate);
            this.groupBox1.Controls.Add(this.txtSpecialItemSaleToDate);
            this.groupBox1.Controls.Add(this.dtPSpecialItemSaleToDate);
            this.groupBox1.Controls.Add(this.lblSpecialItemSaleSelectDesignation);
            this.groupBox1.Controls.Add(this.txtSpecialItemSaleEmployeeID);
            this.groupBox1.Controls.Add(this.lblSpecialItemSaleEmployeeID);
            this.groupBox1.Controls.Add(this.lblSpecialItemSaleSelectEmployee);
            this.groupBox1.Controls.Add(this.lblSpecialItemSaleTargetAmount);
            this.groupBox1.Controls.Add(this.txtSpecialItemSaleTargetAmount);
            this.groupBox1.Controls.Add(this.lblSpecialItemSaleTargetUnit);
            this.groupBox1.Controls.Add(this.dtPSpecialItemSaleFromDate);
            this.groupBox1.Controls.Add(this.lblSpecialItemSaleProductCostPrice);
            this.groupBox1.Controls.Add(this.txtSpecialItemSaleProductCode);
            this.groupBox1.Controls.Add(this.lblSpecialItemSaleProductName);
            this.groupBox1.Controls.Add(this.lblSpecialItemSaleProductID);
            this.groupBox1.Controls.Add(this.lblSpecialItemSaleToDate);
            this.groupBox1.Controls.Add(this.lblSpecialItemSaleFromDate);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(6, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(360, 430);
            this.groupBox1.TabIndex = 49;
            this.groupBox1.TabStop = false;
            // 
            // txtSpecialItemSaleProductSpecialPrice
            // 
            this.txtSpecialItemSaleProductSpecialPrice.BackColor = System.Drawing.SystemColors.Window;
            this.txtSpecialItemSaleProductSpecialPrice.Location = new System.Drawing.Point(110, 205);
            this.txtSpecialItemSaleProductSpecialPrice.Name = "txtSpecialItemSaleProductSpecialPrice";
            this.txtSpecialItemSaleProductSpecialPrice.Size = new System.Drawing.Size(240, 22);
            this.txtSpecialItemSaleProductSpecialPrice.TabIndex = 73;
            // 
            // lblSpecialItemSaleProductSpecialPrice
            // 
            this.lblSpecialItemSaleProductSpecialPrice.AutoSize = true;
            this.lblSpecialItemSaleProductSpecialPrice.Location = new System.Drawing.Point(4, 208);
            this.lblSpecialItemSaleProductSpecialPrice.Name = "lblSpecialItemSaleProductSpecialPrice";
            this.lblSpecialItemSaleProductSpecialPrice.Size = new System.Drawing.Size(94, 16);
            this.lblSpecialItemSaleProductSpecialPrice.TabIndex = 72;
            this.lblSpecialItemSaleProductSpecialPrice.Text = "Special Price :";
            // 
            // txtSpecialItemSaleProductSalePrice
            // 
            this.txtSpecialItemSaleProductSalePrice.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtSpecialItemSaleProductSalePrice.Location = new System.Drawing.Point(110, 175);
            this.txtSpecialItemSaleProductSalePrice.Name = "txtSpecialItemSaleProductSalePrice";
            this.txtSpecialItemSaleProductSalePrice.ReadOnly = true;
            this.txtSpecialItemSaleProductSalePrice.Size = new System.Drawing.Size(240, 22);
            this.txtSpecialItemSaleProductSalePrice.TabIndex = 71;
            this.txtSpecialItemSaleProductSalePrice.TabStop = false;
            // 
            // lblSpecialItemSaleProductSalePrice
            // 
            this.lblSpecialItemSaleProductSalePrice.AutoSize = true;
            this.lblSpecialItemSaleProductSalePrice.Location = new System.Drawing.Point(4, 178);
            this.lblSpecialItemSaleProductSalePrice.Name = "lblSpecialItemSaleProductSalePrice";
            this.lblSpecialItemSaleProductSalePrice.Size = new System.Drawing.Size(76, 16);
            this.lblSpecialItemSaleProductSalePrice.TabIndex = 70;
            this.lblSpecialItemSaleProductSalePrice.Text = "Sale Price :";
            // 
            // txtSpecialItemSaleEmployeeMobileNo
            // 
            this.txtSpecialItemSaleEmployeeMobileNo.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtSpecialItemSaleEmployeeMobileNo.Location = new System.Drawing.Point(110, 341);
            this.txtSpecialItemSaleEmployeeMobileNo.Name = "txtSpecialItemSaleEmployeeMobileNo";
            this.txtSpecialItemSaleEmployeeMobileNo.ReadOnly = true;
            this.txtSpecialItemSaleEmployeeMobileNo.Size = new System.Drawing.Size(240, 22);
            this.txtSpecialItemSaleEmployeeMobileNo.TabIndex = 69;
            this.txtSpecialItemSaleEmployeeMobileNo.TabStop = false;
            // 
            // lblSpecialItemSaleEmployeeMobileNo
            // 
            this.lblSpecialItemSaleEmployeeMobileNo.AutoSize = true;
            this.lblSpecialItemSaleEmployeeMobileNo.Location = new System.Drawing.Point(4, 344);
            this.lblSpecialItemSaleEmployeeMobileNo.Name = "lblSpecialItemSaleEmployeeMobileNo";
            this.lblSpecialItemSaleEmployeeMobileNo.Size = new System.Drawing.Size(76, 16);
            this.lblSpecialItemSaleEmployeeMobileNo.TabIndex = 68;
            this.lblSpecialItemSaleEmployeeMobileNo.Text = "Mobile No :";
            // 
            // cmbSpecialItemSaleSelectEmployee
            // 
            this.cmbSpecialItemSaleSelectEmployee.AllowDrop = true;
            this.cmbSpecialItemSaleSelectEmployee.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSpecialItemSaleSelectEmployee.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSpecialItemSaleSelectEmployee.Enabled = false;
            this.cmbSpecialItemSaleSelectEmployee.FormattingEnabled = true;
            this.cmbSpecialItemSaleSelectEmployee.Location = new System.Drawing.Point(110, 295);
            this.cmbSpecialItemSaleSelectEmployee.Name = "cmbSpecialItemSaleSelectEmployee";
            this.cmbSpecialItemSaleSelectEmployee.Size = new System.Drawing.Size(240, 24);
            this.cmbSpecialItemSaleSelectEmployee.Sorted = true;
            this.cmbSpecialItemSaleSelectEmployee.TabIndex = 62;
            this.cmbSpecialItemSaleSelectEmployee.Text = "Select Employee";
            // 
            // cmbSpecialItemSaleSelectDesignation
            // 
            this.cmbSpecialItemSaleSelectDesignation.AllowDrop = true;
            this.cmbSpecialItemSaleSelectDesignation.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSpecialItemSaleSelectDesignation.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSpecialItemSaleSelectDesignation.Enabled = false;
            this.cmbSpecialItemSaleSelectDesignation.FormattingEnabled = true;
            this.cmbSpecialItemSaleSelectDesignation.Location = new System.Drawing.Point(110, 265);
            this.cmbSpecialItemSaleSelectDesignation.Name = "cmbSpecialItemSaleSelectDesignation";
            this.cmbSpecialItemSaleSelectDesignation.Size = new System.Drawing.Size(240, 24);
            this.cmbSpecialItemSaleSelectDesignation.TabIndex = 61;
            this.cmbSpecialItemSaleSelectDesignation.Text = "Select Designation";
            // 
            // cmbSpecialItemSaleSelectGroup
            // 
            this.cmbSpecialItemSaleSelectGroup.AllowDrop = true;
            this.cmbSpecialItemSaleSelectGroup.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSpecialItemSaleSelectGroup.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSpecialItemSaleSelectGroup.Enabled = false;
            this.cmbSpecialItemSaleSelectGroup.FormattingEnabled = true;
            this.cmbSpecialItemSaleSelectGroup.Location = new System.Drawing.Point(110, 235);
            this.cmbSpecialItemSaleSelectGroup.Name = "cmbSpecialItemSaleSelectGroup";
            this.cmbSpecialItemSaleSelectGroup.Size = new System.Drawing.Size(240, 24);
            this.cmbSpecialItemSaleSelectGroup.Sorted = true;
            this.cmbSpecialItemSaleSelectGroup.TabIndex = 60;
            this.cmbSpecialItemSaleSelectGroup.Text = "Select Team";
            // 
            // lblSpecialItemSaleSelectGroup
            // 
            this.lblSpecialItemSaleSelectGroup.AutoSize = true;
            this.lblSpecialItemSaleSelectGroup.Location = new System.Drawing.Point(4, 238);
            this.lblSpecialItemSaleSelectGroup.Name = "lblSpecialItemSaleSelectGroup";
            this.lblSpecialItemSaleSelectGroup.Size = new System.Drawing.Size(91, 16);
            this.lblSpecialItemSaleSelectGroup.TabIndex = 65;
            this.lblSpecialItemSaleSelectGroup.Text = "Select Team :";
            // 
            // txtSpecialItemSaleTargetUnit
            // 
            this.txtSpecialItemSaleTargetUnit.Enabled = false;
            this.txtSpecialItemSaleTargetUnit.Location = new System.Drawing.Point(110, 371);
            this.txtSpecialItemSaleTargetUnit.Name = "txtSpecialItemSaleTargetUnit";
            this.txtSpecialItemSaleTargetUnit.Size = new System.Drawing.Size(240, 22);
            this.txtSpecialItemSaleTargetUnit.TabIndex = 63;
            // 
            // txtSpecialItemSaleProductCostPrice
            // 
            this.txtSpecialItemSaleProductCostPrice.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtSpecialItemSaleProductCostPrice.Location = new System.Drawing.Point(110, 153);
            this.txtSpecialItemSaleProductCostPrice.Name = "txtSpecialItemSaleProductCostPrice";
            this.txtSpecialItemSaleProductCostPrice.ReadOnly = true;
            this.txtSpecialItemSaleProductCostPrice.Size = new System.Drawing.Size(240, 22);
            this.txtSpecialItemSaleProductCostPrice.TabIndex = 60;
            this.txtSpecialItemSaleProductCostPrice.TabStop = false;
            // 
            // txtSpecialItemSaleProductName
            // 
            this.txtSpecialItemSaleProductName.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtSpecialItemSaleProductName.Location = new System.Drawing.Point(110, 131);
            this.txtSpecialItemSaleProductName.Name = "txtSpecialItemSaleProductName";
            this.txtSpecialItemSaleProductName.ReadOnly = true;
            this.txtSpecialItemSaleProductName.Size = new System.Drawing.Size(240, 22);
            this.txtSpecialItemSaleProductName.TabIndex = 59;
            this.txtSpecialItemSaleProductName.TabStop = false;
            // 
            // txtSpecialItemSaleProductID
            // 
            this.txtSpecialItemSaleProductID.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtSpecialItemSaleProductID.Location = new System.Drawing.Point(110, 109);
            this.txtSpecialItemSaleProductID.Name = "txtSpecialItemSaleProductID";
            this.txtSpecialItemSaleProductID.ReadOnly = true;
            this.txtSpecialItemSaleProductID.Size = new System.Drawing.Size(240, 22);
            this.txtSpecialItemSaleProductID.TabIndex = 58;
            this.txtSpecialItemSaleProductID.TabStop = false;
            // 
            // btnSpecialItemSaleProductCodeBrowse
            // 
            this.btnSpecialItemSaleProductCodeBrowse.Enabled = false;
            this.btnSpecialItemSaleProductCodeBrowse.Location = new System.Drawing.Point(277, 86);
            this.btnSpecialItemSaleProductCodeBrowse.Name = "btnSpecialItemSaleProductCodeBrowse";
            this.btnSpecialItemSaleProductCodeBrowse.Size = new System.Drawing.Size(73, 22);
            this.btnSpecialItemSaleProductCodeBrowse.TabIndex = 59;
            this.btnSpecialItemSaleProductCodeBrowse.Text = "Browse";
            this.btnSpecialItemSaleProductCodeBrowse.UseVisualStyleBackColor = true;
            this.btnSpecialItemSaleProductCodeBrowse.Click += new System.EventHandler(this.btnSpecialItemSaleProductCodeBrowse_Click);
            // 
            // lblSpecialItemSaleProductCode
            // 
            this.lblSpecialItemSaleProductCode.AutoSize = true;
            this.lblSpecialItemSaleProductCode.Location = new System.Drawing.Point(4, 90);
            this.lblSpecialItemSaleProductCode.Name = "lblSpecialItemSaleProductCode";
            this.lblSpecialItemSaleProductCode.Size = new System.Drawing.Size(96, 16);
            this.lblSpecialItemSaleProductCode.TabIndex = 56;
            this.lblSpecialItemSaleProductCode.Text = "Product Code :";
            // 
            // txtSpecialItemSaleFromDate
            // 
            this.txtSpecialItemSaleFromDate.Enabled = false;
            this.txtSpecialItemSaleFromDate.Location = new System.Drawing.Point(110, 27);
            this.txtSpecialItemSaleFromDate.Name = "txtSpecialItemSaleFromDate";
            this.txtSpecialItemSaleFromDate.Size = new System.Drawing.Size(225, 22);
            this.txtSpecialItemSaleFromDate.TabIndex = 54;
            // 
            // txtSpecialItemSaleToDate
            // 
            this.txtSpecialItemSaleToDate.Enabled = false;
            this.txtSpecialItemSaleToDate.Location = new System.Drawing.Point(110, 57);
            this.txtSpecialItemSaleToDate.Name = "txtSpecialItemSaleToDate";
            this.txtSpecialItemSaleToDate.Size = new System.Drawing.Size(225, 22);
            this.txtSpecialItemSaleToDate.TabIndex = 56;
            // 
            // dtPSpecialItemSaleToDate
            // 
            this.dtPSpecialItemSaleToDate.Enabled = false;
            this.dtPSpecialItemSaleToDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtPSpecialItemSaleToDate.Location = new System.Drawing.Point(334, 57);
            this.dtPSpecialItemSaleToDate.Name = "dtPSpecialItemSaleToDate";
            this.dtPSpecialItemSaleToDate.Size = new System.Drawing.Size(16, 22);
            this.dtPSpecialItemSaleToDate.TabIndex = 57;
            this.dtPSpecialItemSaleToDate.TabStop = false;
            // 
            // lblSpecialItemSaleSelectDesignation
            // 
            this.lblSpecialItemSaleSelectDesignation.AutoSize = true;
            this.lblSpecialItemSaleSelectDesignation.Location = new System.Drawing.Point(4, 268);
            this.lblSpecialItemSaleSelectDesignation.Name = "lblSpecialItemSaleSelectDesignation";
            this.lblSpecialItemSaleSelectDesignation.Size = new System.Drawing.Size(86, 16);
            this.lblSpecialItemSaleSelectDesignation.TabIndex = 46;
            this.lblSpecialItemSaleSelectDesignation.Text = "Designation :";
            // 
            // txtSpecialItemSaleEmployeeID
            // 
            this.txtSpecialItemSaleEmployeeID.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtSpecialItemSaleEmployeeID.Location = new System.Drawing.Point(110, 319);
            this.txtSpecialItemSaleEmployeeID.Name = "txtSpecialItemSaleEmployeeID";
            this.txtSpecialItemSaleEmployeeID.ReadOnly = true;
            this.txtSpecialItemSaleEmployeeID.Size = new System.Drawing.Size(240, 22);
            this.txtSpecialItemSaleEmployeeID.TabIndex = 47;
            this.txtSpecialItemSaleEmployeeID.TabStop = false;
            // 
            // lblSpecialItemSaleEmployeeID
            // 
            this.lblSpecialItemSaleEmployeeID.AutoSize = true;
            this.lblSpecialItemSaleEmployeeID.Location = new System.Drawing.Point(4, 322);
            this.lblSpecialItemSaleEmployeeID.Name = "lblSpecialItemSaleEmployeeID";
            this.lblSpecialItemSaleEmployeeID.Size = new System.Drawing.Size(92, 16);
            this.lblSpecialItemSaleEmployeeID.TabIndex = 44;
            this.lblSpecialItemSaleEmployeeID.Text = "Employee ID :";
            // 
            // lblSpecialItemSaleSelectEmployee
            // 
            this.lblSpecialItemSaleSelectEmployee.AutoSize = true;
            this.lblSpecialItemSaleSelectEmployee.Location = new System.Drawing.Point(4, 298);
            this.lblSpecialItemSaleSelectEmployee.Name = "lblSpecialItemSaleSelectEmployee";
            this.lblSpecialItemSaleSelectEmployee.Size = new System.Drawing.Size(83, 16);
            this.lblSpecialItemSaleSelectEmployee.TabIndex = 42;
            this.lblSpecialItemSaleSelectEmployee.Text = "Select Emp :";
            // 
            // lblSpecialItemSaleTargetAmount
            // 
            this.lblSpecialItemSaleTargetAmount.AutoSize = true;
            this.lblSpecialItemSaleTargetAmount.Location = new System.Drawing.Point(4, 404);
            this.lblSpecialItemSaleTargetAmount.Name = "lblSpecialItemSaleTargetAmount";
            this.lblSpecialItemSaleTargetAmount.Size = new System.Drawing.Size(102, 16);
            this.lblSpecialItemSaleTargetAmount.TabIndex = 40;
            this.lblSpecialItemSaleTargetAmount.Text = "Target Amount :";
            // 
            // txtSpecialItemSaleTargetAmount
            // 
            this.txtSpecialItemSaleTargetAmount.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtSpecialItemSaleTargetAmount.Location = new System.Drawing.Point(110, 401);
            this.txtSpecialItemSaleTargetAmount.Name = "txtSpecialItemSaleTargetAmount";
            this.txtSpecialItemSaleTargetAmount.ReadOnly = true;
            this.txtSpecialItemSaleTargetAmount.Size = new System.Drawing.Size(240, 22);
            this.txtSpecialItemSaleTargetAmount.TabIndex = 41;
            this.txtSpecialItemSaleTargetAmount.TabStop = false;
            // 
            // lblSpecialItemSaleTargetUnit
            // 
            this.lblSpecialItemSaleTargetUnit.AutoSize = true;
            this.lblSpecialItemSaleTargetUnit.Location = new System.Drawing.Point(4, 374);
            this.lblSpecialItemSaleTargetUnit.Name = "lblSpecialItemSaleTargetUnit";
            this.lblSpecialItemSaleTargetUnit.Size = new System.Drawing.Size(80, 16);
            this.lblSpecialItemSaleTargetUnit.TabIndex = 39;
            this.lblSpecialItemSaleTargetUnit.Text = "Target Unit :";
            // 
            // dtPSpecialItemSaleFromDate
            // 
            this.dtPSpecialItemSaleFromDate.Enabled = false;
            this.dtPSpecialItemSaleFromDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtPSpecialItemSaleFromDate.Location = new System.Drawing.Point(334, 27);
            this.dtPSpecialItemSaleFromDate.Name = "dtPSpecialItemSaleFromDate";
            this.dtPSpecialItemSaleFromDate.Size = new System.Drawing.Size(16, 22);
            this.dtPSpecialItemSaleFromDate.TabIndex = 55;
            // 
            // lblSpecialItemSaleProductCostPrice
            // 
            this.lblSpecialItemSaleProductCostPrice.AutoSize = true;
            this.lblSpecialItemSaleProductCostPrice.Location = new System.Drawing.Point(4, 156);
            this.lblSpecialItemSaleProductCostPrice.Name = "lblSpecialItemSaleProductCostPrice";
            this.lblSpecialItemSaleProductCostPrice.Size = new System.Drawing.Size(75, 16);
            this.lblSpecialItemSaleProductCostPrice.TabIndex = 9;
            this.lblSpecialItemSaleProductCostPrice.Text = "Cost Price :";
            // 
            // txtSpecialItemSaleProductCode
            // 
            this.txtSpecialItemSaleProductCode.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtSpecialItemSaleProductCode.Enabled = false;
            this.txtSpecialItemSaleProductCode.Location = new System.Drawing.Point(110, 87);
            this.txtSpecialItemSaleProductCode.Name = "txtSpecialItemSaleProductCode";
            this.txtSpecialItemSaleProductCode.ReadOnly = true;
            this.txtSpecialItemSaleProductCode.Size = new System.Drawing.Size(166, 22);
            this.txtSpecialItemSaleProductCode.TabIndex = 58;
            this.txtSpecialItemSaleProductCode.TabStop = false;
            // 
            // lblSpecialItemSaleProductName
            // 
            this.lblSpecialItemSaleProductName.AutoSize = true;
            this.lblSpecialItemSaleProductName.Location = new System.Drawing.Point(4, 134);
            this.lblSpecialItemSaleProductName.Name = "lblSpecialItemSaleProductName";
            this.lblSpecialItemSaleProductName.Size = new System.Drawing.Size(100, 16);
            this.lblSpecialItemSaleProductName.TabIndex = 3;
            this.lblSpecialItemSaleProductName.Text = "Product Name :";
            // 
            // lblSpecialItemSaleProductID
            // 
            this.lblSpecialItemSaleProductID.AutoSize = true;
            this.lblSpecialItemSaleProductID.Location = new System.Drawing.Point(4, 112);
            this.lblSpecialItemSaleProductID.Name = "lblSpecialItemSaleProductID";
            this.lblSpecialItemSaleProductID.Size = new System.Drawing.Size(76, 16);
            this.lblSpecialItemSaleProductID.TabIndex = 2;
            this.lblSpecialItemSaleProductID.Text = "Product ID :";
            // 
            // lblSpecialItemSaleToDate
            // 
            this.lblSpecialItemSaleToDate.AutoSize = true;
            this.lblSpecialItemSaleToDate.Location = new System.Drawing.Point(4, 60);
            this.lblSpecialItemSaleToDate.Name = "lblSpecialItemSaleToDate";
            this.lblSpecialItemSaleToDate.Size = new System.Drawing.Size(63, 16);
            this.lblSpecialItemSaleToDate.TabIndex = 1;
            this.lblSpecialItemSaleToDate.Text = "To Date :";
            // 
            // lblSpecialItemSaleFromDate
            // 
            this.lblSpecialItemSaleFromDate.AutoSize = true;
            this.lblSpecialItemSaleFromDate.Location = new System.Drawing.Point(4, 30);
            this.lblSpecialItemSaleFromDate.Name = "lblSpecialItemSaleFromDate";
            this.lblSpecialItemSaleFromDate.Size = new System.Drawing.Size(77, 16);
            this.lblSpecialItemSaleFromDate.TabIndex = 0;
            this.lblSpecialItemSaleFromDate.Text = "From Date :";
            // 
            // tbSalesDetails
            // 
            this.tbSalesDetails.Controls.Add(this.groupBox2);
            this.tbSalesDetails.Controls.Add(this.dgvSalesDetails);
            this.tbSalesDetails.Location = new System.Drawing.Point(4, 25);
            this.tbSalesDetails.Name = "tbSalesDetails";
            this.tbSalesDetails.Size = new System.Drawing.Size(1337, 611);
            this.tbSalesDetails.TabIndex = 14;
            this.tbSalesDetails.Text = "Sales Details";
            this.tbSalesDetails.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnRefreshSalesDetails);
            this.groupBox2.Controls.Add(this.radioBtnSalesDetailsSearchByProductCode);
            this.groupBox2.Controls.Add(this.txtSalesDetailsToDate);
            this.groupBox2.Controls.Add(this.dtPSalesDetailsToDate);
            this.groupBox2.Controls.Add(this.lblSalesDetailsToDate);
            this.groupBox2.Controls.Add(this.txtSalesDetailsFormDate);
            this.groupBox2.Controls.Add(this.dtPSalesDetailsFormDate);
            this.groupBox2.Controls.Add(this.lblSalesDetailsFormDate);
            this.groupBox2.Controls.Add(this.radioBtnSalesDetailsSearchByDesignation);
            this.groupBox2.Controls.Add(this.radioBtnSalesDetailsShowAll);
            this.groupBox2.Controls.Add(this.btnSalesDetailsSearch);
            this.groupBox2.Controls.Add(this.cmbSalesDetailsDesignation);
            this.groupBox2.Controls.Add(this.txtSalesDetailsSearchCriteria);
            this.groupBox2.Controls.Add(this.radioBtnSalesDetailsSearchByGroupAndDesignation);
            this.groupBox2.Controls.Add(this.radioBtnSalesDetailsSearchByGroup);
            this.groupBox2.Controls.Add(this.radioBtnSalesDetailsSearchByMobile);
            this.groupBox2.Controls.Add(this.radioBtnSalesDetailsSearchByEmp);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(7, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1325, 105);
            this.groupBox2.TabIndex = 55;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Search";
            // 
            // btnRefreshSalesDetails
            // 
            this.btnRefreshSalesDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefreshSalesDetails.Location = new System.Drawing.Point(365, 74);
            this.btnRefreshSalesDetails.Name = "btnRefreshSalesDetails";
            this.btnRefreshSalesDetails.Size = new System.Drawing.Size(76, 25);
            this.btnRefreshSalesDetails.TabIndex = 82;
            this.btnRefreshSalesDetails.Text = "Refresh";
            this.btnRefreshSalesDetails.UseVisualStyleBackColor = true;
            this.btnRefreshSalesDetails.Click += new System.EventHandler(this.btnRefreshSalesDetails_Click);
            // 
            // radioBtnSalesDetailsSearchByProductCode
            // 
            this.radioBtnSalesDetailsSearchByProductCode.AutoSize = true;
            this.radioBtnSalesDetailsSearchByProductCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioBtnSalesDetailsSearchByProductCode.Location = new System.Drawing.Point(534, 48);
            this.radioBtnSalesDetailsSearchByProductCode.Name = "radioBtnSalesDetailsSearchByProductCode";
            this.radioBtnSalesDetailsSearchByProductCode.Size = new System.Drawing.Size(108, 20);
            this.radioBtnSalesDetailsSearchByProductCode.TabIndex = 81;
            this.radioBtnSalesDetailsSearchByProductCode.TabStop = true;
            this.radioBtnSalesDetailsSearchByProductCode.Text = "Product Code";
            this.radioBtnSalesDetailsSearchByProductCode.UseVisualStyleBackColor = true;
            // 
            // txtSalesDetailsToDate
            // 
            this.txtSalesDetailsToDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSalesDetailsToDate.Location = new System.Drawing.Point(227, 19);
            this.txtSalesDetailsToDate.Name = "txtSalesDetailsToDate";
            this.txtSalesDetailsToDate.Size = new System.Drawing.Size(108, 22);
            this.txtSalesDetailsToDate.TabIndex = 79;
            // 
            // dtPSalesDetailsToDate
            // 
            this.dtPSalesDetailsToDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtPSalesDetailsToDate.Location = new System.Drawing.Point(335, 19);
            this.dtPSalesDetailsToDate.Name = "dtPSalesDetailsToDate";
            this.dtPSalesDetailsToDate.Size = new System.Drawing.Size(16, 22);
            this.dtPSalesDetailsToDate.TabIndex = 80;
            this.dtPSalesDetailsToDate.CloseUp += new System.EventHandler(this.dtPSalesDetailsToDate_CloseUp);
            // 
            // lblSalesDetailsToDate
            // 
            this.lblSalesDetailsToDate.AutoSize = true;
            this.lblSalesDetailsToDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalesDetailsToDate.Location = new System.Drawing.Point(193, 22);
            this.lblSalesDetailsToDate.Name = "lblSalesDetailsToDate";
            this.lblSalesDetailsToDate.Size = new System.Drawing.Size(31, 16);
            this.lblSalesDetailsToDate.TabIndex = 78;
            this.lblSalesDetailsToDate.Text = "To :";
            // 
            // txtSalesDetailsFormDate
            // 
            this.txtSalesDetailsFormDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSalesDetailsFormDate.Location = new System.Drawing.Point(54, 19);
            this.txtSalesDetailsFormDate.Name = "txtSalesDetailsFormDate";
            this.txtSalesDetailsFormDate.Size = new System.Drawing.Size(108, 22);
            this.txtSalesDetailsFormDate.TabIndex = 76;
            // 
            // dtPSalesDetailsFormDate
            // 
            this.dtPSalesDetailsFormDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtPSalesDetailsFormDate.Location = new System.Drawing.Point(162, 19);
            this.dtPSalesDetailsFormDate.Name = "dtPSalesDetailsFormDate";
            this.dtPSalesDetailsFormDate.Size = new System.Drawing.Size(16, 22);
            this.dtPSalesDetailsFormDate.TabIndex = 77;
            this.dtPSalesDetailsFormDate.CloseUp += new System.EventHandler(this.dtPSalesDetailsFormDate_CloseUp);
            // 
            // lblSalesDetailsFormDate
            // 
            this.lblSalesDetailsFormDate.AutoSize = true;
            this.lblSalesDetailsFormDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalesDetailsFormDate.Location = new System.Drawing.Point(8, 22);
            this.lblSalesDetailsFormDate.Name = "lblSalesDetailsFormDate";
            this.lblSalesDetailsFormDate.Size = new System.Drawing.Size(45, 16);
            this.lblSalesDetailsFormDate.TabIndex = 75;
            this.lblSalesDetailsFormDate.Text = "From :";
            // 
            // radioBtnSalesDetailsSearchByDesignation
            // 
            this.radioBtnSalesDetailsSearchByDesignation.AutoSize = true;
            this.radioBtnSalesDetailsSearchByDesignation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioBtnSalesDetailsSearchByDesignation.Location = new System.Drawing.Point(261, 48);
            this.radioBtnSalesDetailsSearchByDesignation.Name = "radioBtnSalesDetailsSearchByDesignation";
            this.radioBtnSalesDetailsSearchByDesignation.Size = new System.Drawing.Size(98, 20);
            this.radioBtnSalesDetailsSearchByDesignation.TabIndex = 74;
            this.radioBtnSalesDetailsSearchByDesignation.TabStop = true;
            this.radioBtnSalesDetailsSearchByDesignation.Text = "Designation";
            this.radioBtnSalesDetailsSearchByDesignation.UseVisualStyleBackColor = true;
            // 
            // radioBtnSalesDetailsShowAll
            // 
            this.radioBtnSalesDetailsShowAll.AutoSize = true;
            this.radioBtnSalesDetailsShowAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioBtnSalesDetailsShowAll.Location = new System.Drawing.Point(648, 48);
            this.radioBtnSalesDetailsShowAll.Name = "radioBtnSalesDetailsShowAll";
            this.radioBtnSalesDetailsShowAll.Size = new System.Drawing.Size(77, 20);
            this.radioBtnSalesDetailsShowAll.TabIndex = 70;
            this.radioBtnSalesDetailsShowAll.TabStop = true;
            this.radioBtnSalesDetailsShowAll.Text = "Show All";
            this.radioBtnSalesDetailsShowAll.UseVisualStyleBackColor = true;
            // 
            // btnSalesDetailsSearch
            // 
            this.btnSalesDetailsSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalesDetailsSearch.Location = new System.Drawing.Point(280, 73);
            this.btnSalesDetailsSearch.Name = "btnSalesDetailsSearch";
            this.btnSalesDetailsSearch.Size = new System.Drawing.Size(79, 25);
            this.btnSalesDetailsSearch.TabIndex = 73;
            this.btnSalesDetailsSearch.Text = "Search";
            this.btnSalesDetailsSearch.UseVisualStyleBackColor = true;
            this.btnSalesDetailsSearch.Click += new System.EventHandler(this.btnSalesDetailsSearch_Click);
            // 
            // cmbSalesDetailsDesignation
            // 
            this.cmbSalesDetailsDesignation.Enabled = false;
            this.cmbSalesDetailsDesignation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSalesDetailsDesignation.FormattingEnabled = true;
            this.cmbSalesDetailsDesignation.Location = new System.Drawing.Point(196, 74);
            this.cmbSalesDetailsDesignation.Name = "cmbSalesDetailsDesignation";
            this.cmbSalesDetailsDesignation.Size = new System.Drawing.Size(75, 24);
            this.cmbSalesDetailsDesignation.TabIndex = 72;
            // 
            // txtSalesDetailsSearchCriteria
            // 
            this.txtSalesDetailsSearchCriteria.Enabled = false;
            this.txtSalesDetailsSearchCriteria.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSalesDetailsSearchCriteria.Location = new System.Drawing.Point(11, 74);
            this.txtSalesDetailsSearchCriteria.Name = "txtSalesDetailsSearchCriteria";
            this.txtSalesDetailsSearchCriteria.Size = new System.Drawing.Size(177, 22);
            this.txtSalesDetailsSearchCriteria.TabIndex = 71;
            // 
            // radioBtnSalesDetailsSearchByGroupAndDesignation
            // 
            this.radioBtnSalesDetailsSearchByGroupAndDesignation.AutoSize = true;
            this.radioBtnSalesDetailsSearchByGroupAndDesignation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioBtnSalesDetailsSearchByGroupAndDesignation.Location = new System.Drawing.Point(365, 48);
            this.radioBtnSalesDetailsSearchByGroupAndDesignation.Name = "radioBtnSalesDetailsSearchByGroupAndDesignation";
            this.radioBtnSalesDetailsSearchByGroupAndDesignation.Size = new System.Drawing.Size(163, 20);
            this.radioBtnSalesDetailsSearchByGroupAndDesignation.TabIndex = 69;
            this.radioBtnSalesDetailsSearchByGroupAndDesignation.TabStop = true;
            this.radioBtnSalesDetailsSearchByGroupAndDesignation.Text = "Team and Designation";
            this.radioBtnSalesDetailsSearchByGroupAndDesignation.UseVisualStyleBackColor = true;
            // 
            // radioBtnSalesDetailsSearchByGroup
            // 
            this.radioBtnSalesDetailsSearchByGroup.AutoSize = true;
            this.radioBtnSalesDetailsSearchByGroup.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioBtnSalesDetailsSearchByGroup.Location = new System.Drawing.Point(183, 48);
            this.radioBtnSalesDetailsSearchByGroup.Name = "radioBtnSalesDetailsSearchByGroup";
            this.radioBtnSalesDetailsSearchByGroup.Size = new System.Drawing.Size(62, 20);
            this.radioBtnSalesDetailsSearchByGroup.TabIndex = 68;
            this.radioBtnSalesDetailsSearchByGroup.TabStop = true;
            this.radioBtnSalesDetailsSearchByGroup.Text = "Team";
            this.radioBtnSalesDetailsSearchByGroup.UseVisualStyleBackColor = true;
            // 
            // radioBtnSalesDetailsSearchByMobile
            // 
            this.radioBtnSalesDetailsSearchByMobile.AutoSize = true;
            this.radioBtnSalesDetailsSearchByMobile.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioBtnSalesDetailsSearchByMobile.Location = new System.Drawing.Point(100, 48);
            this.radioBtnSalesDetailsSearchByMobile.Name = "radioBtnSalesDetailsSearchByMobile";
            this.radioBtnSalesDetailsSearchByMobile.Size = new System.Drawing.Size(67, 20);
            this.radioBtnSalesDetailsSearchByMobile.TabIndex = 67;
            this.radioBtnSalesDetailsSearchByMobile.TabStop = true;
            this.radioBtnSalesDetailsSearchByMobile.Text = "Mobile";
            this.radioBtnSalesDetailsSearchByMobile.UseVisualStyleBackColor = true;
            // 
            // radioBtnSalesDetailsSearchByEmp
            // 
            this.radioBtnSalesDetailsSearchByEmp.AutoSize = true;
            this.radioBtnSalesDetailsSearchByEmp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioBtnSalesDetailsSearchByEmp.Location = new System.Drawing.Point(6, 48);
            this.radioBtnSalesDetailsSearchByEmp.Name = "radioBtnSalesDetailsSearchByEmp";
            this.radioBtnSalesDetailsSearchByEmp.Size = new System.Drawing.Size(88, 20);
            this.radioBtnSalesDetailsSearchByEmp.TabIndex = 66;
            this.radioBtnSalesDetailsSearchByEmp.TabStop = true;
            this.radioBtnSalesDetailsSearchByEmp.Text = "Employee";
            this.radioBtnSalesDetailsSearchByEmp.UseVisualStyleBackColor = true;
            // 
            // dgvSalesDetails
            // 
            this.dgvSalesDetails.AllowUserToAddRows = false;
            this.dgvSalesDetails.AllowUserToDeleteRows = false;
            this.dgvSalesDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvSalesDetails.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dgvSalesDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSalesDetails.Location = new System.Drawing.Point(6, 116);
            this.dgvSalesDetails.MultiSelect = false;
            this.dgvSalesDetails.Name = "dgvSalesDetails";
            this.dgvSalesDetails.ReadOnly = true;
            this.dgvSalesDetails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSalesDetails.Size = new System.Drawing.Size(1325, 490);
            this.dgvSalesDetails.TabIndex = 54;
            this.dgvSalesDetails.TabStop = false;
            // 
            // tbReports
            // 
            this.tbReports.Controls.Add(this.groupBoxSelectOptionForReports);
            this.tbReports.Location = new System.Drawing.Point(4, 25);
            this.tbReports.Name = "tbReports";
            this.tbReports.Size = new System.Drawing.Size(1337, 611);
            this.tbReports.TabIndex = 15;
            this.tbReports.Text = "Reports";
            this.tbReports.UseVisualStyleBackColor = true;
            // 
            // groupBoxSelectOptionForReports
            // 
            this.groupBoxSelectOptionForReports.Controls.Add(this.radioButtonDivisionReport);
            this.groupBoxSelectOptionForReports.Controls.Add(this.radioButtonProductReport);
            this.groupBoxSelectOptionForReports.Controls.Add(this.btnLoadTSM);
            this.groupBoxSelectOptionForReports.Controls.Add(this.btnLoadSR);
            this.groupBoxSelectOptionForReports.Controls.Add(this.btnLoadSM);
            this.groupBoxSelectOptionForReports.Controls.Add(this.btnLoadASM);
            this.groupBoxSelectOptionForReports.Controls.Add(this.radioButtonUserReport);
            this.groupBoxSelectOptionForReports.Controls.Add(this.btnReportShow);
            this.groupBoxSelectOptionForReports.Controls.Add(this.radioBtnSalesTargetReport);
            this.groupBoxSelectOptionForReports.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxSelectOptionForReports.Location = new System.Drawing.Point(7, 3);
            this.groupBoxSelectOptionForReports.Name = "groupBoxSelectOptionForReports";
            this.groupBoxSelectOptionForReports.Size = new System.Drawing.Size(1325, 105);
            this.groupBoxSelectOptionForReports.TabIndex = 56;
            this.groupBoxSelectOptionForReports.TabStop = false;
            this.groupBoxSelectOptionForReports.Text = "Select Option For Reports";
            // 
            // radioButtonDivisionReport
            // 
            this.radioButtonDivisionReport.AutoSize = true;
            this.radioButtonDivisionReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonDivisionReport.Location = new System.Drawing.Point(393, 21);
            this.radioButtonDivisionReport.Name = "radioButtonDivisionReport";
            this.radioButtonDivisionReport.Size = new System.Drawing.Size(118, 20);
            this.radioButtonDivisionReport.TabIndex = 80;
            this.radioButtonDivisionReport.TabStop = true;
            this.radioButtonDivisionReport.Text = "Division Report";
            this.radioButtonDivisionReport.UseVisualStyleBackColor = true;
            // 
            // radioButtonProductReport
            // 
            this.radioButtonProductReport.AutoSize = true;
            this.radioButtonProductReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonProductReport.Location = new System.Drawing.Point(269, 21);
            this.radioButtonProductReport.Name = "radioButtonProductReport";
            this.radioButtonProductReport.Size = new System.Drawing.Size(116, 20);
            this.radioButtonProductReport.TabIndex = 79;
            this.radioButtonProductReport.TabStop = true;
            this.radioButtonProductReport.Text = "Product Report";
            this.radioButtonProductReport.UseVisualStyleBackColor = true;
            // 
            // btnLoadTSM
            // 
            this.btnLoadTSM.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoadTSM.Location = new System.Drawing.Point(373, 73);
            this.btnLoadTSM.Name = "btnLoadTSM";
            this.btnLoadTSM.Size = new System.Drawing.Size(90, 25);
            this.btnLoadTSM.TabIndex = 77;
            this.btnLoadTSM.Text = "Load TSM";
            this.btnLoadTSM.UseVisualStyleBackColor = true;
            this.btnLoadTSM.Visible = false;
            // 
            // btnLoadSR
            // 
            this.btnLoadSR.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoadSR.Location = new System.Drawing.Point(464, 73);
            this.btnLoadSR.Name = "btnLoadSR";
            this.btnLoadSR.Size = new System.Drawing.Size(90, 25);
            this.btnLoadSR.TabIndex = 78;
            this.btnLoadSR.Text = "Load SR";
            this.btnLoadSR.UseVisualStyleBackColor = true;
            this.btnLoadSR.Visible = false;
            // 
            // btnLoadSM
            // 
            this.btnLoadSM.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoadSM.Location = new System.Drawing.Point(192, 73);
            this.btnLoadSM.Name = "btnLoadSM";
            this.btnLoadSM.Size = new System.Drawing.Size(90, 25);
            this.btnLoadSM.TabIndex = 75;
            this.btnLoadSM.Text = "Load SM";
            this.btnLoadSM.UseVisualStyleBackColor = true;
            this.btnLoadSM.Visible = false;
            // 
            // btnLoadASM
            // 
            this.btnLoadASM.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoadASM.Location = new System.Drawing.Point(283, 73);
            this.btnLoadASM.Name = "btnLoadASM";
            this.btnLoadASM.Size = new System.Drawing.Size(90, 25);
            this.btnLoadASM.TabIndex = 76;
            this.btnLoadASM.Text = "Load ASM";
            this.btnLoadASM.UseVisualStyleBackColor = true;
            this.btnLoadASM.Visible = false;
            // 
            // radioButtonUserReport
            // 
            this.radioButtonUserReport.AutoSize = true;
            this.radioButtonUserReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonUserReport.Location = new System.Drawing.Point(162, 21);
            this.radioButtonUserReport.Name = "radioButtonUserReport";
            this.radioButtonUserReport.Size = new System.Drawing.Size(99, 20);
            this.radioButtonUserReport.TabIndex = 74;
            this.radioButtonUserReport.TabStop = true;
            this.radioButtonUserReport.Text = "User Report";
            this.radioButtonUserReport.UseVisualStyleBackColor = true;
            // 
            // btnReportShow
            // 
            this.btnReportShow.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReportShow.Location = new System.Drawing.Point(6, 73);
            this.btnReportShow.Name = "btnReportShow";
            this.btnReportShow.Size = new System.Drawing.Size(180, 25);
            this.btnReportShow.TabIndex = 73;
            this.btnReportShow.Text = "Show Report Form";
            this.btnReportShow.UseVisualStyleBackColor = true;
            this.btnReportShow.Click += new System.EventHandler(this.btnReportShow_Click);
            // 
            // radioBtnSalesTargetReport
            // 
            this.radioBtnSalesTargetReport.AutoSize = true;
            this.radioBtnSalesTargetReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioBtnSalesTargetReport.Location = new System.Drawing.Point(6, 21);
            this.radioBtnSalesTargetReport.Name = "radioBtnSalesTargetReport";
            this.radioBtnSalesTargetReport.Size = new System.Drawing.Size(148, 20);
            this.radioBtnSalesTargetReport.TabIndex = 66;
            this.radioBtnSalesTargetReport.TabStop = true;
            this.radioBtnSalesTargetReport.Text = "Sales Target Report";
            this.radioBtnSalesTargetReport.UseVisualStyleBackColor = true;
            // 
            // btnOK
            // 
            this.btnOK.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOK.Location = new System.Drawing.Point(430, 12);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(97, 25);
            this.btnOK.TabIndex = 14;
            this.btnOK.Text = "Connect";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // gboConnectionStatus
            // 
            this.gboConnectionStatus.BackColor = System.Drawing.Color.Transparent;
            this.gboConnectionStatus.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gboConnectionStatus.Controls.Add(this.btnDBBackup);
            this.gboConnectionStatus.Controls.Add(this.btnExitApplication);
            this.gboConnectionStatus.Controls.Add(this.btnOK);
            this.gboConnectionStatus.Controls.Add(this.label23);
            this.gboConnectionStatus.Controls.Add(this.lblConnectionStatus);
            this.gboConnectionStatus.Controls.Add(this.btnDisconnect);
            this.gboConnectionStatus.Location = new System.Drawing.Point(2, 644);
            this.gboConnectionStatus.Name = "gboConnectionStatus";
            this.gboConnectionStatus.Size = new System.Drawing.Size(832, 41);
            this.gboConnectionStatus.TabIndex = 41;
            this.gboConnectionStatus.TabStop = false;
            // 
            // btnDBBackup
            // 
            this.btnDBBackup.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDBBackup.Location = new System.Drawing.Point(730, 12);
            this.btnDBBackup.Name = "btnDBBackup";
            this.btnDBBackup.Size = new System.Drawing.Size(97, 25);
            this.btnDBBackup.TabIndex = 39;
            this.btnDBBackup.Text = "BackUp";
            this.btnDBBackup.Click += new System.EventHandler(this.btnDBBackup_Click);
            // 
            // btnExitApplication
            // 
            this.btnExitApplication.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExitApplication.Location = new System.Drawing.Point(630, 12);
            this.btnExitApplication.Name = "btnExitApplication";
            this.btnExitApplication.Size = new System.Drawing.Size(97, 25);
            this.btnExitApplication.TabIndex = 38;
            this.btnExitApplication.Text = "Exit";
            this.btnExitApplication.Click += new System.EventHandler(this.btnExitApplication_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(6, 16);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(140, 16);
            this.label23.TabIndex = 37;
            this.label23.Text = "Connection Status :";
            // 
            // lblConnectionStatus
            // 
            this.lblConnectionStatus.AutoSize = true;
            this.lblConnectionStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConnectionStatus.ForeColor = System.Drawing.Color.Red;
            this.lblConnectionStatus.Location = new System.Drawing.Point(152, 16);
            this.lblConnectionStatus.Name = "lblConnectionStatus";
            this.lblConnectionStatus.Size = new System.Drawing.Size(110, 16);
            this.lblConnectionStatus.TabIndex = 36;
            this.lblConnectionStatus.Text = "Not Connected";
            // 
            // btnDisconnect
            // 
            this.btnDisconnect.Enabled = false;
            this.btnDisconnect.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDisconnect.Location = new System.Drawing.Point(530, 12);
            this.btnDisconnect.Name = "btnDisconnect";
            this.btnDisconnect.Size = new System.Drawing.Size(97, 25);
            this.btnDisconnect.TabIndex = 4;
            this.btnDisconnect.Text = "Disconnect";
            this.btnDisconnect.Click += new System.EventHandler(this.btnDisconnect_Click);
            // 
            // statusBar1
            // 
            this.statusBar1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.statusBar1.Location = new System.Drawing.Point(0, 689);
            this.statusBar1.Name = "statusBar1";
            this.statusBar1.Size = new System.Drawing.Size(1347, 20);
            this.statusBar1.TabIndex = 75;
            this.statusBar1.Text = "Message";
            // 
            // reset_Focus_Timer
            // 
            this.reset_Focus_Timer.Enabled = true;
            this.reset_Focus_Timer.Interval = 10000;
            this.reset_Focus_Timer.Tick += new System.EventHandler(this.reset_Focus_Timer_Tick);
            // 
            // txtStartTime
            // 
            this.txtStartTime.Location = new System.Drawing.Point(934, 659);
            this.txtStartTime.Name = "txtStartTime";
            this.txtStartTime.Size = new System.Drawing.Size(43, 20);
            this.txtStartTime.TabIndex = 76;
            this.txtStartTime.Text = "12";
            // 
            // lblStartTime
            // 
            this.lblStartTime.AutoSize = true;
            this.lblStartTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStartTime.Location = new System.Drawing.Point(846, 660);
            this.lblStartTime.Name = "lblStartTime";
            this.lblStartTime.Size = new System.Drawing.Size(87, 16);
            this.lblStartTime.TabIndex = 39;
            this.lblStartTime.Text = "Auto Send :";
            // 
            // lblEndTime
            // 
            this.lblEndTime.AutoSize = true;
            this.lblEndTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEndTime.Location = new System.Drawing.Point(985, 660);
            this.lblEndTime.Name = "lblEndTime";
            this.lblEndTime.Size = new System.Drawing.Size(82, 16);
            this.lblEndTime.TabIndex = 77;
            this.lblEndTime.Text = "End Time :";
            // 
            // txtEndTime
            // 
            this.txtEndTime.Location = new System.Drawing.Point(1070, 659);
            this.txtEndTime.Name = "txtEndTime";
            this.txtEndTime.Size = new System.Drawing.Size(43, 20);
            this.txtEndTime.TabIndex = 78;
            // 
            // checkBoxSMSRead
            // 
            this.checkBoxSMSRead.AutoSize = true;
            this.checkBoxSMSRead.Location = new System.Drawing.Point(1122, 661);
            this.checkBoxSMSRead.Name = "checkBoxSMSRead";
            this.checkBoxSMSRead.Size = new System.Drawing.Size(78, 17);
            this.checkBoxSMSRead.TabIndex = 79;
            this.checkBoxSMSRead.Text = "SMS Read";
            this.checkBoxSMSRead.UseVisualStyleBackColor = true;
            this.checkBoxSMSRead.Click += new System.EventHandler(this.checkBoxSMSRead_Click);
            // 
            // checkBoxSMSSend
            // 
            this.checkBoxSMSSend.AutoSize = true;
            this.checkBoxSMSSend.Location = new System.Drawing.Point(1201, 661);
            this.checkBoxSMSSend.Name = "checkBoxSMSSend";
            this.checkBoxSMSSend.Size = new System.Drawing.Size(77, 17);
            this.checkBoxSMSSend.TabIndex = 80;
            this.checkBoxSMSSend.Text = "SMS Send";
            this.checkBoxSMSSend.UseVisualStyleBackColor = true;
            this.checkBoxSMSSend.Click += new System.EventHandler(this.checkBoxSMSSend_Click);
            // 
            // Auto_Read_Timer
            // 
            this.Auto_Read_Timer.Enabled = true;
            this.Auto_Read_Timer.Interval = 60000;
            this.Auto_Read_Timer.Tick += new System.EventHandler(this.Auto_Read_Timer_Tick);
            // 
            // SMSapplication
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(1347, 709);
            this.Controls.Add(this.checkBoxSMSSend);
            this.Controls.Add(this.checkBoxSMSRead);
            this.Controls.Add(this.txtEndTime);
            this.Controls.Add(this.lblEndTime);
            this.Controls.Add(this.lblStartTime);
            this.Controls.Add(this.txtStartTime);
            this.Controls.Add(this.statusBar1);
            this.Controls.Add(this.gboConnectionStatus);
            this.Controls.Add(this.tabSMSapplication);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SMSapplication";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SMS Application";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.SMSapplication_Load);
            this.tabSMSapplication.ResumeLayout(false);
            this.tbPortSettings.ResumeLayout(false);
            this.gboPortSettings.ResumeLayout(false);
            this.gboPortSettings.PerformLayout();
            this.tbSendSMS.ResumeLayout(false);
            this.gboSendSMS.ResumeLayout(false);
            this.gboSendSMS.PerformLayout();
            this.tbReadSMS.ResumeLayout(false);
            this.gboReadSMS.ResumeLayout(false);
            this.gboReadSMS.PerformLayout();
            this.tbDeleteSMS.ResumeLayout(false);
            this.groupBoxSMSCount.ResumeLayout(false);
            this.groupBoxSMSCount.PerformLayout();
            this.gboDeleteSMS.ResumeLayout(false);
            this.gboDeleteSMS.PerformLayout();
            this.tbUserCreate.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewUserDetails)).EndInit();
            this.groupBoxUser.ResumeLayout(false);
            this.groupBoxUser.PerformLayout();
            this.tbDepartment.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDepartmentDetails)).EndInit();
            this.groupBoxDepartment.ResumeLayout(false);
            this.groupBoxDepartment.PerformLayout();
            this.tbDesignation.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDesignationList)).EndInit();
            this.groupBoxDesignation.ResumeLayout(false);
            this.groupBoxDesignation.PerformLayout();
            this.tbGroup.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewGroupDetails)).EndInit();
            this.groupBoxGroup.ResumeLayout(false);
            this.groupBoxGroup.PerformLayout();
            this.tbEmployee.ResumeLayout(false);
            this.groupBoxSearchEmployee.ResumeLayout(false);
            this.groupBoxSearchEmployee.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEmployeeList)).EndInit();
            this.groupBoxEmployee.ResumeLayout(false);
            this.groupBoxEmployee.PerformLayout();
            this.tbDivision.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPreviousAddedEmpList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLoadDistinctDivision)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLoadTempDivision)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLoadGroup)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDivision)).EndInit();
            this.groupBoxDivision.ResumeLayout(false);
            this.groupBoxDivision.PerformLayout();
            this.tbMarket.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMarket)).EndInit();
            this.groupBoxMarket.ResumeLayout(false);
            this.groupBoxMarket.PerformLayout();
            this.tbMarketSetup.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvLoadMarketBySelectedDivision)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMarketSetup)).EndInit();
            this.groupBoxMarketSetup.ResumeLayout(false);
            this.groupBoxMarketSetup.PerformLayout();
            this.tbProduct.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProduct)).EndInit();
            this.groupBoxProduct.ResumeLayout(false);
            this.groupBoxProduct.PerformLayout();
            this.tbProductPriceUpdateLog.ResumeLayout(false);
            this.groupBoxProductPriceLogSearch.ResumeLayout(false);
            this.groupBoxProductPriceLogSearch.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProductPriceUpdateLog)).EndInit();
            this.tbSalesTarget.ResumeLayout(false);
            this.tbSalesTarget.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPrevAddedSalesTargetDetails)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProductListForSalesTarget)).EndInit();
            this.groupBoxTargetSearch.ResumeLayout(false);
            this.groupBoxTargetSearch.PerformLayout();
            this.groupBoxSalesTarget.ResumeLayout(false);
            this.groupBoxSalesTarget.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSalesTargetDetails)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSalesTarget)).EndInit();
            this.tbSpecialItemSaleTarget.ResumeLayout(false);
            this.groupBoxSpecialItemSearch.ResumeLayout(false);
            this.groupBoxSpecialItemSearch.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSpecialItemSalesTarget)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tbSalesDetails.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSalesDetails)).EndInit();
            this.tbReports.ResumeLayout(false);
            this.groupBoxSelectOptionForReports.ResumeLayout(false);
            this.groupBoxSelectOptionForReports.PerformLayout();
            this.gboConnectionStatus.ResumeLayout(false);
            this.gboConnectionStatus.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabSMSapplication;
        private System.Windows.Forms.TabPage tbPortSettings;
        private System.Windows.Forms.TabPage tbSendSMS;
        private System.Windows.Forms.TabPage tbReadSMS;
        private System.Windows.Forms.TabPage tbDeleteSMS;
        private System.Windows.Forms.GroupBox gboPortSettings;
        private System.Windows.Forms.Label lblWriteTimeout;
        private System.Windows.Forms.Label lblReadTimeout;
        private System.Windows.Forms.Label lblParityBits;
        private System.Windows.Forms.Label lblStopBits;
        private System.Windows.Forms.Label lblDataBits;
        private System.Windows.Forms.Label lblBaudRate;
        private System.Windows.Forms.Label lblPortName;
        private System.Windows.Forms.TextBox txtWriteTimeOut;
        private System.Windows.Forms.TextBox txtReadTimeOut;
        private System.Windows.Forms.ComboBox cboParityBits;
        private System.Windows.Forms.ComboBox cboStopBits;
        private System.Windows.Forms.ComboBox cboDataBits;
        private System.Windows.Forms.ComboBox cboBaudRate;
        private System.Windows.Forms.ComboBox cboPortName;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.GroupBox gboSendSMS;
        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.Label lblMobileNo;
        private System.Windows.Forms.TextBox txtSIM;
        private System.Windows.Forms.TextBox txtMessage;
        private System.Windows.Forms.Button btnSendSMS;
        private System.Windows.Forms.GroupBox gboReadSMS;
        private System.Windows.Forms.Button btnReadSMS;
        private System.Windows.Forms.ListView lvwMessages;
        private System.Windows.Forms.ColumnHeader colSender;
        private System.Windows.Forms.ColumnHeader colMessage;
        private System.Windows.Forms.GroupBox gboConnectionStatus;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label lblConnectionStatus;
        private System.Windows.Forms.Button btnDisconnect;
        private System.Windows.Forms.Button btnDeleteSMS;
        private System.Windows.Forms.GroupBox gboDeleteSMS;
        private System.Windows.Forms.RadioButton rbDeleteAllSMS;
        private System.Windows.Forms.RadioButton rbDeleteReadSMS;
        private System.Windows.Forms.GroupBox groupBoxSMSCount;
        private System.Windows.Forms.Button btnCountSMS;
        private System.Windows.Forms.TextBox txtCountSMS;
        private System.Windows.Forms.Label lblCountSMS;
        private System.Windows.Forms.ColumnHeader colIndex;
        private System.Windows.Forms.RadioButton rbReadUnRead;
        private System.Windows.Forms.RadioButton rbReadAll;
        private System.Windows.Forms.RadioButton rbReadStoreUnSent;
        private System.Windows.Forms.RadioButton rbReadStoreSent;
        private System.Windows.Forms.ColumnHeader colSentTime;
        private System.Windows.Forms.StatusBar statusBar1;
        private System.Windows.Forms.Timer reset_Focus_Timer;
        private System.Windows.Forms.Button btnExitApplication;
        private System.Windows.Forms.Label lblMaxSMSSize;
        private System.Windows.Forms.TabPage tbUserCreate;
        private System.Windows.Forms.GroupBox groupBoxUser;
        private System.Windows.Forms.TextBox txtRoleID;
        private System.Windows.Forms.ComboBox cmbUserRole;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.TextBox txtUserName;
        private System.Windows.Forms.Label lblRoleID;
        private System.Windows.Forms.Label lblUserRole;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.Label lblUserName;
        private System.Windows.Forms.ComboBox cmbActive;
        private System.Windows.Forms.Label lblActive;
        private System.Windows.Forms.Button btnSaveUser;
        private System.Windows.Forms.DataGridView dataGridViewUserDetails;
        private System.Windows.Forms.Button btnAddUser;
        private System.Windows.Forms.TabPage tbEmployee;
        private System.Windows.Forms.TabPage tbGroup;
        private System.Windows.Forms.TabPage tbProduct;
        private System.Windows.Forms.Button btnAddGroup;
        private System.Windows.Forms.DataGridView dataGridViewGroupDetails;
        private System.Windows.Forms.GroupBox groupBoxGroup;
        private System.Windows.Forms.ComboBox cmbGroupActive;
        private System.Windows.Forms.Label lblGroupActive;
        private System.Windows.Forms.TextBox txtLocation;
        private System.Windows.Forms.TextBox txtGroupName;
        private System.Windows.Forms.Label lblLocation;
        private System.Windows.Forms.Label lblGroupName;
        private System.Windows.Forms.Button btnSaveGroup;
        private System.Windows.Forms.Button btnSMSMoveToDB;
        private System.Windows.Forms.TextBox txtStartTime;
        private System.Windows.Forms.Label lblStartTime;
        private System.Windows.Forms.Label lblEndTime;
        private System.Windows.Forms.TextBox txtEndTime;
        private System.Windows.Forms.CheckBox checkBoxSMSRead;
        private System.Windows.Forms.CheckBox checkBoxSMSSend;
        private System.Windows.Forms.TabPage tbDepartment;
        private System.Windows.Forms.TabPage tbDesignation;
        private System.Windows.Forms.Button btnAddDepartment;
        private System.Windows.Forms.DataGridView dataGridViewDepartmentDetails;
        private System.Windows.Forms.GroupBox groupBoxDepartment;
        private System.Windows.Forms.ComboBox cmbActiveDepartment;
        private System.Windows.Forms.Label lblActiveDepartment;
        private System.Windows.Forms.TextBox txtDepartment;
        private System.Windows.Forms.Label lblDepartmentName;
        private System.Windows.Forms.Button btnSaveDepartment;
        private System.Windows.Forms.Button btnAddDesignation;
        private System.Windows.Forms.DataGridView dataGridViewDesignationList;
        private System.Windows.Forms.GroupBox groupBoxDesignation;
        private System.Windows.Forms.ComboBox cmbActiveDesignation;
        private System.Windows.Forms.Label lblDesignationActive;
        private System.Windows.Forms.TextBox txtDesignationDetails;
        private System.Windows.Forms.TextBox txtDesignation;
        private System.Windows.Forms.Label lblDesignationDetails;
        private System.Windows.Forms.Label lblDesignation;
        private System.Windows.Forms.Button btnSaveDesignation;
        private System.Windows.Forms.TabPage tbMarket;
        private System.Windows.Forms.Timer Auto_Read_Timer;
        private System.Windows.Forms.Button btnAddEmployee;
        private System.Windows.Forms.DataGridView dataGridViewEmployeeList;
        private System.Windows.Forms.GroupBox groupBoxEmployee;
        private System.Windows.Forms.ComboBox cmbEmployeeDesignation;
        private System.Windows.Forms.Label lblEmployeeDesignationID;
        private System.Windows.Forms.TextBox txtEmployeeDesignationID;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.TextBox txtEmployeeName;
        private System.Windows.Forms.Label lblEmployeeDesignation;
        private System.Windows.Forms.Label lblDateOfBirth;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.Label lblEmployeeName;
        private System.Windows.Forms.Button btnSaveEmployee;
        private System.Windows.Forms.DateTimePicker dTPDateOfBirth;
        private System.Windows.Forms.ComboBox cmbEmployeeGroup;
        private System.Windows.Forms.Label lblEmployeeGroupID;
        private System.Windows.Forms.TextBox txtEmployeeGroupID;
        private System.Windows.Forms.Label lblEmployeeGroupName;
        private System.Windows.Forms.TextBox txtOfficialCellNo;
        private System.Windows.Forms.Label lblOfficialCellNo;
        private System.Windows.Forms.ComboBox cmbEmployeeDepartment;
        private System.Windows.Forms.Label lblEmployeeDepartmentID;
        private System.Windows.Forms.TextBox txtEmployeeDepartmentID;
        private System.Windows.Forms.Label lblEmployeeDepartment;
        private System.Windows.Forms.ComboBox cmbEmployeeActive;
        private System.Windows.Forms.Label lblEmployeeActive;
        private System.Windows.Forms.GroupBox groupBoxMarket;
        private System.Windows.Forms.Button btnAddMarket;
        private System.Windows.Forms.Button btnSaveMarket;
        private System.Windows.Forms.Label lblMarketCode;
        private System.Windows.Forms.DataGridView dataGridViewMarket;
        private System.Windows.Forms.TextBox txtNumberOfSR;
        private System.Windows.Forms.TextBox txtNumberOfTSM;
        private System.Windows.Forms.TextBox txtNumberOfASM;
        private System.Windows.Forms.TextBox txtNumberOfSM;
        private System.Windows.Forms.TextBox txtNumberOfDM;
        private System.Windows.Forms.TextBox txtNumberOfDGM;
        private System.Windows.Forms.TextBox txtNumberOfGM;
        private System.Windows.Forms.TextBox txtNumberOfDO;
        private System.Windows.Forms.Label lblNumberOfDO;
        private System.Windows.Forms.Label lblNumberOfSR;
        private System.Windows.Forms.Label lblNumberOfTSM;
        private System.Windows.Forms.Label lblNumberOfASM;
        private System.Windows.Forms.Label lblNumberOfSM;
        private System.Windows.Forms.Label lblNumberOfDM;
        private System.Windows.Forms.Label lblNumberOfDGM;
        private System.Windows.Forms.Label lblNumberOfGM;
        private System.Windows.Forms.Label lblNumberOfMD;
        private System.Windows.Forms.Label lblNumberOfDMD;
        private System.Windows.Forms.TextBox txtNumberOfDMD;
        private System.Windows.Forms.TextBox txtNumberOfMD;
        private System.Windows.Forms.TextBox txtMarketCode;
        private System.Windows.Forms.Label lblMarketName;
        private System.Windows.Forms.Label lblTotalNoOfParty;
        private System.Windows.Forms.TextBox txtMarketName;
        private System.Windows.Forms.TextBox txtMonthlyNoOfVisit;
        private System.Windows.Forms.TextBox txtTarget;
        private System.Windows.Forms.TextBox txtTotalNoOfParty;
        private System.Windows.Forms.Label lblNoOfVisit;
        private System.Windows.Forms.Label lblTarget;
        private System.Windows.Forms.Label lblMarketActive;
        private System.Windows.Forms.ComboBox cmbMarketActive;
        private System.Windows.Forms.DateTimePicker dTPQuitDate;
        private System.Windows.Forms.Label lblQuitDate;
        private System.Windows.Forms.TextBox txtDOB;
        private System.Windows.Forms.TextBox txtQuitDate;
        private System.Windows.Forms.DataGridView dataGridViewProduct;
        private System.Windows.Forms.Button btnAddProduct;
        private System.Windows.Forms.Label lblUnitSalePrice;
        private System.Windows.Forms.Button btnSaveProduct;
        private System.Windows.Forms.GroupBox groupBoxProduct;
        private System.Windows.Forms.ComboBox cmbPackSize;
        private System.Windows.Forms.TextBox txtUnitCostPrice;
        private System.Windows.Forms.TextBox txtUnitSalePrice;
        private System.Windows.Forms.Label lblUnitCostPrice;
        private System.Windows.Forms.Label lblPackSize;
        private System.Windows.Forms.TextBox txtProductName;
        private System.Windows.Forms.Label lblProductName;
        private System.Windows.Forms.TextBox txtProductCode;
        private System.Windows.Forms.Label lblProductCode;
        private System.Windows.Forms.ComboBox cmbProductActive;
        private System.Windows.Forms.Label lblProductActive;
        private System.Windows.Forms.TabPage tbProductPriceUpdateLog;
        private System.Windows.Forms.DataGridView dgvProductPriceUpdateLog;
        private System.Windows.Forms.GroupBox groupBoxSearchEmployee;
        private System.Windows.Forms.Button btnSearchEmployee;
        private System.Windows.Forms.ComboBox cmbSearchCriteriaForEmployeeByDesignation;
        private System.Windows.Forms.TextBox txtSearchCriteriaForEmployee;
        private System.Windows.Forms.RadioButton radioBtnByGroupAndDesignation;
        private System.Windows.Forms.RadioButton radioBtnByGroup;
        private System.Windows.Forms.RadioButton radioBtnOfficialMobileNumber;
        private System.Windows.Forms.RadioButton radioBtnEmployeeName;
        private System.Windows.Forms.RadioButton radioBtnShowAllEmp;
        private System.Windows.Forms.TabPage tbSalesTarget;
        private System.Windows.Forms.GroupBox groupBoxTargetSearch;
        private System.Windows.Forms.RadioButton radioButtonShowAllForSalesTarget;
        private System.Windows.Forms.Button btnSearchForSalesTarget;
        private System.Windows.Forms.ComboBox cmbSearchCriteriaByDesigForSalesTarget;
        private System.Windows.Forms.TextBox txtSearchCriteriaForSalesTarget;
        private System.Windows.Forms.RadioButton radioButtonByGroupAndDesigForSalesTarget;
        private System.Windows.Forms.RadioButton radioButtonByGroupForSalesTarget;
        private System.Windows.Forms.RadioButton radioButtonByMobileForSalesTarget;
        private System.Windows.Forms.RadioButton radioButtonByNameForSalesTarget;
        private System.Windows.Forms.Button btnAddTarget;
        private System.Windows.Forms.DataGridView dataGridViewSalesTarget;
        private System.Windows.Forms.GroupBox groupBoxSalesTarget;
        private System.Windows.Forms.TextBox txtFromDate;
        private System.Windows.Forms.TextBox txtToDate;
        private System.Windows.Forms.DateTimePicker dTPToDate;
        private System.Windows.Forms.Label lblEmployeeDesignationForSalesTarget;
        private System.Windows.Forms.TextBox txtEmployeeIDForSalesTarget;
        private System.Windows.Forms.Label lblEmployeeIDForSalesTarget;
        private System.Windows.Forms.Label lblSelectEmployeeForSalesTarget;
        private System.Windows.Forms.Label lblTargetAmountForSalesTarget;
        private System.Windows.Forms.TextBox txtTargetAmountForSalesTarget;
        private System.Windows.Forms.Label lblTargetUnitForSalesTarget;
        private System.Windows.Forms.DateTimePicker dTPFromDate;
        private System.Windows.Forms.Label lblToDate;
        private System.Windows.Forms.Label lblFromDate;
        private System.Windows.Forms.Button btnSaveTarget;
        private System.Windows.Forms.TextBox txtTargetUnitForSalesTarget;
        private System.Windows.Forms.ComboBox cmbSelectGroupForSalesTarget;
        private System.Windows.Forms.Label lblSelectGroupForSalesTarget;
        private System.Windows.Forms.ComboBox cmbSelectEmployeeForSalesTarget;
        private System.Windows.Forms.ComboBox cmbSelectDesignationForSalesTarget;
        private System.Windows.Forms.TextBox txtEmpMobileNoForSalesTarget;
        private System.Windows.Forms.Label lblEmpMobileNoForSalesTarget;
        private System.Windows.Forms.TextBox txtSearchDateTo;
        private System.Windows.Forms.DateTimePicker dtpSearchDateTo;
        private System.Windows.Forms.Label lblSearchDateTo;
        private System.Windows.Forms.TextBox txtSearchDateFrom;
        private System.Windows.Forms.DateTimePicker dtpSearchDateFrom;
        private System.Windows.Forms.Label lblSearchDateFrom;
        private System.Windows.Forms.RadioButton radioButtonByDesignationForSalesTarget;
        private System.Windows.Forms.RadioButton radioButtonByProductCodeForSalesTarget;
        private System.Windows.Forms.Button btnDBBackup;
        private System.Windows.Forms.GroupBox groupBoxProductPriceLogSearch;
        private System.Windows.Forms.RadioButton radioBtnPriceUpdateLogShowAll;
        private System.Windows.Forms.Button btnPriceUpdateLogSearch;
        private System.Windows.Forms.TextBox txtPriceUpdateLogSearchCriteria;
        private System.Windows.Forms.RadioButton radioBtnPriceUpdateLogSearchByPName;
        private System.Windows.Forms.RadioButton radioBtnPriceUpdateLogSearchByPCode;
        private System.Windows.Forms.TabPage tbSpecialItemSaleTarget;
        private System.Windows.Forms.GroupBox groupBoxSpecialItemSearch;
        private System.Windows.Forms.RadioButton radioButtonSpecialItemSearchByProductCode;
        private System.Windows.Forms.TextBox txtSpecialItemSearchToDate;
        private System.Windows.Forms.DateTimePicker dtPSpecialItemSearchToDate;
        private System.Windows.Forms.Label lblSpecialItemSearchToDate;
        private System.Windows.Forms.TextBox txtSpecialItemSearchFromDate;
        private System.Windows.Forms.DateTimePicker dtPSpecialItemSearchFromDate;
        private System.Windows.Forms.Label lblSpecialItemSearchFromDate;
        private System.Windows.Forms.RadioButton radioButtonSpecialItemSearchByDesignation;
        private System.Windows.Forms.RadioButton radioButtonSpecialItemShowAll;
        private System.Windows.Forms.Button btnSpecialItemSearch;
        private System.Windows.Forms.ComboBox cmbSpecialItemSearchByEmpDesignation;
        private System.Windows.Forms.TextBox txtSpecialItemSearchCriteria;
        private System.Windows.Forms.RadioButton radioButtonSpecialItemSearchByGroupNameAndDesignation;
        private System.Windows.Forms.RadioButton radioButtonSpecialItemSearchByGroupName;
        private System.Windows.Forms.RadioButton radioButtonSpecialItemSearchByEmpMobileNo;
        private System.Windows.Forms.RadioButton radioButtonSpecialItemSearchByEmpName;
        private System.Windows.Forms.Button btnSpecialItemSaleAddTarget;
        private System.Windows.Forms.Button btnSpecialItemSaleSaveTarget;
        private System.Windows.Forms.DataGridView dgvSpecialItemSalesTarget;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtSpecialItemSaleProductSpecialPrice;
        private System.Windows.Forms.Label lblSpecialItemSaleProductSpecialPrice;
        private System.Windows.Forms.TextBox txtSpecialItemSaleProductSalePrice;
        private System.Windows.Forms.Label lblSpecialItemSaleProductSalePrice;
        private System.Windows.Forms.TextBox txtSpecialItemSaleEmployeeMobileNo;
        private System.Windows.Forms.Label lblSpecialItemSaleEmployeeMobileNo;
        private System.Windows.Forms.ComboBox cmbSpecialItemSaleSelectEmployee;
        private System.Windows.Forms.ComboBox cmbSpecialItemSaleSelectDesignation;
        private System.Windows.Forms.ComboBox cmbSpecialItemSaleSelectGroup;
        private System.Windows.Forms.Label lblSpecialItemSaleSelectGroup;
        private System.Windows.Forms.TextBox txtSpecialItemSaleTargetUnit;
        private System.Windows.Forms.TextBox txtSpecialItemSaleProductCostPrice;
        private System.Windows.Forms.TextBox txtSpecialItemSaleProductName;
        private System.Windows.Forms.TextBox txtSpecialItemSaleProductID;
        private System.Windows.Forms.Button btnSpecialItemSaleProductCodeBrowse;
        private System.Windows.Forms.Label lblSpecialItemSaleProductCode;
        private System.Windows.Forms.TextBox txtSpecialItemSaleFromDate;
        private System.Windows.Forms.TextBox txtSpecialItemSaleToDate;
        private System.Windows.Forms.DateTimePicker dtPSpecialItemSaleToDate;
        private System.Windows.Forms.Label lblSpecialItemSaleSelectDesignation;
        private System.Windows.Forms.TextBox txtSpecialItemSaleEmployeeID;
        private System.Windows.Forms.Label lblSpecialItemSaleEmployeeID;
        private System.Windows.Forms.Label lblSpecialItemSaleSelectEmployee;
        private System.Windows.Forms.Label lblSpecialItemSaleTargetAmount;
        private System.Windows.Forms.TextBox txtSpecialItemSaleTargetAmount;
        private System.Windows.Forms.Label lblSpecialItemSaleTargetUnit;
        private System.Windows.Forms.DateTimePicker dtPSpecialItemSaleFromDate;
        private System.Windows.Forms.Label lblSpecialItemSaleProductCostPrice;
        private System.Windows.Forms.TextBox txtSpecialItemSaleProductCode;
        private System.Windows.Forms.Label lblSpecialItemSaleProductName;
        private System.Windows.Forms.Label lblSpecialItemSaleProductID;
        private System.Windows.Forms.Label lblSpecialItemSaleToDate;
        private System.Windows.Forms.Label lblSpecialItemSaleFromDate;
        private System.Windows.Forms.TabPage tbSalesDetails;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton radioBtnSalesDetailsSearchByProductCode;
        private System.Windows.Forms.TextBox txtSalesDetailsToDate;
        private System.Windows.Forms.DateTimePicker dtPSalesDetailsToDate;
        private System.Windows.Forms.Label lblSalesDetailsToDate;
        private System.Windows.Forms.TextBox txtSalesDetailsFormDate;
        private System.Windows.Forms.DateTimePicker dtPSalesDetailsFormDate;
        private System.Windows.Forms.Label lblSalesDetailsFormDate;
        private System.Windows.Forms.RadioButton radioBtnSalesDetailsSearchByDesignation;
        private System.Windows.Forms.RadioButton radioBtnSalesDetailsShowAll;
        private System.Windows.Forms.Button btnSalesDetailsSearch;
        private System.Windows.Forms.ComboBox cmbSalesDetailsDesignation;
        private System.Windows.Forms.TextBox txtSalesDetailsSearchCriteria;
        private System.Windows.Forms.RadioButton radioBtnSalesDetailsSearchByGroupAndDesignation;
        private System.Windows.Forms.RadioButton radioBtnSalesDetailsSearchByGroup;
        private System.Windows.Forms.RadioButton radioBtnSalesDetailsSearchByMobile;
        private System.Windows.Forms.RadioButton radioBtnSalesDetailsSearchByEmp;
        private System.Windows.Forms.DataGridView dgvSalesDetails;
        private System.Windows.Forms.TabPage tbReports;
        private System.Windows.Forms.GroupBox groupBoxSelectOptionForReports;
        private System.Windows.Forms.Button btnReportShow;
        private System.Windows.Forms.RadioButton radioBtnSalesTargetReport;
        private System.Windows.Forms.Button btnAddToList;
        private System.Windows.Forms.DataGridView dgvSalesTargetDetails;
        private System.Windows.Forms.Button btnSaveList;
        private System.Windows.Forms.TextBox txtProductPriceForSalesTarget;
        private System.Windows.Forms.TextBox txtProductNameForSalesTarget;
        private System.Windows.Forms.TextBox txtProductIDForSalesTarget;
        private System.Windows.Forms.Button btnBrowseProductCodeForSalesTarget;
        private System.Windows.Forms.Label lblProductCodeForSalesTarget;
        private System.Windows.Forms.Label lblProductPriceForSalesTarget;
        private System.Windows.Forms.TextBox txtProductCodeForSalesTarget;
        private System.Windows.Forms.Label lblProductNameForSalesTarget;
        private System.Windows.Forms.Label lblProductIDForSalesTarget;
        private System.Windows.Forms.DataGridView dgvPrevAddedSalesTargetDetails;
        private System.Windows.Forms.RadioButton radioButtonUserReport;
        private System.Windows.Forms.TabPage tbMarketSetup;
        private System.Windows.Forms.DataGridView dataGridViewMarketSetup;
        private System.Windows.Forms.Button btnAddMarketSetup;
        private System.Windows.Forms.Button btnSaveMarketSetup;
        private System.Windows.Forms.GroupBox groupBoxMarketSetup;
        private System.Windows.Forms.TextBox txtEmpDesigForMarketSetup;
        private System.Windows.Forms.TextBox txtEmpIDForMarketSetup;
        private System.Windows.Forms.Label lblEmpIDForMarketSetup;
        private System.Windows.Forms.ComboBox cmbSelectDevisionForMarketSetup;
        private System.Windows.Forms.Label lblSelectDevisionForMarketSetup;
        private System.Windows.Forms.ComboBox cmbSelectEmployeeForMarketSetup;
        private System.Windows.Forms.Label lblSelectEmployeeForMarketSetup;
        private System.Windows.Forms.ComboBox cmbSelectGroupForMarketSetup;
        private System.Windows.Forms.Label lblGroupIDForMarketSetup;
        private System.Windows.Forms.TextBox txtGroupIDForMarketSetup;
        private System.Windows.Forms.Label lblSelectGroupForMarketSetup;
        private System.Windows.Forms.TextBox txtEmpCellNoForMarketSetup;
        private System.Windows.Forms.Label lblEmpDesigForMarketSetup;
        private System.Windows.Forms.Label lblEmpCellNoForMarketSetup;
        private System.Windows.Forms.TabPage tbDivision;
        private System.Windows.Forms.GroupBox groupBoxDivision;
        private System.Windows.Forms.TextBox txtDivisionName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblTeamID;
        private System.Windows.Forms.TextBox txtTeamIDForDivision;
        private System.Windows.Forms.ComboBox cmbSelectTeam;
        private System.Windows.Forms.Label lblSelectTeam;
        private System.Windows.Forms.Button btnAddDivision;
        private System.Windows.Forms.Button btnSaveDivision;
        private System.Windows.Forms.ComboBox cmbSelectSRForDivision;
        private System.Windows.Forms.Label lblSelectSR;
        private System.Windows.Forms.ComboBox cmbSelectTSMForDivision;
        private System.Windows.Forms.Label lblSelectTSM;
        private System.Windows.Forms.ComboBox cmbSelectSMForDivision;
        private System.Windows.Forms.Label lblSelectSM;
        private System.Windows.Forms.ComboBox cmbSelectASMForDivision;
        private System.Windows.Forms.Label lblSelectASM;
        private System.Windows.Forms.ComboBox cmbSelectDMForDivision;
        private System.Windows.Forms.Label lblSelectDM;
        private System.Windows.Forms.ComboBox cmbSelectDGMForDivision;
        private System.Windows.Forms.Label lblSelectDGM;
        private System.Windows.Forms.ComboBox cmbSelectGMForDivision;
        private System.Windows.Forms.Label lblSelectGM;
        private System.Windows.Forms.ComboBox cmbSelectDOForDivision;
        private System.Windows.Forms.Label lblSelectDO;
        private System.Windows.Forms.DataGridView dgvLoadTempDivision;
        private System.Windows.Forms.DataGridView dgvLoadGroup;
        private System.Windows.Forms.DataGridView dgvDivision;
        private System.Windows.Forms.Button btnLoadGroup;
        private System.Windows.Forms.ComboBox cmbActiveForDivision;
        private System.Windows.Forms.Label lblActiveForDivision;
        private System.Windows.Forms.ComboBox cmbSelectRSMForDivision;
        private System.Windows.Forms.Label lblSelectRSM;
        private System.Windows.Forms.Button btnLoadTSM;
        private System.Windows.Forms.Button btnLoadSR;
        private System.Windows.Forms.Button btnLoadSM;
        private System.Windows.Forms.Button btnLoadASM;
        private System.Windows.Forms.Button btnAddToTempDivision;
        private System.Windows.Forms.DataGridView dgvProductListForSalesTarget;
        private System.Windows.Forms.Button btnAddOrEditDataOfPrevDivision;
        private System.Windows.Forms.ComboBox cmbSelectDivisionForUpdate;
        private System.Windows.Forms.DataGridView dgvPreviousAddedEmpList;
        private System.Windows.Forms.ComboBox cmbSelectMarketForMarketSetup;
        private System.Windows.Forms.Label lblSelectMarket;
        private System.Windows.Forms.ComboBox cmbSelectDivisionForMarket;
        private System.Windows.Forms.Label lblSelectDivisionForMarket;
        private System.Windows.Forms.Label lblTeamIDForMarket;
        private System.Windows.Forms.TextBox txtTeamIDForMarket;
        private System.Windows.Forms.Label lblTeamNameForMarket;
        private System.Windows.Forms.TextBox txtTeamNameForMarket;
        private System.Windows.Forms.DataGridView dgvLoadMarketBySelectedDivision;
        private System.Windows.Forms.RadioButton radioButtonProductReport;
        private System.Windows.Forms.RadioButton radioButtonDivisionReport;
        private System.Windows.Forms.Button btnUserReport;
        private System.Windows.Forms.Button btnDivisionReport;
        private System.Windows.Forms.Button btnProductReport;
        private System.Windows.Forms.Button btnEnableDisableDivision;
        public System.Windows.Forms.DataGridView dgvLoadDistinctDivision;
        private System.Windows.Forms.Button btnRefreshDivision;
        private System.Windows.Forms.TextBox txtEmpDivNameForSalesTarget;
        private System.Windows.Forms.Button btnRefreshUser;
        private System.Windows.Forms.Button btnRefreshDepartment;
        private System.Windows.Forms.Button btnRefreshDesignation;
        private System.Windows.Forms.Button btnRefreshTeam;
        private System.Windows.Forms.Button btnRefreshEmployee;
        private System.Windows.Forms.Button btnRefreshMarket;
        private System.Windows.Forms.Button btnRefreshMarketSetup;
        private System.Windows.Forms.Button btnRefreshProduct;
        private System.Windows.Forms.Button btnRefreshSalesTarget;
        private System.Windows.Forms.Button btnRefreshProductPriceLog;
        private System.Windows.Forms.Button btnRefreshSalesDetails;
    }
}

