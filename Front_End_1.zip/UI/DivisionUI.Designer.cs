﻿namespace SMSapplication.UI
{
    partial class DivisionUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DivisionUI));
            this.groupBoxGroup = new System.Windows.Forms.GroupBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.txtTeamIDForDivision = new System.Windows.Forms.TextBox();
            this.lblTeamIDForDivision = new System.Windows.Forms.Label();
            this.cmbSelectTeamForDivision = new System.Windows.Forms.ComboBox();
            this.lblSelectTeamForDivision = new System.Windows.Forms.Label();
            this.btnRefreshDivision = new System.Windows.Forms.Button();
            this.btnDivisionReport = new System.Windows.Forms.Button();
            this.txtDivisionActivityEndDate = new System.Windows.Forms.TextBox();
            this.btnSaveDivision = new System.Windows.Forms.Button();
            this.btnAddDivision = new System.Windows.Forms.Button();
            this.dTPDivisionActivityEndDate = new System.Windows.Forms.DateTimePicker();
            this.lblTeamActivityEndDate = new System.Windows.Forms.Label();
            this.txtDivisionActivityStartDate = new System.Windows.Forms.TextBox();
            this.dTPDivisionActivityStartDate = new System.Windows.Forms.DateTimePicker();
            this.cmbSelectEmployeeForDivision = new System.Windows.Forms.ComboBox();
            this.lblSelectEmployeeForTeam = new System.Windows.Forms.Label();
            this.cmbSelectDesignationForDivision = new System.Windows.Forms.ComboBox();
            this.lblTeamActivityStartDate = new System.Windows.Forms.Label();
            this.cmbDivisionActive = new System.Windows.Forms.ComboBox();
            this.lblGroupActive = new System.Windows.Forms.Label();
            this.txtDivisionName = new System.Windows.Forms.TextBox();
            this.lblSelectDesignation = new System.Windows.Forms.Label();
            this.lblDivisionName = new System.Windows.Forms.Label();
            this.dataGridViewDivisionDetails = new System.Windows.Forms.DataGridView();
            this.groupBoxGroup.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDivisionDetails)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBoxGroup
            // 
            this.groupBoxGroup.Controls.Add(this.btnClose);
            this.groupBoxGroup.Controls.Add(this.txtTeamIDForDivision);
            this.groupBoxGroup.Controls.Add(this.lblTeamIDForDivision);
            this.groupBoxGroup.Controls.Add(this.cmbSelectTeamForDivision);
            this.groupBoxGroup.Controls.Add(this.lblSelectTeamForDivision);
            this.groupBoxGroup.Controls.Add(this.btnRefreshDivision);
            this.groupBoxGroup.Controls.Add(this.btnDivisionReport);
            this.groupBoxGroup.Controls.Add(this.txtDivisionActivityEndDate);
            this.groupBoxGroup.Controls.Add(this.btnSaveDivision);
            this.groupBoxGroup.Controls.Add(this.btnAddDivision);
            this.groupBoxGroup.Controls.Add(this.dTPDivisionActivityEndDate);
            this.groupBoxGroup.Controls.Add(this.lblTeamActivityEndDate);
            this.groupBoxGroup.Controls.Add(this.txtDivisionActivityStartDate);
            this.groupBoxGroup.Controls.Add(this.dTPDivisionActivityStartDate);
            this.groupBoxGroup.Controls.Add(this.cmbSelectEmployeeForDivision);
            this.groupBoxGroup.Controls.Add(this.lblSelectEmployeeForTeam);
            this.groupBoxGroup.Controls.Add(this.cmbSelectDesignationForDivision);
            this.groupBoxGroup.Controls.Add(this.lblTeamActivityStartDate);
            this.groupBoxGroup.Controls.Add(this.cmbDivisionActive);
            this.groupBoxGroup.Controls.Add(this.lblGroupActive);
            this.groupBoxGroup.Controls.Add(this.txtDivisionName);
            this.groupBoxGroup.Controls.Add(this.lblSelectDesignation);
            this.groupBoxGroup.Controls.Add(this.lblDivisionName);
            this.groupBoxGroup.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxGroup.Location = new System.Drawing.Point(6, 0);
            this.groupBoxGroup.Name = "groupBoxGroup";
            this.groupBoxGroup.Size = new System.Drawing.Size(822, 180);
            this.groupBoxGroup.TabIndex = 12;
            this.groupBoxGroup.TabStop = false;
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Location = new System.Drawing.Point(657, 146);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(160, 25);
            this.btnClose.TabIndex = 11;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // txtTeamIDForDivision
            // 
            this.txtTeamIDForDivision.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtTeamIDForDivision.Location = new System.Drawing.Point(573, 117);
            this.txtTeamIDForDivision.Name = "txtTeamIDForDivision";
            this.txtTeamIDForDivision.ReadOnly = true;
            this.txtTeamIDForDivision.Size = new System.Drawing.Size(240, 22);
            this.txtTeamIDForDivision.TabIndex = 71;
            this.txtTeamIDForDivision.TabStop = false;
            // 
            // lblTeamIDForDivision
            // 
            this.lblTeamIDForDivision.AutoSize = true;
            this.lblTeamIDForDivision.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeamIDForDivision.Location = new System.Drawing.Point(433, 120);
            this.lblTeamIDForDivision.Name = "lblTeamIDForDivision";
            this.lblTeamIDForDivision.Size = new System.Drawing.Size(75, 16);
            this.lblTeamIDForDivision.TabIndex = 70;
            this.lblTeamIDForDivision.Text = "Team ID :";
            // 
            // cmbSelectTeamForDivision
            // 
            this.cmbSelectTeamForDivision.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSelectTeamForDivision.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectTeamForDivision.Enabled = false;
            this.cmbSelectTeamForDivision.FormattingEnabled = true;
            this.cmbSelectTeamForDivision.Location = new System.Drawing.Point(574, 87);
            this.cmbSelectTeamForDivision.Name = "cmbSelectTeamForDivision";
            this.cmbSelectTeamForDivision.Size = new System.Drawing.Size(240, 24);
            this.cmbSelectTeamForDivision.TabIndex = 7;
            this.cmbSelectTeamForDivision.Text = "Select Team";
            this.cmbSelectTeamForDivision.SelectedIndexChanged += new System.EventHandler(this.cmbSelectTeamForDivision_SelectedIndexChanged);
            // 
            // lblSelectTeamForDivision
            // 
            this.lblSelectTeamForDivision.AutoSize = true;
            this.lblSelectTeamForDivision.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectTeamForDivision.Location = new System.Drawing.Point(433, 90);
            this.lblSelectTeamForDivision.Name = "lblSelectTeamForDivision";
            this.lblSelectTeamForDivision.Size = new System.Drawing.Size(104, 16);
            this.lblSelectTeamForDivision.TabIndex = 68;
            this.lblSelectTeamForDivision.Text = "Select Team :";
            // 
            // btnRefreshDivision
            // 
            this.btnRefreshDivision.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefreshDivision.Location = new System.Drawing.Point(494, 146);
            this.btnRefreshDivision.Name = "btnRefreshDivision";
            this.btnRefreshDivision.Size = new System.Drawing.Size(160, 25);
            this.btnRefreshDivision.TabIndex = 10;
            this.btnRefreshDivision.Text = "Refresh";
            this.btnRefreshDivision.UseVisualStyleBackColor = true;
            this.btnRefreshDivision.Click += new System.EventHandler(this.btnRefreshDivision_Click);
            // 
            // btnDivisionReport
            // 
            this.btnDivisionReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDivisionReport.Location = new System.Drawing.Point(331, 146);
            this.btnDivisionReport.Name = "btnDivisionReport";
            this.btnDivisionReport.Size = new System.Drawing.Size(160, 25);
            this.btnDivisionReport.TabIndex = 9;
            this.btnDivisionReport.Text = "Division Report";
            this.btnDivisionReport.UseVisualStyleBackColor = true;
            // 
            // txtDivisionActivityEndDate
            // 
            this.txtDivisionActivityEndDate.Enabled = false;
            this.txtDivisionActivityEndDate.Location = new System.Drawing.Point(573, 57);
            this.txtDivisionActivityEndDate.Name = "txtDivisionActivityEndDate";
            this.txtDivisionActivityEndDate.Size = new System.Drawing.Size(225, 22);
            this.txtDivisionActivityEndDate.TabIndex = 6;
            // 
            // btnSaveDivision
            // 
            this.btnSaveDivision.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveDivision.Location = new System.Drawing.Point(168, 146);
            this.btnSaveDivision.Name = "btnSaveDivision";
            this.btnSaveDivision.Size = new System.Drawing.Size(160, 25);
            this.btnSaveDivision.TabIndex = 8;
            this.btnSaveDivision.Text = "Save Division";
            this.btnSaveDivision.UseVisualStyleBackColor = true;
            this.btnSaveDivision.Click += new System.EventHandler(this.btnSaveDivision_Click);
            // 
            // btnAddDivision
            // 
            this.btnAddDivision.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddDivision.Location = new System.Drawing.Point(5, 146);
            this.btnAddDivision.Name = "btnAddDivision";
            this.btnAddDivision.Size = new System.Drawing.Size(160, 25);
            this.btnAddDivision.TabIndex = 0;
            this.btnAddDivision.Text = "Add Division";
            this.btnAddDivision.UseVisualStyleBackColor = true;
            this.btnAddDivision.Click += new System.EventHandler(this.btnAddDivision_Click);
            // 
            // dTPDivisionActivityEndDate
            // 
            this.dTPDivisionActivityEndDate.Enabled = false;
            this.dTPDivisionActivityEndDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dTPDivisionActivityEndDate.Location = new System.Drawing.Point(798, 57);
            this.dTPDivisionActivityEndDate.Name = "dTPDivisionActivityEndDate";
            this.dTPDivisionActivityEndDate.Size = new System.Drawing.Size(16, 22);
            this.dTPDivisionActivityEndDate.TabIndex = 67;
            this.dTPDivisionActivityEndDate.CloseUp += new System.EventHandler(this.dTPDivisionActivityEndDate_CloseUp);
            // 
            // lblTeamActivityEndDate
            // 
            this.lblTeamActivityEndDate.AutoSize = true;
            this.lblTeamActivityEndDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeamActivityEndDate.Location = new System.Drawing.Point(433, 60);
            this.lblTeamActivityEndDate.Name = "lblTeamActivityEndDate";
            this.lblTeamActivityEndDate.Size = new System.Drawing.Size(134, 16);
            this.lblTeamActivityEndDate.TabIndex = 65;
            this.lblTeamActivityEndDate.Text = "Activity End Date :";
            // 
            // txtDivisionActivityStartDate
            // 
            this.txtDivisionActivityStartDate.Enabled = false;
            this.txtDivisionActivityStartDate.Location = new System.Drawing.Point(151, 117);
            this.txtDivisionActivityStartDate.Name = "txtDivisionActivityStartDate";
            this.txtDivisionActivityStartDate.Size = new System.Drawing.Size(225, 22);
            this.txtDivisionActivityStartDate.TabIndex = 4;
            // 
            // dTPDivisionActivityStartDate
            // 
            this.dTPDivisionActivityStartDate.Enabled = false;
            this.dTPDivisionActivityStartDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dTPDivisionActivityStartDate.Location = new System.Drawing.Point(376, 117);
            this.dTPDivisionActivityStartDate.Name = "dTPDivisionActivityStartDate";
            this.dTPDivisionActivityStartDate.Size = new System.Drawing.Size(16, 22);
            this.dTPDivisionActivityStartDate.TabIndex = 64;
            this.dTPDivisionActivityStartDate.CloseUp += new System.EventHandler(this.dTPDivisionActivityStartDate_CloseUp);
            // 
            // cmbSelectEmployeeForDivision
            // 
            this.cmbSelectEmployeeForDivision.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSelectEmployeeForDivision.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectEmployeeForDivision.Enabled = false;
            this.cmbSelectEmployeeForDivision.FormattingEnabled = true;
            this.cmbSelectEmployeeForDivision.Location = new System.Drawing.Point(151, 87);
            this.cmbSelectEmployeeForDivision.Name = "cmbSelectEmployeeForDivision";
            this.cmbSelectEmployeeForDivision.Size = new System.Drawing.Size(240, 24);
            this.cmbSelectEmployeeForDivision.TabIndex = 3;
            this.cmbSelectEmployeeForDivision.Text = "Select Employee";
            // 
            // lblSelectEmployeeForTeam
            // 
            this.lblSelectEmployeeForTeam.AutoSize = true;
            this.lblSelectEmployeeForTeam.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectEmployeeForTeam.Location = new System.Drawing.Point(4, 90);
            this.lblSelectEmployeeForTeam.Name = "lblSelectEmployeeForTeam";
            this.lblSelectEmployeeForTeam.Size = new System.Drawing.Size(134, 16);
            this.lblSelectEmployeeForTeam.TabIndex = 62;
            this.lblSelectEmployeeForTeam.Text = "Select Employee :";
            // 
            // cmbSelectDesignationForDivision
            // 
            this.cmbSelectDesignationForDivision.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSelectDesignationForDivision.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectDesignationForDivision.Enabled = false;
            this.cmbSelectDesignationForDivision.FormattingEnabled = true;
            this.cmbSelectDesignationForDivision.Location = new System.Drawing.Point(151, 57);
            this.cmbSelectDesignationForDivision.Name = "cmbSelectDesignationForDivision";
            this.cmbSelectDesignationForDivision.Size = new System.Drawing.Size(240, 24);
            this.cmbSelectDesignationForDivision.TabIndex = 2;
            this.cmbSelectDesignationForDivision.Text = "Select Designation";
            this.cmbSelectDesignationForDivision.SelectedIndexChanged += new System.EventHandler(this.cmbSelectDesignationForDivision_SelectedIndexChanged);
            this.cmbSelectDesignationForDivision.SelectedValueChanged += new System.EventHandler(this.cmbSelectDesignationForDivision_SelectedValueChanged);
            // 
            // lblTeamActivityStartDate
            // 
            this.lblTeamActivityStartDate.AutoSize = true;
            this.lblTeamActivityStartDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeamActivityStartDate.Location = new System.Drawing.Point(4, 120);
            this.lblTeamActivityStartDate.Name = "lblTeamActivityStartDate";
            this.lblTeamActivityStartDate.Size = new System.Drawing.Size(139, 16);
            this.lblTeamActivityStartDate.TabIndex = 59;
            this.lblTeamActivityStartDate.Text = "Activity Start Date :";
            // 
            // cmbDivisionActive
            // 
            this.cmbDivisionActive.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbDivisionActive.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbDivisionActive.Enabled = false;
            this.cmbDivisionActive.FormattingEnabled = true;
            this.cmbDivisionActive.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cmbDivisionActive.Location = new System.Drawing.Point(573, 27);
            this.cmbDivisionActive.Name = "cmbDivisionActive";
            this.cmbDivisionActive.Size = new System.Drawing.Size(240, 24);
            this.cmbDivisionActive.TabIndex = 5;
            this.cmbDivisionActive.Text = "Select Active";
            this.cmbDivisionActive.SelectedValueChanged += new System.EventHandler(this.cmbDivisionActive_SelectedValueChanged);
            // 
            // lblGroupActive
            // 
            this.lblGroupActive.AutoSize = true;
            this.lblGroupActive.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGroupActive.Location = new System.Drawing.Point(433, 30);
            this.lblGroupActive.Name = "lblGroupActive";
            this.lblGroupActive.Size = new System.Drawing.Size(59, 16);
            this.lblGroupActive.TabIndex = 11;
            this.lblGroupActive.Text = "Active :";
            // 
            // txtDivisionName
            // 
            this.txtDivisionName.Enabled = false;
            this.txtDivisionName.Location = new System.Drawing.Point(151, 27);
            this.txtDivisionName.Name = "txtDivisionName";
            this.txtDivisionName.Size = new System.Drawing.Size(240, 22);
            this.txtDivisionName.TabIndex = 1;
            // 
            // lblSelectDesignation
            // 
            this.lblSelectDesignation.AutoSize = true;
            this.lblSelectDesignation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectDesignation.Location = new System.Drawing.Point(4, 60);
            this.lblSelectDesignation.Name = "lblSelectDesignation";
            this.lblSelectDesignation.Size = new System.Drawing.Size(147, 16);
            this.lblSelectDesignation.TabIndex = 1;
            this.lblSelectDesignation.Text = "Select Designation :";
            // 
            // lblDivisionName
            // 
            this.lblDivisionName.AutoSize = true;
            this.lblDivisionName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDivisionName.Location = new System.Drawing.Point(4, 30);
            this.lblDivisionName.Name = "lblDivisionName";
            this.lblDivisionName.Size = new System.Drawing.Size(117, 16);
            this.lblDivisionName.TabIndex = 0;
            this.lblDivisionName.Text = "Division Name :";
            // 
            // dataGridViewDivisionDetails
            // 
            this.dataGridViewDivisionDetails.AllowUserToAddRows = false;
            this.dataGridViewDivisionDetails.AllowUserToDeleteRows = false;
            this.dataGridViewDivisionDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewDivisionDetails.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridViewDivisionDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDivisionDetails.Location = new System.Drawing.Point(6, 185);
            this.dataGridViewDivisionDetails.MultiSelect = false;
            this.dataGridViewDivisionDetails.Name = "dataGridViewDivisionDetails";
            this.dataGridViewDivisionDetails.ReadOnly = true;
            this.dataGridViewDivisionDetails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewDivisionDetails.Size = new System.Drawing.Size(822, 348);
            this.dataGridViewDivisionDetails.TabIndex = 13;
            this.dataGridViewDivisionDetails.TabStop = false;
            this.dataGridViewDivisionDetails.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewDivisionDetails_CellDoubleClick);
            // 
            // DivisionUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(834, 537);
            this.Controls.Add(this.dataGridViewDivisionDetails);
            this.Controls.Add(this.groupBoxGroup);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "DivisionUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add / Edit Division";
            this.Load += new System.EventHandler(this.DivisionUI_Load);
            this.groupBoxGroup.ResumeLayout(false);
            this.groupBoxGroup.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDivisionDetails)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxGroup;
        private System.Windows.Forms.Button btnRefreshDivision;
        private System.Windows.Forms.Button btnDivisionReport;
        private System.Windows.Forms.TextBox txtDivisionActivityEndDate;
        private System.Windows.Forms.Button btnSaveDivision;
        private System.Windows.Forms.Button btnAddDivision;
        private System.Windows.Forms.DateTimePicker dTPDivisionActivityEndDate;
        private System.Windows.Forms.Label lblTeamActivityEndDate;
        private System.Windows.Forms.TextBox txtDivisionActivityStartDate;
        private System.Windows.Forms.DateTimePicker dTPDivisionActivityStartDate;
        private System.Windows.Forms.ComboBox cmbSelectEmployeeForDivision;
        private System.Windows.Forms.Label lblSelectEmployeeForTeam;
        private System.Windows.Forms.ComboBox cmbSelectDesignationForDivision;
        private System.Windows.Forms.Label lblTeamActivityStartDate;
        private System.Windows.Forms.ComboBox cmbDivisionActive;
        private System.Windows.Forms.Label lblGroupActive;
        private System.Windows.Forms.TextBox txtDivisionName;
        private System.Windows.Forms.Label lblSelectDesignation;
        private System.Windows.Forms.Label lblDivisionName;
        private System.Windows.Forms.DataGridView dataGridViewDivisionDetails;
        private System.Windows.Forms.TextBox txtTeamIDForDivision;
        private System.Windows.Forms.Label lblTeamIDForDivision;
        private System.Windows.Forms.ComboBox cmbSelectTeamForDivision;
        private System.Windows.Forms.Label lblSelectTeamForDivision;
        private System.Windows.Forms.Button btnClose;
    }
}