﻿namespace SMSapplication.UI
{
    partial class AreaUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AreaUI));
            this.dataGridViewAreaDetails = new System.Windows.Forms.DataGridView();
            this.groupBoxArea = new System.Windows.Forms.GroupBox();
            this.txtCellNoForArea = new System.Windows.Forms.TextBox();
            this.lblCellNoForArea = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.txtZoneIDForArea = new System.Windows.Forms.TextBox();
            this.lblZoneIDForArea = new System.Windows.Forms.Label();
            this.cmbSelectZoneForArea = new System.Windows.Forms.ComboBox();
            this.lblSelectZoneForArea = new System.Windows.Forms.Label();
            this.btnRefreshArea = new System.Windows.Forms.Button();
            this.btnAreaReport = new System.Windows.Forms.Button();
            this.txtAreaActivityEndDate = new System.Windows.Forms.TextBox();
            this.btnSaveArea = new System.Windows.Forms.Button();
            this.btnAddArea = new System.Windows.Forms.Button();
            this.dTPAreaActivityEndDate = new System.Windows.Forms.DateTimePicker();
            this.lblAreaActivityEndDate = new System.Windows.Forms.Label();
            this.txtAreaActivityStartDate = new System.Windows.Forms.TextBox();
            this.dTPAreaActivityStartDate = new System.Windows.Forms.DateTimePicker();
            this.cmbSelectEmployeeForArea = new System.Windows.Forms.ComboBox();
            this.lblSelectEmployeeForArea = new System.Windows.Forms.Label();
            this.cmbSelectDesignationForArea = new System.Windows.Forms.ComboBox();
            this.lblAreaActivityStartDate = new System.Windows.Forms.Label();
            this.cmbAreaActive = new System.Windows.Forms.ComboBox();
            this.lblAreaActive = new System.Windows.Forms.Label();
            this.txtAreaName = new System.Windows.Forms.TextBox();
            this.lblSelectDesignation = new System.Windows.Forms.Label();
            this.lblAreaName = new System.Windows.Forms.Label();
            this.txtCellNoPrefixForArea = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAreaDetails)).BeginInit();
            this.groupBoxArea.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridViewAreaDetails
            // 
            this.dataGridViewAreaDetails.AllowUserToAddRows = false;
            this.dataGridViewAreaDetails.AllowUserToDeleteRows = false;
            this.dataGridViewAreaDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewAreaDetails.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridViewAreaDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewAreaDetails.Location = new System.Drawing.Point(6, 208);
            this.dataGridViewAreaDetails.MultiSelect = false;
            this.dataGridViewAreaDetails.Name = "dataGridViewAreaDetails";
            this.dataGridViewAreaDetails.ReadOnly = true;
            this.dataGridViewAreaDetails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewAreaDetails.Size = new System.Drawing.Size(822, 325);
            this.dataGridViewAreaDetails.TabIndex = 18;
            this.dataGridViewAreaDetails.TabStop = false;
            this.dataGridViewAreaDetails.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewAreaDetails_CellDoubleClick);
            // 
            // groupBoxArea
            // 
            this.groupBoxArea.Controls.Add(this.txtCellNoPrefixForArea);
            this.groupBoxArea.Controls.Add(this.txtCellNoForArea);
            this.groupBoxArea.Controls.Add(this.lblCellNoForArea);
            this.groupBoxArea.Controls.Add(this.btnClose);
            this.groupBoxArea.Controls.Add(this.txtZoneIDForArea);
            this.groupBoxArea.Controls.Add(this.lblZoneIDForArea);
            this.groupBoxArea.Controls.Add(this.cmbSelectZoneForArea);
            this.groupBoxArea.Controls.Add(this.lblSelectZoneForArea);
            this.groupBoxArea.Controls.Add(this.btnRefreshArea);
            this.groupBoxArea.Controls.Add(this.btnAreaReport);
            this.groupBoxArea.Controls.Add(this.txtAreaActivityEndDate);
            this.groupBoxArea.Controls.Add(this.btnSaveArea);
            this.groupBoxArea.Controls.Add(this.btnAddArea);
            this.groupBoxArea.Controls.Add(this.dTPAreaActivityEndDate);
            this.groupBoxArea.Controls.Add(this.lblAreaActivityEndDate);
            this.groupBoxArea.Controls.Add(this.txtAreaActivityStartDate);
            this.groupBoxArea.Controls.Add(this.dTPAreaActivityStartDate);
            this.groupBoxArea.Controls.Add(this.cmbSelectEmployeeForArea);
            this.groupBoxArea.Controls.Add(this.lblSelectEmployeeForArea);
            this.groupBoxArea.Controls.Add(this.cmbSelectDesignationForArea);
            this.groupBoxArea.Controls.Add(this.lblAreaActivityStartDate);
            this.groupBoxArea.Controls.Add(this.cmbAreaActive);
            this.groupBoxArea.Controls.Add(this.lblAreaActive);
            this.groupBoxArea.Controls.Add(this.txtAreaName);
            this.groupBoxArea.Controls.Add(this.lblSelectDesignation);
            this.groupBoxArea.Controls.Add(this.lblAreaName);
            this.groupBoxArea.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxArea.Location = new System.Drawing.Point(6, 0);
            this.groupBoxArea.Name = "groupBoxArea";
            this.groupBoxArea.Size = new System.Drawing.Size(822, 203);
            this.groupBoxArea.TabIndex = 17;
            this.groupBoxArea.TabStop = false;
            // 
            // txtCellNoForArea
            // 
            this.txtCellNoForArea.Enabled = false;
            this.txtCellNoForArea.Location = new System.Drawing.Point(624, 142);
            this.txtCellNoForArea.Name = "txtCellNoForArea";
            this.txtCellNoForArea.Size = new System.Drawing.Size(189, 22);
            this.txtCellNoForArea.TabIndex = 10;
            // 
            // lblCellNoForArea
            // 
            this.lblCellNoForArea.AutoSize = true;
            this.lblCellNoForArea.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCellNoForArea.Location = new System.Drawing.Point(433, 145);
            this.lblCellNoForArea.Name = "lblCellNoForArea";
            this.lblCellNoForArea.Size = new System.Drawing.Size(67, 16);
            this.lblCellNoForArea.TabIndex = 72;
            this.lblCellNoForArea.Text = "Cell No :";
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Location = new System.Drawing.Point(657, 170);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(160, 25);
            this.btnClose.TabIndex = 14;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // txtZoneIDForArea
            // 
            this.txtZoneIDForArea.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtZoneIDForArea.Location = new System.Drawing.Point(573, 112);
            this.txtZoneIDForArea.Name = "txtZoneIDForArea";
            this.txtZoneIDForArea.ReadOnly = true;
            this.txtZoneIDForArea.Size = new System.Drawing.Size(240, 22);
            this.txtZoneIDForArea.TabIndex = 71;
            this.txtZoneIDForArea.TabStop = false;
            // 
            // lblZoneIDForArea
            // 
            this.lblZoneIDForArea.AutoSize = true;
            this.lblZoneIDForArea.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblZoneIDForArea.Location = new System.Drawing.Point(433, 115);
            this.lblZoneIDForArea.Name = "lblZoneIDForArea";
            this.lblZoneIDForArea.Size = new System.Drawing.Size(70, 16);
            this.lblZoneIDForArea.TabIndex = 70;
            this.lblZoneIDForArea.Text = "Zone ID :";
            // 
            // cmbSelectZoneForArea
            // 
            this.cmbSelectZoneForArea.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSelectZoneForArea.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectZoneForArea.Enabled = false;
            this.cmbSelectZoneForArea.FormattingEnabled = true;
            this.cmbSelectZoneForArea.Location = new System.Drawing.Point(574, 82);
            this.cmbSelectZoneForArea.Name = "cmbSelectZoneForArea";
            this.cmbSelectZoneForArea.Size = new System.Drawing.Size(240, 24);
            this.cmbSelectZoneForArea.TabIndex = 9;
            this.cmbSelectZoneForArea.Text = "Select Zone";
            this.cmbSelectZoneForArea.SelectedIndexChanged += new System.EventHandler(this.cmbSelectZoneForArea_SelectedIndexChanged);
            // 
            // lblSelectZoneForArea
            // 
            this.lblSelectZoneForArea.AutoSize = true;
            this.lblSelectZoneForArea.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectZoneForArea.Location = new System.Drawing.Point(433, 85);
            this.lblSelectZoneForArea.Name = "lblSelectZoneForArea";
            this.lblSelectZoneForArea.Size = new System.Drawing.Size(99, 16);
            this.lblSelectZoneForArea.TabIndex = 68;
            this.lblSelectZoneForArea.Text = "Select Zone :";
            // 
            // btnRefreshArea
            // 
            this.btnRefreshArea.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefreshArea.Location = new System.Drawing.Point(494, 170);
            this.btnRefreshArea.Name = "btnRefreshArea";
            this.btnRefreshArea.Size = new System.Drawing.Size(160, 25);
            this.btnRefreshArea.TabIndex = 13;
            this.btnRefreshArea.Text = "Refresh";
            this.btnRefreshArea.UseVisualStyleBackColor = true;
            this.btnRefreshArea.Click += new System.EventHandler(this.btnRefreshArea_Click);
            // 
            // btnAreaReport
            // 
            this.btnAreaReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAreaReport.Location = new System.Drawing.Point(331, 170);
            this.btnAreaReport.Name = "btnAreaReport";
            this.btnAreaReport.Size = new System.Drawing.Size(160, 25);
            this.btnAreaReport.TabIndex = 12;
            this.btnAreaReport.Text = "Area Report";
            this.btnAreaReport.UseVisualStyleBackColor = true;
            // 
            // txtAreaActivityEndDate
            // 
            this.txtAreaActivityEndDate.Enabled = false;
            this.txtAreaActivityEndDate.Location = new System.Drawing.Point(573, 52);
            this.txtAreaActivityEndDate.Name = "txtAreaActivityEndDate";
            this.txtAreaActivityEndDate.Size = new System.Drawing.Size(225, 22);
            this.txtAreaActivityEndDate.TabIndex = 8;
            // 
            // btnSaveArea
            // 
            this.btnSaveArea.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveArea.Location = new System.Drawing.Point(168, 170);
            this.btnSaveArea.Name = "btnSaveArea";
            this.btnSaveArea.Size = new System.Drawing.Size(160, 25);
            this.btnSaveArea.TabIndex = 11;
            this.btnSaveArea.Text = "Save Area";
            this.btnSaveArea.UseVisualStyleBackColor = true;
            this.btnSaveArea.Click += new System.EventHandler(this.btnSaveArea_Click);
            // 
            // btnAddArea
            // 
            this.btnAddArea.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddArea.Location = new System.Drawing.Point(5, 170);
            this.btnAddArea.Name = "btnAddArea";
            this.btnAddArea.Size = new System.Drawing.Size(160, 25);
            this.btnAddArea.TabIndex = 0;
            this.btnAddArea.Text = "Add Area";
            this.btnAddArea.UseVisualStyleBackColor = true;
            this.btnAddArea.Click += new System.EventHandler(this.btnAddArea_Click);
            // 
            // dTPAreaActivityEndDate
            // 
            this.dTPAreaActivityEndDate.Enabled = false;
            this.dTPAreaActivityEndDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dTPAreaActivityEndDate.Location = new System.Drawing.Point(798, 52);
            this.dTPAreaActivityEndDate.Name = "dTPAreaActivityEndDate";
            this.dTPAreaActivityEndDate.Size = new System.Drawing.Size(16, 22);
            this.dTPAreaActivityEndDate.TabIndex = 7;
            this.dTPAreaActivityEndDate.CloseUp += new System.EventHandler(this.dTPAreaActivityEndDate_CloseUp);
            // 
            // lblAreaActivityEndDate
            // 
            this.lblAreaActivityEndDate.AutoSize = true;
            this.lblAreaActivityEndDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAreaActivityEndDate.Location = new System.Drawing.Point(433, 55);
            this.lblAreaActivityEndDate.Name = "lblAreaActivityEndDate";
            this.lblAreaActivityEndDate.Size = new System.Drawing.Size(134, 16);
            this.lblAreaActivityEndDate.TabIndex = 65;
            this.lblAreaActivityEndDate.Text = "Activity End Date :";
            // 
            // txtAreaActivityStartDate
            // 
            this.txtAreaActivityStartDate.Enabled = false;
            this.txtAreaActivityStartDate.Location = new System.Drawing.Point(151, 112);
            this.txtAreaActivityStartDate.Name = "txtAreaActivityStartDate";
            this.txtAreaActivityStartDate.Size = new System.Drawing.Size(225, 22);
            this.txtAreaActivityStartDate.TabIndex = 5;
            // 
            // dTPAreaActivityStartDate
            // 
            this.dTPAreaActivityStartDate.Enabled = false;
            this.dTPAreaActivityStartDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dTPAreaActivityStartDate.Location = new System.Drawing.Point(376, 112);
            this.dTPAreaActivityStartDate.Name = "dTPAreaActivityStartDate";
            this.dTPAreaActivityStartDate.Size = new System.Drawing.Size(16, 22);
            this.dTPAreaActivityStartDate.TabIndex = 4;
            this.dTPAreaActivityStartDate.CloseUp += new System.EventHandler(this.dTPAreaActivityStartDate_CloseUp);
            // 
            // cmbSelectEmployeeForArea
            // 
            this.cmbSelectEmployeeForArea.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSelectEmployeeForArea.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectEmployeeForArea.Enabled = false;
            this.cmbSelectEmployeeForArea.FormattingEnabled = true;
            this.cmbSelectEmployeeForArea.Location = new System.Drawing.Point(151, 82);
            this.cmbSelectEmployeeForArea.Name = "cmbSelectEmployeeForArea";
            this.cmbSelectEmployeeForArea.Size = new System.Drawing.Size(240, 24);
            this.cmbSelectEmployeeForArea.TabIndex = 3;
            this.cmbSelectEmployeeForArea.Text = "Select Employee";
            // 
            // lblSelectEmployeeForArea
            // 
            this.lblSelectEmployeeForArea.AutoSize = true;
            this.lblSelectEmployeeForArea.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectEmployeeForArea.Location = new System.Drawing.Point(4, 85);
            this.lblSelectEmployeeForArea.Name = "lblSelectEmployeeForArea";
            this.lblSelectEmployeeForArea.Size = new System.Drawing.Size(134, 16);
            this.lblSelectEmployeeForArea.TabIndex = 62;
            this.lblSelectEmployeeForArea.Text = "Select Employee :";
            // 
            // cmbSelectDesignationForArea
            // 
            this.cmbSelectDesignationForArea.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSelectDesignationForArea.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectDesignationForArea.Enabled = false;
            this.cmbSelectDesignationForArea.FormattingEnabled = true;
            this.cmbSelectDesignationForArea.Location = new System.Drawing.Point(151, 52);
            this.cmbSelectDesignationForArea.Name = "cmbSelectDesignationForArea";
            this.cmbSelectDesignationForArea.Size = new System.Drawing.Size(240, 24);
            this.cmbSelectDesignationForArea.TabIndex = 2;
            this.cmbSelectDesignationForArea.Text = "Select Designation";
            this.cmbSelectDesignationForArea.SelectedIndexChanged += new System.EventHandler(this.cmbSelectDesignationForArea_SelectedIndexChanged);
            this.cmbSelectDesignationForArea.SelectedValueChanged += new System.EventHandler(this.cmbSelectDesignationForArea_SelectedValueChanged);
            // 
            // lblAreaActivityStartDate
            // 
            this.lblAreaActivityStartDate.AutoSize = true;
            this.lblAreaActivityStartDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAreaActivityStartDate.Location = new System.Drawing.Point(4, 115);
            this.lblAreaActivityStartDate.Name = "lblAreaActivityStartDate";
            this.lblAreaActivityStartDate.Size = new System.Drawing.Size(139, 16);
            this.lblAreaActivityStartDate.TabIndex = 59;
            this.lblAreaActivityStartDate.Text = "Activity Start Date :";
            // 
            // cmbAreaActive
            // 
            this.cmbAreaActive.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbAreaActive.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbAreaActive.Enabled = false;
            this.cmbAreaActive.FormattingEnabled = true;
            this.cmbAreaActive.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cmbAreaActive.Location = new System.Drawing.Point(573, 22);
            this.cmbAreaActive.Name = "cmbAreaActive";
            this.cmbAreaActive.Size = new System.Drawing.Size(240, 24);
            this.cmbAreaActive.TabIndex = 6;
            this.cmbAreaActive.Text = "Select Active";
            this.cmbAreaActive.SelectedValueChanged += new System.EventHandler(this.cmbAreaActive_SelectedValueChanged);
            // 
            // lblAreaActive
            // 
            this.lblAreaActive.AutoSize = true;
            this.lblAreaActive.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAreaActive.Location = new System.Drawing.Point(433, 25);
            this.lblAreaActive.Name = "lblAreaActive";
            this.lblAreaActive.Size = new System.Drawing.Size(59, 16);
            this.lblAreaActive.TabIndex = 11;
            this.lblAreaActive.Text = "Active :";
            // 
            // txtAreaName
            // 
            this.txtAreaName.Enabled = false;
            this.txtAreaName.Location = new System.Drawing.Point(151, 22);
            this.txtAreaName.Name = "txtAreaName";
            this.txtAreaName.Size = new System.Drawing.Size(240, 22);
            this.txtAreaName.TabIndex = 1;
            // 
            // lblSelectDesignation
            // 
            this.lblSelectDesignation.AutoSize = true;
            this.lblSelectDesignation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectDesignation.Location = new System.Drawing.Point(4, 55);
            this.lblSelectDesignation.Name = "lblSelectDesignation";
            this.lblSelectDesignation.Size = new System.Drawing.Size(147, 16);
            this.lblSelectDesignation.TabIndex = 1;
            this.lblSelectDesignation.Text = "Select Designation :";
            // 
            // lblAreaName
            // 
            this.lblAreaName.AutoSize = true;
            this.lblAreaName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAreaName.Location = new System.Drawing.Point(4, 25);
            this.lblAreaName.Name = "lblAreaName";
            this.lblAreaName.Size = new System.Drawing.Size(94, 16);
            this.lblAreaName.TabIndex = 0;
            this.lblAreaName.Text = "Area Name :";
            // 
            // txtCellNoPrefixForArea
            // 
            this.txtCellNoPrefixForArea.Enabled = false;
            this.txtCellNoPrefixForArea.Location = new System.Drawing.Point(573, 142);
            this.txtCellNoPrefixForArea.Name = "txtCellNoPrefixForArea";
            this.txtCellNoPrefixForArea.Size = new System.Drawing.Size(50, 22);
            this.txtCellNoPrefixForArea.TabIndex = 73;
            this.txtCellNoPrefixForArea.TabStop = false;
            this.txtCellNoPrefixForArea.Text = "+880";
            // 
            // AreaUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(834, 537);
            this.Controls.Add(this.dataGridViewAreaDetails);
            this.Controls.Add(this.groupBoxArea);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AreaUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add / Edit Area";
            this.Load += new System.EventHandler(this.AreaUI_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAreaDetails)).EndInit();
            this.groupBoxArea.ResumeLayout(false);
            this.groupBoxArea.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewAreaDetails;
        private System.Windows.Forms.GroupBox groupBoxArea;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.TextBox txtZoneIDForArea;
        private System.Windows.Forms.Label lblZoneIDForArea;
        private System.Windows.Forms.ComboBox cmbSelectZoneForArea;
        private System.Windows.Forms.Label lblSelectZoneForArea;
        private System.Windows.Forms.Button btnRefreshArea;
        private System.Windows.Forms.Button btnAreaReport;
        private System.Windows.Forms.TextBox txtAreaActivityEndDate;
        private System.Windows.Forms.Button btnSaveArea;
        private System.Windows.Forms.Button btnAddArea;
        private System.Windows.Forms.DateTimePicker dTPAreaActivityEndDate;
        private System.Windows.Forms.Label lblAreaActivityEndDate;
        private System.Windows.Forms.TextBox txtAreaActivityStartDate;
        private System.Windows.Forms.DateTimePicker dTPAreaActivityStartDate;
        private System.Windows.Forms.ComboBox cmbSelectEmployeeForArea;
        private System.Windows.Forms.Label lblSelectEmployeeForArea;
        private System.Windows.Forms.ComboBox cmbSelectDesignationForArea;
        private System.Windows.Forms.Label lblAreaActivityStartDate;
        private System.Windows.Forms.ComboBox cmbAreaActive;
        private System.Windows.Forms.Label lblAreaActive;
        private System.Windows.Forms.TextBox txtAreaName;
        private System.Windows.Forms.Label lblSelectDesignation;
        private System.Windows.Forms.Label lblAreaName;
        private System.Windows.Forms.TextBox txtCellNoForArea;
        private System.Windows.Forms.Label lblCellNoForArea;
        private System.Windows.Forms.TextBox txtCellNoPrefixForArea;
    }
}