﻿namespace SMSapplication.UI
{
    partial class DepartmentUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DepartmentUI));
            this.groupBoxDepartment = new System.Windows.Forms.GroupBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnDepartmentReport = new System.Windows.Forms.Button();
            this.btnRefreshDepartment = new System.Windows.Forms.Button();
            this.cmbActiveDepartment = new System.Windows.Forms.ComboBox();
            this.btnAddDepartment = new System.Windows.Forms.Button();
            this.btnSaveDepartment = new System.Windows.Forms.Button();
            this.lblActiveDepartment = new System.Windows.Forms.Label();
            this.txtDepartment = new System.Windows.Forms.TextBox();
            this.lblDepartmentName = new System.Windows.Forms.Label();
            this.dataGridViewDepartmentDetails = new System.Windows.Forms.DataGridView();
            this.groupBoxDepartment.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDepartmentDetails)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBoxDepartment
            // 
            this.groupBoxDepartment.Controls.Add(this.btnClose);
            this.groupBoxDepartment.Controls.Add(this.btnDepartmentReport);
            this.groupBoxDepartment.Controls.Add(this.btnRefreshDepartment);
            this.groupBoxDepartment.Controls.Add(this.cmbActiveDepartment);
            this.groupBoxDepartment.Controls.Add(this.btnAddDepartment);
            this.groupBoxDepartment.Controls.Add(this.btnSaveDepartment);
            this.groupBoxDepartment.Controls.Add(this.lblActiveDepartment);
            this.groupBoxDepartment.Controls.Add(this.txtDepartment);
            this.groupBoxDepartment.Controls.Add(this.lblDepartmentName);
            this.groupBoxDepartment.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxDepartment.Location = new System.Drawing.Point(6, 0);
            this.groupBoxDepartment.Name = "groupBoxDepartment";
            this.groupBoxDepartment.Size = new System.Drawing.Size(722, 96);
            this.groupBoxDepartment.TabIndex = 15;
            this.groupBoxDepartment.TabStop = false;
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Location = new System.Drawing.Point(598, 56);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(120, 25);
            this.btnClose.TabIndex = 6;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnDepartmentReport
            // 
            this.btnDepartmentReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDepartmentReport.Location = new System.Drawing.Point(356, 56);
            this.btnDepartmentReport.Name = "btnDepartmentReport";
            this.btnDepartmentReport.Size = new System.Drawing.Size(120, 25);
            this.btnDepartmentReport.TabIndex = 4;
            this.btnDepartmentReport.Text = "Dept. Report";
            this.btnDepartmentReport.UseVisualStyleBackColor = true;
            this.btnDepartmentReport.Click += new System.EventHandler(this.btnDepartmentReport_Click);
            // 
            // btnRefreshDepartment
            // 
            this.btnRefreshDepartment.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefreshDepartment.Location = new System.Drawing.Point(477, 56);
            this.btnRefreshDepartment.Name = "btnRefreshDepartment";
            this.btnRefreshDepartment.Size = new System.Drawing.Size(120, 25);
            this.btnRefreshDepartment.TabIndex = 5;
            this.btnRefreshDepartment.Text = "Refresh";
            this.btnRefreshDepartment.UseVisualStyleBackColor = true;
            this.btnRefreshDepartment.Click += new System.EventHandler(this.btnRefreshDepartment_Click);
            // 
            // cmbActiveDepartment
            // 
            this.cmbActiveDepartment.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbActiveDepartment.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbActiveDepartment.Enabled = false;
            this.cmbActiveDepartment.FormattingEnabled = true;
            this.cmbActiveDepartment.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cmbActiveDepartment.Location = new System.Drawing.Point(110, 57);
            this.cmbActiveDepartment.Name = "cmbActiveDepartment";
            this.cmbActiveDepartment.Size = new System.Drawing.Size(240, 24);
            this.cmbActiveDepartment.TabIndex = 2;
            this.cmbActiveDepartment.Text = "Select Active";
            // 
            // btnAddDepartment
            // 
            this.btnAddDepartment.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddDepartment.Location = new System.Drawing.Point(356, 26);
            this.btnAddDepartment.Name = "btnAddDepartment";
            this.btnAddDepartment.Size = new System.Drawing.Size(180, 25);
            this.btnAddDepartment.TabIndex = 0;
            this.btnAddDepartment.Text = "Add Department";
            this.btnAddDepartment.UseVisualStyleBackColor = true;
            this.btnAddDepartment.Click += new System.EventHandler(this.btnAddDepartment_Click);
            // 
            // btnSaveDepartment
            // 
            this.btnSaveDepartment.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveDepartment.Location = new System.Drawing.Point(538, 26);
            this.btnSaveDepartment.Name = "btnSaveDepartment";
            this.btnSaveDepartment.Size = new System.Drawing.Size(180, 25);
            this.btnSaveDepartment.TabIndex = 3;
            this.btnSaveDepartment.Text = "Save Department";
            this.btnSaveDepartment.UseVisualStyleBackColor = true;
            this.btnSaveDepartment.Click += new System.EventHandler(this.btnSaveDepartment_Click);
            // 
            // lblActiveDepartment
            // 
            this.lblActiveDepartment.AutoSize = true;
            this.lblActiveDepartment.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblActiveDepartment.Location = new System.Drawing.Point(4, 60);
            this.lblActiveDepartment.Name = "lblActiveDepartment";
            this.lblActiveDepartment.Size = new System.Drawing.Size(59, 16);
            this.lblActiveDepartment.TabIndex = 11;
            this.lblActiveDepartment.Text = "Active :";
            // 
            // txtDepartment
            // 
            this.txtDepartment.Enabled = false;
            this.txtDepartment.Location = new System.Drawing.Point(110, 27);
            this.txtDepartment.Name = "txtDepartment";
            this.txtDepartment.Size = new System.Drawing.Size(240, 22);
            this.txtDepartment.TabIndex = 1;
            // 
            // lblDepartmentName
            // 
            this.lblDepartmentName.AutoSize = true;
            this.lblDepartmentName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDepartmentName.Location = new System.Drawing.Point(4, 30);
            this.lblDepartmentName.Name = "lblDepartmentName";
            this.lblDepartmentName.Size = new System.Drawing.Size(98, 16);
            this.lblDepartmentName.TabIndex = 0;
            this.lblDepartmentName.Text = "Dept. Name :";
            // 
            // dataGridViewDepartmentDetails
            // 
            this.dataGridViewDepartmentDetails.AllowUserToAddRows = false;
            this.dataGridViewDepartmentDetails.AllowUserToDeleteRows = false;
            this.dataGridViewDepartmentDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewDepartmentDetails.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridViewDepartmentDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDepartmentDetails.Location = new System.Drawing.Point(6, 102);
            this.dataGridViewDepartmentDetails.MultiSelect = false;
            this.dataGridViewDepartmentDetails.Name = "dataGridViewDepartmentDetails";
            this.dataGridViewDepartmentDetails.ReadOnly = true;
            this.dataGridViewDepartmentDetails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewDepartmentDetails.Size = new System.Drawing.Size(722, 419);
            this.dataGridViewDepartmentDetails.TabIndex = 16;
            this.dataGridViewDepartmentDetails.TabStop = false;
            this.dataGridViewDepartmentDetails.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewDepartmentDetails_CellContentDoubleClick);
            this.dataGridViewDepartmentDetails.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewDepartmentDetails_CellDoubleClick);
            // 
            // DepartmentUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(734, 526);
            this.Controls.Add(this.dataGridViewDepartmentDetails);
            this.Controls.Add(this.groupBoxDepartment);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "DepartmentUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add / Edit Department";
            this.Load += new System.EventHandler(this.DepartmentUI_Load);
            this.groupBoxDepartment.ResumeLayout(false);
            this.groupBoxDepartment.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDepartmentDetails)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxDepartment;
        private System.Windows.Forms.ComboBox cmbActiveDepartment;
        private System.Windows.Forms.Label lblActiveDepartment;
        private System.Windows.Forms.TextBox txtDepartment;
        private System.Windows.Forms.Label lblDepartmentName;
        private System.Windows.Forms.Button btnRefreshDepartment;
        private System.Windows.Forms.Button btnAddDepartment;
        private System.Windows.Forms.Button btnSaveDepartment;
        private System.Windows.Forms.DataGridView dataGridViewDepartmentDetails;
        private System.Windows.Forms.Button btnDepartmentReport;
        private System.Windows.Forms.Button btnClose;
    }
}