﻿namespace SMSapplication.UI
{
    partial class EmployeeUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EmployeeUI));
            this.groupBoxEmployee = new System.Windows.Forms.GroupBox();
            this.btnEmployeeReport = new System.Windows.Forms.Button();
            this.btnRefreshEmployee = new System.Windows.Forms.Button();
            this.groupBoxSearchEmployee = new System.Windows.Forms.GroupBox();
            this.radioBtnShowAllEmp = new System.Windows.Forms.RadioButton();
            this.btnSearchEmployee = new System.Windows.Forms.Button();
            this.cmbSearchCriteriaForEmployeeByDesignation = new System.Windows.Forms.ComboBox();
            this.txtSearchCriteriaForEmployee = new System.Windows.Forms.TextBox();
            this.radioBtnByGroupAndDesignation = new System.Windows.Forms.RadioButton();
            this.radioBtnOfficialMobileNumber = new System.Windows.Forms.RadioButton();
            this.radioBtnEmployeeName = new System.Windows.Forms.RadioButton();
            this.txtDOB = new System.Windows.Forms.TextBox();
            this.btnSaveEmployee = new System.Windows.Forms.Button();
            this.btnAddEmployee = new System.Windows.Forms.Button();
            this.txtQuitDate = new System.Windows.Forms.TextBox();
            this.dTPQuitDate = new System.Windows.Forms.DateTimePicker();
            this.lblQuitDate = new System.Windows.Forms.Label();
            this.cmbEmployeeActive = new System.Windows.Forms.ComboBox();
            this.lblEmployeeActive = new System.Windows.Forms.Label();
            this.txtOfficialCellNo = new System.Windows.Forms.TextBox();
            this.lblOfficialCellNo = new System.Windows.Forms.Label();
            this.cmbEmployeeDepartment = new System.Windows.Forms.ComboBox();
            this.lblEmployeeDepartment = new System.Windows.Forms.Label();
            this.dTPDateOfBirth = new System.Windows.Forms.DateTimePicker();
            this.cmbEmployeeDesignation = new System.Windows.Forms.ComboBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.txtEmployeeName = new System.Windows.Forms.TextBox();
            this.lblEmployeeDesignation = new System.Windows.Forms.Label();
            this.lblDateOfBirth = new System.Windows.Forms.Label();
            this.lblAddress = new System.Windows.Forms.Label();
            this.lblEmployeeName = new System.Windows.Forms.Label();
            this.dataGridViewEmployeeList = new System.Windows.Forms.DataGridView();
            this.btnClose = new System.Windows.Forms.Button();
            this.groupBoxEmployee.SuspendLayout();
            this.groupBoxSearchEmployee.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEmployeeList)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBoxEmployee
            // 
            this.groupBoxEmployee.Controls.Add(this.btnClose);
            this.groupBoxEmployee.Controls.Add(this.btnEmployeeReport);
            this.groupBoxEmployee.Controls.Add(this.btnRefreshEmployee);
            this.groupBoxEmployee.Controls.Add(this.groupBoxSearchEmployee);
            this.groupBoxEmployee.Controls.Add(this.txtDOB);
            this.groupBoxEmployee.Controls.Add(this.btnSaveEmployee);
            this.groupBoxEmployee.Controls.Add(this.btnAddEmployee);
            this.groupBoxEmployee.Controls.Add(this.txtQuitDate);
            this.groupBoxEmployee.Controls.Add(this.dTPQuitDate);
            this.groupBoxEmployee.Controls.Add(this.lblQuitDate);
            this.groupBoxEmployee.Controls.Add(this.cmbEmployeeActive);
            this.groupBoxEmployee.Controls.Add(this.lblEmployeeActive);
            this.groupBoxEmployee.Controls.Add(this.txtOfficialCellNo);
            this.groupBoxEmployee.Controls.Add(this.lblOfficialCellNo);
            this.groupBoxEmployee.Controls.Add(this.cmbEmployeeDepartment);
            this.groupBoxEmployee.Controls.Add(this.lblEmployeeDepartment);
            this.groupBoxEmployee.Controls.Add(this.dTPDateOfBirth);
            this.groupBoxEmployee.Controls.Add(this.cmbEmployeeDesignation);
            this.groupBoxEmployee.Controls.Add(this.txtAddress);
            this.groupBoxEmployee.Controls.Add(this.txtEmployeeName);
            this.groupBoxEmployee.Controls.Add(this.lblEmployeeDesignation);
            this.groupBoxEmployee.Controls.Add(this.lblDateOfBirth);
            this.groupBoxEmployee.Controls.Add(this.lblAddress);
            this.groupBoxEmployee.Controls.Add(this.lblEmployeeName);
            this.groupBoxEmployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxEmployee.Location = new System.Drawing.Point(6, 0);
            this.groupBoxEmployee.Name = "groupBoxEmployee";
            this.groupBoxEmployee.Size = new System.Drawing.Size(1150, 209);
            this.groupBoxEmployee.TabIndex = 22;
            this.groupBoxEmployee.TabStop = false;
            // 
            // btnEmployeeReport
            // 
            this.btnEmployeeReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmployeeReport.Location = new System.Drawing.Point(676, 176);
            this.btnEmployeeReport.Name = "btnEmployeeReport";
            this.btnEmployeeReport.Size = new System.Drawing.Size(150, 25);
            this.btnEmployeeReport.TabIndex = 10;
            this.btnEmployeeReport.Text = "Employee Report";
            this.btnEmployeeReport.UseVisualStyleBackColor = true;
            this.btnEmployeeReport.Click += new System.EventHandler(this.btnEmployeeReport_Click);
            // 
            // btnRefreshEmployee
            // 
            this.btnRefreshEmployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefreshEmployee.Location = new System.Drawing.Point(829, 176);
            this.btnRefreshEmployee.Name = "btnRefreshEmployee";
            this.btnRefreshEmployee.Size = new System.Drawing.Size(150, 25);
            this.btnRefreshEmployee.TabIndex = 11;
            this.btnRefreshEmployee.Text = "Refresh";
            this.btnRefreshEmployee.UseVisualStyleBackColor = true;
            this.btnRefreshEmployee.Click += new System.EventHandler(this.btnRefreshEmployee_Click);
            // 
            // groupBoxSearchEmployee
            // 
            this.groupBoxSearchEmployee.Controls.Add(this.radioBtnShowAllEmp);
            this.groupBoxSearchEmployee.Controls.Add(this.btnSearchEmployee);
            this.groupBoxSearchEmployee.Controls.Add(this.cmbSearchCriteriaForEmployeeByDesignation);
            this.groupBoxSearchEmployee.Controls.Add(this.txtSearchCriteriaForEmployee);
            this.groupBoxSearchEmployee.Controls.Add(this.radioBtnByGroupAndDesignation);
            this.groupBoxSearchEmployee.Controls.Add(this.radioBtnOfficialMobileNumber);
            this.groupBoxSearchEmployee.Controls.Add(this.radioBtnEmployeeName);
            this.groupBoxSearchEmployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxSearchEmployee.Location = new System.Drawing.Point(850, 21);
            this.groupBoxSearchEmployee.Name = "groupBoxSearchEmployee";
            this.groupBoxSearchEmployee.Size = new System.Drawing.Size(282, 146);
            this.groupBoxSearchEmployee.TabIndex = 48;
            this.groupBoxSearchEmployee.TabStop = false;
            this.groupBoxSearchEmployee.Text = "Search";
            // 
            // radioBtnShowAllEmp
            // 
            this.radioBtnShowAllEmp.AutoSize = true;
            this.radioBtnShowAllEmp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioBtnShowAllEmp.Location = new System.Drawing.Point(166, 51);
            this.radioBtnShowAllEmp.Name = "radioBtnShowAllEmp";
            this.radioBtnShowAllEmp.Size = new System.Drawing.Size(77, 20);
            this.radioBtnShowAllEmp.TabIndex = 16;
            this.radioBtnShowAllEmp.TabStop = true;
            this.radioBtnShowAllEmp.Text = "Show All";
            this.radioBtnShowAllEmp.UseVisualStyleBackColor = true;
            this.radioBtnShowAllEmp.CheckedChanged += new System.EventHandler(this.radioBtnShowAllEmp_CheckedChanged);
            // 
            // btnSearchEmployee
            // 
            this.btnSearchEmployee.Enabled = false;
            this.btnSearchEmployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearchEmployee.Location = new System.Drawing.Point(14, 112);
            this.btnSearchEmployee.Name = "btnSearchEmployee";
            this.btnSearchEmployee.Size = new System.Drawing.Size(248, 25);
            this.btnSearchEmployee.TabIndex = 19;
            this.btnSearchEmployee.Text = "Search";
            this.btnSearchEmployee.UseVisualStyleBackColor = true;
            this.btnSearchEmployee.Click += new System.EventHandler(this.btnSearchEmployee_Click);
            // 
            // cmbSearchCriteriaForEmployeeByDesignation
            // 
            this.cmbSearchCriteriaForEmployeeByDesignation.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSearchCriteriaForEmployeeByDesignation.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSearchCriteriaForEmployeeByDesignation.Enabled = false;
            this.cmbSearchCriteriaForEmployeeByDesignation.FormattingEnabled = true;
            this.cmbSearchCriteriaForEmployeeByDesignation.Location = new System.Drawing.Point(170, 83);
            this.cmbSearchCriteriaForEmployeeByDesignation.Name = "cmbSearchCriteriaForEmployeeByDesignation";
            this.cmbSearchCriteriaForEmployeeByDesignation.Size = new System.Drawing.Size(92, 24);
            this.cmbSearchCriteriaForEmployeeByDesignation.TabIndex = 18;
            // 
            // txtSearchCriteriaForEmployee
            // 
            this.txtSearchCriteriaForEmployee.Enabled = false;
            this.txtSearchCriteriaForEmployee.Location = new System.Drawing.Point(14, 83);
            this.txtSearchCriteriaForEmployee.Name = "txtSearchCriteriaForEmployee";
            this.txtSearchCriteriaForEmployee.Size = new System.Drawing.Size(150, 22);
            this.txtSearchCriteriaForEmployee.TabIndex = 17;
            // 
            // radioBtnByGroupAndDesignation
            // 
            this.radioBtnByGroupAndDesignation.AutoSize = true;
            this.radioBtnByGroupAndDesignation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioBtnByGroupAndDesignation.Location = new System.Drawing.Point(14, 51);
            this.radioBtnByGroupAndDesignation.Name = "radioBtnByGroupAndDesignation";
            this.radioBtnByGroupAndDesignation.Size = new System.Drawing.Size(117, 20);
            this.radioBtnByGroupAndDesignation.TabIndex = 15;
            this.radioBtnByGroupAndDesignation.TabStop = true;
            this.radioBtnByGroupAndDesignation.Text = "By Designation";
            this.radioBtnByGroupAndDesignation.UseVisualStyleBackColor = true;
            this.radioBtnByGroupAndDesignation.CheckedChanged += new System.EventHandler(this.radioBtnByGroupAndDesignation_CheckedChanged);
            // 
            // radioBtnOfficialMobileNumber
            // 
            this.radioBtnOfficialMobileNumber.AutoSize = true;
            this.radioBtnOfficialMobileNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioBtnOfficialMobileNumber.Location = new System.Drawing.Point(166, 25);
            this.radioBtnOfficialMobileNumber.Name = "radioBtnOfficialMobileNumber";
            this.radioBtnOfficialMobileNumber.Size = new System.Drawing.Size(86, 20);
            this.radioBtnOfficialMobileNumber.TabIndex = 14;
            this.radioBtnOfficialMobileNumber.TabStop = true;
            this.radioBtnOfficialMobileNumber.Text = "By Mobile";
            this.radioBtnOfficialMobileNumber.UseVisualStyleBackColor = true;
            this.radioBtnOfficialMobileNumber.CheckedChanged += new System.EventHandler(this.radioBtnOfficialMobileNumber_CheckedChanged);
            // 
            // radioBtnEmployeeName
            // 
            this.radioBtnEmployeeName.AutoSize = true;
            this.radioBtnEmployeeName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioBtnEmployeeName.Location = new System.Drawing.Point(14, 25);
            this.radioBtnEmployeeName.Name = "radioBtnEmployeeName";
            this.radioBtnEmployeeName.Size = new System.Drawing.Size(82, 20);
            this.radioBtnEmployeeName.TabIndex = 13;
            this.radioBtnEmployeeName.TabStop = true;
            this.radioBtnEmployeeName.Text = "By Name";
            this.radioBtnEmployeeName.UseVisualStyleBackColor = true;
            this.radioBtnEmployeeName.CheckedChanged += new System.EventHandler(this.radioBtnEmployeeName_CheckedChanged);
            // 
            // txtDOB
            // 
            this.txtDOB.Enabled = false;
            this.txtDOB.Location = new System.Drawing.Point(128, 147);
            this.txtDOB.Name = "txtDOB";
            this.txtDOB.Size = new System.Drawing.Size(225, 22);
            this.txtDOB.TabIndex = 3;
            // 
            // btnSaveEmployee
            // 
            this.btnSaveEmployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveEmployee.Location = new System.Drawing.Point(523, 176);
            this.btnSaveEmployee.Name = "btnSaveEmployee";
            this.btnSaveEmployee.Size = new System.Drawing.Size(150, 25);
            this.btnSaveEmployee.TabIndex = 9;
            this.btnSaveEmployee.Text = "Save Employee";
            this.btnSaveEmployee.UseVisualStyleBackColor = true;
            this.btnSaveEmployee.Click += new System.EventHandler(this.btnSaveEmployee_Click);
            // 
            // btnAddEmployee
            // 
            this.btnAddEmployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddEmployee.Location = new System.Drawing.Point(370, 176);
            this.btnAddEmployee.Name = "btnAddEmployee";
            this.btnAddEmployee.Size = new System.Drawing.Size(150, 25);
            this.btnAddEmployee.TabIndex = 0;
            this.btnAddEmployee.Text = "Add Employee";
            this.btnAddEmployee.UseVisualStyleBackColor = true;
            this.btnAddEmployee.Click += new System.EventHandler(this.btnAddEmployee_Click);
            // 
            // txtQuitDate
            // 
            this.txtQuitDate.Enabled = false;
            this.txtQuitDate.Location = new System.Drawing.Point(554, 147);
            this.txtQuitDate.Name = "txtQuitDate";
            this.txtQuitDate.Size = new System.Drawing.Size(225, 22);
            this.txtQuitDate.TabIndex = 8;
            // 
            // dTPQuitDate
            // 
            this.dTPQuitDate.Enabled = false;
            this.dTPQuitDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dTPQuitDate.Location = new System.Drawing.Point(778, 147);
            this.dTPQuitDate.Name = "dTPQuitDate";
            this.dTPQuitDate.Size = new System.Drawing.Size(16, 22);
            this.dTPQuitDate.TabIndex = 44;
            this.dTPQuitDate.TabStop = false;
            this.dTPQuitDate.CloseUp += new System.EventHandler(this.dTPQuitDate_CloseUp);
            // 
            // lblQuitDate
            // 
            this.lblQuitDate.AutoSize = true;
            this.lblQuitDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuitDate.Location = new System.Drawing.Point(433, 150);
            this.lblQuitDate.Name = "lblQuitDate";
            this.lblQuitDate.Size = new System.Drawing.Size(80, 16);
            this.lblQuitDate.TabIndex = 55;
            this.lblQuitDate.Text = "Quit Date :";
            // 
            // cmbEmployeeActive
            // 
            this.cmbEmployeeActive.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbEmployeeActive.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbEmployeeActive.Enabled = false;
            this.cmbEmployeeActive.FormattingEnabled = true;
            this.cmbEmployeeActive.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cmbEmployeeActive.Location = new System.Drawing.Point(554, 117);
            this.cmbEmployeeActive.Name = "cmbEmployeeActive";
            this.cmbEmployeeActive.Size = new System.Drawing.Size(240, 24);
            this.cmbEmployeeActive.TabIndex = 7;
            this.cmbEmployeeActive.Text = "Select Active";
            this.cmbEmployeeActive.SelectedValueChanged += new System.EventHandler(this.cmbEmployeeActive_SelectedValueChanged);
            // 
            // lblEmployeeActive
            // 
            this.lblEmployeeActive.AutoSize = true;
            this.lblEmployeeActive.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmployeeActive.Location = new System.Drawing.Point(433, 120);
            this.lblEmployeeActive.Name = "lblEmployeeActive";
            this.lblEmployeeActive.Size = new System.Drawing.Size(59, 16);
            this.lblEmployeeActive.TabIndex = 48;
            this.lblEmployeeActive.Text = "Active :";
            // 
            // txtOfficialCellNo
            // 
            this.txtOfficialCellNo.Enabled = false;
            this.txtOfficialCellNo.Location = new System.Drawing.Point(554, 87);
            this.txtOfficialCellNo.Name = "txtOfficialCellNo";
            this.txtOfficialCellNo.Size = new System.Drawing.Size(240, 22);
            this.txtOfficialCellNo.TabIndex = 6;
            // 
            // lblOfficialCellNo
            // 
            this.lblOfficialCellNo.AutoSize = true;
            this.lblOfficialCellNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOfficialCellNo.Location = new System.Drawing.Point(431, 90);
            this.lblOfficialCellNo.Name = "lblOfficialCellNo";
            this.lblOfficialCellNo.Size = new System.Drawing.Size(67, 16);
            this.lblOfficialCellNo.TabIndex = 42;
            this.lblOfficialCellNo.Text = "Cell No :";
            // 
            // cmbEmployeeDepartment
            // 
            this.cmbEmployeeDepartment.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbEmployeeDepartment.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbEmployeeDepartment.Enabled = false;
            this.cmbEmployeeDepartment.FormattingEnabled = true;
            this.cmbEmployeeDepartment.Location = new System.Drawing.Point(554, 57);
            this.cmbEmployeeDepartment.Name = "cmbEmployeeDepartment";
            this.cmbEmployeeDepartment.Size = new System.Drawing.Size(240, 24);
            this.cmbEmployeeDepartment.TabIndex = 5;
            this.cmbEmployeeDepartment.Text = "Select Department";
            // 
            // lblEmployeeDepartment
            // 
            this.lblEmployeeDepartment.AutoSize = true;
            this.lblEmployeeDepartment.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmployeeDepartment.Location = new System.Drawing.Point(431, 60);
            this.lblEmployeeDepartment.Name = "lblEmployeeDepartment";
            this.lblEmployeeDepartment.Size = new System.Drawing.Size(96, 16);
            this.lblEmployeeDepartment.TabIndex = 39;
            this.lblEmployeeDepartment.Text = "Department :";
            // 
            // dTPDateOfBirth
            // 
            this.dTPDateOfBirth.Enabled = false;
            this.dTPDateOfBirth.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dTPDateOfBirth.Location = new System.Drawing.Point(352, 147);
            this.dTPDateOfBirth.Name = "dTPDateOfBirth";
            this.dTPDateOfBirth.Size = new System.Drawing.Size(16, 22);
            this.dTPDateOfBirth.TabIndex = 37;
            this.dTPDateOfBirth.CloseUp += new System.EventHandler(this.dTPDateOfBirth_CloseUp);
            // 
            // cmbEmployeeDesignation
            // 
            this.cmbEmployeeDesignation.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbEmployeeDesignation.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbEmployeeDesignation.Enabled = false;
            this.cmbEmployeeDesignation.FormattingEnabled = true;
            this.cmbEmployeeDesignation.Location = new System.Drawing.Point(554, 27);
            this.cmbEmployeeDesignation.Name = "cmbEmployeeDesignation";
            this.cmbEmployeeDesignation.Size = new System.Drawing.Size(240, 24);
            this.cmbEmployeeDesignation.TabIndex = 4;
            this.cmbEmployeeDesignation.Text = "Select Designation";
            // 
            // txtAddress
            // 
            this.txtAddress.Enabled = false;
            this.txtAddress.Location = new System.Drawing.Point(128, 57);
            this.txtAddress.Multiline = true;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(240, 80);
            this.txtAddress.TabIndex = 2;
            // 
            // txtEmployeeName
            // 
            this.txtEmployeeName.Enabled = false;
            this.txtEmployeeName.Location = new System.Drawing.Point(128, 27);
            this.txtEmployeeName.Name = "txtEmployeeName";
            this.txtEmployeeName.Size = new System.Drawing.Size(240, 22);
            this.txtEmployeeName.TabIndex = 1;
            // 
            // lblEmployeeDesignation
            // 
            this.lblEmployeeDesignation.AutoSize = true;
            this.lblEmployeeDesignation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmployeeDesignation.Location = new System.Drawing.Point(431, 30);
            this.lblEmployeeDesignation.Name = "lblEmployeeDesignation";
            this.lblEmployeeDesignation.Size = new System.Drawing.Size(99, 16);
            this.lblEmployeeDesignation.TabIndex = 3;
            this.lblEmployeeDesignation.Text = "Designation :";
            // 
            // lblDateOfBirth
            // 
            this.lblDateOfBirth.AutoSize = true;
            this.lblDateOfBirth.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDateOfBirth.Location = new System.Drawing.Point(2, 150);
            this.lblDateOfBirth.Name = "lblDateOfBirth";
            this.lblDateOfBirth.Size = new System.Drawing.Size(101, 16);
            this.lblDateOfBirth.TabIndex = 2;
            this.lblDateOfBirth.Text = "Date of Birth :";
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddress.Location = new System.Drawing.Point(4, 60);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(74, 16);
            this.lblAddress.TabIndex = 1;
            this.lblAddress.Text = "Address :";
            // 
            // lblEmployeeName
            // 
            this.lblEmployeeName.AutoSize = true;
            this.lblEmployeeName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmployeeName.Location = new System.Drawing.Point(4, 30);
            this.lblEmployeeName.Name = "lblEmployeeName";
            this.lblEmployeeName.Size = new System.Drawing.Size(96, 16);
            this.lblEmployeeName.TabIndex = 0;
            this.lblEmployeeName.Text = "Emp. Name :";
            // 
            // dataGridViewEmployeeList
            // 
            this.dataGridViewEmployeeList.AllowUserToAddRows = false;
            this.dataGridViewEmployeeList.AllowUserToDeleteRows = false;
            this.dataGridViewEmployeeList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewEmployeeList.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridViewEmployeeList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewEmployeeList.Location = new System.Drawing.Point(6, 215);
            this.dataGridViewEmployeeList.MultiSelect = false;
            this.dataGridViewEmployeeList.Name = "dataGridViewEmployeeList";
            this.dataGridViewEmployeeList.ReadOnly = true;
            this.dataGridViewEmployeeList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewEmployeeList.Size = new System.Drawing.Size(1150, 422);
            this.dataGridViewEmployeeList.TabIndex = 23;
            this.dataGridViewEmployeeList.TabStop = false;
            this.dataGridViewEmployeeList.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewEmployeeList_CellContentDoubleClick);
            this.dataGridViewEmployeeList.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewEmployeeList_CellDoubleClick);
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Location = new System.Drawing.Point(982, 176);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(150, 25);
            this.btnClose.TabIndex = 12;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // EmployeeUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(1162, 642);
            this.Controls.Add(this.dataGridViewEmployeeList);
            this.Controls.Add(this.groupBoxEmployee);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "EmployeeUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add / Edit Employee";
            this.Load += new System.EventHandler(this.EmployeeUI_Load);
            this.groupBoxEmployee.ResumeLayout(false);
            this.groupBoxEmployee.PerformLayout();
            this.groupBoxSearchEmployee.ResumeLayout(false);
            this.groupBoxSearchEmployee.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEmployeeList)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxEmployee;
        private System.Windows.Forms.TextBox txtDOB;
        private System.Windows.Forms.TextBox txtQuitDate;
        private System.Windows.Forms.DateTimePicker dTPQuitDate;
        private System.Windows.Forms.Label lblQuitDate;
        private System.Windows.Forms.ComboBox cmbEmployeeActive;
        private System.Windows.Forms.Label lblEmployeeActive;
        private System.Windows.Forms.TextBox txtOfficialCellNo;
        private System.Windows.Forms.Label lblOfficialCellNo;
        private System.Windows.Forms.ComboBox cmbEmployeeDepartment;
        private System.Windows.Forms.Label lblEmployeeDepartment;
        private System.Windows.Forms.DateTimePicker dTPDateOfBirth;
        private System.Windows.Forms.ComboBox cmbEmployeeDesignation;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.TextBox txtEmployeeName;
        private System.Windows.Forms.Label lblEmployeeDesignation;
        private System.Windows.Forms.Label lblDateOfBirth;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.Label lblEmployeeName;
        private System.Windows.Forms.GroupBox groupBoxSearchEmployee;
        private System.Windows.Forms.RadioButton radioBtnShowAllEmp;
        private System.Windows.Forms.Button btnSearchEmployee;
        private System.Windows.Forms.ComboBox cmbSearchCriteriaForEmployeeByDesignation;
        private System.Windows.Forms.TextBox txtSearchCriteriaForEmployee;
        private System.Windows.Forms.RadioButton radioBtnByGroupAndDesignation;
        private System.Windows.Forms.RadioButton radioBtnOfficialMobileNumber;
        private System.Windows.Forms.RadioButton radioBtnEmployeeName;
        private System.Windows.Forms.Button btnRefreshEmployee;
        private System.Windows.Forms.Button btnAddEmployee;
        private System.Windows.Forms.Button btnSaveEmployee;
        private System.Windows.Forms.DataGridView dataGridViewEmployeeList;
        private System.Windows.Forms.Button btnEmployeeReport;
        private System.Windows.Forms.Button btnClose;
    }
}