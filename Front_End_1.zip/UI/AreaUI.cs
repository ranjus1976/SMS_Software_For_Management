﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using SMSapplication.BLL;
using SMSapplication.DAL;
using SMSapplication.DAL.DAO;
using SMSapplication.DAL.Gateway;
using SMSapplication.UI;

namespace SMSapplication.UI
{
    public partial class AreaUI : Form
    {
        DivisionDetailsManager objDivisionDetailsManager = new DivisionDetailsManager();
        DesignationDetailsManager objDesignationDetailsManager = new DesignationDetailsManager();
        EmployeeDetailsManager objEmployeeDetailsManager = new EmployeeDetailsManager();
        GroupDetailsManager objGroupDetailsManager = new GroupDetailsManager();
        RegionDetailsManager objRegionDetailsManager = new RegionDetailsManager();
        ZoneDetailsManager objZoneDetailsManager = new ZoneDetailsManager();
        AreaDetailsManager objAreaDetailsManager = new AreaDetailsManager();

        private int areaId;
        private string areaName;
        private string empName;
        private string empDesignationCode;
        private string areaActivityStartDate;
        private string areaActivityEndDate;
        private string areaActive;
        private string zoneNameForArea;
        private int zoneIdForArea;
        private string cellNoForArea;
        private string checkCellNoFirstDigit;
        private string retreiveCellNo;
        
        public AreaUI()
        {
            InitializeComponent();
            RefreshArea();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void AreaUI_Load(object sender, EventArgs e)
        {
            RefreshArea();
        }

        public void RefreshArea()
        {
            ClearArea();

            if (txtAreaName.Enabled == true)
            {
                txtAreaName.Enabled = false;
            }

            if (cmbSelectDesignationForArea.Enabled == true)
            {
                cmbSelectDesignationForArea.Enabled = false;
            }

            if (cmbSelectEmployeeForArea.Enabled == true)
            {
                cmbSelectEmployeeForArea.Enabled = false;
            }

            if (txtAreaActivityStartDate.Enabled == true)
            {
                txtAreaActivityStartDate.Enabled = false;
            }

            if (dTPAreaActivityStartDate.Enabled == true)
            {
                dTPAreaActivityStartDate.Enabled = false;
            }

            if (txtAreaActivityEndDate.Enabled == true)
            {
                txtAreaActivityEndDate.Enabled = false;
            }

            if (dTPAreaActivityEndDate.Enabled == true)
            {
                dTPAreaActivityEndDate.Enabled = false;
            }

            if (cmbSelectZoneForArea.Enabled == true)
            {
                cmbSelectZoneForArea.Enabled = false;
            }

            if (cmbAreaActive.Enabled == true)
            {
                cmbAreaActive.Enabled = false;
            }

            if (btnSaveArea.Text == "Update Area")
            {
                btnSaveArea.Text = "Save Area";
            }

            if (btnSaveArea.Enabled == true)
            {
                btnSaveArea.Enabled = false;
            }

            if (txtCellNoForArea.Enabled == true)
            {
                txtCellNoForArea.Enabled = false;
            }

            dataGridViewAreaDetails.DataSource = objAreaDetailsManager.ShowAllArea();
            dataGridViewAreaDetails.Columns[0].Visible = false;
            DataGridViewAreaDetailsHeaderText();
            btnAddArea.Focus();
        }

        public void DataGridViewAreaDetailsHeaderText()
        {
            dataGridViewAreaDetails.Columns[1].HeaderText = "Area Name";
            dataGridViewAreaDetails.Columns[2].HeaderText = "Employee Name";
            dataGridViewAreaDetails.Columns[3].HeaderText = "Designation Code";
            dataGridViewAreaDetails.Columns[4].HeaderText = "Official Cell No";
            dataGridViewAreaDetails.Columns[5].HeaderText = "Activity Start Date";
            dataGridViewAreaDetails.Columns[6].HeaderText = "Activity End Date";
            dataGridViewAreaDetails.Columns[7].HeaderText = "Zone Name";
            dataGridViewAreaDetails.Columns[8].HeaderText = "Zone ID";
        }

        public void ClearArea()
        {
            txtAreaName.Text = "";
            cmbSelectDesignationForArea.DataSource = objDesignationDetailsManager.LoadDesignationCombo();
            cmbSelectDesignationForArea.DisplayMember = "Designation_Code";
            cmbSelectDesignationForArea.ValueMember = "Designation_Code";
            cmbSelectDesignationForArea.Text = "Select Designation";
            cmbSelectEmployeeForArea.Text = "Select Employee";
            txtAreaActivityStartDate.Text = "";
            txtAreaActivityEndDate.Text = "";
            txtCellNoForArea.Text = "";

            cmbSelectZoneForArea.DataSource = objZoneDetailsManager.LoadDistinctEnabledZone();
            cmbSelectZoneForArea.DisplayMember = "Zone_Name";
            cmbSelectZoneForArea.ValueMember = "Zone_Name";
            cmbSelectZoneForArea.Text = "Select Zone";
            txtZoneIDForArea.Text = "";
            txtZoneIDForArea.ReadOnly = true;
            cmbAreaActive.Text = "Select Active";
            if (btnSaveArea.Text == "Update Area")
            {
                btnSaveArea.Text = "Save Area";
            }
        }

        private void btnAddArea_Click(object sender, EventArgs e)
        {
            if (btnSaveArea.Enabled == false)
            {
                btnSaveArea.Enabled = true;
            }
            if (txtAreaName.Enabled == false)
            {
                txtAreaName.Enabled = true;
            }
            if (cmbSelectDesignationForArea.Enabled == false)
            {
                cmbSelectDesignationForArea.Enabled = true;
            }
            if (cmbSelectEmployeeForArea.Enabled == false)
            {
                cmbSelectEmployeeForArea.Enabled = true;
            }
            if (txtAreaActivityStartDate.Enabled == false)
            {
                txtAreaActivityStartDate.Enabled = true;
            }
            if (dTPAreaActivityStartDate.Enabled == false)
            {
                dTPAreaActivityStartDate.Enabled = true;
            }
            if (txtAreaActivityEndDate.Enabled == true)
            {
                txtAreaActivityEndDate.Enabled = false;
            }
            if (dTPAreaActivityEndDate.Enabled == true)
            {
                dTPAreaActivityEndDate.Enabled = false;
            }
            if (cmbAreaActive.Enabled == false)
            {
                cmbAreaActive.Enabled = true;
            }
            if (btnAddArea.Enabled == false)
            {
                btnAddArea.Enabled = true;
            }
            if (btnSaveArea.Text == "Update Area")
            {
                btnSaveArea.Text = "Save Area";
            }

            if (cmbSelectZoneForArea.Enabled == false)
            {
                cmbSelectZoneForArea.Enabled = true;
            }

            if (txtCellNoForArea.Enabled == false)
            {
                txtCellNoForArea.Enabled = true;
            }
            ClearArea();
            txtAreaName.Focus();
        }

        private void btnRefreshArea_Click(object sender, EventArgs e)
        {
            RefreshArea();
        }

        private void btnSaveArea_Click(object sender, EventArgs e)
        {
            if (txtAreaName.Text == "")
            {
                MessageBox.Show("Area Name can't be blank.");
                txtAreaName.Focus();
            }
            else if (cmbSelectDesignationForArea.Text == "Select Designation" || cmbSelectDesignationForArea.Text == "")
            {
                MessageBox.Show("Please select Designation.");
                cmbSelectDesignationForArea.Focus();
            }
            else if (cmbSelectEmployeeForArea.Text == "Select Employee" || cmbSelectEmployeeForArea.Text == "")
            {
                MessageBox.Show("Please select Employee.");
                cmbSelectEmployeeForArea.Focus();
            }
            else if (txtAreaActivityStartDate.Text == "")
            {
                MessageBox.Show("Activity Start Date can't be blank.");
                txtAreaActivityStartDate.Focus();
            }
            else if (cmbAreaActive.Text == "Select Active" || cmbAreaActive.Text == "")
            {
                MessageBox.Show("Please select Active for Area.");
                cmbAreaActive.Focus();
            }
            else if (cmbAreaActive.Text == "No" && txtAreaActivityEndDate.Text == "")
            {
                MessageBox.Show("Activity End Date can't be blank.");
                txtAreaActivityEndDate.Focus();
            }
            else if (txtAreaActivityEndDate.Text != "" && txtAreaActivityStartDate.Text != "" &&
                     Convert.ToDateTime(txtAreaActivityEndDate.Text) <
                     Convert.ToDateTime(txtAreaActivityStartDate.Text))
            {
                MessageBox.Show("Activity End Date can't be small than Activity Start Date.");
                txtAreaActivityEndDate.Focus();
            }
            else if (cmbSelectZoneForArea.Text == "Select Area" || cmbSelectZoneForArea.Text == "" ||
                     txtZoneIDForArea.Text == "")
            {
                MessageBox.Show("Please select Zone.");
                cmbSelectZoneForArea.Focus();
            }
            else if (txtCellNoForArea.Text == "")
            {
                MessageBox.Show("Cell No can't be blank.");
                txtCellNoForArea.Focus();
            }
            else
            {
                areaName = txtAreaName.Text;
                empDesignationCode = cmbSelectDesignationForArea.Text;
                empName = cmbSelectEmployeeForArea.Text;
                areaActivityStartDate = txtAreaActivityStartDate.Text;
                areaActive = cmbAreaActive.Text;
                areaActivityEndDate = txtAreaActivityEndDate.Text;
                zoneIdForArea = Convert.ToInt16(txtZoneIDForArea.Text);
                zoneNameForArea = cmbSelectZoneForArea.Text;
                areaId = GlobalClass.AreaIdForUpdateArea;
                
                cellNoForArea = txtCellNoForArea.Text;
                checkCellNoFirstDigit = cellNoForArea.Substring(0, 1);
                if (checkCellNoFirstDigit == "0")
                {
                    cellNoForArea = cellNoForArea.Remove(0,1);
                    txtCellNoForArea.Text = cellNoForArea;
                }
                cellNoForArea = txtCellNoPrefixForArea.Text + txtCellNoForArea.Text;
                
                if (btnSaveArea.Text == "Save Area")
                {
                    if (objAreaDetailsManager.checkDuplicateCellNoForInsertArea(cellNoForArea) == 0)
                    {
                        objAreaDetailsManager.InsertArea(areaName,empDesignationCode,empName,cellNoForArea,areaActivityStartDate,areaActive,zoneIdForArea,zoneNameForArea);
                        btnAddArea.Enabled = true;
                        btnAddArea.Enabled = false;

                        MessageBox.Show("Area Added Succesfully");
                    }
                    else
                    {
                        MessageBox.Show("Cell Number already exist.");
                        txtCellNoForArea.Text = "";
                        txtCellNoForArea.Focus();
                        return;
                    }
                }
                else if (btnSaveArea.Text == "Update Area")
                {
                    if (GlobalClass.PreviousAreaName != txtAreaName.Text && GlobalClass.PreviousEmployeeNameForArea == cmbSelectEmployeeForArea.Text)
                    {
                        if (MessageBox.Show("Do you want to Update " + GlobalClass.PreviousAreaName + " as " + txtAreaName.Text + " ? All Previous Data and Records of " + GlobalClass.PreviousAreaName + " will be updated as " + txtAreaName.Text + " from now on.", "Save!", MessageBoxButtons.YesNo) == DialogResult.Yes)
                        {
                            UpdateArea();
                        }
                    }
                    else if (GlobalClass.PreviousAreaName == txtAreaName.Text && GlobalClass.PreviousEmployeeNameForArea != cmbSelectEmployeeForArea.Text)
                    {
                        if (MessageBox.Show("Do you want to Update Employee of " + GlobalClass.PreviousAreaName + " ? All Data and Records of " + GlobalClass.PreviousEmployeeNameForArea + " for " + GlobalClass.PreviousAreaName + " will be Updated as " + cmbSelectEmployeeForArea.Text + " from now on.", "Save!", MessageBoxButtons.YesNo) == DialogResult.Yes)
                        {
                            UpdateArea();
                        }
                    }
                    else if (GlobalClass.PreviousAreaName != txtAreaName.Text && GlobalClass.PreviousEmployeeNameForArea != cmbSelectEmployeeForArea.Text)
                    {
                        if (MessageBox.Show("Do you want to Update " + GlobalClass.PreviousAreaName + " and Employee of " + GlobalClass.PreviousAreaName + " ? All Data and Records will be Updated as " + txtAreaName.Text + " and Employee for " + txtAreaName.Text + " as " + cmbSelectEmployeeForArea.Text + " from now on.", "Save!", MessageBoxButtons.YesNo) == DialogResult.Yes)
                        {
                            UpdateArea();
                        }
                    }
                    else if (GlobalClass.PreviousZoneNameForArea != cmbSelectZoneForArea.Text && GlobalClass.PreviousZoneIdForArea != Convert.ToInt16(txtZoneIDForArea.Text.ToString()))
                    {
                        if (MessageBox.Show("Do you want to Update " + GlobalClass.PreviousZoneNameForArea + " to " + cmbSelectZoneForArea.Text + " ? All Data and Records of " + GlobalClass.PreviousZoneNameForArea + " will be Updated as " + cmbSelectZoneForArea.Text + " from now on.", "Save!", MessageBoxButtons.YesNo) == DialogResult.Yes)
                        {
                            UpdateAreaByUpdatingZone();
                        }
                    }
                    else
                    {
                        UpdateArea();
                    }
                }
                RefreshArea();
            }
        }

        private void UpdateArea()
        {
            if (cmbAreaActive.Text == "No" && txtAreaActivityEndDate.Text != "")
            {
                //objZoneDetailsManager.UpdateZoneWithEndDate(zoneId, zoneName, empDesignationCode, empName, zoneActivityStartDate, zoneActivityEndDate, zoneActive, regionNameForZone, regionIdForZone);
                //objZoneDetailsManager.UpdateTeamDetailsWithEndDate(zoneId, zoneName, empDesignationCode, empName, zoneActivityStartDate, zoneActivityEndDate, zoneActive, regionNameForZone, regionIdForZone);
                //objZoneDetailsManager.UpdateRegionZone(zoneId, zoneName, empDesignationCode, empName, zoneActivityStartDate, zoneActivityEndDate, zoneActive, regionNameForZone, regionIdForZone);
                
                objAreaDetailsManager.UpdateAreaWithEndDate(areaId, areaName, empDesignationCode, empName, areaActivityStartDate, areaActivityEndDate, areaActive, zoneNameForArea, zoneIdForArea, cellNoForArea);
                objAreaDetailsManager.UpdateTeamDetailsWithEndDate(areaId, areaName, empDesignationCode, empName, areaActivityStartDate, areaActivityEndDate, areaActive, zoneNameForArea, zoneIdForArea);
                objAreaDetailsManager.UpdateZoneArea(areaId, areaName, empDesignationCode, empName, areaActivityStartDate, areaActivityEndDate, areaActive, zoneNameForArea, zoneIdForArea);
                btnAddArea.Enabled = true;
                btnSaveArea.Enabled = false;
                MessageBox.Show("Area Updated Succesfully");
            }
            else
            {
                //objZoneDetailsManager.UpdateZone(zoneId, zoneName, empDesignationCode, empName, zoneActivityStartDate, zoneActivityEndDate, zoneActive, regionNameForZone, regionIdForZone);
                //objZoneDetailsManager.UpdateTeamDetails(zoneId, zoneName, empDesignationCode, empName, zoneActivityStartDate, zoneActivityEndDate, zoneActive, regionNameForZone, regionIdForZone);
                //objZoneDetailsManager.UpdateRegionZone(zoneId, zoneName, empDesignationCode, empName, zoneActivityStartDate, zoneActivityEndDate, zoneActive, regionNameForZone, regionIdForZone);

                objAreaDetailsManager.UpdateArea(areaId, areaName, empDesignationCode, empName, areaActivityStartDate, areaActivityEndDate, areaActive, zoneNameForArea, zoneIdForArea, cellNoForArea);
                objAreaDetailsManager.UpdateTeamDetails(areaId, areaName, empDesignationCode, empName, areaActivityStartDate, areaActivityEndDate, areaActive, zoneNameForArea, zoneIdForArea);
                objAreaDetailsManager.UpdateZoneArea(areaId, areaName, empDesignationCode, empName, areaActivityStartDate, areaActivityEndDate, areaActive, zoneNameForArea, zoneIdForArea);
                btnAddArea.Enabled = true;
                btnSaveArea.Enabled = false;
                MessageBox.Show("Area Updated Succesfully");
            }
        }

        private void UpdateAreaByUpdatingZone()
        {
            UpdateArea();
            //objZoneDetailsManager.UpdateTeamDetailsByUpdateRegionName(zoneId, zoneName, empDesignationCode, empName, zoneActivityStartDate, zoneActivityEndDate, zoneActive, regionNameForZone, regionIdForZone);
            objAreaDetailsManager.UpdateTeamDetailsByUpdateZoneName(areaId, areaName, empDesignationCode, empName, areaActivityStartDate, areaActivityEndDate, areaActive, zoneNameForArea, zoneIdForArea);
        }

        private void cmbSelectDesignationForArea_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (btnSaveArea.Text == "Save Area")
            {
                if (cmbSelectDesignationForArea.Text != "Select Designation")
                {
                    cmbSelectEmployeeForArea.DataSource = objEmployeeDetailsManager.SearchEmployeeDesignation(cmbSelectDesignationForArea.Text.ToString());
                    cmbSelectEmployeeForArea.DisplayMember = "Employee_Name";
                    cmbSelectEmployeeForArea.ValueMember = "Employee_Name";
                    cmbSelectEmployeeForArea.Text = "Select Employee";
                }
            }
            else if (btnSaveArea.Text == "Update Area")
            {
                if (cmbSelectDesignationForArea.Text != "Select Designation")
                {
                    cmbSelectEmployeeForArea.DataSource = objEmployeeDetailsManager.SearchEmployeeDesignation(cmbSelectDesignationForArea.Text.ToString());
                    cmbSelectEmployeeForArea.DisplayMember = "Employee_Name";
                    cmbSelectEmployeeForArea.ValueMember = "Employee_Name";
                }
            }
        }

        private void cmbSelectDesignationForArea_SelectedValueChanged(object sender, EventArgs e)
        {
            if (btnSaveArea.Text == "Save Area")
            {
                if (cmbSelectDesignationForArea.Text != "Select Designation")
                {
                    cmbSelectEmployeeForArea.DataSource = objEmployeeDetailsManager.SearchEmployeeDesignation(cmbSelectDesignationForArea.Text.ToString());
                    cmbSelectEmployeeForArea.DisplayMember = "Employee_Name";
                    cmbSelectEmployeeForArea.ValueMember = "Employee_Name";
                    cmbSelectEmployeeForArea.Text = "Select Employee";
                }
            }
            else if (btnSaveArea.Text == "Update Area")
            {
                if (cmbSelectDesignationForArea.Text != "Select Designation")
                {
                    cmbSelectEmployeeForArea.DataSource = objEmployeeDetailsManager.SearchEmployeeDesignation(cmbSelectDesignationForArea.Text.ToString());
                    cmbSelectEmployeeForArea.DisplayMember = "Employee_Name";
                    cmbSelectEmployeeForArea.ValueMember = "Employee_Name";
                }
            }
        }

        private void dTPAreaActivityStartDate_CloseUp(object sender, EventArgs e)
        {
            txtAreaActivityStartDate.Text = dTPAreaActivityStartDate.Text.ToString();
            txtAreaActivityStartDate.Focus();
        }

        private void cmbAreaActive_SelectedValueChanged(object sender, EventArgs e)
        {
            if (cmbAreaActive.Text == "No")
            {
                txtAreaActivityEndDate.Enabled = true;
                dTPAreaActivityEndDate.Enabled = true;
                txtAreaActivityEndDate.Focus();
            }
            else if (cmbAreaActive.Text == "Yes")
            {
                txtAreaActivityEndDate.Text = "";
                txtAreaActivityEndDate.Enabled = false;
                dTPAreaActivityEndDate.Enabled = false;
            }
        }

        private void dTPAreaActivityEndDate_CloseUp(object sender, EventArgs e)
        {
            txtAreaActivityEndDate.Text = dTPAreaActivityEndDate.Text.ToString();
            txtAreaActivityEndDate.Focus();
        }

        private void cmbSelectZoneForArea_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtZoneIDForArea.Text = objZoneDetailsManager.GetZoneID(cmbSelectZoneForArea.Text); //objRegionDetailsManager.GetRegionID(cmbSelectRegionForZone.Text);
        }

        private void dataGridViewAreaDetails_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (btnSaveArea.Enabled == false)
            {
                btnSaveArea.Enabled = true;
            }
            btnSaveArea.Text = "Update Area";

            GlobalClass.AreaIdForUpdateArea = Convert.ToInt16(dataGridViewAreaDetails.CurrentRow.Cells[0].Value.ToString());
            GlobalClass.PreviousAreaName = dataGridViewAreaDetails.CurrentRow.Cells[1].Value.ToString();
            txtAreaName.Text = dataGridViewAreaDetails.CurrentRow.Cells[1].Value.ToString();
            cmbSelectDesignationForArea.Text = dataGridViewAreaDetails.CurrentRow.Cells[3].Value.ToString();
            GlobalClass.PreviousEmployeeNameForArea = dataGridViewAreaDetails.CurrentRow.Cells[2].Value.ToString();
            cmbSelectEmployeeForArea.Text = dataGridViewAreaDetails.CurrentRow.Cells[2].Value.ToString();

            retreiveCellNo = dataGridViewAreaDetails.CurrentRow.Cells[4].Value.ToString();
            retreiveCellNo = retreiveCellNo.Remove(0, 4);
            //MessageBox.Show(cellNoForArea);
            txtCellNoForArea.Text = retreiveCellNo;

            txtAreaActivityStartDate.Text = dataGridViewAreaDetails.CurrentRow.Cells[5].Value.ToString();
            txtAreaActivityStartDate.Text = txtAreaActivityStartDate.Text.Replace("12:00:00 AM", "");
            txtAreaActivityStartDate.Text = txtAreaActivityStartDate.Text.Trim();
            txtAreaActivityEndDate.Text = dataGridViewAreaDetails.CurrentRow.Cells[6].Value.ToString();

            if (txtAreaActivityEndDate.Text != "")
            {
                txtAreaActivityEndDate.Text = txtAreaActivityEndDate.Text.Replace("12:00:00 AM", "");
                txtAreaActivityEndDate.Text = txtAreaActivityEndDate.Text.Trim();
            }
            cmbAreaActive.Text = dataGridViewAreaDetails.CurrentRow.Cells[7].Value.ToString();
            cmbSelectZoneForArea.Text = dataGridViewAreaDetails.CurrentRow.Cells[8].Value.ToString();
            GlobalClass.PreviousZoneNameForArea = dataGridViewAreaDetails.CurrentRow.Cells[8].Value.ToString();
            txtZoneIDForArea.Text = dataGridViewAreaDetails.CurrentRow.Cells[9].Value.ToString();
            GlobalClass.PreviousZoneIdForArea = Convert.ToInt16(dataGridViewAreaDetails.CurrentRow.Cells[9].Value.ToString());

            if (txtAreaName.Enabled == false)
            {
                txtAreaName.Enabled = true;
            }
            if (cmbSelectDesignationForArea.Enabled == false)
            {
                cmbSelectDesignationForArea.Enabled = true;
            }
            if (cmbSelectEmployeeForArea.Enabled == false)
            {
                cmbSelectEmployeeForArea.Enabled = true;
            }
            if (txtAreaActivityStartDate.Enabled == false)
            {
                txtAreaActivityStartDate.Enabled = true;
            }
            if (dTPAreaActivityStartDate.Enabled == false)
            {
                dTPAreaActivityStartDate.Enabled = true;
            }
            if (txtAreaActivityEndDate.Text != "")
            {
                txtAreaActivityEndDate.Enabled = true;
                dTPAreaActivityEndDate.Enabled = true;
            }
            else
            {
                txtAreaActivityEndDate.Enabled = false;
                dTPAreaActivityEndDate.Enabled = false;
            }

            if (cmbAreaActive.Enabled == false)
            {
                cmbAreaActive.Enabled = true;
            }
            if (cmbSelectZoneForArea.Enabled == false)
            {
                cmbSelectZoneForArea.Enabled = true;
            }

            if (btnAddArea.Enabled == false)
            {
                btnAddArea.Enabled = true;
            }

            if (btnSaveArea.Text == "Save Area")
            {
                btnSaveArea.Text = "Update Area";
            }

            if (txtCellNoForArea.Enabled == false)
            {
                txtCellNoForArea.Enabled = true;
            }
        }
    }
}
