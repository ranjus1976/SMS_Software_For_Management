﻿namespace SMSapplication.UI
{
    partial class TeamUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TeamUI));
            this.groupBoxGroup = new System.Windows.Forms.GroupBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnRefreshTeam = new System.Windows.Forms.Button();
            this.btnTeamReport = new System.Windows.Forms.Button();
            this.txtTeamActivityEndDate = new System.Windows.Forms.TextBox();
            this.btnSaveTeam = new System.Windows.Forms.Button();
            this.btnAddTeam = new System.Windows.Forms.Button();
            this.dTPTeamActivityEndDate = new System.Windows.Forms.DateTimePicker();
            this.lblTeamActivityEndDate = new System.Windows.Forms.Label();
            this.txtTeamActivityStartDate = new System.Windows.Forms.TextBox();
            this.dTPTeamActivityStartDate = new System.Windows.Forms.DateTimePicker();
            this.cmbSelectEmployeeForTeam = new System.Windows.Forms.ComboBox();
            this.lblSelectEmployeeForTeam = new System.Windows.Forms.Label();
            this.cmbSelectDesignationForTeam = new System.Windows.Forms.ComboBox();
            this.lblTeamActivityStartDate = new System.Windows.Forms.Label();
            this.cmbTeamActive = new System.Windows.Forms.ComboBox();
            this.lblGroupActive = new System.Windows.Forms.Label();
            this.txtTeamName = new System.Windows.Forms.TextBox();
            this.lblSelectDesignation = new System.Windows.Forms.Label();
            this.lblTeamName = new System.Windows.Forms.Label();
            this.dataGridViewTeamDetails = new System.Windows.Forms.DataGridView();
            this.groupBoxGroup.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTeamDetails)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBoxGroup
            // 
            this.groupBoxGroup.Controls.Add(this.btnClose);
            this.groupBoxGroup.Controls.Add(this.btnRefreshTeam);
            this.groupBoxGroup.Controls.Add(this.btnTeamReport);
            this.groupBoxGroup.Controls.Add(this.txtTeamActivityEndDate);
            this.groupBoxGroup.Controls.Add(this.btnSaveTeam);
            this.groupBoxGroup.Controls.Add(this.btnAddTeam);
            this.groupBoxGroup.Controls.Add(this.dTPTeamActivityEndDate);
            this.groupBoxGroup.Controls.Add(this.lblTeamActivityEndDate);
            this.groupBoxGroup.Controls.Add(this.txtTeamActivityStartDate);
            this.groupBoxGroup.Controls.Add(this.dTPTeamActivityStartDate);
            this.groupBoxGroup.Controls.Add(this.cmbSelectEmployeeForTeam);
            this.groupBoxGroup.Controls.Add(this.lblSelectEmployeeForTeam);
            this.groupBoxGroup.Controls.Add(this.cmbSelectDesignationForTeam);
            this.groupBoxGroup.Controls.Add(this.lblTeamActivityStartDate);
            this.groupBoxGroup.Controls.Add(this.cmbTeamActive);
            this.groupBoxGroup.Controls.Add(this.lblGroupActive);
            this.groupBoxGroup.Controls.Add(this.txtTeamName);
            this.groupBoxGroup.Controls.Add(this.lblSelectDesignation);
            this.groupBoxGroup.Controls.Add(this.lblTeamName);
            this.groupBoxGroup.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxGroup.Location = new System.Drawing.Point(6, 0);
            this.groupBoxGroup.Name = "groupBoxGroup";
            this.groupBoxGroup.Size = new System.Drawing.Size(822, 157);
            this.groupBoxGroup.TabIndex = 11;
            this.groupBoxGroup.TabStop = false;
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Location = new System.Drawing.Point(657, 120);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(160, 25);
            this.btnClose.TabIndex = 68;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnRefreshTeam
            // 
            this.btnRefreshTeam.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefreshTeam.Location = new System.Drawing.Point(494, 120);
            this.btnRefreshTeam.Name = "btnRefreshTeam";
            this.btnRefreshTeam.Size = new System.Drawing.Size(160, 25);
            this.btnRefreshTeam.TabIndex = 9;
            this.btnRefreshTeam.Text = "Refresh";
            this.btnRefreshTeam.UseVisualStyleBackColor = true;
            this.btnRefreshTeam.Click += new System.EventHandler(this.btnRefreshTeam_Click);
            // 
            // btnTeamReport
            // 
            this.btnTeamReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTeamReport.Location = new System.Drawing.Point(331, 120);
            this.btnTeamReport.Name = "btnTeamReport";
            this.btnTeamReport.Size = new System.Drawing.Size(160, 25);
            this.btnTeamReport.TabIndex = 8;
            this.btnTeamReport.Text = "Team Report";
            this.btnTeamReport.UseVisualStyleBackColor = true;
            // 
            // txtTeamActivityEndDate
            // 
            this.txtTeamActivityEndDate.Enabled = false;
            this.txtTeamActivityEndDate.Location = new System.Drawing.Point(572, 87);
            this.txtTeamActivityEndDate.Name = "txtTeamActivityEndDate";
            this.txtTeamActivityEndDate.Size = new System.Drawing.Size(225, 22);
            this.txtTeamActivityEndDate.TabIndex = 6;
            // 
            // btnSaveTeam
            // 
            this.btnSaveTeam.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveTeam.Location = new System.Drawing.Point(168, 120);
            this.btnSaveTeam.Name = "btnSaveTeam";
            this.btnSaveTeam.Size = new System.Drawing.Size(160, 25);
            this.btnSaveTeam.TabIndex = 7;
            this.btnSaveTeam.Text = "Save Team";
            this.btnSaveTeam.UseVisualStyleBackColor = true;
            this.btnSaveTeam.Click += new System.EventHandler(this.btnSaveTeam_Click);
            // 
            // btnAddTeam
            // 
            this.btnAddTeam.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddTeam.Location = new System.Drawing.Point(5, 120);
            this.btnAddTeam.Name = "btnAddTeam";
            this.btnAddTeam.Size = new System.Drawing.Size(160, 25);
            this.btnAddTeam.TabIndex = 0;
            this.btnAddTeam.Text = "Add Team";
            this.btnAddTeam.UseVisualStyleBackColor = true;
            this.btnAddTeam.Click += new System.EventHandler(this.btnAddTeam_Click);
            // 
            // dTPTeamActivityEndDate
            // 
            this.dTPTeamActivityEndDate.Enabled = false;
            this.dTPTeamActivityEndDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dTPTeamActivityEndDate.Location = new System.Drawing.Point(797, 87);
            this.dTPTeamActivityEndDate.Name = "dTPTeamActivityEndDate";
            this.dTPTeamActivityEndDate.Size = new System.Drawing.Size(16, 22);
            this.dTPTeamActivityEndDate.TabIndex = 67;
            this.dTPTeamActivityEndDate.CloseUp += new System.EventHandler(this.dTPTeamActivityEndDate_CloseUp);
            //this.dTPTeamActivityEndDate.ValueChanged += new System.EventHandler(this.dTPTeamActivityEndDate_ValueChanged);
            // 
            // lblTeamActivityEndDate
            // 
            this.lblTeamActivityEndDate.AutoSize = true;
            this.lblTeamActivityEndDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeamActivityEndDate.Location = new System.Drawing.Point(433, 90);
            this.lblTeamActivityEndDate.Name = "lblTeamActivityEndDate";
            this.lblTeamActivityEndDate.Size = new System.Drawing.Size(134, 16);
            this.lblTeamActivityEndDate.TabIndex = 65;
            this.lblTeamActivityEndDate.Text = "Activity End Date :";
            // 
            // txtTeamActivityStartDate
            // 
            this.txtTeamActivityStartDate.Enabled = false;
            this.txtTeamActivityStartDate.Location = new System.Drawing.Point(572, 27);
            this.txtTeamActivityStartDate.Name = "txtTeamActivityStartDate";
            this.txtTeamActivityStartDate.Size = new System.Drawing.Size(225, 22);
            this.txtTeamActivityStartDate.TabIndex = 4;
            // 
            // dTPTeamActivityStartDate
            // 
            this.dTPTeamActivityStartDate.Enabled = false;
            this.dTPTeamActivityStartDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dTPTeamActivityStartDate.Location = new System.Drawing.Point(797, 27);
            this.dTPTeamActivityStartDate.Name = "dTPTeamActivityStartDate";
            this.dTPTeamActivityStartDate.Size = new System.Drawing.Size(16, 22);
            this.dTPTeamActivityStartDate.TabIndex = 64;
            this.dTPTeamActivityStartDate.CloseUp += new System.EventHandler(this.dTPTeamActivityStartDate_CloseUp);
            // 
            // cmbSelectEmployeeForTeam
            // 
            this.cmbSelectEmployeeForTeam.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSelectEmployeeForTeam.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectEmployeeForTeam.Enabled = false;
            this.cmbSelectEmployeeForTeam.FormattingEnabled = true;
            this.cmbSelectEmployeeForTeam.Location = new System.Drawing.Point(151, 87);
            this.cmbSelectEmployeeForTeam.Name = "cmbSelectEmployeeForTeam";
            this.cmbSelectEmployeeForTeam.Size = new System.Drawing.Size(240, 24);
            this.cmbSelectEmployeeForTeam.TabIndex = 3;
            this.cmbSelectEmployeeForTeam.Text = "Select Employee";
            // 
            // lblSelectEmployeeForTeam
            // 
            this.lblSelectEmployeeForTeam.AutoSize = true;
            this.lblSelectEmployeeForTeam.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectEmployeeForTeam.Location = new System.Drawing.Point(4, 90);
            this.lblSelectEmployeeForTeam.Name = "lblSelectEmployeeForTeam";
            this.lblSelectEmployeeForTeam.Size = new System.Drawing.Size(134, 16);
            this.lblSelectEmployeeForTeam.TabIndex = 62;
            this.lblSelectEmployeeForTeam.Text = "Select Employee :";
            // 
            // cmbSelectDesignationForTeam
            // 
            this.cmbSelectDesignationForTeam.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSelectDesignationForTeam.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectDesignationForTeam.Enabled = false;
            this.cmbSelectDesignationForTeam.FormattingEnabled = true;
            this.cmbSelectDesignationForTeam.Location = new System.Drawing.Point(151, 57);
            this.cmbSelectDesignationForTeam.Name = "cmbSelectDesignationForTeam";
            this.cmbSelectDesignationForTeam.Size = new System.Drawing.Size(240, 24);
            this.cmbSelectDesignationForTeam.TabIndex = 2;
            this.cmbSelectDesignationForTeam.Text = "Select Designation";
            this.cmbSelectDesignationForTeam.SelectedIndexChanged += new System.EventHandler(this.cmbSelectDesignationForTeam_SelectedIndexChanged);
            this.cmbSelectDesignationForTeam.SelectedValueChanged += new System.EventHandler(this.cmbSelectDesignationForTeam_SelectedValueChanged);
            // 
            // lblTeamActivityStartDate
            // 
            this.lblTeamActivityStartDate.AutoSize = true;
            this.lblTeamActivityStartDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeamActivityStartDate.Location = new System.Drawing.Point(433, 30);
            this.lblTeamActivityStartDate.Name = "lblTeamActivityStartDate";
            this.lblTeamActivityStartDate.Size = new System.Drawing.Size(139, 16);
            this.lblTeamActivityStartDate.TabIndex = 59;
            this.lblTeamActivityStartDate.Text = "Activity Start Date :";
            // 
            // cmbTeamActive
            // 
            this.cmbTeamActive.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbTeamActive.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbTeamActive.Enabled = false;
            this.cmbTeamActive.FormattingEnabled = true;
            this.cmbTeamActive.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cmbTeamActive.Location = new System.Drawing.Point(572, 57);
            this.cmbTeamActive.Name = "cmbTeamActive";
            this.cmbTeamActive.Size = new System.Drawing.Size(240, 24);
            this.cmbTeamActive.TabIndex = 5;
            this.cmbTeamActive.Text = "Select Active";
            this.cmbTeamActive.SelectedValueChanged += new System.EventHandler(this.cmbTeamActive_SelectedValueChanged_1);
            // 
            // lblGroupActive
            // 
            this.lblGroupActive.AutoSize = true;
            this.lblGroupActive.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGroupActive.Location = new System.Drawing.Point(433, 60);
            this.lblGroupActive.Name = "lblGroupActive";
            this.lblGroupActive.Size = new System.Drawing.Size(59, 16);
            this.lblGroupActive.TabIndex = 11;
            this.lblGroupActive.Text = "Active :";
            // 
            // txtTeamName
            // 
            this.txtTeamName.Enabled = false;
            this.txtTeamName.Location = new System.Drawing.Point(151, 27);
            this.txtTeamName.Name = "txtTeamName";
            this.txtTeamName.Size = new System.Drawing.Size(240, 22);
            this.txtTeamName.TabIndex = 1;
            // 
            // lblSelectDesignation
            // 
            this.lblSelectDesignation.AutoSize = true;
            this.lblSelectDesignation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectDesignation.Location = new System.Drawing.Point(4, 60);
            this.lblSelectDesignation.Name = "lblSelectDesignation";
            this.lblSelectDesignation.Size = new System.Drawing.Size(147, 16);
            this.lblSelectDesignation.TabIndex = 1;
            this.lblSelectDesignation.Text = "Select Designation :";
            // 
            // lblTeamName
            // 
            this.lblTeamName.AutoSize = true;
            this.lblTeamName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeamName.Location = new System.Drawing.Point(4, 30);
            this.lblTeamName.Name = "lblTeamName";
            this.lblTeamName.Size = new System.Drawing.Size(101, 16);
            this.lblTeamName.TabIndex = 0;
            this.lblTeamName.Text = "Team Name :";
            // 
            // dataGridViewTeamDetails
            // 
            this.dataGridViewTeamDetails.AllowUserToAddRows = false;
            this.dataGridViewTeamDetails.AllowUserToDeleteRows = false;
            this.dataGridViewTeamDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewTeamDetails.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridViewTeamDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewTeamDetails.Location = new System.Drawing.Point(6, 163);
            this.dataGridViewTeamDetails.MultiSelect = false;
            this.dataGridViewTeamDetails.Name = "dataGridViewTeamDetails";
            this.dataGridViewTeamDetails.ReadOnly = true;
            this.dataGridViewTeamDetails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewTeamDetails.Size = new System.Drawing.Size(822, 370);
            this.dataGridViewTeamDetails.TabIndex = 12;
            this.dataGridViewTeamDetails.TabStop = false;
            this.dataGridViewTeamDetails.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewTeamDetails_CellDoubleClick);
            // 
            // TeamUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(834, 537);
            this.Controls.Add(this.dataGridViewTeamDetails);
            this.Controls.Add(this.groupBoxGroup);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "TeamUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add / Edit Team";
            this.Load += new System.EventHandler(this.TeamUI_Load);
            this.groupBoxGroup.ResumeLayout(false);
            this.groupBoxGroup.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTeamDetails)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxGroup;
        private System.Windows.Forms.Label lblTeamActivityStartDate;
        private System.Windows.Forms.ComboBox cmbTeamActive;
        private System.Windows.Forms.Label lblGroupActive;
        private System.Windows.Forms.TextBox txtTeamName;
        private System.Windows.Forms.Label lblSelectDesignation;
        private System.Windows.Forms.Label lblTeamName;
        private System.Windows.Forms.ComboBox cmbSelectEmployeeForTeam;
        private System.Windows.Forms.Label lblSelectEmployeeForTeam;
        private System.Windows.Forms.ComboBox cmbSelectDesignationForTeam;
        private System.Windows.Forms.TextBox txtTeamActivityEndDate;
        private System.Windows.Forms.DateTimePicker dTPTeamActivityEndDate;
        private System.Windows.Forms.Label lblTeamActivityEndDate;
        private System.Windows.Forms.TextBox txtTeamActivityStartDate;
        private System.Windows.Forms.DateTimePicker dTPTeamActivityStartDate;
        private System.Windows.Forms.Button btnRefreshTeam;
        private System.Windows.Forms.Button btnTeamReport;
        private System.Windows.Forms.Button btnSaveTeam;
        private System.Windows.Forms.Button btnAddTeam;
        private System.Windows.Forms.DataGridView dataGridViewTeamDetails;
        private System.Windows.Forms.Button btnClose;
    }
}