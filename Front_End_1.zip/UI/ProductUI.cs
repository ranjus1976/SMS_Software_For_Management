﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using SMSapplication.BLL;
using SMSapplication.DAL;
using SMSapplication.DAL.DAO;
using SMSapplication.DAL.Gateway;
using SMSapplication.UI;

namespace SMSapplication.UI
{
    public partial class ProductUI : Form
    {
        ProductDetailsManager objProductDetailsManager = new ProductDetailsManager();
        public DateTime now = DateTime.Now;
        public ProductUI()
        {
            InitializeComponent();
            RefreshProduct();
        }

        private void ProductUI_Load(object sender, EventArgs e)
        {
            RefreshProduct();
        }

        public void ClearProductTab()
        {
            txtProductCode.Text = "";
            txtProductName.Text = "";
            cmbPackSize.Text = "Select Pack Size";
            txtUnitCostPrice.Text = "";
            txtUnitSalePrice.Text = "";
            cmbProductActive.Text = "Select Active";
            //btnAddProduct.Focus();
            //txtProductCode.Focus();
        }

        private void RefreshProduct()
        {
            ClearProductTab();

            if (txtProductCode.Enabled == true)
            {
                txtProductCode.Enabled = false;
            }

            if (txtProductName.Enabled == true)
            {
                txtProductName.Enabled = false;
            }

            if (cmbPackSize.Enabled == true)
            {
                cmbPackSize.Enabled = false;
            }

            if (txtUnitCostPrice.Enabled == true)
            {
                txtUnitCostPrice.Enabled = false;
            }

            if (txtUnitSalePrice.Enabled == true)
            {
                txtUnitSalePrice.Enabled = false;
            }

            if (cmbProductActive.Enabled == true)
            {
                cmbProductActive.Enabled = false;
            }

            if (btnSaveProduct.Text == "Update Product")
            {
                btnSaveProduct.Text = "Save Product";
            }

            if (btnSaveProduct.Enabled == true)
            {
                btnSaveProduct.Enabled = false;
            }

            if (btnAddProduct.Enabled == false)
            {
                btnAddProduct.Enabled = true;
            }

            dataGridViewProduct.DataSource = objProductDetailsManager.ShowAllProduct();
            DataGridViewProductHeaderText();
            
            btnAddProduct.Focus();
        }

        public void DataGridViewProductHeaderText()
        {
            dataGridViewProduct.Columns[0].HeaderText = "Product ID";
            dataGridViewProduct.Columns[1].HeaderText = "Product Code";
            dataGridViewProduct.Columns[2].HeaderText = "Product Name";
            dataGridViewProduct.Columns[3].HeaderText = "Pack Size";
            dataGridViewProduct.Columns[4].HeaderText = "Cost Price";
            dataGridViewProduct.Columns[5].HeaderText = "Sale Price";
        }

        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            ClearProductTab();

            if (txtProductCode.Enabled == false)
            {
                txtProductCode.Enabled = true;
            }

            if (txtProductName.Enabled == false)
            {
                txtProductName.Enabled = true;
            }

            if (cmbPackSize.Enabled == false)
            {
                cmbPackSize.Enabled = true;
            }

            if (txtUnitCostPrice.Enabled == false)
            {
                txtUnitCostPrice.Enabled = true;
            }

            if (txtUnitSalePrice.Enabled == false)
            {
                txtUnitSalePrice.Enabled = true;
            }

            if (cmbProductActive.Enabled == false)
            {
                cmbProductActive.Enabled = true;
            }

            if (btnSaveProduct.Text == "Update Product")
            {
                btnSaveProduct.Text = "Save Product";
            }

            if (btnSaveProduct.Enabled == false)
            {
                btnSaveProduct.Enabled = true;
            }

            if (btnAddProduct.Enabled == false)
            {
                btnAddProduct.Enabled = true;
            }
            txtProductCode.Focus();
        }

        private void btnSaveProduct_Click(object sender, EventArgs e)
        {
            int productID;
            string productCode;
            string productName;
            string packSize;
            decimal unitCostPrice = 0;
            decimal unitSalePrice = 0;
            string productActive;

            //for ProductPriceUpdateLog
            string today;
            today = now.ToShortDateString().ToString();//Convert.ToString(now.ToShortTimeString().Substring(0,2));
            int productIDForProductPriceLog;
            int productPriceUpdateLogID;
            //today = today.Replace()
            //txtEndTime.Text = txtEndTime.Text.Replace(':', ' ');
            //End of for ProductPriceUpdateLog
            productCode = txtProductCode.Text;
            productName = txtProductName.Text;
            packSize = cmbPackSize.Text;
            
            if (txtUnitCostPrice.Text != "")
            {
                unitCostPrice = Convert.ToDecimal(txtUnitCostPrice.Text);
            }
            
            if (txtUnitSalePrice.Text != "")
            {
                unitSalePrice = Convert.ToDecimal(txtUnitSalePrice.Text);
            }
            
            productActive = cmbProductActive.Text;

            if (txtProductCode.Text == "")
            {
                MessageBox.Show("Product Code can't be blank.");
                txtProductCode.Focus();
            }
            else if (txtProductName.Text == "")
            {
                MessageBox.Show("Product Name can't be blank.");
                txtProductName.Focus();
            }
            else if (cmbPackSize.Text == "" || cmbPackSize.Text == "")
            {
                MessageBox.Show("Please select Pack Size.");
                cmbPackSize.Focus();
            }
            else if (txtUnitCostPrice.Text == "" || txtUnitCostPrice.Text == "0.00" || txtUnitCostPrice.Text == "00.00" || txtUnitCostPrice.Text == "0.0" || txtUnitCostPrice.Text == "0")
            {
                MessageBox.Show("Unit Cost Price can't be blank or 0.");
                txtUnitCostPrice.Focus();
            }
            else if (txtUnitSalePrice.Text == "" || txtUnitSalePrice.Text == "0.00" || txtUnitSalePrice.Text == "00.00" || txtUnitSalePrice.Text == "0.0" || txtUnitSalePrice.Text == "0")
            {
                MessageBox.Show("Unit Sales Price can't be blank or 0.");
                txtUnitSalePrice.Focus();
            }
            else if (cmbProductActive.Text == "" || cmbProductActive.Text == "Select Active")
            {
                MessageBox.Show("Product Activation can't be blank.");
                cmbProductActive.Focus();
            }
            else
            {
                if (btnSaveProduct.Text == "Save Product")
                {
                    objProductDetailsManager.InsertProduct(productCode, productName, packSize, unitCostPrice, unitSalePrice, productActive);
                    productIDForProductPriceLog = objProductDetailsManager.GetProductID(productCode);
                    objProductDetailsManager.InsertProductPriceUpdateLog(productIDForProductPriceLog, productCode, productName, packSize, unitCostPrice, unitSalePrice, today, productActive);
                    dataGridViewProduct.DataSource = objProductDetailsManager.ShowAllProduct();
                    //dataGridViewProduct.Columns[0].Visible = false;
                    btnSaveProduct.Text = "Save Product";
                    btnAddProduct.Enabled = true;
                    MessageBox.Show("Product Added Succesfully");
                    RefreshProduct();
                }
                else if (btnSaveProduct.Text == "Update Product")
                {
                    if (GlobalClass.CurrCostPrice != unitCostPrice ||
                        GlobalClass.CurrSalePrice != unitSalePrice)
                    {
                        productID = Convert.ToInt32(GlobalClass.ProductIdForUpdateProduct.ToString());
                        productPriceUpdateLogID = objProductDetailsManager.GetProductPriceUpdateLogID(productID);
                        objProductDetailsManager.UpdateProductPriceUpdateLog(productPriceUpdateLogID, today); //, productCode, productName, packSize, unitCostPrice, unitSalePrice, today);
                        objProductDetailsManager.InsertProductPriceUpdateLog(productID, productCode, productName, packSize, unitCostPrice, unitSalePrice, today, productActive);
                        objProductDetailsManager.UpdateProduct(productID, productCode, productName, packSize, unitCostPrice, unitSalePrice, productActive);
                    }
                    else
                    {
                        productID = Convert.ToInt32(GlobalClass.ProductIdForUpdateProduct.ToString());
                        productPriceUpdateLogID = objProductDetailsManager.GetProductPriceUpdateLogID(productID);
                        objProductDetailsManager.UpdateProduct(productID, productCode, productName, packSize, unitCostPrice, unitSalePrice, productActive);
                        objProductDetailsManager.UpdateProductPriceUpdateLogData(productPriceUpdateLogID, productID, productCode, productName, packSize, unitCostPrice, unitSalePrice, productActive);
                    }
                    dataGridViewProduct.DataSource = objProductDetailsManager.ShowAllProduct();
                    //dataGridViewProduct.Columns[0].Visible = false;
                    MessageBox.Show("Product Update Successfully.");
                    RefreshProduct();
                }

                //ClearProductTab();

                //if (txtProductCode.Enabled == true)
                //{
                //    txtProductCode.Enabled = false;
                //}

                //if (txtProductName.Enabled == true)
                //{
                //    txtProductName.Enabled = false;
                //}

                //if (cmbPackSize.Enabled == true)
                //{
                //    cmbPackSize.Enabled = false;
                //}

                //if (txtUnitCostPrice.Enabled == true)
                //{
                //    txtUnitCostPrice.Enabled = false;
                //}

                //if (txtUnitSalePrice.Enabled == true)
                //{
                //    txtUnitSalePrice.Enabled = false;
                //}

                //if (cmbProductActive.Enabled == true)
                //{
                //    cmbProductActive.Enabled = false;
                //}

                //if (btnSaveProduct.Text == "Update Product")
                //{
                //    btnSaveProduct.Text = "Save Product";
                //}

                //if (btnSaveProduct.Enabled == true)
                //{
                //    btnSaveProduct.Enabled = false;
                //}

                //if (btnAddProduct.Enabled == false)
                //{
                //    btnAddProduct.Enabled = true;
                //}

                //DataGridViewProductHeaderText();
            }
        }

        private void btnProductReport_Click(object sender, EventArgs e)
        {
            ProductReportUI objProductReportUi = new ProductReportUI();
            objProductReportUi.ShowDialog();
        }

        private void btnRefreshProduct_Click(object sender, EventArgs e)
        {
            RefreshProduct();
        }

        private void dataGridViewProduct_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (btnSaveProduct.Enabled == false)
            {
                btnSaveProduct.Enabled = true;
            }

            btnSaveProduct.Text = "Update Product";

            GlobalClass.ProductIdForUpdateProduct = dataGridViewProduct.CurrentRow.Cells[0].Value.ToString();
            //GlobalClass.DesignationIDforUpdateDesignation = dataGridViewDesignationList.CurrentRow.Cells[0].Value.ToString();
            txtProductCode.Text = dataGridViewProduct.CurrentRow.Cells[1].Value.ToString();
            txtProductName.Text = dataGridViewProduct.CurrentRow.Cells[2].Value.ToString();
            cmbPackSize.Text = dataGridViewProduct.CurrentRow.Cells[3].Value.ToString();
            txtUnitCostPrice.Text = dataGridViewProduct.CurrentRow.Cells[4].Value.ToString();
            txtUnitSalePrice.Text = dataGridViewProduct.CurrentRow.Cells[5].Value.ToString();
            cmbProductActive.Text = dataGridViewProduct.CurrentRow.Cells[6].Value.ToString();

            GlobalClass.ProductCode = dataGridViewProduct.CurrentRow.Cells[1].Value.ToString();
            GlobalClass.CurrCostPrice = Convert.ToDecimal(dataGridViewProduct.CurrentRow.Cells[4].Value.ToString());
            GlobalClass.CurrSalePrice = Convert.ToDecimal(dataGridViewProduct.CurrentRow.Cells[5].Value.ToString());

            if (txtProductCode.Enabled == false)
            {
                txtProductCode.Enabled = true;
            }

            if (txtProductName.Enabled == false)
            {
                txtProductName.Enabled = true;
            }

            if (cmbPackSize.Enabled == false)
            {
                cmbPackSize.Enabled = true;
            }

            if (txtUnitCostPrice.Enabled == false)
            {
                txtUnitCostPrice.Enabled = true;
            }

            if (txtUnitSalePrice.Enabled == false)
            {
                txtUnitSalePrice.Enabled = true;
            }

            if (cmbProductActive.Enabled == false)
            {
                cmbProductActive.Enabled = true;
            }

            if (btnSaveProduct.Enabled == false)
            {
                btnSaveProduct.Enabled = true;
            }

            if (btnAddProduct.Enabled == false)
            {
                btnAddProduct.Enabled = true;
            }
        }

        private void dataGridViewProduct_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (btnSaveProduct.Enabled == false)
            {
                btnSaveProduct.Enabled = true;
            }

            btnSaveProduct.Text = "Update Product";

            GlobalClass.ProductIdForUpdateProduct = dataGridViewProduct.CurrentRow.Cells[0].Value.ToString();
            //GlobalClass.DesignationIDforUpdateDesignation = dataGridViewDesignationList.CurrentRow.Cells[0].Value.ToString();
            txtProductCode.Text = dataGridViewProduct.CurrentRow.Cells[1].Value.ToString();
            txtProductName.Text = dataGridViewProduct.CurrentRow.Cells[2].Value.ToString();
            cmbPackSize.Text = dataGridViewProduct.CurrentRow.Cells[3].Value.ToString();
            txtUnitCostPrice.Text = dataGridViewProduct.CurrentRow.Cells[4].Value.ToString();
            txtUnitSalePrice.Text = dataGridViewProduct.CurrentRow.Cells[5].Value.ToString();
            cmbProductActive.Text = dataGridViewProduct.CurrentRow.Cells[6].Value.ToString();

            GlobalClass.ProductCode = dataGridViewProduct.CurrentRow.Cells[1].Value.ToString();
            GlobalClass.CurrCostPrice = Convert.ToDecimal(dataGridViewProduct.CurrentRow.Cells[4].Value.ToString());
            GlobalClass.CurrSalePrice = Convert.ToDecimal(dataGridViewProduct.CurrentRow.Cells[5].Value.ToString());

            if (txtProductCode.Enabled == false)
            {
                txtProductCode.Enabled = true;
            }

            if (txtProductName.Enabled == false)
            {
                txtProductName.Enabled = true;
            }

            if (cmbPackSize.Enabled == false)
            {
                cmbPackSize.Enabled = true;
            }

            if (txtUnitCostPrice.Enabled == false)
            {
                txtUnitCostPrice.Enabled = true;
            }

            if (txtUnitSalePrice.Enabled == false)
            {
                txtUnitSalePrice.Enabled = true;
            }

            if (cmbProductActive.Enabled == false)
            {
                cmbProductActive.Enabled = true;
            }

            if (btnSaveProduct.Enabled == false)
            {
                btnSaveProduct.Enabled = true;
            }

            if (btnAddProduct.Enabled == false)
            {
                btnAddProduct.Enabled = true;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
