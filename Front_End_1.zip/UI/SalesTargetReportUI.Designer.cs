﻿namespace SMSapplication.UI
{
    partial class SalesTargetReportUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SalesTargetReportUI));
            this.groupBoxSalestargetReportCriteria = new System.Windows.Forms.GroupBox();
            this.txtSearchDateTo = new System.Windows.Forms.TextBox();
            this.dtpSearchDateTo = new System.Windows.Forms.DateTimePicker();
            this.lblSearchDateTo = new System.Windows.Forms.Label();
            this.txtSearchDateFrom = new System.Windows.Forms.TextBox();
            this.dtpSearchDateFrom = new System.Windows.Forms.DateTimePicker();
            this.lblSearchDateFrom = new System.Windows.Forms.Label();
            this.cmbSelectGroupForSalesTarget = new System.Windows.Forms.ComboBox();
            this.lblSelectGroupForSalesTarget = new System.Windows.Forms.Label();
            this.cmbSelectDivisionForSalesTarget = new System.Windows.Forms.ComboBox();
            this.lblSelectDivisionForMarket = new System.Windows.Forms.Label();
            this.cmbSelectEmployeeForSalesTarget = new System.Windows.Forms.ComboBox();
            this.lblSelectEmployeeForSalesTarget = new System.Windows.Forms.Label();
            this.btnUserReport = new System.Windows.Forms.Button();
            this.groupBoxSalestargetReportCriteria.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxSalestargetReportCriteria
            // 
            this.groupBoxSalestargetReportCriteria.Controls.Add(this.btnUserReport);
            this.groupBoxSalestargetReportCriteria.Controls.Add(this.cmbSelectEmployeeForSalesTarget);
            this.groupBoxSalestargetReportCriteria.Controls.Add(this.lblSelectEmployeeForSalesTarget);
            this.groupBoxSalestargetReportCriteria.Controls.Add(this.cmbSelectDivisionForSalesTarget);
            this.groupBoxSalestargetReportCriteria.Controls.Add(this.lblSelectDivisionForMarket);
            this.groupBoxSalestargetReportCriteria.Controls.Add(this.cmbSelectGroupForSalesTarget);
            this.groupBoxSalestargetReportCriteria.Controls.Add(this.lblSelectGroupForSalesTarget);
            this.groupBoxSalestargetReportCriteria.Controls.Add(this.txtSearchDateTo);
            this.groupBoxSalestargetReportCriteria.Controls.Add(this.dtpSearchDateTo);
            this.groupBoxSalestargetReportCriteria.Controls.Add(this.lblSearchDateTo);
            this.groupBoxSalestargetReportCriteria.Controls.Add(this.txtSearchDateFrom);
            this.groupBoxSalestargetReportCriteria.Controls.Add(this.dtpSearchDateFrom);
            this.groupBoxSalestargetReportCriteria.Controls.Add(this.lblSearchDateFrom);
            this.groupBoxSalestargetReportCriteria.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxSalestargetReportCriteria.Location = new System.Drawing.Point(6, 0);
            this.groupBoxSalestargetReportCriteria.Name = "groupBoxSalestargetReportCriteria";
            this.groupBoxSalestargetReportCriteria.Size = new System.Drawing.Size(360, 181);
            this.groupBoxSalestargetReportCriteria.TabIndex = 53;
            this.groupBoxSalestargetReportCriteria.TabStop = false;
            this.groupBoxSalestargetReportCriteria.Text = "Sales Taget Report Criteria";
            // 
            // txtSearchDateTo
            // 
            this.txtSearchDateTo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearchDateTo.Location = new System.Drawing.Point(227, 22);
            this.txtSearchDateTo.Name = "txtSearchDateTo";
            this.txtSearchDateTo.Size = new System.Drawing.Size(108, 22);
            this.txtSearchDateTo.TabIndex = 79;
            // 
            // dtpSearchDateTo
            // 
            this.dtpSearchDateTo.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpSearchDateTo.Location = new System.Drawing.Point(335, 22);
            this.dtpSearchDateTo.Name = "dtpSearchDateTo";
            this.dtpSearchDateTo.Size = new System.Drawing.Size(16, 22);
            this.dtpSearchDateTo.TabIndex = 80;
            this.dtpSearchDateTo.CloseUp += new System.EventHandler(this.dtpSearchDateTo_CloseUp);
            // 
            // lblSearchDateTo
            // 
            this.lblSearchDateTo.AutoSize = true;
            this.lblSearchDateTo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchDateTo.Location = new System.Drawing.Point(193, 25);
            this.lblSearchDateTo.Name = "lblSearchDateTo";
            this.lblSearchDateTo.Size = new System.Drawing.Size(35, 16);
            this.lblSearchDateTo.TabIndex = 78;
            this.lblSearchDateTo.Text = "To :";
            // 
            // txtSearchDateFrom
            // 
            this.txtSearchDateFrom.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearchDateFrom.Location = new System.Drawing.Point(57, 22);
            this.txtSearchDateFrom.Name = "txtSearchDateFrom";
            this.txtSearchDateFrom.Size = new System.Drawing.Size(108, 22);
            this.txtSearchDateFrom.TabIndex = 76;
            // 
            // dtpSearchDateFrom
            // 
            this.dtpSearchDateFrom.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpSearchDateFrom.Location = new System.Drawing.Point(165, 22);
            this.dtpSearchDateFrom.Name = "dtpSearchDateFrom";
            this.dtpSearchDateFrom.Size = new System.Drawing.Size(16, 22);
            this.dtpSearchDateFrom.TabIndex = 77;
            this.dtpSearchDateFrom.CloseUp += new System.EventHandler(this.dtpSearchDateFrom_CloseUp);
            // 
            // lblSearchDateFrom
            // 
            this.lblSearchDateFrom.AutoSize = true;
            this.lblSearchDateFrom.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchDateFrom.Location = new System.Drawing.Point(8, 25);
            this.lblSearchDateFrom.Name = "lblSearchDateFrom";
            this.lblSearchDateFrom.Size = new System.Drawing.Size(51, 16);
            this.lblSearchDateFrom.TabIndex = 75;
            this.lblSearchDateFrom.Text = "From :";
            // 
            // cmbSelectGroupForSalesTarget
            // 
            this.cmbSelectGroupForSalesTarget.AllowDrop = true;
            this.cmbSelectGroupForSalesTarget.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSelectGroupForSalesTarget.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectGroupForSalesTarget.Enabled = false;
            this.cmbSelectGroupForSalesTarget.FormattingEnabled = true;
            this.cmbSelectGroupForSalesTarget.Location = new System.Drawing.Point(111, 52);
            this.cmbSelectGroupForSalesTarget.Name = "cmbSelectGroupForSalesTarget";
            this.cmbSelectGroupForSalesTarget.Size = new System.Drawing.Size(240, 24);
            this.cmbSelectGroupForSalesTarget.Sorted = true;
            this.cmbSelectGroupForSalesTarget.TabIndex = 81;
            this.cmbSelectGroupForSalesTarget.Text = "Select Team";
            this.cmbSelectGroupForSalesTarget.SelectedIndexChanged += new System.EventHandler(this.cmbSelectGroupForSalesTarget_SelectedIndexChanged);
            this.cmbSelectGroupForSalesTarget.SelectedValueChanged += new System.EventHandler(this.cmbSelectGroupForSalesTarget_SelectedValueChanged);
            // 
            // lblSelectGroupForSalesTarget
            // 
            this.lblSelectGroupForSalesTarget.AutoSize = true;
            this.lblSelectGroupForSalesTarget.Location = new System.Drawing.Point(7, 55);
            this.lblSelectGroupForSalesTarget.Name = "lblSelectGroupForSalesTarget";
            this.lblSelectGroupForSalesTarget.Size = new System.Drawing.Size(56, 16);
            this.lblSelectGroupForSalesTarget.TabIndex = 82;
            this.lblSelectGroupForSalesTarget.Text = "Team :";
            // 
            // cmbSelectDivisionForSalesTarget
            // 
            this.cmbSelectDivisionForSalesTarget.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSelectDivisionForSalesTarget.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectDivisionForSalesTarget.Enabled = false;
            this.cmbSelectDivisionForSalesTarget.FormattingEnabled = true;
            this.cmbSelectDivisionForSalesTarget.Location = new System.Drawing.Point(111, 82);
            this.cmbSelectDivisionForSalesTarget.Name = "cmbSelectDivisionForSalesTarget";
            this.cmbSelectDivisionForSalesTarget.Size = new System.Drawing.Size(240, 24);
            this.cmbSelectDivisionForSalesTarget.Sorted = true;
            this.cmbSelectDivisionForSalesTarget.TabIndex = 83;
            this.cmbSelectDivisionForSalesTarget.Text = "Select Division";
            this.cmbSelectDivisionForSalesTarget.SelectedIndexChanged += new System.EventHandler(this.cmbSelectDivisionForSalesTarget_SelectedIndexChanged);
            // 
            // lblSelectDivisionForMarket
            // 
            this.lblSelectDivisionForMarket.AutoSize = true;
            this.lblSelectDivisionForMarket.Location = new System.Drawing.Point(7, 85);
            this.lblSelectDivisionForMarket.Name = "lblSelectDivisionForMarket";
            this.lblSelectDivisionForMarket.Size = new System.Drawing.Size(72, 16);
            this.lblSelectDivisionForMarket.TabIndex = 84;
            this.lblSelectDivisionForMarket.Text = "Division :";
            // 
            // cmbSelectEmployeeForSalesTarget
            // 
            this.cmbSelectEmployeeForSalesTarget.AllowDrop = true;
            this.cmbSelectEmployeeForSalesTarget.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSelectEmployeeForSalesTarget.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectEmployeeForSalesTarget.Enabled = false;
            this.cmbSelectEmployeeForSalesTarget.FormattingEnabled = true;
            this.cmbSelectEmployeeForSalesTarget.Location = new System.Drawing.Point(111, 112);
            this.cmbSelectEmployeeForSalesTarget.Name = "cmbSelectEmployeeForSalesTarget";
            this.cmbSelectEmployeeForSalesTarget.Size = new System.Drawing.Size(240, 24);
            this.cmbSelectEmployeeForSalesTarget.Sorted = true;
            this.cmbSelectEmployeeForSalesTarget.TabIndex = 86;
            this.cmbSelectEmployeeForSalesTarget.Text = "Select Employee";
            this.cmbSelectEmployeeForSalesTarget.SelectedIndexChanged += new System.EventHandler(this.cmbSelectEmployeeForSalesTarget_SelectedIndexChanged);
            // 
            // lblSelectEmployeeForSalesTarget
            // 
            this.lblSelectEmployeeForSalesTarget.AutoSize = true;
            this.lblSelectEmployeeForSalesTarget.Location = new System.Drawing.Point(7, 115);
            this.lblSelectEmployeeForSalesTarget.Name = "lblSelectEmployeeForSalesTarget";
            this.lblSelectEmployeeForSalesTarget.Size = new System.Drawing.Size(86, 16);
            this.lblSelectEmployeeForSalesTarget.TabIndex = 85;
            this.lblSelectEmployeeForSalesTarget.Text = "Employee :";
            // 
            // btnUserReport
            // 
            this.btnUserReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUserReport.Location = new System.Drawing.Point(6, 145);
            this.btnUserReport.Name = "btnUserReport";
            this.btnUserReport.Size = new System.Drawing.Size(345, 25);
            this.btnUserReport.TabIndex = 87;
            this.btnUserReport.Text = "Report";
            this.btnUserReport.UseVisualStyleBackColor = true;
            this.btnUserReport.Click += new System.EventHandler(this.btnUserReport_Click);
            // 
            // SalesTargetReportUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(372, 185);
            this.Controls.Add(this.groupBoxSalestargetReportCriteria);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SalesTargetReportUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sales Target Report";
            this.Load += new System.EventHandler(this.SalesTargetReportUI_Load);
            this.groupBoxSalestargetReportCriteria.ResumeLayout(false);
            this.groupBoxSalestargetReportCriteria.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxSalestargetReportCriteria;
        private System.Windows.Forms.TextBox txtSearchDateTo;
        private System.Windows.Forms.DateTimePicker dtpSearchDateTo;
        private System.Windows.Forms.Label lblSearchDateTo;
        private System.Windows.Forms.TextBox txtSearchDateFrom;
        private System.Windows.Forms.DateTimePicker dtpSearchDateFrom;
        private System.Windows.Forms.Label lblSearchDateFrom;
        private System.Windows.Forms.ComboBox cmbSelectGroupForSalesTarget;
        private System.Windows.Forms.Label lblSelectGroupForSalesTarget;
        private System.Windows.Forms.ComboBox cmbSelectDivisionForSalesTarget;
        private System.Windows.Forms.Label lblSelectDivisionForMarket;
        private System.Windows.Forms.ComboBox cmbSelectEmployeeForSalesTarget;
        private System.Windows.Forms.Label lblSelectEmployeeForSalesTarget;
        private System.Windows.Forms.Button btnUserReport;
    }
}