﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using CrystalDecisions.Windows.Forms;
using SMSapplication.Reports;
using SMSapplication.BLL;
using SMSapplication.DAL.DAO;
using SMSapplication.DAL.Gateway;

namespace SMSapplication.UI
{
    public partial class UserReportUI : Form
    {
        UserDetailsGateway objUserDetailsGateway = new UserDetailsGateway();
        DataTable dt = new DataTable();
        DataTable tmpDt = new DataTable();
        
        public UserReportUI()
        {
            InitializeComponent();
        }

        private void btnUserReport_Click(object sender, EventArgs e)
        {
            try
            {
                string reportPath = Application.StartupPath + "\\Reports\\UserReport.rpt";
                if (radioButtonActiveUserForUserReport.Checked == true)
                {
                    dt = objUserDetailsGateway.GetActiveUser();
                }
                else if (radioButtonNonActiveUserForUserReport.Checked == true)
                {
                    dt = objUserDetailsGateway.GetNonActiveUser();
                }
                else if (radioButtonAllUserForUserReport.Checked == true)
                {
                    dt = objUserDetailsGateway.GetAllUser();
                }

                tmpDt = objUserDetailsGateway.GetTempData();

                ReportDocument reportDocument = new ReportDocument();
                ReportViewer objViewer = new ReportViewer();
                reportDocument.Load(reportPath);
                reportDocument.SetDataSource(tmpDt);
                objViewer.CrystalReportViewer1.ReportSource = reportDocument;
                objViewer.CrystalReportViewer1.Refresh();
                objViewer.ShowDialog();
                this.Close();
            }
            
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
