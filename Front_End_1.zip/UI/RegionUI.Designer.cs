﻿namespace SMSapplication.UI
{
    partial class RegionUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RegionUI));
            this.groupBoxGroup = new System.Windows.Forms.GroupBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.txtDivisionIDForRegion = new System.Windows.Forms.TextBox();
            this.lblDivisionIDForRegion = new System.Windows.Forms.Label();
            this.cmbSelectDivisionForRegion = new System.Windows.Forms.ComboBox();
            this.lblSelectDivisionForRegion = new System.Windows.Forms.Label();
            this.btnRefreshRegion = new System.Windows.Forms.Button();
            this.btnRegionReport = new System.Windows.Forms.Button();
            this.txtRegionActivityEndDate = new System.Windows.Forms.TextBox();
            this.btnSaveRegion = new System.Windows.Forms.Button();
            this.btnAddRegion = new System.Windows.Forms.Button();
            this.dTPRegionActivityEndDate = new System.Windows.Forms.DateTimePicker();
            this.lblTeamActivityEndDate = new System.Windows.Forms.Label();
            this.txtRegionActivityStartDate = new System.Windows.Forms.TextBox();
            this.dTPRegionActivityStartDate = new System.Windows.Forms.DateTimePicker();
            this.cmbSelectEmployeeForRegion = new System.Windows.Forms.ComboBox();
            this.lblSelectEmployeeForRegion = new System.Windows.Forms.Label();
            this.cmbSelectDesignationForRegion = new System.Windows.Forms.ComboBox();
            this.lblTeamActivityStartDate = new System.Windows.Forms.Label();
            this.cmbRegionActive = new System.Windows.Forms.ComboBox();
            this.lblGroupActive = new System.Windows.Forms.Label();
            this.txtRegionName = new System.Windows.Forms.TextBox();
            this.lblSelectDesignation = new System.Windows.Forms.Label();
            this.lblRegionName = new System.Windows.Forms.Label();
            this.dataGridViewRegionDetails = new System.Windows.Forms.DataGridView();
            this.chkTeam = new System.Windows.Forms.CheckBox();
            this.groupBoxGroup.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewRegionDetails)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBoxGroup
            // 
            this.groupBoxGroup.Controls.Add(this.chkTeam);
            this.groupBoxGroup.Controls.Add(this.btnClose);
            this.groupBoxGroup.Controls.Add(this.txtDivisionIDForRegion);
            this.groupBoxGroup.Controls.Add(this.lblDivisionIDForRegion);
            this.groupBoxGroup.Controls.Add(this.cmbSelectDivisionForRegion);
            this.groupBoxGroup.Controls.Add(this.lblSelectDivisionForRegion);
            this.groupBoxGroup.Controls.Add(this.btnRefreshRegion);
            this.groupBoxGroup.Controls.Add(this.btnRegionReport);
            this.groupBoxGroup.Controls.Add(this.txtRegionActivityEndDate);
            this.groupBoxGroup.Controls.Add(this.btnSaveRegion);
            this.groupBoxGroup.Controls.Add(this.btnAddRegion);
            this.groupBoxGroup.Controls.Add(this.dTPRegionActivityEndDate);
            this.groupBoxGroup.Controls.Add(this.lblTeamActivityEndDate);
            this.groupBoxGroup.Controls.Add(this.txtRegionActivityStartDate);
            this.groupBoxGroup.Controls.Add(this.dTPRegionActivityStartDate);
            this.groupBoxGroup.Controls.Add(this.cmbSelectEmployeeForRegion);
            this.groupBoxGroup.Controls.Add(this.lblSelectEmployeeForRegion);
            this.groupBoxGroup.Controls.Add(this.cmbSelectDesignationForRegion);
            this.groupBoxGroup.Controls.Add(this.lblTeamActivityStartDate);
            this.groupBoxGroup.Controls.Add(this.cmbRegionActive);
            this.groupBoxGroup.Controls.Add(this.lblGroupActive);
            this.groupBoxGroup.Controls.Add(this.txtRegionName);
            this.groupBoxGroup.Controls.Add(this.lblSelectDesignation);
            this.groupBoxGroup.Controls.Add(this.lblRegionName);
            this.groupBoxGroup.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxGroup.Location = new System.Drawing.Point(6, 0);
            this.groupBoxGroup.Name = "groupBoxGroup";
            this.groupBoxGroup.Size = new System.Drawing.Size(822, 208);
            this.groupBoxGroup.TabIndex = 13;
            this.groupBoxGroup.TabStop = false;
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Location = new System.Drawing.Point(657, 174);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(160, 25);
            this.btnClose.TabIndex = 11;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // txtDivisionIDForRegion
            // 
            this.txtDivisionIDForRegion.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtDivisionIDForRegion.Location = new System.Drawing.Point(573, 117);
            this.txtDivisionIDForRegion.Name = "txtDivisionIDForRegion";
            this.txtDivisionIDForRegion.ReadOnly = true;
            this.txtDivisionIDForRegion.Size = new System.Drawing.Size(240, 22);
            this.txtDivisionIDForRegion.TabIndex = 71;
            this.txtDivisionIDForRegion.TabStop = false;
            // 
            // lblDivisionIDForRegion
            // 
            this.lblDivisionIDForRegion.AutoSize = true;
            this.lblDivisionIDForRegion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDivisionIDForRegion.Location = new System.Drawing.Point(433, 120);
            this.lblDivisionIDForRegion.Name = "lblDivisionIDForRegion";
            this.lblDivisionIDForRegion.Size = new System.Drawing.Size(91, 16);
            this.lblDivisionIDForRegion.TabIndex = 70;
            this.lblDivisionIDForRegion.Text = "Division ID :";
            // 
            // cmbSelectDivisionForRegion
            // 
            this.cmbSelectDivisionForRegion.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSelectDivisionForRegion.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectDivisionForRegion.Enabled = false;
            this.cmbSelectDivisionForRegion.FormattingEnabled = true;
            this.cmbSelectDivisionForRegion.Location = new System.Drawing.Point(574, 87);
            this.cmbSelectDivisionForRegion.Name = "cmbSelectDivisionForRegion";
            this.cmbSelectDivisionForRegion.Size = new System.Drawing.Size(240, 24);
            this.cmbSelectDivisionForRegion.TabIndex = 7;
            this.cmbSelectDivisionForRegion.Text = "Select Division";
            this.cmbSelectDivisionForRegion.SelectedIndexChanged += new System.EventHandler(this.cmbSelectDivisionForRegion_SelectedIndexChanged);
            // 
            // lblSelectDivisionForRegion
            // 
            this.lblSelectDivisionForRegion.AutoSize = true;
            this.lblSelectDivisionForRegion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectDivisionForRegion.Location = new System.Drawing.Point(433, 90);
            this.lblSelectDivisionForRegion.Name = "lblSelectDivisionForRegion";
            this.lblSelectDivisionForRegion.Size = new System.Drawing.Size(120, 16);
            this.lblSelectDivisionForRegion.TabIndex = 68;
            this.lblSelectDivisionForRegion.Text = "Select Division :";
            // 
            // btnRefreshRegion
            // 
            this.btnRefreshRegion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefreshRegion.Location = new System.Drawing.Point(494, 174);
            this.btnRefreshRegion.Name = "btnRefreshRegion";
            this.btnRefreshRegion.Size = new System.Drawing.Size(160, 25);
            this.btnRefreshRegion.TabIndex = 10;
            this.btnRefreshRegion.Text = "Refresh";
            this.btnRefreshRegion.UseVisualStyleBackColor = true;
            this.btnRefreshRegion.Click += new System.EventHandler(this.btnRefreshRegion_Click);
            // 
            // btnRegionReport
            // 
            this.btnRegionReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegionReport.Location = new System.Drawing.Point(331, 174);
            this.btnRegionReport.Name = "btnRegionReport";
            this.btnRegionReport.Size = new System.Drawing.Size(160, 25);
            this.btnRegionReport.TabIndex = 9;
            this.btnRegionReport.Text = "Region Report";
            this.btnRegionReport.UseVisualStyleBackColor = true;
            // 
            // txtRegionActivityEndDate
            // 
            this.txtRegionActivityEndDate.Enabled = false;
            this.txtRegionActivityEndDate.Location = new System.Drawing.Point(573, 57);
            this.txtRegionActivityEndDate.Name = "txtRegionActivityEndDate";
            this.txtRegionActivityEndDate.Size = new System.Drawing.Size(225, 22);
            this.txtRegionActivityEndDate.TabIndex = 6;
            // 
            // btnSaveRegion
            // 
            this.btnSaveRegion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveRegion.Location = new System.Drawing.Point(168, 174);
            this.btnSaveRegion.Name = "btnSaveRegion";
            this.btnSaveRegion.Size = new System.Drawing.Size(160, 25);
            this.btnSaveRegion.TabIndex = 8;
            this.btnSaveRegion.Text = "Save Region";
            this.btnSaveRegion.UseVisualStyleBackColor = true;
            this.btnSaveRegion.Click += new System.EventHandler(this.btnSaveRegion_Click);
            // 
            // btnAddRegion
            // 
            this.btnAddRegion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddRegion.Location = new System.Drawing.Point(5, 174);
            this.btnAddRegion.Name = "btnAddRegion";
            this.btnAddRegion.Size = new System.Drawing.Size(160, 25);
            this.btnAddRegion.TabIndex = 0;
            this.btnAddRegion.Text = "Add Region";
            this.btnAddRegion.UseVisualStyleBackColor = true;
            this.btnAddRegion.Click += new System.EventHandler(this.btnAddRegion_Click);
            // 
            // dTPRegionActivityEndDate
            // 
            this.dTPRegionActivityEndDate.Enabled = false;
            this.dTPRegionActivityEndDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dTPRegionActivityEndDate.Location = new System.Drawing.Point(798, 57);
            this.dTPRegionActivityEndDate.Name = "dTPRegionActivityEndDate";
            this.dTPRegionActivityEndDate.Size = new System.Drawing.Size(16, 22);
            this.dTPRegionActivityEndDate.TabIndex = 67;
            this.dTPRegionActivityEndDate.CloseUp += new System.EventHandler(this.dTPRegionActivityEndDate_CloseUp);
            // 
            // lblTeamActivityEndDate
            // 
            this.lblTeamActivityEndDate.AutoSize = true;
            this.lblTeamActivityEndDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeamActivityEndDate.Location = new System.Drawing.Point(433, 60);
            this.lblTeamActivityEndDate.Name = "lblTeamActivityEndDate";
            this.lblTeamActivityEndDate.Size = new System.Drawing.Size(134, 16);
            this.lblTeamActivityEndDate.TabIndex = 65;
            this.lblTeamActivityEndDate.Text = "Activity End Date :";
            // 
            // txtRegionActivityStartDate
            // 
            this.txtRegionActivityStartDate.Enabled = false;
            this.txtRegionActivityStartDate.Location = new System.Drawing.Point(151, 117);
            this.txtRegionActivityStartDate.Name = "txtRegionActivityStartDate";
            this.txtRegionActivityStartDate.Size = new System.Drawing.Size(225, 22);
            this.txtRegionActivityStartDate.TabIndex = 4;
            // 
            // dTPRegionActivityStartDate
            // 
            this.dTPRegionActivityStartDate.Enabled = false;
            this.dTPRegionActivityStartDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dTPRegionActivityStartDate.Location = new System.Drawing.Point(376, 117);
            this.dTPRegionActivityStartDate.Name = "dTPRegionActivityStartDate";
            this.dTPRegionActivityStartDate.Size = new System.Drawing.Size(16, 22);
            this.dTPRegionActivityStartDate.TabIndex = 64;
            this.dTPRegionActivityStartDate.CloseUp += new System.EventHandler(this.dTPRegionActivityStartDate_CloseUp);
            // 
            // cmbSelectEmployeeForRegion
            // 
            this.cmbSelectEmployeeForRegion.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSelectEmployeeForRegion.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectEmployeeForRegion.Enabled = false;
            this.cmbSelectEmployeeForRegion.FormattingEnabled = true;
            this.cmbSelectEmployeeForRegion.Location = new System.Drawing.Point(151, 87);
            this.cmbSelectEmployeeForRegion.Name = "cmbSelectEmployeeForRegion";
            this.cmbSelectEmployeeForRegion.Size = new System.Drawing.Size(240, 24);
            this.cmbSelectEmployeeForRegion.TabIndex = 3;
            this.cmbSelectEmployeeForRegion.Text = "Select Employee";
            // 
            // lblSelectEmployeeForRegion
            // 
            this.lblSelectEmployeeForRegion.AutoSize = true;
            this.lblSelectEmployeeForRegion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectEmployeeForRegion.Location = new System.Drawing.Point(4, 90);
            this.lblSelectEmployeeForRegion.Name = "lblSelectEmployeeForRegion";
            this.lblSelectEmployeeForRegion.Size = new System.Drawing.Size(134, 16);
            this.lblSelectEmployeeForRegion.TabIndex = 62;
            this.lblSelectEmployeeForRegion.Text = "Select Employee :";
            // 
            // cmbSelectDesignationForRegion
            // 
            this.cmbSelectDesignationForRegion.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSelectDesignationForRegion.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectDesignationForRegion.Enabled = false;
            this.cmbSelectDesignationForRegion.FormattingEnabled = true;
            this.cmbSelectDesignationForRegion.Location = new System.Drawing.Point(151, 57);
            this.cmbSelectDesignationForRegion.Name = "cmbSelectDesignationForRegion";
            this.cmbSelectDesignationForRegion.Size = new System.Drawing.Size(240, 24);
            this.cmbSelectDesignationForRegion.TabIndex = 2;
            this.cmbSelectDesignationForRegion.Text = "Select Designation";
            this.cmbSelectDesignationForRegion.SelectedIndexChanged += new System.EventHandler(this.cmbSelectDesignationForRegion_SelectedIndexChanged);
            this.cmbSelectDesignationForRegion.SelectedValueChanged += new System.EventHandler(this.cmbSelectDesignationForRegion_SelectedValueChanged);
            // 
            // lblTeamActivityStartDate
            // 
            this.lblTeamActivityStartDate.AutoSize = true;
            this.lblTeamActivityStartDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeamActivityStartDate.Location = new System.Drawing.Point(4, 120);
            this.lblTeamActivityStartDate.Name = "lblTeamActivityStartDate";
            this.lblTeamActivityStartDate.Size = new System.Drawing.Size(139, 16);
            this.lblTeamActivityStartDate.TabIndex = 59;
            this.lblTeamActivityStartDate.Text = "Activity Start Date :";
            // 
            // cmbRegionActive
            // 
            this.cmbRegionActive.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbRegionActive.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbRegionActive.Enabled = false;
            this.cmbRegionActive.FormattingEnabled = true;
            this.cmbRegionActive.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cmbRegionActive.Location = new System.Drawing.Point(573, 27);
            this.cmbRegionActive.Name = "cmbRegionActive";
            this.cmbRegionActive.Size = new System.Drawing.Size(240, 24);
            this.cmbRegionActive.TabIndex = 5;
            this.cmbRegionActive.Text = "Select Active";
            this.cmbRegionActive.SelectedValueChanged += new System.EventHandler(this.cmbRegionActive_SelectedValueChanged);
            // 
            // lblGroupActive
            // 
            this.lblGroupActive.AutoSize = true;
            this.lblGroupActive.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGroupActive.Location = new System.Drawing.Point(433, 30);
            this.lblGroupActive.Name = "lblGroupActive";
            this.lblGroupActive.Size = new System.Drawing.Size(59, 16);
            this.lblGroupActive.TabIndex = 11;
            this.lblGroupActive.Text = "Active :";
            // 
            // txtRegionName
            // 
            this.txtRegionName.Enabled = false;
            this.txtRegionName.Location = new System.Drawing.Point(151, 27);
            this.txtRegionName.Name = "txtRegionName";
            this.txtRegionName.Size = new System.Drawing.Size(240, 22);
            this.txtRegionName.TabIndex = 1;
            // 
            // lblSelectDesignation
            // 
            this.lblSelectDesignation.AutoSize = true;
            this.lblSelectDesignation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectDesignation.Location = new System.Drawing.Point(4, 60);
            this.lblSelectDesignation.Name = "lblSelectDesignation";
            this.lblSelectDesignation.Size = new System.Drawing.Size(147, 16);
            this.lblSelectDesignation.TabIndex = 1;
            this.lblSelectDesignation.Text = "Select Designation :";
            // 
            // lblRegionName
            // 
            this.lblRegionName.AutoSize = true;
            this.lblRegionName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRegionName.Location = new System.Drawing.Point(4, 30);
            this.lblRegionName.Name = "lblRegionName";
            this.lblRegionName.Size = new System.Drawing.Size(111, 16);
            this.lblRegionName.TabIndex = 0;
            this.lblRegionName.Text = "Region Name :";
            // 
            // dataGridViewRegionDetails
            // 
            this.dataGridViewRegionDetails.AllowUserToAddRows = false;
            this.dataGridViewRegionDetails.AllowUserToDeleteRows = false;
            this.dataGridViewRegionDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewRegionDetails.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridViewRegionDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewRegionDetails.Location = new System.Drawing.Point(6, 213);
            this.dataGridViewRegionDetails.MultiSelect = false;
            this.dataGridViewRegionDetails.Name = "dataGridViewRegionDetails";
            this.dataGridViewRegionDetails.ReadOnly = true;
            this.dataGridViewRegionDetails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewRegionDetails.Size = new System.Drawing.Size(822, 320);
            this.dataGridViewRegionDetails.TabIndex = 14;
            this.dataGridViewRegionDetails.TabStop = false;
            this.dataGridViewRegionDetails.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewRegionDetails_CellDoubleClick);
            // 
            // chkTeam
            // 
            this.chkTeam.AutoSize = true;
            this.chkTeam.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkTeam.Location = new System.Drawing.Point(574, 148);
            this.chkTeam.Name = "chkTeam";
            this.chkTeam.Size = new System.Drawing.Size(67, 20);
            this.chkTeam.TabIndex = 72;
            this.chkTeam.Text = "Team";
            this.chkTeam.UseVisualStyleBackColor = true;
            this.chkTeam.CheckedChanged += new System.EventHandler(this.chkTeam_CheckedChanged);
            // 
            // RegionUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(834, 537);
            this.Controls.Add(this.dataGridViewRegionDetails);
            this.Controls.Add(this.groupBoxGroup);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "RegionUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add / Edit Region";
            this.Load += new System.EventHandler(this.RegionUI_Load);
            this.groupBoxGroup.ResumeLayout(false);
            this.groupBoxGroup.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewRegionDetails)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxGroup;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.TextBox txtDivisionIDForRegion;
        private System.Windows.Forms.Label lblDivisionIDForRegion;
        private System.Windows.Forms.ComboBox cmbSelectDivisionForRegion;
        private System.Windows.Forms.Label lblSelectDivisionForRegion;
        private System.Windows.Forms.Button btnRefreshRegion;
        private System.Windows.Forms.Button btnRegionReport;
        private System.Windows.Forms.TextBox txtRegionActivityEndDate;
        private System.Windows.Forms.Button btnSaveRegion;
        private System.Windows.Forms.Button btnAddRegion;
        private System.Windows.Forms.DateTimePicker dTPRegionActivityEndDate;
        private System.Windows.Forms.Label lblTeamActivityEndDate;
        private System.Windows.Forms.TextBox txtRegionActivityStartDate;
        private System.Windows.Forms.DateTimePicker dTPRegionActivityStartDate;
        private System.Windows.Forms.ComboBox cmbSelectEmployeeForRegion;
        private System.Windows.Forms.Label lblSelectEmployeeForRegion;
        private System.Windows.Forms.ComboBox cmbSelectDesignationForRegion;
        private System.Windows.Forms.Label lblTeamActivityStartDate;
        private System.Windows.Forms.ComboBox cmbRegionActive;
        private System.Windows.Forms.Label lblGroupActive;
        private System.Windows.Forms.TextBox txtRegionName;
        private System.Windows.Forms.Label lblSelectDesignation;
        private System.Windows.Forms.Label lblRegionName;
        private System.Windows.Forms.DataGridView dataGridViewRegionDetails;
        private System.Windows.Forms.CheckBox chkTeam;
    }
}