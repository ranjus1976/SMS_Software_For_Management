﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CrystalDecisions.Windows.Forms;

namespace SMSapplication.UI
{
    public partial class ReportViewer : Form
    {
        public CrystalReportViewer CrystalReportViewer1
        {
            get { return crystalReportViewer1; }
            set { crystalReportViewer1 = value; }
        }
        public ReportViewer()
        {
            InitializeComponent();
        }

        
    }
}
