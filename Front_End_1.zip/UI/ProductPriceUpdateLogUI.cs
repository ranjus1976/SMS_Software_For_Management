﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using SMSapplication.BLL;
using SMSapplication.DAL;
using SMSapplication.DAL.DAO;
using SMSapplication.DAL.Gateway;
using SMSapplication.UI;

namespace SMSapplication.UI
{
    public partial class ProductPriceUpdateLogUI : Form
    {
        ProductDetailsManager objProductDetailsManager = new ProductDetailsManager();

        public ProductPriceUpdateLogUI()
        {
            InitializeComponent();
            RefreshProductPriceLog();
        }

        private void ProductPriceUpdateLogUI_Load(object sender, EventArgs e)
        {
            RefreshProductPriceLog();
        }

        private void RefreshProductPriceLog()
        {
            radioBtnPriceUpdateLogSearchByPCode.Checked = false;
            radioBtnPriceUpdateLogSearchByPName.Checked = false;
            radioBtnPriceUpdateLogShowAll.Checked = false;
            
            txtPriceUpdateLogSearchCriteria.Text = "";
            txtPriceUpdateLogSearchCriteria.Enabled = false;
            
            dgvProductPriceUpdateLog.Columns.Clear();
            dgvProductPriceUpdateLog.Refresh();
            dgvProductPriceUpdateLog.DataSource = objProductDetailsManager.ShowUpdateLogForAllProduct();
            dgvProductPriceUpdateLog.Columns[0].Visible = false;
            DataGridViewProductPriceUpdateLogHeaderText();
        }

        public void DataGridViewProductPriceUpdateLogHeaderText()
        {
            dgvProductPriceUpdateLog.Columns[1].HeaderText = "Product ID";
            dgvProductPriceUpdateLog.Columns[2].HeaderText = "Product Code";
            dgvProductPriceUpdateLog.Columns[3].HeaderText = "Product Name";
            dgvProductPriceUpdateLog.Columns[4].HeaderText = "Pack Size";
            dgvProductPriceUpdateLog.Columns[5].HeaderText = "Product Cost Price";
            dgvProductPriceUpdateLog.Columns[6].HeaderText = "Product Sale Price";
            dgvProductPriceUpdateLog.Columns[7].HeaderText = "Valid From";
            dgvProductPriceUpdateLog.Columns[8].HeaderText = "Valid UpTo";
        }

        private void radioBtnPriceUpdateLogSearchByPCode_CheckedChanged(object sender, EventArgs e)
        {
            if (radioBtnPriceUpdateLogSearchByPCode.Checked == true)
            {
                radioBtnPriceUpdateLogSearchByPName.Checked = false;
                radioBtnPriceUpdateLogShowAll.Checked = false;
            }

            if (txtPriceUpdateLogSearchCriteria.Enabled == false)
            {
                txtPriceUpdateLogSearchCriteria.Enabled = true;
                txtPriceUpdateLogSearchCriteria.Text = "";
                txtPriceUpdateLogSearchCriteria.Focus();
            }
            else
            {
                txtPriceUpdateLogSearchCriteria.Enabled = true;
                txtPriceUpdateLogSearchCriteria.Text = "";
                txtPriceUpdateLogSearchCriteria.Focus();
            }
        }

        private void radioBtnPriceUpdateLogSearchByPName_CheckedChanged(object sender, EventArgs e)
        {
            if (radioBtnPriceUpdateLogSearchByPName.Checked == true)
            {
                radioBtnPriceUpdateLogSearchByPCode.Checked = false;
                radioBtnPriceUpdateLogShowAll.Checked = false;
            }

            if (txtPriceUpdateLogSearchCriteria.Enabled == false)
            {
                txtPriceUpdateLogSearchCriteria.Enabled = true;
                txtPriceUpdateLogSearchCriteria.Text = "";
                txtPriceUpdateLogSearchCriteria.Focus();
            }
            else
            {
                txtPriceUpdateLogSearchCriteria.Enabled = true;
                txtPriceUpdateLogSearchCriteria.Text = "";
                txtPriceUpdateLogSearchCriteria.Focus();
            }
        }

        private void radioBtnPriceUpdateLogShowAll_CheckedChanged(object sender, EventArgs e)
        {
            if (radioBtnPriceUpdateLogShowAll.Checked == true)
            {
                radioBtnPriceUpdateLogSearchByPCode.Checked = false;
                radioBtnPriceUpdateLogSearchByPName.Checked = false;
            }

            txtPriceUpdateLogSearchCriteria.Enabled = false;
            txtPriceUpdateLogSearchCriteria.Text = "";
            btnPriceUpdateLogSearch.Focus();
        }

        private void btnPriceUpdateLogSearch_Click(object sender, EventArgs e)
        {
            if (radioBtnPriceUpdateLogSearchByPCode.Checked == true)
            {
                radioBtnPriceUpdateLogSearchByPName.Checked = false;
                radioBtnPriceUpdateLogShowAll.Checked = false;

                dgvProductPriceUpdateLog.DataSource = objProductDetailsManager.GetProductUpdateLogByProductCode(txtPriceUpdateLogSearchCriteria.Text.ToString());
                if (dgvProductPriceUpdateLog.RowCount > 0)
                {
                    dgvProductPriceUpdateLog.Refresh();
                    dgvProductPriceUpdateLog.Columns[0].Visible = false;
                    txtPriceUpdateLogSearchCriteria.Text = "";
                }
                else
                {
                    MessageBox.Show("No Data Found");
                }
            }

            if (radioBtnPriceUpdateLogSearchByPName.Checked == true)
            {
                radioBtnPriceUpdateLogSearchByPCode.Checked = false;
                radioBtnPriceUpdateLogShowAll.Checked = false;

                dgvProductPriceUpdateLog.DataSource = objProductDetailsManager.GetProductUpdateLogByProductName(txtPriceUpdateLogSearchCriteria.Text.ToString());
                if (dgvProductPriceUpdateLog.RowCount > 0)
                {
                    dgvProductPriceUpdateLog.Refresh();
                    dgvProductPriceUpdateLog.Columns[0].Visible = false;
                    txtPriceUpdateLogSearchCriteria.Text = "";
                }
                else
                {
                    MessageBox.Show("No Data Found");
                }
            }

            if (radioBtnPriceUpdateLogShowAll.Checked == true)
            {
                radioBtnPriceUpdateLogSearchByPCode.Checked = false;
                radioBtnPriceUpdateLogSearchByPName.Checked = false;

                dgvProductPriceUpdateLog.DataSource = objProductDetailsManager.ShowUpdateLogForAllProduct();
                if (dgvProductPriceUpdateLog.RowCount > 0)
                {
                    dgvProductPriceUpdateLog.Refresh();
                    dgvProductPriceUpdateLog.Columns[0].Visible = false;
                    txtPriceUpdateLogSearchCriteria.Text = "";
                }
                else
                {
                    MessageBox.Show("No Data Found");
                }
            }

            DataGridViewProductPriceUpdateLogHeaderText();
        }

        private void btnRefreshProductPriceLog_Click(object sender, EventArgs e)
        {
            RefreshProductPriceLog();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
