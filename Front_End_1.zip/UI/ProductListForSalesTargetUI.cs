﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using SMSapplication.BLL;
using SMSapplication.DAL.DAO;

namespace SMSapplication.UI
{
    public partial class ProductListForSalesTargetUI : Form
    {
        ProductDetailsManager objProductDetailsManager = new ProductDetailsManager();
        ProductDetails objProductDetails = new ProductDetails();
        SalesTargerDetailsManager objSalesTargerDetailsManager = new SalesTargerDetailsManager();
        DataGridViewCheckBoxColumn checkBoxColumn = new DataGridViewCheckBoxColumn();
        DataGridViewTextBoxColumn orderQTY = new DataGridViewTextBoxColumn();
        DataGridViewTextBoxColumn orderAmount = new DataGridViewTextBoxColumn();
        SMSapplication objSmSapplication = new SMSapplication();
        
        //DataGridViewCheckBoxCell objDataGridViewCheckBoxCell = row.c
        public ProductListForSalesTargetUI()
        {
            InitializeComponent();
        }

        private void ProductListForSalesTargetUI_Load(object sender, EventArgs e)
        {
            try
            {
                dgvProductListForSalesTarget.DataSource = objProductDetailsManager.ShowAllProduct();
                //dgvProductListForSalesTarget.Columns[0].Visible = false;
                dgvProductListForSalesTarget.Columns[4].Visible = false;
                //dgvProductListForSalesTarget.Columns[5].Visible = false;
                dgvProductListForSalesTarget.Columns[6].Visible = false;

                dgvProductListForSalesTarget.Columns[0].ReadOnly = true;
                dgvProductListForSalesTarget.Columns[1].ReadOnly = true;
                dgvProductListForSalesTarget.Columns[2].ReadOnly = true;
                dgvProductListForSalesTarget.Columns[3].ReadOnly = true;
                dgvProductListForSalesTarget.Columns[5].ReadOnly = true;
                
                dgvProductListForSalesTarget.Columns.Add(orderQTY);
                orderQTY.HeaderText = "Order QTY";

                //dgvProductListForSalesTarget.Columns.Add(orderAmount);
                //orderAmount.HeaderText = "Order Amount";

                dgvProductListForSalesTarget.Columns.Add(checkBoxColumn);
                checkBoxColumn.HeaderText = "Check to Insert";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dgvProductListForSalesTarget_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex > 3 && e.ColumnIndex < 6)
                {
                    if (dgvProductListForSalesTarget.Columns[e.ColumnIndex].HeaderText == "Order QTY")
                    {
                        dgvProductListForSalesTarget.BeginEdit(true);
                    }
                }

                //if (e.ColumnIndex > 3 || e.ColumnIndex < 6)
                //{
                //    if (dgvProductListForSalesTarget.Columns[e.ColumnIndex].HeaderText == "Order QTY" ||
                //        dgvProductListForSalesTarget.Columns[e.ColumnIndex].HeaderText == "Check to Insert")
                //    {
                //        dgvProductListForSalesTarget.BeginEdit(true);
                //    }
                //}
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }

        private void dgvProductListForSalesTarget_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                if (e.KeyChar == (char)Keys.F2)
                {
                    if (dgvProductListForSalesTarget.CurrentCell.OwningColumn.HeaderText == "Order QTY" ||
                        dgvProductListForSalesTarget.CurrentCell.OwningColumn.HeaderText == "Check to Insert")
                    {
                        dgvProductListForSalesTarget.BeginEdit(true);
                    }
                }
                //else if (e.KeyChar == (char) Keys.Enter)
                //{
                //    if (dgvProductListForSalesTarget.CurrentCell.OwningColumn.HeaderText == "Order QTY" ||
                //        dgvProductListForSalesTarget.CurrentCell.OwningColumn.HeaderText == "Check to Insert")
                //    {
                //        dgvProductListForSalesTarget.BeginEdit(true);
                //    }
                //}
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }

        private void btnSaveProductList_Click(object sender, EventArgs e)
        {
            try
            {
                for (int i = 0; i <= dgvProductListForSalesTarget.RowCount - 1; i++)
                {
                    if (Convert.ToBoolean(dgvProductListForSalesTarget.Rows[i].Cells[8].Value))
                    {
                        //MessageBox.Show(GlobalClass.FromDateForSalesTarget);
                        //MessageBox.Show(GlobalClass.ToDateForSalesTarget);
                        //MessageBox.Show(GlobalClass.GroupNameForSalesTarget);
                        //MessageBox.Show(GlobalClass.EmpDesignationForSalesTarget);
                        //MessageBox.Show(GlobalClass.EmpNameForSalesTarget);
                        //MessageBox.Show(GlobalClass.EmpIdForSalesTarget);
                        //MessageBox.Show(GlobalClass.EmpMobileNoForSalesTarget);
                        //MessageBox.Show(dgvProductListForSalesTarget.Rows[i].Cells[0].Value.ToString());
                        //MessageBox.Show(dgvProductListForSalesTarget.Rows[i].Cells[1].Value.ToString());
                        //MessageBox.Show(dgvProductListForSalesTarget.Rows[i].Cells[2].Value.ToString());
                        //MessageBox.Show(dgvProductListForSalesTarget.Rows[i].Cells[5].Value.ToString());
                        //MessageBox.Show(dgvProductListForSalesTarget.Rows[i].Cells[7].Value.ToString());
                        GlobalClass.OrderAmountForSalesTarget =
                            Convert.ToDecimal(dgvProductListForSalesTarget.Rows[i].Cells[5].Value.ToString())*
                            Convert.ToInt32(dgvProductListForSalesTarget.Rows[i].Cells[7].Value.ToString());
                        //MessageBox.Show(GlobalClass.OrderAmountForSalesTarget.ToString());

                        objSalesTargerDetailsManager.InsertTempSalesTarget(
                            GlobalClass.FromDateForSalesTarget.ToString(),
                            GlobalClass.ToDateForSalesTarget.ToString(),
                            Convert.ToInt32(dgvProductListForSalesTarget.Rows[i].Cells[0].Value.ToString()),
                            dgvProductListForSalesTarget.Rows[i].Cells[1].Value.ToString(),
                            dgvProductListForSalesTarget.Rows[i].Cells[2].Value.ToString(),
                            Convert.ToDecimal(dgvProductListForSalesTarget.Rows[i].Cells[5].Value.ToString()),
                            Convert.ToInt32(dgvProductListForSalesTarget.Rows[i].Cells[7].Value.ToString()),
                            Convert.ToDecimal(GlobalClass.OrderAmountForSalesTarget.ToString()),
                            Convert.ToInt32(GlobalClass.EmpIdForSalesTarget),
                            GlobalClass.EmpNameForSalesTarget.ToString(),
                            GlobalClass.EmpDesignationForSalesTarget.ToString(),
                            GlobalClass.EmpMobileNoForSalesTarget.ToString(),
                            GlobalClass.GroupNameForSalesTarget.ToString(),
                            GlobalClass.DivisionNameOfEmployeeForSalesTarget.ToString()
                            );
                    }
                }
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
            finally
            {
                objSmSapplication.loadTempSalesTarget();
                this.Close();
            }

        }
    }
}
