﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using SMSapplication.BLL;
using SMSapplication.DAL;
using SMSapplication.DAL.DAO;
using SMSapplication.DAL.Gateway;
using SMSapplication.UI;

namespace SMSapplication.UI
{
    public partial class TeamDetailsUI : Form
    {
        GroupDetailsManager objGroupDetailsManager = new GroupDetailsManager();

        public TeamDetailsUI()
        {
            InitializeComponent();
            RefreshTeamDetails();
        }

        private void TeamDetailsUI_Load(object sender, EventArgs e)
        {
            RefreshTeamDetails();
        }

        private void RefreshTeamDetails()
        {
            radioBtnTeamDetailsSearchByTeamName.Checked = false;
            radioBtnTeamDetailsSearchByDivisionName.Checked = false;
            radioBtnTeamDetailsSearchByRegionName.Checked = false;
            radioBtnTeamDetailsSearchByZoneName.Checked = false;
            radioBtnTeamDetailsSearchByAreaName.Checked = false;

            txtTeamDetailsSearchCriteria.Text = "";
            txtTeamDetailsSearchCriteria.Enabled = false;

            dgvTeamDetails.Columns.Clear();
            dgvTeamDetails.Refresh();
            dgvTeamDetails.DataSource = objGroupDetailsManager.ShowAllTeamDetails();
            dgvTeamDetails.Columns[0].Visible = false;
            dgvTeamDetails.Columns[1].Visible = false;
            dgvTeamDetails.Columns[3].Visible = false;
            dgvTeamDetails.Columns[5].Visible = false;
            dgvTeamDetails.Columns[7].Visible = false;
            dgvTeamDetails.Columns[9].Visible = false;
            DataGridViewTeamDetailsHeaderText();
        }

        private void DataGridViewTeamDetailsHeaderText()
        {
            dgvTeamDetails.Columns[2].HeaderText = "Team Name";
            dgvTeamDetails.Columns[4].HeaderText = "Division Name";
            dgvTeamDetails.Columns[6].HeaderText = "Region Name";
            dgvTeamDetails.Columns[8].HeaderText = "Zone Name";
            dgvTeamDetails.Columns[10].HeaderText = "Area Name";
            dgvTeamDetails.Columns[11].HeaderText = "Employee Name";
            dgvTeamDetails.Columns[12].HeaderText = "Designation Code";
            dgvTeamDetails.Columns[13].HeaderText = "Activity Start Date";
            dgvTeamDetails.Columns[14].HeaderText = "Activity End Date";
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
