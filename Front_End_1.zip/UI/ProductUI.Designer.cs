﻿namespace SMSapplication.UI
{
    partial class ProductUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProductUI));
            this.groupBoxProduct = new System.Windows.Forms.GroupBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnRefreshProduct = new System.Windows.Forms.Button();
            this.cmbProductActive = new System.Windows.Forms.ComboBox();
            this.btnProductReport = new System.Windows.Forms.Button();
            this.lblProductActive = new System.Windows.Forms.Label();
            this.btnSaveProduct = new System.Windows.Forms.Button();
            this.btnAddProduct = new System.Windows.Forms.Button();
            this.cmbPackSize = new System.Windows.Forms.ComboBox();
            this.txtUnitCostPrice = new System.Windows.Forms.TextBox();
            this.lblUnitSalePrice = new System.Windows.Forms.Label();
            this.txtUnitSalePrice = new System.Windows.Forms.TextBox();
            this.lblUnitCostPrice = new System.Windows.Forms.Label();
            this.lblPackSize = new System.Windows.Forms.Label();
            this.txtProductName = new System.Windows.Forms.TextBox();
            this.lblProductName = new System.Windows.Forms.Label();
            this.txtProductCode = new System.Windows.Forms.TextBox();
            this.lblProductCode = new System.Windows.Forms.Label();
            this.dataGridViewProduct = new System.Windows.Forms.DataGridView();
            this.groupBoxProduct.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProduct)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBoxProduct
            // 
            this.groupBoxProduct.Controls.Add(this.btnClose);
            this.groupBoxProduct.Controls.Add(this.btnRefreshProduct);
            this.groupBoxProduct.Controls.Add(this.cmbProductActive);
            this.groupBoxProduct.Controls.Add(this.btnProductReport);
            this.groupBoxProduct.Controls.Add(this.lblProductActive);
            this.groupBoxProduct.Controls.Add(this.btnSaveProduct);
            this.groupBoxProduct.Controls.Add(this.btnAddProduct);
            this.groupBoxProduct.Controls.Add(this.cmbPackSize);
            this.groupBoxProduct.Controls.Add(this.txtUnitCostPrice);
            this.groupBoxProduct.Controls.Add(this.lblUnitSalePrice);
            this.groupBoxProduct.Controls.Add(this.txtUnitSalePrice);
            this.groupBoxProduct.Controls.Add(this.lblUnitCostPrice);
            this.groupBoxProduct.Controls.Add(this.lblPackSize);
            this.groupBoxProduct.Controls.Add(this.txtProductName);
            this.groupBoxProduct.Controls.Add(this.lblProductName);
            this.groupBoxProduct.Controls.Add(this.txtProductCode);
            this.groupBoxProduct.Controls.Add(this.lblProductCode);
            this.groupBoxProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxProduct.Location = new System.Drawing.Point(6, 0);
            this.groupBoxProduct.Name = "groupBoxProduct";
            this.groupBoxProduct.Size = new System.Drawing.Size(822, 157);
            this.groupBoxProduct.TabIndex = 49;
            this.groupBoxProduct.TabStop = false;
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Location = new System.Drawing.Point(657, 120);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(160, 25);
            this.btnClose.TabIndex = 69;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnRefreshProduct
            // 
            this.btnRefreshProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefreshProduct.Location = new System.Drawing.Point(494, 120);
            this.btnRefreshProduct.Name = "btnRefreshProduct";
            this.btnRefreshProduct.Size = new System.Drawing.Size(160, 25);
            this.btnRefreshProduct.TabIndex = 9;
            this.btnRefreshProduct.Text = "Refresh";
            this.btnRefreshProduct.UseVisualStyleBackColor = true;
            this.btnRefreshProduct.Click += new System.EventHandler(this.btnRefreshProduct_Click);
            // 
            // cmbProductActive
            // 
            this.cmbProductActive.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbProductActive.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbProductActive.Enabled = false;
            this.cmbProductActive.FormattingEnabled = true;
            this.cmbProductActive.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cmbProductActive.Location = new System.Drawing.Point(561, 87);
            this.cmbProductActive.Name = "cmbProductActive";
            this.cmbProductActive.Size = new System.Drawing.Size(240, 24);
            this.cmbProductActive.TabIndex = 6;
            this.cmbProductActive.Text = "Select Active";
            // 
            // btnProductReport
            // 
            this.btnProductReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProductReport.Location = new System.Drawing.Point(331, 120);
            this.btnProductReport.Name = "btnProductReport";
            this.btnProductReport.Size = new System.Drawing.Size(160, 25);
            this.btnProductReport.TabIndex = 8;
            this.btnProductReport.Text = "Product Report";
            this.btnProductReport.UseVisualStyleBackColor = true;
            this.btnProductReport.Click += new System.EventHandler(this.btnProductReport_Click);
            // 
            // lblProductActive
            // 
            this.lblProductActive.AutoSize = true;
            this.lblProductActive.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProductActive.Location = new System.Drawing.Point(419, 90);
            this.lblProductActive.Name = "lblProductActive";
            this.lblProductActive.Size = new System.Drawing.Size(59, 16);
            this.lblProductActive.TabIndex = 60;
            this.lblProductActive.Text = "Active :";
            // 
            // btnSaveProduct
            // 
            this.btnSaveProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveProduct.Location = new System.Drawing.Point(168, 120);
            this.btnSaveProduct.Name = "btnSaveProduct";
            this.btnSaveProduct.Size = new System.Drawing.Size(160, 25);
            this.btnSaveProduct.TabIndex = 7;
            this.btnSaveProduct.Text = "Save Product";
            this.btnSaveProduct.UseVisualStyleBackColor = true;
            this.btnSaveProduct.Click += new System.EventHandler(this.btnSaveProduct_Click);
            // 
            // btnAddProduct
            // 
            this.btnAddProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddProduct.Location = new System.Drawing.Point(5, 120);
            this.btnAddProduct.Name = "btnAddProduct";
            this.btnAddProduct.Size = new System.Drawing.Size(160, 25);
            this.btnAddProduct.TabIndex = 0;
            this.btnAddProduct.Text = "Add Product";
            this.btnAddProduct.UseVisualStyleBackColor = true;
            this.btnAddProduct.Click += new System.EventHandler(this.btnAddProduct_Click);
            // 
            // cmbPackSize
            // 
            this.cmbPackSize.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbPackSize.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbPackSize.Enabled = false;
            this.cmbPackSize.FormattingEnabled = true;
            this.cmbPackSize.Items.AddRange(new object[] {
            "ml",
            "gm",
            "pcs"});
            this.cmbPackSize.Location = new System.Drawing.Point(138, 87);
            this.cmbPackSize.Name = "cmbPackSize";
            this.cmbPackSize.Size = new System.Drawing.Size(240, 24);
            this.cmbPackSize.TabIndex = 3;
            this.cmbPackSize.Text = "Select Pack Size";
            // 
            // txtUnitCostPrice
            // 
            this.txtUnitCostPrice.Enabled = false;
            this.txtUnitCostPrice.Location = new System.Drawing.Point(561, 27);
            this.txtUnitCostPrice.Name = "txtUnitCostPrice";
            this.txtUnitCostPrice.Size = new System.Drawing.Size(240, 22);
            this.txtUnitCostPrice.TabIndex = 4;
            // 
            // lblUnitSalePrice
            // 
            this.lblUnitSalePrice.AutoSize = true;
            this.lblUnitSalePrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUnitSalePrice.Location = new System.Drawing.Point(419, 60);
            this.lblUnitSalePrice.Name = "lblUnitSalePrice";
            this.lblUnitSalePrice.Size = new System.Drawing.Size(119, 16);
            this.lblUnitSalePrice.TabIndex = 58;
            this.lblUnitSalePrice.Text = "Unit Sale Price :";
            // 
            // txtUnitSalePrice
            // 
            this.txtUnitSalePrice.Enabled = false;
            this.txtUnitSalePrice.Location = new System.Drawing.Point(561, 57);
            this.txtUnitSalePrice.Name = "txtUnitSalePrice";
            this.txtUnitSalePrice.Size = new System.Drawing.Size(240, 22);
            this.txtUnitSalePrice.TabIndex = 5;
            // 
            // lblUnitCostPrice
            // 
            this.lblUnitCostPrice.AutoSize = true;
            this.lblUnitCostPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUnitCostPrice.Location = new System.Drawing.Point(419, 30);
            this.lblUnitCostPrice.Name = "lblUnitCostPrice";
            this.lblUnitCostPrice.Size = new System.Drawing.Size(118, 16);
            this.lblUnitCostPrice.TabIndex = 59;
            this.lblUnitCostPrice.Text = "Unit Cost Price :";
            // 
            // lblPackSize
            // 
            this.lblPackSize.AutoSize = true;
            this.lblPackSize.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPackSize.Location = new System.Drawing.Point(4, 90);
            this.lblPackSize.Name = "lblPackSize";
            this.lblPackSize.Size = new System.Drawing.Size(85, 16);
            this.lblPackSize.TabIndex = 57;
            this.lblPackSize.Text = "Pack Size :";
            // 
            // txtProductName
            // 
            this.txtProductName.Enabled = false;
            this.txtProductName.Location = new System.Drawing.Point(138, 57);
            this.txtProductName.Name = "txtProductName";
            this.txtProductName.Size = new System.Drawing.Size(240, 22);
            this.txtProductName.TabIndex = 2;
            // 
            // lblProductName
            // 
            this.lblProductName.AutoSize = true;
            this.lblProductName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProductName.Location = new System.Drawing.Point(4, 60);
            this.lblProductName.Name = "lblProductName";
            this.lblProductName.Size = new System.Drawing.Size(114, 16);
            this.lblProductName.TabIndex = 55;
            this.lblProductName.Text = "Product Name :";
            // 
            // txtProductCode
            // 
            this.txtProductCode.Enabled = false;
            this.txtProductCode.Location = new System.Drawing.Point(138, 27);
            this.txtProductCode.MaxLength = 5;
            this.txtProductCode.Name = "txtProductCode";
            this.txtProductCode.Size = new System.Drawing.Size(240, 22);
            this.txtProductCode.TabIndex = 1;
            // 
            // lblProductCode
            // 
            this.lblProductCode.AutoSize = true;
            this.lblProductCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProductCode.Location = new System.Drawing.Point(4, 30);
            this.lblProductCode.Name = "lblProductCode";
            this.lblProductCode.Size = new System.Drawing.Size(110, 16);
            this.lblProductCode.TabIndex = 53;
            this.lblProductCode.Text = "Product Code :";
            // 
            // dataGridViewProduct
            // 
            this.dataGridViewProduct.AllowUserToAddRows = false;
            this.dataGridViewProduct.AllowUserToDeleteRows = false;
            this.dataGridViewProduct.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewProduct.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridViewProduct.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewProduct.Location = new System.Drawing.Point(6, 163);
            this.dataGridViewProduct.MultiSelect = false;
            this.dataGridViewProduct.Name = "dataGridViewProduct";
            this.dataGridViewProduct.ReadOnly = true;
            this.dataGridViewProduct.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewProduct.Size = new System.Drawing.Size(822, 370);
            this.dataGridViewProduct.TabIndex = 52;
            this.dataGridViewProduct.TabStop = false;
            this.dataGridViewProduct.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewProduct_CellContentDoubleClick);
            this.dataGridViewProduct.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewProduct_CellDoubleClick);
            // 
            // ProductUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(834, 537);
            this.Controls.Add(this.dataGridViewProduct);
            this.Controls.Add(this.groupBoxProduct);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ProductUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add / Edit Product";
            this.Load += new System.EventHandler(this.ProductUI_Load);
            this.groupBoxProduct.ResumeLayout(false);
            this.groupBoxProduct.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProduct)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxProduct;
        private System.Windows.Forms.ComboBox cmbProductActive;
        private System.Windows.Forms.Label lblProductActive;
        private System.Windows.Forms.ComboBox cmbPackSize;
        private System.Windows.Forms.TextBox txtUnitCostPrice;
        private System.Windows.Forms.Label lblUnitSalePrice;
        private System.Windows.Forms.TextBox txtUnitSalePrice;
        private System.Windows.Forms.Label lblUnitCostPrice;
        private System.Windows.Forms.Label lblPackSize;
        private System.Windows.Forms.TextBox txtProductName;
        private System.Windows.Forms.Label lblProductName;
        private System.Windows.Forms.TextBox txtProductCode;
        private System.Windows.Forms.Label lblProductCode;
        private System.Windows.Forms.Button btnRefreshProduct;
        private System.Windows.Forms.Button btnProductReport;
        private System.Windows.Forms.Button btnSaveProduct;
        private System.Windows.Forms.Button btnAddProduct;
        private System.Windows.Forms.DataGridView dataGridViewProduct;
        private System.Windows.Forms.Button btnClose;
    }
}