﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.ms.sms;
using System.IO.Ports;

namespace SMSapplication
{
    public partial class AppSMS : Form
    {
        #region Private Variables
        public SerialPort port=new SerialPort ();
        SMSGateway objclsSMS = new SMSGateway();
        PortConnection conn = new PortConnection();
        ShortMessageCollection objShortMessageCollection = new ShortMessageCollection();
        #endregion

        public AppSMS()
        {
            InitializeComponent();
        }
       

        private void btnConnect_Click(object sender, EventArgs e)
        {
            try
            {
                //Open communication port 
                
                port = conn.ConnectPort(this.cboPortName.Text, Convert.ToInt32(this.cboBaudRate.Text), Convert.ToInt32(this.cboDataBits.Text), Convert.ToInt32(this.txtReadTimeOut.Text), Convert.ToInt32(this.txtWriteTimeOut.Text), Encoding.Unicode);
                port.Open();
                if (port != null)
                {
                    this.gboPortSettings.Enabled = false;

                    this.statusBar1.Text = "Modem is connected at PORT " + this.cboPortName.Text;
                    this.lblConnectionStatus.Text = "Connected at " + this.cboPortName.Text;
                    this.btnDisconnect.Enabled = true;
                }

                else
                {
                    this.statusBar1.Text = "Invalid port settings";
                }
            }
            catch (Exception ex)
            {
                //ErrorLog(ex.Message);
                //MessageBox.Show(Convert.ToString(ex));

                MessageBox.Show(ex.Message);
            }
        }

        private void btnDisconnect_Click(object sender, EventArgs e)
        {
            try
            {
                this.gboPortSettings.Enabled = true;
                objclsSMS.DisconnectPort(port);
                this.lblConnectionStatus.Text = "Not Connected";
                this.btnDisconnect.Enabled = false;
                this.statusBar1.Text = "Modem is Disconnected at PORT " + this.cboPortName.Text;


            }
            catch (Exception ex)
            {
                //ErrorLog(ex.Message);
            }
        }

        private void treeViewMessage_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            TreeNode tn = treeViewMessage.SelectedNode;
            SendMessage obj=new SendMessage ();
            if (tn.Name == "NodeWriteMsg")
                obj.Show();
            if (tn.Name == "NodeInbox")
                tn.Text = "Index(0)";
            if (tn.Name == "NodeSent")
                obj.Show();
            if (tn.Name == "NodeOutbox")
                obj.Show();
            if (tn.Name == "NodeDelivery")
                obj.Show();
            if (tn.Name == "NodeDeleteMsg")
                obj.Show();
               
        }

        private void AppSMS_Load(object sender, EventArgs e)
        {
            treeViewMessage.ExpandAll();
            //timer1.Start();

            string[] ports = SerialPort.GetPortNames();

            foreach (string port in ports)
            {
                cboPortName.Items.Add(port);
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            //TreeNodeCollection tn = treeViewMessage.Nodes;
            //if (tn.Equals(treeViewMessage.Nodes))
            //    //tn.Text = "Index(0)";

            //    foreach (TreeNode node in tn)
            //    {
            //        if (node.Name == "NodeInbox")
            //            treeViewMessage.Nodes[1].Text = "Index(0)";
            //        if (node.Name == "NodeSent")
            //            node.Text = "NodeSent(0)";
            //        if (node.Name == "NodeOutbox")
            //            node.Text = "Outbox(0)"; ;
            //        if (node.Name == "NodeDelivery")
            //            node.Text = "NodeDelivery(0)"; ;
            //    }
               
        }

       

        
    }
}
