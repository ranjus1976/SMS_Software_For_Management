﻿namespace SMSapplication.UI
{
    partial class ProductReportUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProductReportUI));
            this.groupBoxProductReport = new System.Windows.Forms.GroupBox();
            this.radioButtonAllProductForProductReport = new System.Windows.Forms.RadioButton();
            this.btnUserReport = new System.Windows.Forms.Button();
            this.radioButtonNonActiveProductForProductReport = new System.Windows.Forms.RadioButton();
            this.radioButtonActiveProductForProductReport = new System.Windows.Forms.RadioButton();
            this.groupBoxProductReport.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxProductReport
            // 
            this.groupBoxProductReport.Controls.Add(this.radioButtonAllProductForProductReport);
            this.groupBoxProductReport.Controls.Add(this.btnUserReport);
            this.groupBoxProductReport.Controls.Add(this.radioButtonNonActiveProductForProductReport);
            this.groupBoxProductReport.Controls.Add(this.radioButtonActiveProductForProductReport);
            this.groupBoxProductReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxProductReport.Location = new System.Drawing.Point(6, 3);
            this.groupBoxProductReport.Name = "groupBoxProductReport";
            this.groupBoxProductReport.Size = new System.Drawing.Size(360, 130);
            this.groupBoxProductReport.TabIndex = 54;
            this.groupBoxProductReport.TabStop = false;
            this.groupBoxProductReport.Text = "Product Report Criteria";
            // 
            // radioButtonAllProductForProductReport
            // 
            this.radioButtonAllProductForProductReport.AutoSize = true;
            this.radioButtonAllProductForProductReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonAllProductForProductReport.Location = new System.Drawing.Point(6, 70);
            this.radioButtonAllProductForProductReport.Name = "radioButtonAllProductForProductReport";
            this.radioButtonAllProductForProductReport.Size = new System.Drawing.Size(101, 20);
            this.radioButtonAllProductForProductReport.TabIndex = 70;
            this.radioButtonAllProductForProductReport.TabStop = true;
            this.radioButtonAllProductForProductReport.Text = "All Product";
            this.radioButtonAllProductForProductReport.UseVisualStyleBackColor = true;
            // 
            // btnUserReport
            // 
            this.btnUserReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUserReport.Location = new System.Drawing.Point(6, 100);
            this.btnUserReport.Name = "btnUserReport";
            this.btnUserReport.Size = new System.Drawing.Size(347, 25);
            this.btnUserReport.TabIndex = 73;
            this.btnUserReport.Text = "Report";
            this.btnUserReport.UseVisualStyleBackColor = true;
            this.btnUserReport.Click += new System.EventHandler(this.btnUserReport_Click);
            // 
            // radioButtonNonActiveProductForProductReport
            // 
            this.radioButtonNonActiveProductForProductReport.AutoSize = true;
            this.radioButtonNonActiveProductForProductReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonNonActiveProductForProductReport.Location = new System.Drawing.Point(6, 45);
            this.radioButtonNonActiveProductForProductReport.Name = "radioButtonNonActiveProductForProductReport";
            this.radioButtonNonActiveProductForProductReport.Size = new System.Drawing.Size(158, 20);
            this.radioButtonNonActiveProductForProductReport.TabIndex = 67;
            this.radioButtonNonActiveProductForProductReport.TabStop = true;
            this.radioButtonNonActiveProductForProductReport.Text = "Non Active Product";
            this.radioButtonNonActiveProductForProductReport.UseVisualStyleBackColor = true;
            // 
            // radioButtonActiveProductForProductReport
            // 
            this.radioButtonActiveProductForProductReport.AutoSize = true;
            this.radioButtonActiveProductForProductReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonActiveProductForProductReport.Location = new System.Drawing.Point(6, 20);
            this.radioButtonActiveProductForProductReport.Name = "radioButtonActiveProductForProductReport";
            this.radioButtonActiveProductForProductReport.Size = new System.Drawing.Size(126, 20);
            this.radioButtonActiveProductForProductReport.TabIndex = 66;
            this.radioButtonActiveProductForProductReport.TabStop = true;
            this.radioButtonActiveProductForProductReport.Text = "Active Product";
            this.radioButtonActiveProductForProductReport.UseVisualStyleBackColor = true;
            // 
            // ProductReportUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(372, 137);
            this.Controls.Add(this.groupBoxProductReport);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ProductReportUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Product Report";
            this.groupBoxProductReport.ResumeLayout(false);
            this.groupBoxProductReport.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxProductReport;
        private System.Windows.Forms.RadioButton radioButtonAllProductForProductReport;
        private System.Windows.Forms.Button btnUserReport;
        private System.Windows.Forms.RadioButton radioButtonNonActiveProductForProductReport;
        private System.Windows.Forms.RadioButton radioButtonActiveProductForProductReport;
    }
}