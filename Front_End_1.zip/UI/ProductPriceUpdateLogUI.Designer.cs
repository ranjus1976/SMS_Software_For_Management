﻿namespace SMSapplication.UI
{
    partial class ProductPriceUpdateLogUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProductPriceUpdateLogUI));
            this.groupBoxProductPriceLogSearch = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.btnRefreshProductPriceLog = new System.Windows.Forms.Button();
            this.radioBtnPriceUpdateLogShowAll = new System.Windows.Forms.RadioButton();
            this.btnPriceUpdateLogSearch = new System.Windows.Forms.Button();
            this.txtPriceUpdateLogSearchCriteria = new System.Windows.Forms.TextBox();
            this.radioBtnPriceUpdateLogSearchByPName = new System.Windows.Forms.RadioButton();
            this.radioBtnPriceUpdateLogSearchByPCode = new System.Windows.Forms.RadioButton();
            this.dgvProductPriceUpdateLog = new System.Windows.Forms.DataGridView();
            this.btnClose = new System.Windows.Forms.Button();
            this.groupBoxProductPriceLogSearch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProductPriceUpdateLog)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBoxProductPriceLogSearch
            // 
            this.groupBoxProductPriceLogSearch.Controls.Add(this.btnClose);
            this.groupBoxProductPriceLogSearch.Controls.Add(this.button1);
            this.groupBoxProductPriceLogSearch.Controls.Add(this.btnRefreshProductPriceLog);
            this.groupBoxProductPriceLogSearch.Controls.Add(this.radioBtnPriceUpdateLogShowAll);
            this.groupBoxProductPriceLogSearch.Controls.Add(this.btnPriceUpdateLogSearch);
            this.groupBoxProductPriceLogSearch.Controls.Add(this.txtPriceUpdateLogSearchCriteria);
            this.groupBoxProductPriceLogSearch.Controls.Add(this.radioBtnPriceUpdateLogSearchByPName);
            this.groupBoxProductPriceLogSearch.Controls.Add(this.radioBtnPriceUpdateLogSearchByPCode);
            this.groupBoxProductPriceLogSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxProductPriceLogSearch.Location = new System.Drawing.Point(6, 0);
            this.groupBoxProductPriceLogSearch.Name = "groupBoxProductPriceLogSearch";
            this.groupBoxProductPriceLogSearch.Size = new System.Drawing.Size(1197, 80);
            this.groupBoxProductPriceLogSearch.TabIndex = 54;
            this.groupBoxProductPriceLogSearch.TabStop = false;
            this.groupBoxProductPriceLogSearch.Text = "Search";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(368, 45);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(180, 25);
            this.button1.TabIndex = 5;
            this.button1.Text = "Price Log Report";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // btnRefreshProductPriceLog
            // 
            this.btnRefreshProductPriceLog.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefreshProductPriceLog.Location = new System.Drawing.Point(552, 45);
            this.btnRefreshProductPriceLog.Name = "btnRefreshProductPriceLog";
            this.btnRefreshProductPriceLog.Size = new System.Drawing.Size(180, 25);
            this.btnRefreshProductPriceLog.TabIndex = 6;
            this.btnRefreshProductPriceLog.Text = "Refresh";
            this.btnRefreshProductPriceLog.UseVisualStyleBackColor = true;
            this.btnRefreshProductPriceLog.Click += new System.EventHandler(this.btnRefreshProductPriceLog_Click);
            // 
            // radioBtnPriceUpdateLogShowAll
            // 
            this.radioBtnPriceUpdateLogShowAll.AutoSize = true;
            this.radioBtnPriceUpdateLogShowAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioBtnPriceUpdateLogShowAll.Location = new System.Drawing.Point(292, 20);
            this.radioBtnPriceUpdateLogShowAll.Name = "radioBtnPriceUpdateLogShowAll";
            this.radioBtnPriceUpdateLogShowAll.Size = new System.Drawing.Size(77, 20);
            this.radioBtnPriceUpdateLogShowAll.TabIndex = 3;
            this.radioBtnPriceUpdateLogShowAll.TabStop = true;
            this.radioBtnPriceUpdateLogShowAll.Text = "Show All";
            this.radioBtnPriceUpdateLogShowAll.UseVisualStyleBackColor = true;
            this.radioBtnPriceUpdateLogShowAll.CheckedChanged += new System.EventHandler(this.radioBtnPriceUpdateLogShowAll_CheckedChanged);
            // 
            // btnPriceUpdateLogSearch
            // 
            this.btnPriceUpdateLogSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPriceUpdateLogSearch.Location = new System.Drawing.Point(184, 45);
            this.btnPriceUpdateLogSearch.Name = "btnPriceUpdateLogSearch";
            this.btnPriceUpdateLogSearch.Size = new System.Drawing.Size(180, 25);
            this.btnPriceUpdateLogSearch.TabIndex = 0;
            this.btnPriceUpdateLogSearch.Text = "Search";
            this.btnPriceUpdateLogSearch.UseVisualStyleBackColor = true;
            this.btnPriceUpdateLogSearch.Click += new System.EventHandler(this.btnPriceUpdateLogSearch_Click);
            // 
            // txtPriceUpdateLogSearchCriteria
            // 
            this.txtPriceUpdateLogSearchCriteria.Enabled = false;
            this.txtPriceUpdateLogSearchCriteria.Location = new System.Drawing.Point(6, 46);
            this.txtPriceUpdateLogSearchCriteria.Name = "txtPriceUpdateLogSearchCriteria";
            this.txtPriceUpdateLogSearchCriteria.Size = new System.Drawing.Size(173, 22);
            this.txtPriceUpdateLogSearchCriteria.TabIndex = 4;
            // 
            // radioBtnPriceUpdateLogSearchByPName
            // 
            this.radioBtnPriceUpdateLogSearchByPName.AutoSize = true;
            this.radioBtnPriceUpdateLogSearchByPName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioBtnPriceUpdateLogSearchByPName.Location = new System.Drawing.Point(145, 20);
            this.radioBtnPriceUpdateLogSearchByPName.Name = "radioBtnPriceUpdateLogSearchByPName";
            this.radioBtnPriceUpdateLogSearchByPName.Size = new System.Drawing.Size(131, 20);
            this.radioBtnPriceUpdateLogSearchByPName.TabIndex = 2;
            this.radioBtnPriceUpdateLogSearchByPName.TabStop = true;
            this.radioBtnPriceUpdateLogSearchByPName.Text = "By Product Name";
            this.radioBtnPriceUpdateLogSearchByPName.UseVisualStyleBackColor = true;
            this.radioBtnPriceUpdateLogSearchByPName.CheckedChanged += new System.EventHandler(this.radioBtnPriceUpdateLogSearchByPName_CheckedChanged);
            // 
            // radioBtnPriceUpdateLogSearchByPCode
            // 
            this.radioBtnPriceUpdateLogSearchByPCode.AutoSize = true;
            this.radioBtnPriceUpdateLogSearchByPCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioBtnPriceUpdateLogSearchByPCode.Location = new System.Drawing.Point(6, 20);
            this.radioBtnPriceUpdateLogSearchByPCode.Name = "radioBtnPriceUpdateLogSearchByPCode";
            this.radioBtnPriceUpdateLogSearchByPCode.Size = new System.Drawing.Size(127, 20);
            this.radioBtnPriceUpdateLogSearchByPCode.TabIndex = 1;
            this.radioBtnPriceUpdateLogSearchByPCode.TabStop = true;
            this.radioBtnPriceUpdateLogSearchByPCode.Text = "By Product Code";
            this.radioBtnPriceUpdateLogSearchByPCode.UseVisualStyleBackColor = true;
            this.radioBtnPriceUpdateLogSearchByPCode.CheckedChanged += new System.EventHandler(this.radioBtnPriceUpdateLogSearchByPCode_CheckedChanged);
            // 
            // dgvProductPriceUpdateLog
            // 
            this.dgvProductPriceUpdateLog.AllowUserToAddRows = false;
            this.dgvProductPriceUpdateLog.AllowUserToDeleteRows = false;
            this.dgvProductPriceUpdateLog.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvProductPriceUpdateLog.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dgvProductPriceUpdateLog.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProductPriceUpdateLog.Location = new System.Drawing.Point(6, 86);
            this.dgvProductPriceUpdateLog.MultiSelect = false;
            this.dgvProductPriceUpdateLog.Name = "dgvProductPriceUpdateLog";
            this.dgvProductPriceUpdateLog.ReadOnly = true;
            this.dgvProductPriceUpdateLog.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvProductPriceUpdateLog.Size = new System.Drawing.Size(1197, 436);
            this.dgvProductPriceUpdateLog.TabIndex = 55;
            this.dgvProductPriceUpdateLog.TabStop = false;
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Location = new System.Drawing.Point(736, 45);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(180, 25);
            this.btnClose.TabIndex = 7;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // ProductPriceUpdateLogUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(1209, 526);
            this.Controls.Add(this.dgvProductPriceUpdateLog);
            this.Controls.Add(this.groupBoxProductPriceLogSearch);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ProductPriceUpdateLogUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Product Price Update Log";
            this.Load += new System.EventHandler(this.ProductPriceUpdateLogUI_Load);
            this.groupBoxProductPriceLogSearch.ResumeLayout(false);
            this.groupBoxProductPriceLogSearch.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProductPriceUpdateLog)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxProductPriceLogSearch;
        private System.Windows.Forms.Button btnRefreshProductPriceLog;
        private System.Windows.Forms.RadioButton radioBtnPriceUpdateLogShowAll;
        private System.Windows.Forms.Button btnPriceUpdateLogSearch;
        private System.Windows.Forms.TextBox txtPriceUpdateLogSearchCriteria;
        private System.Windows.Forms.RadioButton radioBtnPriceUpdateLogSearchByPName;
        private System.Windows.Forms.RadioButton radioBtnPriceUpdateLogSearchByPCode;
        private System.Windows.Forms.DataGridView dgvProductPriceUpdateLog;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnClose;
    }
}