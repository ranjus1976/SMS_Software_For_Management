﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using SMSapplication.BLL;
using SMSapplication.DAL;
using SMSapplication.DAL.DAO;
using SMSapplication.DAL.Gateway;
using SMSapplication.UI;

namespace SMSapplication.UI
{
    public partial class TeamUI : Form
    {
        DesignationDetailsManager objDesignationDetailsManager = new DesignationDetailsManager();
        EmployeeDetailsManager objEmployeeDetailsManager = new EmployeeDetailsManager();
        GroupDetailsManager objGroupDetailsManager = new GroupDetailsManager();

        private string teamName;
        private string designationCode;
        private string employeeName;
        private string activityStartDate;
        private string teamActive;
        private string activityEndDate;
        private int teamId;
        
        public TeamUI()
        {
            InitializeComponent();
            RefreshTeam();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnAddTeam_Click(object sender, EventArgs e)
        {
            if (btnSaveTeam.Enabled == false)
            {
                btnSaveTeam.Enabled = true;
            }
            if (txtTeamName.Enabled == false)
            {
                txtTeamName.Enabled = true;
            }
            if (cmbSelectDesignationForTeam.Enabled == false)
            {
                cmbSelectDesignationForTeam.Enabled = true;
            }
            if (cmbSelectEmployeeForTeam.Enabled == false)
            {
                cmbSelectEmployeeForTeam.Enabled = true;
            }
            if (txtTeamActivityStartDate.Enabled == false)
            {
                txtTeamActivityStartDate.Enabled = true;
            }
            if (dTPTeamActivityStartDate.Enabled == false)
            {
                dTPTeamActivityStartDate.Enabled = true;
            }
            if (txtTeamActivityEndDate.Enabled == true)
            {
                txtTeamActivityEndDate.Enabled = false;
            }
            if (dTPTeamActivityEndDate.Enabled == true)
            {
                dTPTeamActivityEndDate.Enabled = false;
            }
            if (cmbTeamActive.Enabled == false)
            {
                cmbTeamActive.Enabled = true;
            }
            if (btnAddTeam.Enabled == false)
            {
                btnAddTeam.Enabled = true;
            }
            if (btnSaveTeam.Text == "Update Team")
            {
                btnSaveTeam.Text = "Save Team";
            }
            ClearTeamTab();
            txtTeamName.Focus();
        }

        public void ClearTeamTab()
        {
            txtTeamName.Text = "";
            cmbSelectDesignationForTeam.DataSource = objDesignationDetailsManager.LoadDesignationCombo();
            cmbSelectDesignationForTeam.DisplayMember = "Designation_Code";
            cmbSelectDesignationForTeam.ValueMember = "Designation_Code";
            cmbSelectDesignationForTeam.Text = "Select Designation";
            cmbSelectEmployeeForTeam.Text = "Select Employee";
            cmbTeamActive.Text = "Select Active";
            txtTeamActivityStartDate.Text = "";
            txtTeamActivityEndDate.Text = "";
        }

        private void dTPTeamActivityStartDate_CloseUp(object sender, EventArgs e)
        {
            txtTeamActivityStartDate.Text = dTPTeamActivityStartDate.Text.ToString();
        }

        //private void dTPTeamActivityEndDate_ValueChanged(object sender, EventArgs e)
        //{
        //    txtTeamActivityEndDate.Text = dTPTeamActivityEndDate.Text.ToString();
        //}

        private void cmbSelectDesignationForTeam_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (btnSaveTeam.Text == "Save Team")
            {
                if (cmbSelectDesignationForTeam.Text != "Select Designation")
                {
                    cmbSelectEmployeeForTeam.DataSource = objEmployeeDetailsManager.SearchEmployeeDesignation(cmbSelectDesignationForTeam.Text.ToString());
                    cmbSelectEmployeeForTeam.DisplayMember = "Employee_Name";
                    cmbSelectEmployeeForTeam.ValueMember = "Employee_Name";
                    cmbSelectEmployeeForTeam.Text = "Select Employee";
                }
            }
            else if (btnSaveTeam.Text == "Update Team")
            {
                if (cmbSelectDesignationForTeam.Text != "Select Designation")
                {
                    cmbSelectEmployeeForTeam.DataSource = objEmployeeDetailsManager.SearchEmployeeDesignation(cmbSelectDesignationForTeam.Text.ToString());
                    cmbSelectEmployeeForTeam.DisplayMember = "Employee_Name";
                    cmbSelectEmployeeForTeam.ValueMember = "Employee_Name";
                }
            }
        }

        private void cmbSelectDesignationForTeam_SelectedValueChanged(object sender, EventArgs e)
        {
            if (btnSaveTeam.Text == "Save Team")
            {
                if (cmbSelectDesignationForTeam.Text != "Select Designation")
                {
                    cmbSelectEmployeeForTeam.DataSource = objEmployeeDetailsManager.SearchEmployeeDesignation(cmbSelectDesignationForTeam.Text.ToString());
                    cmbSelectEmployeeForTeam.DisplayMember = "Employee_Name";
                    cmbSelectEmployeeForTeam.ValueMember = "Employee_Name";
                    cmbSelectEmployeeForTeam.Text = "Select Employee";
                }
            }
            else if (btnSaveTeam.Text == "Update Team")
            {
                if (cmbSelectDesignationForTeam.Text != "Select Designation")
                {
                    cmbSelectEmployeeForTeam.DataSource = objEmployeeDetailsManager.SearchEmployeeDesignation(cmbSelectDesignationForTeam.Text.ToString());
                    cmbSelectEmployeeForTeam.DisplayMember = "Employee_Name";
                    cmbSelectEmployeeForTeam.ValueMember = "Employee_Name";
                }
            }
        }

        private void btnSaveTeam_Click(object sender, EventArgs e)
        {
            if (txtTeamName.Text == "")
            {
                MessageBox.Show("Team Name can't be blank.");
                txtTeamName.Focus();
            }
            else if (cmbSelectDesignationForTeam.Text == "Select Designation" ||
                     cmbSelectDesignationForTeam.Text == "")
            {
                MessageBox.Show("Please select Designation.");
                cmbSelectDesignationForTeam.Focus();
            }
            else if (cmbSelectEmployeeForTeam.Text == "Select Employee" ||
                     cmbSelectEmployeeForTeam.Text == "")
            {
                MessageBox.Show("Please select Employee.");
                cmbSelectEmployeeForTeam.Focus();
            }
            else if (txtTeamActivityStartDate.Text == "")
            {
                MessageBox.Show("Activity Start Date can't be blank.");
                txtTeamActivityStartDate.Focus();
            }
            else if (cmbTeamActive.Text == "Select Active" || cmbTeamActive.Text == "")
            {
                MessageBox.Show("Please select Active for Team.");
                cmbTeamActive.Focus();
            }
            else if (cmbTeamActive.Text == "No" && txtTeamActivityEndDate.Text == "")
            {
                MessageBox.Show("Activity End Date can't be blank.");
                txtTeamActivityEndDate.Focus();
            }
            else if (txtTeamActivityEndDate.Text !="" && txtTeamActivityStartDate.Text !="" && Convert.ToDateTime(txtTeamActivityEndDate.Text) < Convert.ToDateTime(txtTeamActivityStartDate.Text))
            {
                MessageBox.Show("Activity End Date can't be small than Activity Start Date.");
                txtTeamActivityEndDate.Focus();
            }
            else
            {
                teamName = txtTeamName.Text;
                designationCode = cmbSelectDesignationForTeam.Text;
                employeeName = cmbSelectEmployeeForTeam.Text;
                activityStartDate = txtTeamActivityStartDate.Text;
                teamActive = cmbTeamActive.Text;
                activityEndDate = txtTeamActivityEndDate.Text;
                teamId = Convert.ToInt16(GlobalClass.GroupIdForUpdateGroup);

                if (btnSaveTeam.Text == "Save Team")
                {
                    objGroupDetailsManager.InsertTeam(teamName, employeeName, designationCode, activityStartDate, teamActive);
                    objGroupDetailsManager.InsertTeamDetails(teamName, employeeName, designationCode, activityStartDate, teamActive);
                    btnAddTeam.Enabled = true;
                    btnSaveTeam.Enabled = false;
                    MessageBox.Show("Team Added Succesfully");
                }
                else if (btnSaveTeam.Text == "Update Team")
                {
                    if (GlobalClass.PreviousTeamName != txtTeamName.Text && GlobalClass.PreviousEmpNameFromTeam == cmbSelectEmployeeForTeam.Text)
                    {
                        if (MessageBox.Show("Do you want to Update Team " + GlobalClass.PreviousTeamName + " as " + txtTeamName.Text + " ? All Previous Data and Records of " + GlobalClass.PreviousTeamName + " will be updated as " + txtTeamName.Text + " from now on.", "Save!", MessageBoxButtons.YesNo) == DialogResult.Yes)
                        {
                            //objGroupDetailsManager.UpdateTeam(teamId, teamName, employeeName, designationCode, activityStartDate, activityEndDate, teamActive);
                            //objGroupDetailsManager.UpdateTeamDetails(teamId, teamName, employeeName, designationCode, activityStartDate, activityEndDate, teamActive);
                            //btnAddTeam.Enabled = true;
                            //btnSaveTeam.Enabled = false;
                            //MessageBox.Show("Team Updated Succesfully");
                            
                            UpdateTeam();
                        }
                    }
                    else if (GlobalClass.PreviousTeamName == txtTeamName.Text && GlobalClass.PreviousEmpNameFromTeam != cmbSelectEmployeeForTeam.Text)
                    {
                        if (MessageBox.Show("Do you want to Update Employee of " + GlobalClass.PreviousTeamName + " ? All Data and Records of " + GlobalClass.PreviousEmpNameFromTeam + " for " + GlobalClass.PreviousTeamName + " will be Updated as " + cmbSelectEmployeeForTeam.Text + " from now on.", "Save!", MessageBoxButtons.YesNo) == DialogResult.Yes)
                        {
                            //objGroupDetailsManager.UpdateTeam(teamId, teamName, employeeName, designationCode, activityStartDate, activityEndDate, teamActive);
                            //objGroupDetailsManager.UpdateTeamDetails(teamId, teamName, employeeName, designationCode, activityStartDate, activityEndDate, teamActive);
                            //btnAddTeam.Enabled = true;
                            //btnSaveTeam.Enabled = false;
                            //MessageBox.Show("Team Updated Succesfully");
                            
                            UpdateTeam();
                        }
                    }
                    else if (GlobalClass.PreviousTeamName != txtTeamName.Text && GlobalClass.PreviousEmpNameFromTeam != cmbSelectEmployeeForTeam.Text)
                    {
                        if (MessageBox.Show("Do you want to Update " + GlobalClass.PreviousTeamName + " and Employee of " + GlobalClass.PreviousTeamName + " ? All Data and Records will be Updated as " + txtTeamName.Text + " and Employee for " + txtTeamName.Text + " as " + cmbSelectEmployeeForTeam.Text + " from now on.", "Save!", MessageBoxButtons.YesNo) == DialogResult.Yes)
                        {
                            //objGroupDetailsManager.UpdateTeam(teamId, teamName, employeeName, designationCode, activityStartDate, activityEndDate, teamActive);
                            //objGroupDetailsManager.UpdateTeamDetails(teamId, teamName, employeeName, designationCode, activityStartDate, activityEndDate, teamActive);
                            //btnAddTeam.Enabled = true;
                            //btnSaveTeam.Enabled = false;
                            //MessageBox.Show("Team Updated Succesfully");

                            UpdateTeam();
                        }
                    }
                    else
                    {
                        UpdateTeam();
                    }
                }
                RefreshTeam();
            }
        }

        private void UpdateTeam()
        {
            if (cmbTeamActive.Text == "No" && txtTeamActivityEndDate.Text != "")
            {
                objGroupDetailsManager.UpdateTeamWithActivateEndDate(teamId, teamName, employeeName, designationCode, activityStartDate, activityEndDate, teamActive);
                objGroupDetailsManager.UpdateTeamDetailsWithActivateEndDate(teamId, teamName, employeeName, designationCode, activityStartDate, activityEndDate, teamActive);
                btnAddTeam.Enabled = true;
                btnSaveTeam.Enabled = false;
                MessageBox.Show("Team Updated Succesfully");
            }
            else
            {
                objGroupDetailsManager.UpdateTeam(teamId, teamName, employeeName, designationCode, activityStartDate, activityEndDate, teamActive);
                objGroupDetailsManager.UpdateTeamDetails(teamId, teamName, employeeName, designationCode, activityStartDate, activityEndDate, teamActive);
                btnAddTeam.Enabled = true;
                btnSaveTeam.Enabled = false;
                MessageBox.Show("Team Updated Succesfully");
            }
        }

        private void cmbTeamActive_SelectedValueChanged_1(object sender, EventArgs e)
        {
            if (cmbTeamActive.Text == "No")
            {
                txtTeamActivityEndDate.Enabled = true;
                dTPTeamActivityEndDate.Enabled = true;
                txtTeamActivityEndDate.Focus();
            }
            else if (cmbTeamActive.Text == "Yes")
            {
                txtTeamActivityEndDate.Text = "";
                txtTeamActivityEndDate.Enabled = false;
                dTPTeamActivityEndDate.Enabled = false;
            }
        }

        private void RefreshTeam()
        {
            ClearTeamTab();

            if (txtTeamName.Enabled == true)
            {
                txtTeamName.Enabled = false;
            }
            if (cmbSelectDesignationForTeam.Enabled == true)
            {
                cmbSelectDesignationForTeam.Enabled = false;
            }
            if (cmbSelectEmployeeForTeam.Enabled == true)
            {
                cmbSelectEmployeeForTeam.Enabled = false;
            }
            if (txtTeamActivityStartDate.Enabled == true)
            {
                txtTeamActivityStartDate.Enabled = false;
            }
            if (dTPTeamActivityStartDate.Enabled == true)
            {
                dTPTeamActivityStartDate.Enabled = false;
            }
            if (txtTeamActivityEndDate.Enabled == true)
            {
                txtTeamActivityEndDate.Enabled = false;
            }
            if (dTPTeamActivityEndDate.Enabled == true)
            {
                dTPTeamActivityEndDate.Enabled = false;
            }
            if (cmbTeamActive.Enabled == true)
            {
                cmbTeamActive.Enabled = false;
            }
            if (btnAddTeam.Enabled == false)
            {
                btnAddTeam.Enabled = true;
            }
            if (btnSaveTeam.Text == "Update Team")
            {
                btnSaveTeam.Text = "Save Team";
            }
            if (btnSaveTeam.Enabled == true)
            {
                btnSaveTeam.Enabled = false;
            }
            
            dataGridViewTeamDetails.DataSource = objGroupDetailsManager.ShowAllTeam();
            dataGridViewTeamDetails.Columns[0].Visible = false;
            DataGridViewTeamDetailsHeaderText();
            btnAddTeam.Focus();
        }

        private void TeamUI_Load(object sender, EventArgs e)
        {
            RefreshTeam();
        }

        public void DataGridViewTeamDetailsHeaderText()
        {
            dataGridViewTeamDetails.Columns[1].HeaderText = "Team Name";
            dataGridViewTeamDetails.Columns[2].HeaderText = "Employee Name";
            dataGridViewTeamDetails.Columns[3].HeaderText = "Designation Code";
            dataGridViewTeamDetails.Columns[4].HeaderText = "Activity Start Date";
            dataGridViewTeamDetails.Columns[5].HeaderText = "Activity End Date";
        }

        private void dataGridViewTeamDetails_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (btnSaveTeam.Enabled == false)
            {
                btnSaveTeam.Enabled = true;
            }
            btnSaveTeam.Text = "Update Team";
            GlobalClass.GroupIdForUpdateGroup = dataGridViewTeamDetails.CurrentRow.Cells[0].Value.ToString();
            GlobalClass.PreviousTeamName = dataGridViewTeamDetails.CurrentRow.Cells[1].Value.ToString();
            txtTeamName.Text = dataGridViewTeamDetails.CurrentRow.Cells[1].Value.ToString();
            cmbSelectDesignationForTeam.Text = dataGridViewTeamDetails.CurrentRow.Cells[3].Value.ToString();
            GlobalClass.PreviousEmpNameFromTeam = dataGridViewTeamDetails.CurrentRow.Cells[2].Value.ToString();
            cmbSelectEmployeeForTeam.Text = dataGridViewTeamDetails.CurrentRow.Cells[2].Value.ToString();
            txtTeamActivityStartDate.Text = dataGridViewTeamDetails.CurrentRow.Cells[4].Value.ToString();
            txtTeamActivityStartDate.Text = txtTeamActivityStartDate.Text.Replace("12:00:00 AM", "");
            txtTeamActivityStartDate.Text = txtTeamActivityStartDate.Text.Trim();
            txtTeamActivityEndDate.Text = dataGridViewTeamDetails.CurrentRow.Cells[5].Value.ToString();
            if (txtTeamActivityEndDate.Text != "")
            {
                txtTeamActivityEndDate.Text = txtTeamActivityEndDate.Text.Replace("12:00:00 AM", "");
                txtTeamActivityEndDate.Text = txtTeamActivityEndDate.Text.Trim();
            }
            cmbTeamActive.Text = dataGridViewTeamDetails.CurrentRow.Cells[6].Value.ToString();
            if (txtTeamName.Enabled == false)
            {
                txtTeamName.Enabled = true;
            }
            if (cmbSelectDesignationForTeam.Enabled == false)
            {
                cmbSelectDesignationForTeam.Enabled = true;
            }
            if (cmbSelectEmployeeForTeam.Enabled == false)
            {
                cmbSelectEmployeeForTeam.Enabled = true;
            }
            if (txtTeamActivityStartDate.Enabled == false)
            {
                txtTeamActivityStartDate.Enabled = true;
            }
            if (dTPTeamActivityStartDate.Enabled == false)
            {
                dTPTeamActivityStartDate.Enabled = true;
            }
            if (txtTeamActivityEndDate.Text != "")
            {
                txtTeamActivityEndDate.Enabled = true;
                dTPTeamActivityEndDate.Enabled = true;
            }
            else
            {
                txtTeamActivityEndDate.Enabled = false;
                dTPTeamActivityEndDate.Enabled = false;
            }
            
            if (cmbTeamActive.Enabled == false)
            {
                cmbTeamActive.Enabled = true;
            }
            if (btnAddTeam.Enabled == false)
            {
                btnAddTeam.Enabled = true;
            }
            if (btnSaveTeam.Text == "Save Team")
            {
                btnSaveTeam.Text = "Update Team";
            }
        }

        private void btnRefreshTeam_Click(object sender, EventArgs e)
        {
            RefreshTeam();
        }

        private void dTPTeamActivityEndDate_CloseUp(object sender, EventArgs e)
        {
            txtTeamActivityEndDate.Text = dTPTeamActivityEndDate.Text.ToString();
            txtTeamActivityEndDate.Focus();
        }
    }
}
