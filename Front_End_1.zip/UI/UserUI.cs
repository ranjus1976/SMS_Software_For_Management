﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using SMSapplication.BLL;
using SMSapplication.DAL;
using SMSapplication.DAL.DAO;
using SMSapplication.DAL.Gateway;
using SMSapplication.UI;

namespace SMSapplication.UI
{
    public partial class UserUI : Form
    {
        UserDetailsManager objUserDetailsManager = new UserDetailsManager();
        UserRoleDetailsManager objUserRoleDetailsManager = new UserRoleDetailsManager();
        GlobalClass objGlobalClass = new GlobalClass();
        public UserUI()
        {
            InitializeComponent();
            RefreshUser();
        }

        private void UserUI_Load(object sender, EventArgs e)
        {
            RefreshUser();
            
            cmbUserRole.DataSource = objUserDetailsManager.com_UserType_Display();
            cmbUserRole.DisplayMember = "User_Role";
            cmbUserRole.ValueMember = "User_Role";
            cmbUserRole.Text = "Select User Role";
            txtRoleID.Text = "";

            dataGridViewUserDetails.DataSource = objUserDetailsManager.AllUserDetails();
            dataGridViewUserDetails.Columns[0].Visible = false;
            dataGridViewUserDetails.Columns[3].Visible = false;
            DataGridViewUserDetailsHeaderText();
        }

        public void DataGridViewUserDetailsHeaderText()
        {
            //dataGridViewEmployeeList.Columns[1].HeaderText = "Employee Name";
            dataGridViewUserDetails.Columns[1].HeaderText = "User Name";
            dataGridViewUserDetails.Columns[4].HeaderText = "User Role";
            //dataGridViewUserDetails.Columns[5].HeaderText = "Enable / Disable";
        }

        private void cmbUserRole_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.txtRoleID.Text = objUserRoleDetailsManager.GetUserRoleID(cmbUserRole.Text);
        }

        private void cmbUserRole_SelectedValueChanged(object sender, EventArgs e)
        {
            this.txtRoleID.Text = objUserRoleDetailsManager.GetUserRoleID(cmbUserRole.Text);
        }

        public void ClearCreateUserTab()
        {
            txtUserName.Text = "";
            txtPassword.Text = "";
            cmbUserRole.Text = "Select User Role";
            txtRoleID.Text = "";
            cmbActive.Text = "Select Active";
        }

        private void RefreshUser()
        {
            ClearCreateUserTab();

            if (btnSaveUser.Enabled == true)
            {
                btnSaveUser.Enabled = false;
            }

            if (txtUserName.Enabled == true)
            {
                txtUserName.Enabled = false;
            }

            if (txtPassword.Enabled == true)
            {
                txtPassword.Enabled = false;
            }

            if (cmbUserRole.Enabled == true)
            {
                cmbUserRole.Enabled = false;
            }

            if (cmbActive.Enabled == true)
            {
                cmbActive.Enabled = false;
            }

            if (btnSaveUser.Text == "Update User")
            {
                btnSaveUser.Text = "Save User";
            }
            dataGridViewUserDetails.DataSource = objUserDetailsManager.AllUserDetails();
            dataGridViewUserDetails.Columns[0].Visible = false;
            dataGridViewUserDetails.Columns[3].Visible = false;
            //dataGridViewUserDetails.Columns[6].Visible = false;
            DataGridViewUserDetailsHeaderText();
            btnAddUser.Focus();
        }

        private void btnAddUser_Click(object sender, EventArgs e)
        {
            if (txtUserName.Enabled == false)
            {
                txtUserName.Enabled = true;
            }

            if (txtPassword.Enabled == false)
            {
                txtPassword.Enabled = true;
            }

            if (cmbUserRole.Enabled == false)
            {
                cmbUserRole.Enabled = true;
            }

            if (cmbActive.Enabled == false)
            {
                cmbActive.Enabled = true;
            }

            if (btnSaveUser.Enabled == false)
            {
                btnSaveUser.Enabled = true;
            }

            if (btnSaveUser.Text == "Update User")
            {
                btnSaveUser.Text = "Save User";
            }
            ClearCreateUserTab();
            txtUserName.Focus();
        }

        private void btnSaveUser_Click(object sender, EventArgs e)
        {
            string userName;
            string password;
            string passwordDecrypt;
            int userRoleID;
            string userRoleName;
            string activate;
            int userID;

            if (txtUserName.Text == "")
            {
                MessageBox.Show("User Name can't be blank.");
                txtUserName.Focus();
            }
            else if (txtPassword.Text == "")
            {
                MessageBox.Show("Password can't be blank.");
                txtPassword.Focus();
            }
            else if (cmbUserRole.Text == "")
            {
                MessageBox.Show("User Role can't be blank.");
                cmbUserRole.Focus();
            }
            else if (cmbActive.Text == "" || cmbActive.Text == "Select Active")
            {
                MessageBox.Show("User Activation can't be blank.");
                cmbActive.Focus();
            }
            else
            {
                if (btnSaveUser.Text == "Save User")
                {
                    userName = txtUserName.Text;
                    password = objGlobalClass.Encrypt(txtPassword.Text);
                    userRoleID = Convert.ToInt32(txtRoleID.Text);
                    userRoleName = cmbUserRole.Text;
                    activate = cmbActive.Text;

                    objUserDetailsManager.InsertNewUser(userName, password, userRoleID, userRoleName, activate);
                    dataGridViewUserDetails.DataSource = objUserDetailsManager.AllUserDetails();
                    dataGridViewUserDetails.Columns[0].Visible = false;
                    dataGridViewUserDetails.Columns[3].Visible = false;
                    //dataGridViewUserDetails.Columns[6].Visible = false;
                    btnSaveUser.Enabled = false;
                    MessageBox.Show("User Added Succesfully");
                }
                if (btnSaveUser.Text == "Update User")
                {
                    userName = txtUserName.Text;

                    if (txtPassword.Text == GlobalClass.PasswordCheckForUserUpdate)
                    {
                        passwordDecrypt = objGlobalClass.Decrypt(txtPassword.Text);
                        password = objGlobalClass.Encrypt(passwordDecrypt);
                    }
                    else
                    {
                        password = objGlobalClass.Encrypt(txtPassword.Text);
                    }
                    
                    userRoleID = Convert.ToInt32(txtRoleID.Text);
                    userRoleName = cmbUserRole.Text;
                    activate = cmbActive.Text;

                    userID = Convert.ToInt32(GlobalClass.UserIdForEditUserDetails);
                    objUserDetailsManager.UpdateUser(userID, userName, password, userRoleID, userRoleName, activate);
                    dataGridViewUserDetails.DataSource = objUserDetailsManager.AllUserDetails();
                    dataGridViewUserDetails.Columns[0].Visible = false;
                    dataGridViewUserDetails.Columns[3].Visible = false;
                    //dataGridViewUserDetails.Columns[6].Visible = false;
                    btnSaveUser.Text = "Save User";
                    btnSaveUser.Enabled = false;
                    MessageBox.Show("User Updated Succesfully");
                }

                ClearCreateUserTab();

                if (btnSaveUser.Enabled == true)
                {
                    btnSaveUser.Enabled = false;
                }

                if (txtUserName.Enabled == true)
                {
                    txtUserName.Enabled = false;
                }

                if (txtPassword.Enabled == true)
                {
                    txtPassword.Enabled = false;
                }

                if (cmbUserRole.Enabled == true)
                {
                    cmbUserRole.Enabled = false;
                }

                if (cmbActive.Enabled == true)
                {
                    cmbActive.Enabled = false;
                }

                if (btnSaveUser.Text == "Update User")
                {
                    btnSaveUser.Text = "Save User";
                }
            }

            DataGridViewUserDetailsHeaderText();
        }

        private void btnUserReport_Click(object sender, EventArgs e)
        {
            UserReportUI objUserReportUI = new UserReportUI();
            objUserReportUI.ShowDialog();
        }

        private void btnRefreshUser_Click(object sender, EventArgs e)
        {
            RefreshUser();
        }

        private void dataGridViewUserDetails_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (btnSaveUser.Enabled == false)
            {
                btnSaveUser.Enabled = true;
            }

            if (txtUserName.Enabled == false)
            {
                txtUserName.Enabled = true;
            }

            if (txtPassword.Enabled == false)
            {
                txtPassword.Enabled = true;
            }

            if (cmbUserRole.Enabled == false)
            {
                cmbUserRole.Enabled = true;
            }

            if (cmbActive.Enabled == false)
            {
                cmbActive.Enabled = true;
            }

            btnSaveUser.Text = "Update User";
            GlobalClass.UserIdForEditUserDetails = dataGridViewUserDetails.CurrentRow.Cells[0].Value.ToString();
            GlobalClass.PasswordCheckForUserUpdate = dataGridViewUserDetails.CurrentRow.Cells[2].Value.ToString();
            txtUserName.Text = dataGridViewUserDetails.CurrentRow.Cells[1].Value.ToString();
            txtPassword.Text = dataGridViewUserDetails.CurrentRow.Cells[2].Value.ToString();
            cmbUserRole.Text = dataGridViewUserDetails.CurrentRow.Cells[4].Value.ToString();
            txtRoleID.Text = dataGridViewUserDetails.CurrentRow.Cells[3].Value.ToString();
            cmbActive.Text = dataGridViewUserDetails.CurrentRow.Cells[5].Value.ToString();
        }

        private void dataGridViewUserDetails_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            //if (btnSaveUser.Enabled == false)
            //{
            //    btnSaveUser.Enabled = true;
            //}
            //btnSaveUser.Text = "Update User";
            //GlobalClass.UserIdForEditUserDetails = dataGridViewUserDetails.CurrentRow.Cells[0].Value.ToString();
            //GlobalClass.Password = dataGridViewUserDetails.CurrentRow.Cells[2].Value.ToString();
            //txtUserName.Text = dataGridViewUserDetails.CurrentRow.Cells[1].Value.ToString();
            //txtPassword.Text = dataGridViewUserDetails.CurrentRow.Cells[2].Value.ToString();
            //cmbUserRole.Text = dataGridViewUserDetails.CurrentRow.Cells[4].Value.ToString();
            //txtRoleID.Text = dataGridViewUserDetails.CurrentRow.Cells[3].Value.ToString();
            //cmbActive.Text = dataGridViewUserDetails.CurrentRow.Cells[5].Value.ToString();

            if (btnSaveUser.Enabled == false)
            {
                btnSaveUser.Enabled = true;
            }

            if (txtUserName.Enabled == false)
            {
                txtUserName.Enabled = true;
            }

            if (txtPassword.Enabled == false)
            {
                txtPassword.Enabled = true;
            }

            if (cmbUserRole.Enabled == false)
            {
                cmbUserRole.Enabled = true;
            }

            if (cmbActive.Enabled == false)
            {
                cmbActive.Enabled = true;
            }

            btnSaveUser.Text = "Update User";
            GlobalClass.UserIdForEditUserDetails = dataGridViewUserDetails.CurrentRow.Cells[0].Value.ToString();
            GlobalClass.PasswordCheckForUserUpdate = dataGridViewUserDetails.CurrentRow.Cells[2].Value.ToString();
            txtUserName.Text = dataGridViewUserDetails.CurrentRow.Cells[1].Value.ToString();
            txtPassword.Text = dataGridViewUserDetails.CurrentRow.Cells[2].Value.ToString();
            cmbUserRole.Text = dataGridViewUserDetails.CurrentRow.Cells[4].Value.ToString();
            txtRoleID.Text = dataGridViewUserDetails.CurrentRow.Cells[3].Value.ToString();
            cmbActive.Text = dataGridViewUserDetails.CurrentRow.Cells[5].Value.ToString();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
