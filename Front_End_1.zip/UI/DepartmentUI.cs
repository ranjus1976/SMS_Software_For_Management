﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using SMSapplication.BLL;
using SMSapplication.DAL;
using SMSapplication.DAL.DAO;
using SMSapplication.DAL.Gateway;
using SMSapplication.UI;

namespace SMSapplication.UI
{
    public partial class DepartmentUI : Form
    {
        DepartmentDetailsManager objDepartmentDetailsManager = new DepartmentDetailsManager();
        
        public DepartmentUI()
        {
            InitializeComponent();
            RefreshDept();
        }

        private void DepartmentUI_Load(object sender, EventArgs e)
        {
            RefreshDept();
        }

        public void DataGridViewDepartmentDetailsHeaderText()
        {
            dataGridViewDepartmentDetails.Columns[1].HeaderText = "Department Name";
            //dataGridViewDepartmentDetails.Columns[2].HeaderText = "Enable / Disable";
        }

        private void RefreshDept()
        {
            ClearDepartmentTab();

            if (txtDepartment.Enabled == true)
            {
                txtDepartment.Enabled = false;
            }
            if (cmbActiveDepartment.Enabled == true)
            {
                cmbActiveDepartment.Enabled = false;
            }
            if (btnSaveDepartment.Enabled == true)
            {
                btnSaveDepartment.Enabled = false;
            }
            if (btnAddDepartment.Enabled == false)
            {
                btnAddDepartment.Enabled = true;
            }
            if (btnSaveDepartment.Text == "Update Department")
            {
                btnSaveDepartment.Text = "Save Department";
            }
            dataGridViewDepartmentDetails.DataSource = objDepartmentDetailsManager.AllDepartmentDetails();
            dataGridViewDepartmentDetails.Columns[0].Visible = false;
            DataGridViewDepartmentDetailsHeaderText();
            btnAddDepartment.Focus();
        }

        public void ClearDepartmentTab()
        {
            txtDepartment.Text = "";
            cmbActiveDepartment.Text = "Select Active";
        }

        private void btnAddDepartment_Click(object sender, EventArgs e)
        {
            if (btnSaveDepartment.Enabled == false)
            {
                btnSaveDepartment.Enabled = true;
            }

            if (btnSaveDepartment.Text == "Update Department")
            {
                btnSaveDepartment.Text = "Save Department";
            }
            if (txtDepartment.Enabled == false)
            {
                txtDepartment.Enabled = true;
            }
            if (cmbActiveDepartment.Enabled == false)
            {
                cmbActiveDepartment.Enabled = true;
            }
            ClearDepartmentTab();
            txtDepartment.Focus();
        }

        private void btnSaveDepartment_Click(object sender, EventArgs e)
        {
            string deptName;
            string activateDepartment;
            int deptID;

            deptName = txtDepartment.Text;
            activateDepartment = cmbActiveDepartment.Text;

            if (txtDepartment.Text == "")
            {
                MessageBox.Show("Department Name can't be blank.");
                txtDepartment.Focus();
            }
            else if (cmbActiveDepartment.Text == "" || cmbActiveDepartment.Text == "Select Active")
            {
                MessageBox.Show("Department Activation can't be blank.");
                cmbActiveDepartment.Focus();
            }
            else
            {
                if (btnSaveDepartment.Text == "Save Department")
                {
                    objDepartmentDetailsManager.InsertNewDepartment(deptName, activateDepartment);
                    dataGridViewDepartmentDetails.Refresh();
                    dataGridViewDepartmentDetails.DataSource = objDepartmentDetailsManager.AllDepartmentDetails();
                    dataGridViewDepartmentDetails.Columns[0].Visible = false;
                    btnSaveDepartment.Enabled = false;
                    MessageBox.Show("Department Added Succesfully");
                    //cmbEmployeeDepartment.DataSource = objDepartmentDetailsManager.LoadDepartmentCombo();
                    //cmbEmployeeDepartment.DisplayMember = "Department_Name";
                    //cmbEmployeeDepartment.ValueMember = "Department_Name";
                }
                else if (btnSaveDepartment.Text == "Update Department")
                {
                    deptID = Convert.ToInt32(GlobalClass.DeptIdForUpdateDepartment);
                    objDepartmentDetailsManager.UpdateDepartment(deptID, deptName, activateDepartment);
                    //objEmployeeDetailsManager.UpdateDepartmentActiveLogInEmpInfo(deptID, activateDepartment);
                    dataGridViewDepartmentDetails.Refresh();
                    dataGridViewDepartmentDetails.DataSource = objDepartmentDetailsManager.AllDepartmentDetails();
                    dataGridViewDepartmentDetails.Columns[0].Visible = false;
                    btnSaveDepartment.Text = "Save Department";
                    btnSaveDepartment.Enabled = false;
                    MessageBox.Show("Department Updated Succesfully");
                }
            }
            
            ClearDepartmentTab();

            if (txtDepartment.Enabled == true)
            {
                txtDepartment.Enabled = false;
            }
            if (cmbActiveDepartment.Enabled == true)
            {
                cmbActiveDepartment.Enabled = false;
            }
            if (btnSaveDepartment.Enabled == true)
            {
                btnSaveDepartment.Enabled = false;
            }
            if (btnAddDepartment.Enabled == false)
            {
                btnAddDepartment.Enabled = true;
            }
            if (btnSaveDepartment.Text == "Update Department")
            {
                btnSaveDepartment.Text = "Save Department";
            }

            DataGridViewDepartmentDetailsHeaderText();
        }

        private void btnRefreshDepartment_Click(object sender, EventArgs e)
        {
            RefreshDept();
        }

        private void dataGridViewDepartmentDetails_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            //if (btnSaveDepartment.Enabled == false)
            //{
            //    btnSaveDepartment.Enabled = true;
            //}
            //btnSaveDepartment.Text = "Update Department";
            //GlobalClass.DeptIdForUpdateDepartment = dataGridViewDepartmentDetails.CurrentRow.Cells[0].Value.ToString();
            //txtDepartment.Text = dataGridViewDepartmentDetails.CurrentRow.Cells[1].Value.ToString();
            //cmbActiveDepartment.Text = dataGridViewDepartmentDetails.CurrentRow.Cells[2].Value.ToString();

            if (btnSaveDepartment.Enabled == false)
            {
                btnSaveDepartment.Enabled = true;
            }

            btnSaveDepartment.Text = "Update Department";
            GlobalClass.DeptIdForUpdateDepartment = dataGridViewDepartmentDetails.CurrentRow.Cells[0].Value.ToString();
            txtDepartment.Text = dataGridViewDepartmentDetails.CurrentRow.Cells[1].Value.ToString();
            cmbActiveDepartment.Text = dataGridViewDepartmentDetails.CurrentRow.Cells[2].Value.ToString();

            if (txtDepartment.Enabled == false)
            {
                txtDepartment.Enabled = true;
            }
            if (cmbActiveDepartment.Enabled == false)
            {
                cmbActiveDepartment.Enabled = true;
            }
        }

        private void dataGridViewDepartmentDetails_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (btnSaveDepartment.Enabled == false)
            {
                btnSaveDepartment.Enabled = true;
            }

            btnSaveDepartment.Text = "Update Department";
            GlobalClass.DeptIdForUpdateDepartment = dataGridViewDepartmentDetails.CurrentRow.Cells[0].Value.ToString();
            txtDepartment.Text = dataGridViewDepartmentDetails.CurrentRow.Cells[1].Value.ToString();
            cmbActiveDepartment.Text = dataGridViewDepartmentDetails.CurrentRow.Cells[2].Value.ToString();

            if (txtDepartment.Enabled == false)
            {
                txtDepartment.Enabled = true;
            }
            if (cmbActiveDepartment.Enabled == false)
            {
                cmbActiveDepartment.Enabled = true;
            }
        }

        private void btnDepartmentReport_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Development Under Process .....");
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
