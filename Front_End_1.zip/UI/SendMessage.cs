﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.ms.sms;
using System.IO.Ports;

namespace SMSapplication
{
    public partial class SendMessage : Form
    {
        public SendMessage()
        {
            InitializeComponent();
        }
        SMSGateway objclsSMS= new SMSGateway();
        PortConnection conn = new PortConnection();
        SerialPort port = new SerialPort();
        private void btnSend_Click(object sender, EventArgs e)
        {
            try
            {
               
               port = conn.ConnectPort("COM5");
               if (!port.IsOpen)
               {
                   port.Open();
               }
              if(objclsSMS.IsConnected())
                {

               if (objclsSMS.Send(port,txtPhoneNo.Text, this.txtMessage.Text))
               {
                   //MessageBox.Show("Message has sent successfully");
                   this.statusBar1.Text = "Message has sent successfully";
               }
               else
               {
                   //MessageBox.Show("Failed to send message");
                   this.statusBar1.Text = "Failed to send message";
               }
               }
                //String[] phones={"+8801764010666","123456","123456"};
                //if (objclsSMS.Send(port, phones, this.txtMessage.Text))
                //{
                //    //MessageBox.Show("Message has sent successfully");
                //    this.statusBar1.Text = "Message has sent successfully";
                //}
                //else
                //{
                //    //MessageBox.Show("Failed to send message");
                //    this.statusBar1.Text = "Failed to send message";
                //}

            }
            catch (Exception ex)
            {
                //ErrorLog(ex.Message);
            }
        }
    }
}
