﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using SMSapplication.DAL.DAO;

namespace SMSapplication.UI
{
    public partial class SelectOptionUI : Form
    {
        public SelectOptionUI()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            if (radioButtonSMSApplication.Checked == true)
            {
                //radioButtonSMSManagement.Checked = false;
                //SMSapplication objSmSapplication = new SMSapplication();
                //objSmSapplication.ShowDialog();
                //this.Close();
                this.Close();
                //ActiveForm.Close();
                GlobalClass.SelectOption = 1;
                SMSapplication objSmSapplication = new SMSapplication();
                objSmSapplication.ShowDialog();

            }
            else if (radioButtonSMSManagement.Checked == true)
            {
                //radioButtonSMSApplication.Checked = false;
                //SMS_MDI objSmsMdi = new SMS_MDI();
                //objSmsMdi.ShowDialog();
                //this.Close();
                this.Close();
                //ActiveForm.Close();
                GlobalClass.SelectOption = 2;
                SMS_MDI objSmsMdi = new SMS_MDI();
                objSmsMdi.ShowDialog();

                // closed 10-July-2016
                ////SMSapplication objSmSapplication = new SMSapplication();
                ////objSmSapplication.ShowDialog();
                ////this.Close();
                // End closed 10-July-2016
            }
        }
    }
}
