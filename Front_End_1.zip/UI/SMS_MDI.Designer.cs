﻿namespace SMSapplication.UI
{
    partial class SMS_MDI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SMS_MDI));
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.applicationMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.logOffUser = new System.Windows.Forms.ToolStripMenuItem();
            this.databaseBackup = new System.Windows.Forms.ToolStripMenuItem();
            this.exitApplication = new System.Windows.Forms.ToolStripMenuItem();
            this.basicSetupMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.addEditUser = new System.Windows.Forms.ToolStripMenuItem();
            this.addEditDepartment = new System.Windows.Forms.ToolStripMenuItem();
            this.addEditDesignation = new System.Windows.Forms.ToolStripMenuItem();
            this.addEditEmployee = new System.Windows.Forms.ToolStripMenuItem();
            this.addEditProduct = new System.Windows.Forms.ToolStripMenuItem();
            this.productPriceLog = new System.Windows.Forms.ToolStripMenuItem();
            this.salesMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.teamMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.addEditTeam = new System.Windows.Forms.ToolStripMenuItem();
            this.teamTransfer = new System.Windows.Forms.ToolStripMenuItem();
            this.divisionMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.addEditDivision = new System.Windows.Forms.ToolStripMenuItem();
            this.divisionTransfer = new System.Windows.Forms.ToolStripMenuItem();
            this.regionMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.addEditRegion = new System.Windows.Forms.ToolStripMenuItem();
            this.regionTransfer = new System.Windows.Forms.ToolStripMenuItem();
            this.zoneMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.addEditZone = new System.Windows.Forms.ToolStripMenuItem();
            this.zoneTransfer = new System.Windows.Forms.ToolStripMenuItem();
            this.areaMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.addEditArea = new System.Windows.Forms.ToolStripMenuItem();
            this.areaTransfer = new System.Windows.Forms.ToolStripMenuItem();
            this.marketMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.addEditMarket = new System.Windows.Forms.ToolStripMenuItem();
            this.marketTransfer = new System.Windows.Forms.ToolStripMenuItem();
            this.salesTargetMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.addEditSalesTarget = new System.Windows.Forms.ToolStripMenuItem();
            this.utilityMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.smsRelatedInfoMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.addEditInfo = new System.Windows.Forms.ToolStripMenuItem();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.teamDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.applicationMenu,
            this.basicSetupMenu,
            this.salesMenu,
            this.utilityMenu});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(1184, 24);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "MenuStrip";
            // 
            // applicationMenu
            // 
            this.applicationMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.logOffUser,
            this.databaseBackup,
            this.exitApplication});
            this.applicationMenu.Name = "applicationMenu";
            this.applicationMenu.Size = new System.Drawing.Size(80, 20);
            this.applicationMenu.Text = "&Application";
            // 
            // logOffUser
            // 
            this.logOffUser.Name = "logOffUser";
            this.logOffUser.Size = new System.Drawing.Size(164, 22);
            this.logOffUser.Text = "&Log Off";
            this.logOffUser.Click += new System.EventHandler(this.logOffUser_Click);
            // 
            // databaseBackup
            // 
            this.databaseBackup.Name = "databaseBackup";
            this.databaseBackup.Size = new System.Drawing.Size(164, 22);
            this.databaseBackup.Text = "Database &Backup";
            this.databaseBackup.Click += new System.EventHandler(this.databaseBackupToolStripMenuItem_Click);
            // 
            // exitApplication
            // 
            this.exitApplication.Name = "exitApplication";
            this.exitApplication.Size = new System.Drawing.Size(164, 22);
            this.exitApplication.Text = "E&xit";
            this.exitApplication.Click += new System.EventHandler(this.exitApplication_Click);
            // 
            // basicSetupMenu
            // 
            this.basicSetupMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addEditUser,
            this.addEditDepartment,
            this.addEditDesignation,
            this.addEditEmployee,
            this.addEditProduct,
            this.productPriceLog});
            this.basicSetupMenu.Name = "basicSetupMenu";
            this.basicSetupMenu.Size = new System.Drawing.Size(79, 20);
            this.basicSetupMenu.Text = "&Basic Setup";
            // 
            // addEditUser
            // 
            this.addEditUser.Name = "addEditUser";
            this.addEditUser.Size = new System.Drawing.Size(193, 22);
            this.addEditUser.Text = "Add / Edit &User";
            this.addEditUser.Click += new System.EventHandler(this.addEditUser_Click);
            // 
            // addEditDepartment
            // 
            this.addEditDepartment.Name = "addEditDepartment";
            this.addEditDepartment.Size = new System.Drawing.Size(193, 22);
            this.addEditDepartment.Text = "Add / Edit &Department";
            this.addEditDepartment.Click += new System.EventHandler(this.addEditDepartment_Click_1);
            // 
            // addEditDesignation
            // 
            this.addEditDesignation.Name = "addEditDesignation";
            this.addEditDesignation.Size = new System.Drawing.Size(193, 22);
            this.addEditDesignation.Text = "Add / Edit De&signation";
            this.addEditDesignation.Click += new System.EventHandler(this.addEditDesignation_Click_1);
            // 
            // addEditEmployee
            // 
            this.addEditEmployee.Name = "addEditEmployee";
            this.addEditEmployee.Size = new System.Drawing.Size(193, 22);
            this.addEditEmployee.Text = "Add / Edit &Employee";
            this.addEditEmployee.Click += new System.EventHandler(this.addEditEmployee_Click_1);
            // 
            // addEditProduct
            // 
            this.addEditProduct.Name = "addEditProduct";
            this.addEditProduct.Size = new System.Drawing.Size(193, 22);
            this.addEditProduct.Text = "Add / Edit Product";
            this.addEditProduct.Click += new System.EventHandler(this.addEditProduct_Click_1);
            // 
            // productPriceLog
            // 
            this.productPriceLog.Name = "productPriceLog";
            this.productPriceLog.Size = new System.Drawing.Size(193, 22);
            this.productPriceLog.Text = "Product Price Log";
            this.productPriceLog.Click += new System.EventHandler(this.productPriceLog_Click_1);
            // 
            // salesMenu
            // 
            this.salesMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.teamMenu,
            this.divisionMenu,
            this.regionMenu,
            this.zoneMenu,
            this.areaMenu,
            this.marketMenu,
            this.salesTargetMenu});
            this.salesMenu.Name = "salesMenu";
            this.salesMenu.Size = new System.Drawing.Size(78, 20);
            this.salesMenu.Text = "Sa&les Setup";
            // 
            // teamMenu
            // 
            this.teamMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addEditTeam,
            this.teamTransfer,
            this.teamDetailsToolStripMenuItem});
            this.teamMenu.Name = "teamMenu";
            this.teamMenu.Size = new System.Drawing.Size(152, 22);
            this.teamMenu.Text = "&Team";
            // 
            // addEditTeam
            // 
            this.addEditTeam.Name = "addEditTeam";
            this.addEditTeam.Size = new System.Drawing.Size(160, 22);
            this.addEditTeam.Text = "Add / Edit Team";
            this.addEditTeam.Click += new System.EventHandler(this.addEditTeam_Click);
            // 
            // teamTransfer
            // 
            this.teamTransfer.Name = "teamTransfer";
            this.teamTransfer.Size = new System.Drawing.Size(160, 22);
            this.teamTransfer.Text = "Team Transfer";
            this.teamTransfer.Click += new System.EventHandler(this.teamTransfer_Click);
            // 
            // divisionMenu
            // 
            this.divisionMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addEditDivision,
            this.divisionTransfer});
            this.divisionMenu.Name = "divisionMenu";
            this.divisionMenu.Size = new System.Drawing.Size(152, 22);
            this.divisionMenu.Text = "Di&vision";
            // 
            // addEditDivision
            // 
            this.addEditDivision.Name = "addEditDivision";
            this.addEditDivision.Size = new System.Drawing.Size(172, 22);
            this.addEditDivision.Text = "Add / Edit Division";
            this.addEditDivision.Click += new System.EventHandler(this.addEditDivision_Click);
            // 
            // divisionTransfer
            // 
            this.divisionTransfer.Name = "divisionTransfer";
            this.divisionTransfer.Size = new System.Drawing.Size(172, 22);
            this.divisionTransfer.Text = "Division Transfer";
            this.divisionTransfer.Click += new System.EventHandler(this.divisionTransfer_Click);
            // 
            // regionMenu
            // 
            this.regionMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addEditRegion,
            this.regionTransfer});
            this.regionMenu.Name = "regionMenu";
            this.regionMenu.Size = new System.Drawing.Size(152, 22);
            this.regionMenu.Text = "Re&gion";
            // 
            // addEditRegion
            // 
            this.addEditRegion.Name = "addEditRegion";
            this.addEditRegion.Size = new System.Drawing.Size(167, 22);
            this.addEditRegion.Text = "Add / Edit Region";
            this.addEditRegion.Click += new System.EventHandler(this.addEditRegion_Click);
            // 
            // regionTransfer
            // 
            this.regionTransfer.Name = "regionTransfer";
            this.regionTransfer.Size = new System.Drawing.Size(167, 22);
            this.regionTransfer.Text = "Region Transfer";
            this.regionTransfer.Click += new System.EventHandler(this.regionTransfer_Click);
            // 
            // zoneMenu
            // 
            this.zoneMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addEditZone,
            this.zoneTransfer});
            this.zoneMenu.Name = "zoneMenu";
            this.zoneMenu.Size = new System.Drawing.Size(152, 22);
            this.zoneMenu.Text = "&Zone";
            // 
            // addEditZone
            // 
            this.addEditZone.Name = "addEditZone";
            this.addEditZone.Size = new System.Drawing.Size(157, 22);
            this.addEditZone.Text = "Add / Edit Zone";
            this.addEditZone.Click += new System.EventHandler(this.addEditZone_Click);
            // 
            // zoneTransfer
            // 
            this.zoneTransfer.Name = "zoneTransfer";
            this.zoneTransfer.Size = new System.Drawing.Size(157, 22);
            this.zoneTransfer.Text = "Zone Transfer";
            this.zoneTransfer.Click += new System.EventHandler(this.zoneTransfer_Click);
            // 
            // areaMenu
            // 
            this.areaMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addEditArea,
            this.areaTransfer});
            this.areaMenu.Name = "areaMenu";
            this.areaMenu.Size = new System.Drawing.Size(152, 22);
            this.areaMenu.Text = "A&rea";
            // 
            // addEditArea
            // 
            this.addEditArea.Name = "addEditArea";
            this.addEditArea.Size = new System.Drawing.Size(154, 22);
            this.addEditArea.Text = "Add / Edit Area";
            this.addEditArea.Click += new System.EventHandler(this.addEditArea_Click);
            // 
            // areaTransfer
            // 
            this.areaTransfer.Name = "areaTransfer";
            this.areaTransfer.Size = new System.Drawing.Size(154, 22);
            this.areaTransfer.Text = "Area Transfer";
            this.areaTransfer.Click += new System.EventHandler(this.areaTransfer_Click);
            // 
            // marketMenu
            // 
            this.marketMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addEditMarket,
            this.marketTransfer});
            this.marketMenu.Name = "marketMenu";
            this.marketMenu.Size = new System.Drawing.Size(152, 22);
            this.marketMenu.Text = "&Market";
            // 
            // addEditMarket
            // 
            this.addEditMarket.Name = "addEditMarket";
            this.addEditMarket.Size = new System.Drawing.Size(167, 22);
            this.addEditMarket.Text = "Add / Edit Market";
            this.addEditMarket.Click += new System.EventHandler(this.addEditMarket_Click);
            // 
            // marketTransfer
            // 
            this.marketTransfer.Name = "marketTransfer";
            this.marketTransfer.Size = new System.Drawing.Size(167, 22);
            this.marketTransfer.Text = "Market Transfer";
            this.marketTransfer.Click += new System.EventHandler(this.marketTransfer_Click);
            // 
            // salesTargetMenu
            // 
            this.salesTargetMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addEditSalesTarget});
            this.salesTargetMenu.Name = "salesTargetMenu";
            this.salesTargetMenu.Size = new System.Drawing.Size(152, 22);
            this.salesTargetMenu.Text = "Sales &Target";
            // 
            // addEditSalesTarget
            // 
            this.addEditSalesTarget.Name = "addEditSalesTarget";
            this.addEditSalesTarget.Size = new System.Drawing.Size(193, 22);
            this.addEditSalesTarget.Text = "Add / Edit Sales Target";
            // 
            // utilityMenu
            // 
            this.utilityMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.smsRelatedInfoMenu});
            this.utilityMenu.Name = "utilityMenu";
            this.utilityMenu.Size = new System.Drawing.Size(50, 20);
            this.utilityMenu.Text = "&Utility";
            // 
            // smsRelatedInfoMenu
            // 
            this.smsRelatedInfoMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addEditInfo});
            this.smsRelatedInfoMenu.Name = "smsRelatedInfoMenu";
            this.smsRelatedInfoMenu.Size = new System.Drawing.Size(163, 22);
            this.smsRelatedInfoMenu.Text = "SMS Related &Info";
            // 
            // addEditInfo
            // 
            this.addEditInfo.Name = "addEditInfo";
            this.addEditInfo.Size = new System.Drawing.Size(151, 22);
            this.addEditInfo.Text = "Add / Edit Info";
            // 
            // teamDetailsToolStripMenuItem
            // 
            this.teamDetailsToolStripMenuItem.Name = "teamDetailsToolStripMenuItem";
            this.teamDetailsToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.teamDetailsToolStripMenuItem.Text = "Team Details";
            this.teamDetailsToolStripMenuItem.Click += new System.EventHandler(this.teamDetailsToolStripMenuItem_Click);
            // 
            // SMS_MDI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1184, 462);
            this.Controls.Add(this.menuStrip);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "SMS_MDI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SMS Management";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion


        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.ToolStripMenuItem applicationMenu;
        private System.Windows.Forms.ToolStripMenuItem logOffUser;
        private System.Windows.Forms.ToolStripMenuItem exitApplication;
        private System.Windows.Forms.ToolStripMenuItem salesMenu;
        private System.Windows.Forms.ToolStripMenuItem databaseBackup;
        private System.Windows.Forms.ToolStripMenuItem teamMenu;
        private System.Windows.Forms.ToolStripMenuItem divisionMenu;
        private System.Windows.Forms.ToolStripMenuItem regionMenu;
        private System.Windows.Forms.ToolStripMenuItem zoneMenu;
        private System.Windows.Forms.ToolStripMenuItem areaMenu;
        private System.Windows.Forms.ToolStripMenuItem marketMenu;
        private System.Windows.Forms.ToolStripMenuItem basicSetupMenu;
        private System.Windows.Forms.ToolStripMenuItem addEditDepartment;
        private System.Windows.Forms.ToolStripMenuItem addEditDesignation;
        private System.Windows.Forms.ToolStripMenuItem addEditEmployee;
        private System.Windows.Forms.ToolStripMenuItem utilityMenu;
        private System.Windows.Forms.ToolStripMenuItem smsRelatedInfoMenu;
        private System.Windows.Forms.ToolStripMenuItem addEditTeam;
        private System.Windows.Forms.ToolStripMenuItem teamTransfer;
        private System.Windows.Forms.ToolStripMenuItem addEditDivision;
        private System.Windows.Forms.ToolStripMenuItem divisionTransfer;
        private System.Windows.Forms.ToolStripMenuItem addEditRegion;
        private System.Windows.Forms.ToolStripMenuItem regionTransfer;
        private System.Windows.Forms.ToolStripMenuItem addEditZone;
        private System.Windows.Forms.ToolStripMenuItem zoneTransfer;
        private System.Windows.Forms.ToolStripMenuItem addEditArea;
        private System.Windows.Forms.ToolStripMenuItem areaTransfer;
        private System.Windows.Forms.ToolStripMenuItem addEditMarket;
        private System.Windows.Forms.ToolStripMenuItem marketTransfer;
        private System.Windows.Forms.ToolStripMenuItem salesTargetMenu;
        private System.Windows.Forms.ToolStripMenuItem addEditSalesTarget;
        private System.Windows.Forms.ToolStripMenuItem addEditInfo;
        private System.Windows.Forms.ToolStripMenuItem addEditUser;
        private System.Windows.Forms.ToolStripMenuItem addEditProduct;
        private System.Windows.Forms.ToolStripMenuItem productPriceLog;
        private System.Windows.Forms.ToolStripMenuItem teamDetailsToolStripMenuItem;
    }
}



