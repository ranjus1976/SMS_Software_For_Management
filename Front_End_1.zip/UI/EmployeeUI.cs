﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using SMSapplication.BLL;
using SMSapplication.DAL;
using SMSapplication.DAL.DAO;
using SMSapplication.DAL.Gateway;
using SMSapplication.UI;

namespace SMSapplication.UI
{
    public partial class EmployeeUI : Form
    {
        EmployeeDetailsManager objEmployeeDetailsManager = new EmployeeDetailsManager();
        DesignationDetailsManager objDesignationDetailsManager = new DesignationDetailsManager();
        DepartmentDetailsManager objDepartmentDetailsManager = new DepartmentDetailsManager();
        public EmployeeUI()
        {
            InitializeComponent();
            RefreshEmployee();
        }

        private void EmployeeUI_Load(object sender, EventArgs e)
        {
            RefreshEmployee();

            cmbEmployeeDesignation.DataSource = objDesignationDetailsManager.LoadDesignationCombo();
            cmbEmployeeDesignation.DisplayMember = "Designation_Code";
            cmbEmployeeDesignation.ValueMember = "Designation_Code";
            cmbEmployeeDesignation.Text = "Select Designation";

            cmbEmployeeDepartment.DataSource = objDepartmentDetailsManager.LoadDepartmentCombo();
            cmbEmployeeDepartment.DisplayMember = "Department_Name";
            cmbEmployeeDepartment.ValueMember = "Department_Name";
            cmbEmployeeDepartment.Text = "Select Department";
        }

        private void RefreshEmployee()
        {
            ClearEmployeeTab();

            if (txtEmployeeName.Enabled == true)
            {
                txtEmployeeName.Enabled = false;
            }

            if (txtAddress.Enabled == true)
            {
                txtAddress.Enabled = false;
            }

            if (txtDOB.Enabled == true)
            {
                txtDOB.Enabled = false;
            }

            if (dTPDateOfBirth.Enabled == true)
            {
                dTPDateOfBirth.Enabled = false;
            }

            if (cmbEmployeeDesignation.Enabled == true)
            {
                cmbEmployeeDesignation.Enabled = false;
            }

            if (cmbEmployeeDepartment.Enabled == true)
            {
                cmbEmployeeDepartment.Enabled = false;
            }

            if (txtOfficialCellNo.Enabled == true)
            {
                txtOfficialCellNo.Enabled = false;
            }

            if (cmbEmployeeActive.Enabled == true)
            {
                cmbEmployeeActive.Enabled = false;
            }

            if (txtQuitDate.Enabled == true)
            {
                txtQuitDate.Enabled = false;
            }

            if (dTPQuitDate.Enabled == true)
            {
                dTPQuitDate.Enabled = false;
            }

            if (btnSaveEmployee.Text == "Update Employee")
            {
                btnSaveEmployee.Text = "Save Employee";
            }

            if (btnSaveEmployee.Enabled == true)
            {
                btnSaveEmployee.Enabled = false;
            }

            if (btnAddEmployee.Enabled == false)
            {
                btnAddEmployee.Enabled = true;
            }

            if (btnSearchEmployee.Enabled == true)
            {
                btnSearchEmployee.Enabled = false;
            }

            txtSearchCriteriaForEmployee.Text = "";
            txtSearchCriteriaForEmployee.Enabled = false;

            cmbSearchCriteriaForEmployeeByDesignation.Text = "";
            cmbSearchCriteriaForEmployeeByDesignation.Enabled = false;

            dataGridViewEmployeeList.DataSource = objEmployeeDetailsManager.ShowAllEmployee();
            dataGridViewEmployeeList.Columns[0].Visible = false;
            //dataGridViewEmployeeList.Columns[4].Visible = false;
            //dataGridViewEmployeeList.Columns[6].Visible = false;
            dataGridViewEmployeeList.Columns[3].DefaultCellStyle.Format = "MM/dd/yyyy";
            DataGridViewEmployeeListHeaderText();

            btnAddEmployee.Focus();
        }

        public void DataGridViewEmployeeListHeaderText()
        {
            dataGridViewEmployeeList.Columns[1].HeaderText = "Employee Name";
            dataGridViewEmployeeList.Columns[3].HeaderText = "Date of Birth";
            dataGridViewEmployeeList.Columns[4].HeaderText = "Department Name";
            dataGridViewEmployeeList.Columns[5].HeaderText = "Designation Code";
            dataGridViewEmployeeList.Columns[6].HeaderText = "Personal Cell No";
            dataGridViewEmployeeList.Columns[7].HeaderText = "Quit Date";
            //dataGridViewEmployeeList.Columns[8].HeaderText = "Active";
        }

        public void ClearEmployeeTab()
        {
            txtEmployeeName.Text = "";
            txtAddress.Text = "";
            txtDOB.Text = "";
            //dTPDateOfBirth.Text = "";
            cmbEmployeeDesignation.Text = "Select Designation";
            cmbEmployeeDepartment.Text = "Select Department";
            txtOfficialCellNo.Text = "";
            cmbEmployeeActive.Text = "Select Active";
            //cmbEmpMarketName.Text = "";
            //txtEmpMarketID.Text = "";
            //txtEmpMarketCode.Text = "";
            txtQuitDate.Text = "";
            txtQuitDate.Enabled = false;
            dTPQuitDate.Enabled = false;
            radioBtnEmployeeName.Checked = false;
            radioBtnOfficialMobileNumber.Checked = false;
            radioBtnByGroupAndDesignation.Checked = false;
            radioBtnShowAllEmp.Checked = false;
            cmbSearchCriteriaForEmployeeByDesignation.Text = "";
            cmbSearchCriteriaForEmployeeByDesignation.Enabled = false;
            //cmbEmpMarketName.Enabled = false;
        }

        private void btnAddEmployee_Click(object sender, EventArgs e)
        {
            if (btnSaveEmployee.Enabled == false)
            {
                btnSaveEmployee.Enabled = true;
            }

            if (btnSaveEmployee.Text == "Update Department")
            {
                btnSaveEmployee.Text = "Save Department";
            }

            if (txtEmployeeName.Enabled == false)
            {
                txtEmployeeName.Enabled = true;
            }

            if (txtAddress.Enabled == false)
            {
                txtAddress.Enabled = true;
            }

            if (txtDOB.Enabled == false)
            {
                txtDOB.Enabled = true;
            }

            if (dTPDateOfBirth.Enabled == false)
            {
                dTPDateOfBirth.Enabled = true;
            }

            if (cmbEmployeeDesignation.Enabled == false)
            {
                cmbEmployeeDesignation.Enabled = true;
            }

            if (cmbEmployeeDepartment.Enabled == false)
            {
                cmbEmployeeDepartment.Enabled = true;
            }

            if (txtOfficialCellNo.Enabled == false)
            {
                txtOfficialCellNo.Enabled = true;
            }

            if (cmbEmployeeActive.Enabled == false)
            {
                cmbEmployeeActive.Enabled = true;
            }

            if (txtQuitDate.Enabled == false)
            {
                txtQuitDate.Enabled = true;
            }

            //if (dTPQuitDate.Enabled == false)
            //{
            //    dTPQuitDate.Enabled = true;
            //}

            //if (btnAddEmployee.Enabled == false)
            //{
            //    btnAddEmployee.Enabled = true;
            //}

            ClearEmployeeTab();
            txtEmployeeName.Focus();
        }

        private void btnSaveEmployee_Click(object sender, EventArgs e)
        {
            string empName;
            string empAddress;
            string empDOB;
            string empDesination;
            int empDesignationID;
            string empDepartment;
            int empDeptID;
            string empOffCellNo;
            string empGroup;
            int empGroupID;
            string empActive;
            int empID;
            string empDesiActive;
            string empDeptActive;
            string empGroupActive;
            int empMarketID;
            string empMarketCode;
            string empNameOfMarket;
            string empQuitDate;

            empName = txtEmployeeName.Text;
            empAddress = txtAddress.Text;
            //empDOB = dTPDateOfBirth.Text;
            empDOB = txtDOB.Text;
            empDesination = cmbEmployeeDesignation.Text;
            empDepartment = cmbEmployeeDepartment.Text;
            empOffCellNo = txtOfficialCellNo.Text;
            empActive = cmbEmployeeActive.Text;

            //if (txtEmpMarketID.Text == "")
            //{
            //    empMarketID = 0;
            //    empMarketCode = txtEmpMarketCode.Text;
            //    empNameOfMarket = cmbEmpMarketName.Text;
            //}
            //else
            //{
            //    empMarketID = Convert.ToInt32(txtEmpMarketID.Text);
            //    empMarketCode = txtEmpMarketCode.Text;
            //    empNameOfMarket = cmbEmpMarketName.Text;
            //}

            empQuitDate = txtQuitDate.Text;

            if (txtEmployeeName.Text == "")
            {
                MessageBox.Show("Employee Name can't be blank.");
                txtEmployeeName.Focus();
            }
            else if (txtAddress.Text == "")
            {
                MessageBox.Show("Employee's Address can't be blank.");
                txtAddress.Focus();
            }
            else if (txtDOB.Text == "")
            {
                MessageBox.Show("Date of Birth can't be blank.");
                txtDOB.Focus();
            }
            else if (cmbEmployeeDesignation.Text == "" || cmbEmployeeDesignation.Text == "Select Designation")
            {
                MessageBox.Show("Please select Designation.");
                cmbEmployeeDesignation.Focus();
            }
            else if (cmbEmployeeDepartment.Text == "" || cmbEmployeeDepartment.Text == "Select Department")
            {
                MessageBox.Show("Please select Department.");
                cmbEmployeeDepartment.Focus();
            }
            else if (cmbEmployeeActive.Text == "" || cmbEmployeeActive.Text == "Select Active")
            {
                MessageBox.Show("Employee Activation can't be blank.");
                cmbEmployeeActive.Focus();
            }
            else if (txtQuitDate.Enabled == true && dTPQuitDate.Enabled == true)
            {
                if (txtQuitDate.Text == "")
                {
                    MessageBox.Show("Employee Quit Date can't be blank.");
                    txtQuitDate.Focus();
                }
            }
            else
            {
                if (btnSaveEmployee.Text == "Save Employee")
                {
                    objEmployeeDetailsManager.InsertEmployee(empName, empAddress, empDOB, empDesination, empDepartment, empOffCellNo, empActive, empQuitDate);

                    dataGridViewEmployeeList.Refresh();
                    dataGridViewEmployeeList.DataSource = objEmployeeDetailsManager.ShowAllEmployee();
                    dataGridViewEmployeeList.Columns[0].Visible = false;
                    dataGridViewEmployeeList.Columns[3].DefaultCellStyle.Format = "MM/dd/yyyy";
                    btnAddEmployee.Enabled = true;
                    btnSaveEmployee.Enabled = false;
                    MessageBox.Show("Employee Added Succesfully");
                }
                else if (btnSaveEmployee.Text == "Update Employee")
                {
                    empID = Convert.ToInt32(GlobalClass.EmpIDforUpdateEmployee);
                    objEmployeeDetailsManager.UpdateEmployee(empID, empName, empAddress, empDOB, empDesination, empDepartment, empOffCellNo, empActive, empQuitDate); // empDesiActive, empDeptActive, empGroupActive, //, empDesiActive, empDeptActive, empGroupActive, empMarketID, empMarketCode, empNameOfMarket

                    dataGridViewEmployeeList.Refresh();
                    dataGridViewEmployeeList.DataSource = objEmployeeDetailsManager.ShowAllEmployee();
                    dataGridViewEmployeeList.Columns[0].Visible = false;
                    dataGridViewEmployeeList.Columns[3].DefaultCellStyle.Format = "MM/dd/yyyy";
                    btnSaveEmployee.Text = "Save Employee";
                    btnAddEmployee.Enabled = true;
                    btnSaveEmployee.Enabled = false;
                    MessageBox.Show("Employee Updated Succesfully");
                }
            }
            
            ClearEmployeeTab();

            if (txtEmployeeName.Enabled == true)
            {
                txtEmployeeName.Enabled = false;
            }

            if (txtAddress.Enabled == true)
            {
                txtAddress.Enabled = false;
            }

            if (txtDOB.Enabled == true)
            {
                txtDOB.Enabled = false;
            }

            if (dTPDateOfBirth.Enabled == true)
            {
                dTPDateOfBirth.Enabled = false;
            }

            if (cmbEmployeeDesignation.Enabled == true)
            {
                cmbEmployeeDesignation.Enabled = false;
            }

            if (cmbEmployeeDepartment.Enabled == true)
            {
                cmbEmployeeDepartment.Enabled = false;
            }

            if (txtOfficialCellNo.Enabled == true)
            {
                txtOfficialCellNo.Enabled = false;
            }

            if (cmbEmployeeActive.Enabled == true)
            {
                cmbEmployeeActive.Enabled = false;
            }

            if (txtQuitDate.Enabled == true)
            {
                txtQuitDate.Enabled = false;
            }

            if (dTPQuitDate.Enabled == true)
            {
                dTPQuitDate.Enabled = false;
            }

            if (btnSaveEmployee.Text == "Update Employee")
            {
                btnSaveEmployee.Text = "Save Employee";
            }

            if (btnSaveEmployee.Enabled == true)
            {
                btnSaveEmployee.Enabled = false;
            }

            if (btnAddEmployee.Enabled == false)
            {
                btnAddEmployee.Enabled = true;
            }

            DataGridViewEmployeeListHeaderText();
        }

        private void dataGridViewEmployeeList_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            string dobOfEmp;
            //string quitDate;
            if (btnSaveEmployee.Enabled == false)
            {
                btnSaveEmployee.Enabled = true;
            }
            btnSaveEmployee.Text = "Update Employee";
            GlobalClass.EmpIDforUpdateEmployee = dataGridViewEmployeeList.CurrentRow.Cells[0].Value.ToString();
            txtEmployeeName.Text = dataGridViewEmployeeList.CurrentRow.Cells[1].Value.ToString();
            txtAddress.Text = dataGridViewEmployeeList.CurrentRow.Cells[2].Value.ToString();
            //dobOfEmp = String.Format("MM/dd/yyyy", dataGridViewEmployeeList.CurrentRow.Cells[3].Value.ToString());

            dobOfEmp = dataGridViewEmployeeList.CurrentRow.Cells[3].Value.ToString();
            txtDOB.Text = dobOfEmp.Replace("12:00:00 AM", "");
            txtDOB.Text = txtDOB.Text.Trim();

            //txtDOB.Text = dobOfEmp.Substring(0, 10).Trim();
            //Convert.ToDateTime(txtDOB.Text) =  dataGridViewEmployeeList.CurrentRow.Cells[3].Value.ToString();
            //dTPDateOfBirth.Text = dataGridViewEmployeeList.CurrentRow.Cells[3].Value.ToString();
            cmbEmployeeDesignation.Text = dataGridViewEmployeeList.CurrentRow.Cells[5].Value.ToString();
            cmbEmployeeDepartment.Text = dataGridViewEmployeeList.CurrentRow.Cells[4].Value.ToString();
            txtOfficialCellNo.Text = dataGridViewEmployeeList.CurrentRow.Cells[6].Value.ToString();
            cmbEmployeeActive.Text = dataGridViewEmployeeList.CurrentRow.Cells[8].Value.ToString();
            //txtEmpMarketID.Text = dataGridViewEmployeeList.CurrentRow.Cells[15].Value.ToString();
            //txtEmpMarketCode.Text = dataGridViewEmployeeList.CurrentRow.Cells[16].Value.ToString();
            //cmbEmpMarketName.Text = dataGridViewEmployeeList.CurrentRow.Cells[17].Value.ToString();

            //quitDate = dataGridViewEmployeeList.CurrentRow.Cells[18].Value.ToString();

            //if(quitDate != "")
            //{
            //    txtQuitDate.Text = quitDate.Substring(0, 10).Trim();
            //}
            //else
            //{
            //    txtQuitDate.Text = dataGridViewEmployeeList.CurrentRow.Cells[18].Value.ToString();    
            //}


            if (btnSaveEmployee.Enabled == false)
            {
                btnSaveEmployee.Enabled = true;
            }

            if (btnSaveEmployee.Text == "Save Department")
            {
                btnSaveEmployee.Text = "Update Department";
            }

            if (txtEmployeeName.Enabled == false)
            {
                txtEmployeeName.Enabled = true;
            }

            if (txtAddress.Enabled == false)
            {
                txtAddress.Enabled = true;
            }

            if (txtDOB.Enabled == false)
            {
                txtDOB.Enabled = true;
            }

            if (dTPDateOfBirth.Enabled == false)
            {
                dTPDateOfBirth.Enabled = true;
            }

            if (cmbEmployeeDesignation.Enabled == false)
            {
                cmbEmployeeDesignation.Enabled = true;
            }

            if (cmbEmployeeDepartment.Enabled == false)
            {
                cmbEmployeeDepartment.Enabled = true;
            }

            if (txtOfficialCellNo.Enabled == false)
            {
                txtOfficialCellNo.Enabled = true;
            }

            if (cmbEmployeeActive.Enabled == false)
            {
                cmbEmployeeActive.Enabled = true;
            }

            if (txtQuitDate.Enabled == false)
            {
                txtQuitDate.Enabled = true;
            }

            if (dTPQuitDate.Enabled == false)
            {
                dTPQuitDate.Enabled = true;
            }

            if (btnAddEmployee.Enabled == false)
            {
                btnAddEmployee.Enabled = true;
            }

            if (cmbEmployeeActive.Text == "No")
            {
                if (txtQuitDate.Enabled == false)
                {
                    txtQuitDate.Enabled = true;
                }
                if (dTPQuitDate.Enabled == false)
                {
                    dTPQuitDate.Enabled = true;
                }

                txtQuitDate.Text = dataGridViewEmployeeList.CurrentRow.Cells[7].Value.ToString();
                txtQuitDate.Text = txtQuitDate.Text.Replace("12:00:00 AM", "");
                txtQuitDate.Text = txtQuitDate.Text.Trim();
            }

            if (cmbEmployeeActive.Text == "Yes")
            {
                txtQuitDate.Text = "";

                if (txtQuitDate.Enabled == true)
                {
                    txtQuitDate.Enabled = false;
                }

                if (dTPQuitDate.Enabled == true)
                {
                    dTPQuitDate.Enabled = false;
                }
            }

            txtEmployeeName.Focus();
        }

        private void dataGridViewEmployeeList_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            string dobOfEmp;
            //string quitDate;
            if (btnSaveEmployee.Enabled == false)
            {
                btnSaveEmployee.Enabled = true;
            }
            btnSaveEmployee.Text = "Update Employee";
            GlobalClass.EmpIDforUpdateEmployee = dataGridViewEmployeeList.CurrentRow.Cells[0].Value.ToString();
            txtEmployeeName.Text = dataGridViewEmployeeList.CurrentRow.Cells[1].Value.ToString();
            txtAddress.Text = dataGridViewEmployeeList.CurrentRow.Cells[2].Value.ToString();
            //dobOfEmp = String.Format("MM/dd/yyyy", dataGridViewEmployeeList.CurrentRow.Cells[3].Value.ToString());

            dobOfEmp = dataGridViewEmployeeList.CurrentRow.Cells[3].Value.ToString();
            txtDOB.Text = dobOfEmp.Replace("12:00:00 AM", "");
            txtDOB.Text = txtDOB.Text.Trim();

            //txtDOB.Text = dobOfEmp.Substring(0, 10).Trim();
            //Convert.ToDateTime(txtDOB.Text) =  dataGridViewEmployeeList.CurrentRow.Cells[3].Value.ToString();
            //dTPDateOfBirth.Text = dataGridViewEmployeeList.CurrentRow.Cells[3].Value.ToString();
            cmbEmployeeDesignation.Text = dataGridViewEmployeeList.CurrentRow.Cells[5].Value.ToString();
            cmbEmployeeDepartment.Text = dataGridViewEmployeeList.CurrentRow.Cells[4].Value.ToString();
            txtOfficialCellNo.Text = dataGridViewEmployeeList.CurrentRow.Cells[6].Value.ToString();
            cmbEmployeeActive.Text = dataGridViewEmployeeList.CurrentRow.Cells[8].Value.ToString();
            //txtEmpMarketID.Text = dataGridViewEmployeeList.CurrentRow.Cells[15].Value.ToString();
            //txtEmpMarketCode.Text = dataGridViewEmployeeList.CurrentRow.Cells[16].Value.ToString();
            //cmbEmpMarketName.Text = dataGridViewEmployeeList.CurrentRow.Cells[17].Value.ToString();

            //quitDate = dataGridViewEmployeeList.CurrentRow.Cells[18].Value.ToString();

            //if(quitDate != "")
            //{
            //    txtQuitDate.Text = quitDate.Substring(0, 10).Trim();
            //}
            //else
            //{
            //    txtQuitDate.Text = dataGridViewEmployeeList.CurrentRow.Cells[18].Value.ToString();    
            //}


            if (btnSaveEmployee.Enabled == false)
            {
                btnSaveEmployee.Enabled = true;
            }

            if (btnSaveEmployee.Text == "Save Department")
            {
                btnSaveEmployee.Text = "Update Department";
            }

            if (txtEmployeeName.Enabled == false)
            {
                txtEmployeeName.Enabled = true;
            }

            if (txtAddress.Enabled == false)
            {
                txtAddress.Enabled = true;
            }

            if (txtDOB.Enabled == false)
            {
                txtDOB.Enabled = true;
            }

            if (dTPDateOfBirth.Enabled == false)
            {
                dTPDateOfBirth.Enabled = true;
            }

            if (cmbEmployeeDesignation.Enabled == false)
            {
                cmbEmployeeDesignation.Enabled = true;
            }

            if (cmbEmployeeDepartment.Enabled == false)
            {
                cmbEmployeeDepartment.Enabled = true;
            }

            if (txtOfficialCellNo.Enabled == false)
            {
                txtOfficialCellNo.Enabled = true;
            }

            if (cmbEmployeeActive.Enabled == false)
            {
                cmbEmployeeActive.Enabled = true;
            }

            if (txtQuitDate.Enabled == false)
            {
                txtQuitDate.Enabled = true;
            }

            if (dTPQuitDate.Enabled == false)
            {
                dTPQuitDate.Enabled = true;
            }

            if (btnAddEmployee.Enabled == false)
            {
                btnAddEmployee.Enabled = true;
            }

            if (cmbEmployeeActive.Text == "No")
            {
                if (txtQuitDate.Enabled == false)
                {
                    txtQuitDate.Enabled = true;
                }
                if (dTPQuitDate.Enabled == false)
                {
                    dTPQuitDate.Enabled = true;
                }

                txtQuitDate.Text = dataGridViewEmployeeList.CurrentRow.Cells[7].Value.ToString();
                txtQuitDate.Text = txtQuitDate.Text.Replace("12:00:00 AM", "");
                txtQuitDate.Text = txtQuitDate.Text.Trim();
            }

            if (cmbEmployeeActive.Text == "Yes")
            {
                txtQuitDate.Text = "";

                if (txtQuitDate.Enabled == true)
                {
                    txtQuitDate.Enabled = false;
                }

                if (dTPQuitDate.Enabled == true)
                {
                    dTPQuitDate.Enabled = false;
                }
            }

            txtEmployeeName.Focus();
        }

        private void radioBtnEmployeeName_CheckedChanged(object sender, EventArgs e)
        {
            if (radioBtnEmployeeName.Checked == true)
            {
                //radioBtnByGroup.Checked = false;
                radioBtnOfficialMobileNumber.Checked = false;
                radioBtnByGroupAndDesignation.Checked = false;
                if (cmbSearchCriteriaForEmployeeByDesignation.Enabled == true)
                {
                    cmbSearchCriteriaForEmployeeByDesignation.Enabled = false;
                }
                
                if (txtSearchCriteriaForEmployee.Enabled == false)
                {
                    txtSearchCriteriaForEmployee.Enabled = true;
                }

                if (btnSearchEmployee.Enabled == false)
                {
                    btnSearchEmployee.Enabled = true;
                }

                cmbSearchCriteriaForEmployeeByDesignation.Text = "";
                txtSearchCriteriaForEmployee.Focus();
            }
        }

        private void radioBtnOfficialMobileNumber_CheckedChanged(object sender, EventArgs e)
        {
            if (radioBtnOfficialMobileNumber.Checked == true)
            {
                radioBtnEmployeeName.Checked = false;
                //radioBtnByGroup.Checked = false;
                radioBtnByGroupAndDesignation.Checked = false;
                if (cmbSearchCriteriaForEmployeeByDesignation.Enabled == true)
                {
                    cmbSearchCriteriaForEmployeeByDesignation.Enabled = false;
                }

                if (txtSearchCriteriaForEmployee.Enabled == false)
                {
                    txtSearchCriteriaForEmployee.Enabled = true;
                }

                if (btnSearchEmployee.Enabled == false)
                {
                    btnSearchEmployee.Enabled = true;
                }

                cmbSearchCriteriaForEmployeeByDesignation.Text = "";
                txtSearchCriteriaForEmployee.Focus();
            }
        }

        //private void radioBtnByGroup_CheckedChanged(object sender, EventArgs e)
        //{
        //    if (radioBtnByGroup.Checked == true)
        //    {
        //        radioBtnEmployeeName.Checked = false;
        //        radioBtnOfficialMobileNumber.Checked = false;
        //        radioBtnByGroupAndDesignation.Checked = false;
        //        if (cmbSearchCriteriaForEmployeeByDesignation.Enabled == true)
        //        {
        //            cmbSearchCriteriaForEmployeeByDesignation.Enabled = false;
        //        }

        //        cmbSearchCriteriaForEmployeeByDesignation.Text = "";
        //        txtSearchCriteriaForEmployee.Focus();
        //    }
        //}

        private void radioBtnByGroupAndDesignation_CheckedChanged(object sender, EventArgs e)
        {
            if (radioBtnByGroupAndDesignation.Checked == true)
            {
                radioBtnEmployeeName.Checked = false;
                radioBtnOfficialMobileNumber.Checked = false;
                //radioBtnByGroup.Checked = false;
                if (cmbSearchCriteriaForEmployeeByDesignation.Enabled == false)
                {
                    cmbSearchCriteriaForEmployeeByDesignation.Enabled = true;
                    cmbSearchCriteriaForEmployeeByDesignation.DataSource = objDesignationDetailsManager.LoadDesignationCombo();
                    cmbSearchCriteriaForEmployeeByDesignation.DisplayMember = "Designation_Code";
                    cmbSearchCriteriaForEmployeeByDesignation.ValueMember = "Designation_Code";
                }

                if (txtSearchCriteriaForEmployee.Enabled == true)
                {
                    txtSearchCriteriaForEmployee.Enabled = false;
                }

                if (btnSearchEmployee.Enabled == false)
                {
                    btnSearchEmployee.Enabled = true;
                }

                cmbSearchCriteriaForEmployeeByDesignation.Focus();
                //txtSearchCriteriaForEmployee.Focus();
            }
        }

        private void radioBtnShowAllEmp_CheckedChanged(object sender, EventArgs e)
        {
            if (radioBtnShowAllEmp.Checked == true)
            {
                radioBtnEmployeeName.Checked = false;
                radioBtnOfficialMobileNumber.Checked = false;
                //radioBtnByGroup.Checked = false;
                radioBtnByGroupAndDesignation.Checked = false;
                if (cmbSearchCriteriaForEmployeeByDesignation.Enabled == true)
                {
                    cmbSearchCriteriaForEmployeeByDesignation.Enabled = false;
                }

                if (txtSearchCriteriaForEmployee.Enabled == true)
                {
                    txtSearchCriteriaForEmployee.Enabled = false;
                }

                txtSearchCriteriaForEmployee.Text = "";
                cmbSearchCriteriaForEmployeeByDesignation.Text = "";

                dataGridViewEmployeeList.Refresh();
                dataGridViewEmployeeList.DataSource = objEmployeeDetailsManager.ShowAllEmployee();
                dataGridViewEmployeeList.Columns[0].Visible = false;
                //dataGridViewEmployeeList.Columns[4].Visible = false;
                //dataGridViewEmployeeList.Columns[6].Visible = false;
                dataGridViewEmployeeList.Columns[3].DefaultCellStyle.Format = "MM/dd/yyyy";
                DataGridViewEmployeeListHeaderText();
            }
        }

        private void btnSearchEmployee_Click(object sender, EventArgs e)
        {
            if (radioBtnEmployeeName.Checked == true)
            {
                //radioBtnByGroup.Checked = false;
                radioBtnOfficialMobileNumber.Checked = false;
                radioBtnByGroupAndDesignation.Checked = false;
                if (cmbSearchCriteriaForEmployeeByDesignation.Enabled == true)
                {
                    cmbSearchCriteriaForEmployeeByDesignation.Enabled = false;
                }

                dataGridViewEmployeeList.DataSource = objEmployeeDetailsManager.SearchEmployeeByName(txtSearchCriteriaForEmployee.Text.ToString());
                if (dataGridViewEmployeeList.RowCount > 0)
                {
                    dataGridViewEmployeeList.Refresh();
                    //dataGridViewEmployeeList.DataSource = objEmployeeDetailsManager.ShowAllEmployee();
                    dataGridViewEmployeeList.DataSource = objEmployeeDetailsManager.SearchEmployeeByName(txtSearchCriteriaForEmployee.Text.ToString());
                    dataGridViewEmployeeList.Columns[0].Visible = false;
                    //dataGridViewEmployeeList.Columns[4].Visible = false;
                    //dataGridViewEmployeeList.Columns[6].Visible = false;
                    dataGridViewEmployeeList.Columns[3].DefaultCellStyle.Format = "MM/dd/yyyy";
                    txtSearchCriteriaForEmployee.Text = "";
                }
                else
                {
                    MessageBox.Show("No Data Found");
                }
            }

            if (radioBtnOfficialMobileNumber.Checked == true)
            {
                radioBtnEmployeeName.Checked = false;
                //radioBtnByGroup.Checked = false;
                radioBtnByGroupAndDesignation.Checked = false;
                if (cmbSearchCriteriaForEmployeeByDesignation.Enabled == true)
                {
                    cmbSearchCriteriaForEmployeeByDesignation.Enabled = false;
                }

                dataGridViewEmployeeList.DataSource = objEmployeeDetailsManager.SearchEmployeeByMobile(txtSearchCriteriaForEmployee.Text.ToString());
                if (dataGridViewEmployeeList.RowCount > 0)
                {
                    dataGridViewEmployeeList.Refresh();
                    //dataGridViewEmployeeList.DataSource = objEmployeeDetailsManager.ShowAllEmployee();
                    dataGridViewEmployeeList.DataSource = objEmployeeDetailsManager.SearchEmployeeByMobile(txtSearchCriteriaForEmployee.Text.ToString());
                    dataGridViewEmployeeList.Columns[0].Visible = false;
                    //dataGridViewEmployeeList.Columns[4].Visible = false;
                    //dataGridViewEmployeeList.Columns[6].Visible = false;
                    dataGridViewEmployeeList.Columns[3].DefaultCellStyle.Format = "MM/dd/yyyy";
                    txtSearchCriteriaForEmployee.Text = "";
                }
                else
                {
                    MessageBox.Show("No Data Found");
                }
            }

            //if (radioBtnByGroup.Checked == true)
            //{
            //    radioBtnEmployeeName.Checked = false;
            //    radioBtnOfficialMobileNumber.Checked = false;
            //    radioBtnByGroupAndDesignation.Checked = false;
            //    if (cmbSearchCriteriaForEmployeeByDesignation.Enabled == true)
            //    {
            //        cmbSearchCriteriaForEmployeeByDesignation.Enabled = false;
            //    }

            //    dataGridViewEmployeeList.DataSource = objEmployeeDetailsManager.SearchEmployeeByGroup(txtSearchCriteriaForEmployee.Text.ToString());
            //    if (dataGridViewEmployeeList.RowCount > 0)
            //    {
            //        dataGridViewEmployeeList.Refresh();
            //        dataGridViewEmployeeList.DataSource = objEmployeeDetailsManager.ShowAllEmployee();
            //        dataGridViewEmployeeList.Columns[0].Visible = false;
            //        //dataGridViewEmployeeList.Columns[4].Visible = false;
            //        //dataGridViewEmployeeList.Columns[6].Visible = false;
            //        dataGridViewEmployeeList.Columns[3].DefaultCellStyle.Format = "MM/dd/yyyy";
            //        txtSearchCriteriaForEmployee.Text = "";
            //    }
            //    else
            //    {
            //        MessageBox.Show("No Data Found");
            //    }
            //}

            if (radioBtnByGroupAndDesignation.Checked == true)
            {
                radioBtnEmployeeName.Checked = false;
                radioBtnOfficialMobileNumber.Checked = false;
                //radioBtnByGroup.Checked = false;
                if (cmbSearchCriteriaForEmployeeByDesignation.Enabled == false)
                {
                    cmbSearchCriteriaForEmployeeByDesignation.Enabled = true;
                    cmbSearchCriteriaForEmployeeByDesignation.DataSource = objDesignationDetailsManager.LoadDesignationCombo();
                    cmbSearchCriteriaForEmployeeByDesignation.DisplayMember = "Designation_Code";
                    cmbSearchCriteriaForEmployeeByDesignation.ValueMember = "Designation_Code";
                }

                dataGridViewEmployeeList.DataSource = objEmployeeDetailsManager.SearchEmployeeDesignation(cmbSearchCriteriaForEmployeeByDesignation.Text.ToString());
                //dataGridViewEmployeeList.DataSource = objEmployeeDetailsManager.SearchEmployeeByGroupNameAndDesignation(txtSearchCriteriaForEmployee.Text.ToString(), cmbSearchCriteriaForEmployeeByDesignation.Text.ToString());
                if (dataGridViewEmployeeList.RowCount > 0)
                {
                    dataGridViewEmployeeList.Refresh();
                    //dataGridViewEmployeeList.DataSource = objEmployeeDetailsManager.ShowAllEmployee();
                    dataGridViewEmployeeList.DataSource = objEmployeeDetailsManager.SearchEmployeeDesignation(cmbSearchCriteriaForEmployeeByDesignation.Text.ToString());
                    dataGridViewEmployeeList.Columns[0].Visible = false;
                    //dataGridViewEmployeeList.Columns[4].Visible = false;
                    //dataGridViewEmployeeList.Columns[6].Visible = false;
                    dataGridViewEmployeeList.Columns[3].DefaultCellStyle.Format = "MM/dd/yyyy";
                    txtSearchCriteriaForEmployee.Text = "";
                }
                else
                {
                    MessageBox.Show("No Data Found");
                }
            }

            DataGridViewEmployeeListHeaderText();
        }

        private void dTPDateOfBirth_CloseUp(object sender, EventArgs e)
        {
            txtDOB.Text = dTPDateOfBirth.Text.ToString();
        }

        private void dTPQuitDate_CloseUp(object sender, EventArgs e)
        {
            txtQuitDate.Text = dTPQuitDate.Text.ToString();
            txtQuitDate.Focus();
        }

        private void cmbEmployeeActive_SelectedValueChanged(object sender, EventArgs e)
        {
            if (cmbEmployeeActive.Text == "No")
            {
                txtQuitDate.Enabled = true;
                dTPQuitDate.Enabled = true;
                txtQuitDate.Focus();
            }
            else if (cmbEmployeeActive.Text == "Yes")
            {
                txtQuitDate.Text = "";
                txtQuitDate.Enabled = false;
                dTPQuitDate.Enabled = false;
                //txtQuitDate.Focus();
            }
        }

        private void btnRefreshEmployee_Click(object sender, EventArgs e)
        {
            RefreshEmployee();
        }

        private void btnEmployeeReport_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Development Under Process .....");
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
