﻿namespace SMSapplication.UI
{
    partial class TeamDetailsUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TeamDetailsUI));
            this.groupBoxTeamDetailsSearch = new System.Windows.Forms.GroupBox();
            this.radioBtnTeamDetailsSearchByAreaName = new System.Windows.Forms.RadioButton();
            this.radioBtnTeamDetailsSearchByZoneName = new System.Windows.Forms.RadioButton();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnTeamDetailsReport = new System.Windows.Forms.Button();
            this.btnRefreshTeamDetails = new System.Windows.Forms.Button();
            this.radioBtnTeamDetailsSearchByRegionName = new System.Windows.Forms.RadioButton();
            this.btnPriceUpdateLogSearch = new System.Windows.Forms.Button();
            this.txtTeamDetailsSearchCriteria = new System.Windows.Forms.TextBox();
            this.radioBtnTeamDetailsSearchByDivisionName = new System.Windows.Forms.RadioButton();
            this.radioBtnTeamDetailsSearchByTeamName = new System.Windows.Forms.RadioButton();
            this.dgvTeamDetails = new System.Windows.Forms.DataGridView();
            this.groupBoxTeamDetailsSearch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTeamDetails)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBoxTeamDetailsSearch
            // 
            this.groupBoxTeamDetailsSearch.Controls.Add(this.radioBtnTeamDetailsSearchByAreaName);
            this.groupBoxTeamDetailsSearch.Controls.Add(this.radioBtnTeamDetailsSearchByZoneName);
            this.groupBoxTeamDetailsSearch.Controls.Add(this.btnClose);
            this.groupBoxTeamDetailsSearch.Controls.Add(this.btnTeamDetailsReport);
            this.groupBoxTeamDetailsSearch.Controls.Add(this.btnRefreshTeamDetails);
            this.groupBoxTeamDetailsSearch.Controls.Add(this.radioBtnTeamDetailsSearchByRegionName);
            this.groupBoxTeamDetailsSearch.Controls.Add(this.btnPriceUpdateLogSearch);
            this.groupBoxTeamDetailsSearch.Controls.Add(this.txtTeamDetailsSearchCriteria);
            this.groupBoxTeamDetailsSearch.Controls.Add(this.radioBtnTeamDetailsSearchByDivisionName);
            this.groupBoxTeamDetailsSearch.Controls.Add(this.radioBtnTeamDetailsSearchByTeamName);
            this.groupBoxTeamDetailsSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxTeamDetailsSearch.Location = new System.Drawing.Point(6, 0);
            this.groupBoxTeamDetailsSearch.Name = "groupBoxTeamDetailsSearch";
            this.groupBoxTeamDetailsSearch.Size = new System.Drawing.Size(1197, 80);
            this.groupBoxTeamDetailsSearch.TabIndex = 55;
            this.groupBoxTeamDetailsSearch.TabStop = false;
            this.groupBoxTeamDetailsSearch.Text = "Search";
            // 
            // radioBtnTeamDetailsSearchByAreaName
            // 
            this.radioBtnTeamDetailsSearchByAreaName.AutoSize = true;
            this.radioBtnTeamDetailsSearchByAreaName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioBtnTeamDetailsSearchByAreaName.Location = new System.Drawing.Point(561, 20);
            this.radioBtnTeamDetailsSearchByAreaName.Name = "radioBtnTeamDetailsSearchByAreaName";
            this.radioBtnTeamDetailsSearchByAreaName.Size = new System.Drawing.Size(114, 20);
            this.radioBtnTeamDetailsSearchByAreaName.TabIndex = 9;
            this.radioBtnTeamDetailsSearchByAreaName.TabStop = true;
            this.radioBtnTeamDetailsSearchByAreaName.Text = "By Area Name";
            this.radioBtnTeamDetailsSearchByAreaName.UseVisualStyleBackColor = true;
            // 
            // radioBtnTeamDetailsSearchByZoneName
            // 
            this.radioBtnTeamDetailsSearchByZoneName.AutoSize = true;
            this.radioBtnTeamDetailsSearchByZoneName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioBtnTeamDetailsSearchByZoneName.Location = new System.Drawing.Point(429, 20);
            this.radioBtnTeamDetailsSearchByZoneName.Name = "radioBtnTeamDetailsSearchByZoneName";
            this.radioBtnTeamDetailsSearchByZoneName.Size = new System.Drawing.Size(116, 20);
            this.radioBtnTeamDetailsSearchByZoneName.TabIndex = 8;
            this.radioBtnTeamDetailsSearchByZoneName.TabStop = true;
            this.radioBtnTeamDetailsSearchByZoneName.Text = "By Zone Name";
            this.radioBtnTeamDetailsSearchByZoneName.UseVisualStyleBackColor = true;
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Location = new System.Drawing.Point(736, 45);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(180, 25);
            this.btnClose.TabIndex = 7;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnTeamDetailsReport
            // 
            this.btnTeamDetailsReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTeamDetailsReport.Location = new System.Drawing.Point(368, 45);
            this.btnTeamDetailsReport.Name = "btnTeamDetailsReport";
            this.btnTeamDetailsReport.Size = new System.Drawing.Size(180, 25);
            this.btnTeamDetailsReport.TabIndex = 5;
            this.btnTeamDetailsReport.Text = "Team Details Report";
            this.btnTeamDetailsReport.UseVisualStyleBackColor = true;
            // 
            // btnRefreshTeamDetails
            // 
            this.btnRefreshTeamDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefreshTeamDetails.Location = new System.Drawing.Point(552, 45);
            this.btnRefreshTeamDetails.Name = "btnRefreshTeamDetails";
            this.btnRefreshTeamDetails.Size = new System.Drawing.Size(180, 25);
            this.btnRefreshTeamDetails.TabIndex = 6;
            this.btnRefreshTeamDetails.Text = "Refresh";
            this.btnRefreshTeamDetails.UseVisualStyleBackColor = true;
            // 
            // radioBtnTeamDetailsSearchByRegionName
            // 
            this.radioBtnTeamDetailsSearchByRegionName.AutoSize = true;
            this.radioBtnTeamDetailsSearchByRegionName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioBtnTeamDetailsSearchByRegionName.Location = new System.Drawing.Point(286, 20);
            this.radioBtnTeamDetailsSearchByRegionName.Name = "radioBtnTeamDetailsSearchByRegionName";
            this.radioBtnTeamDetailsSearchByRegionName.Size = new System.Drawing.Size(129, 20);
            this.radioBtnTeamDetailsSearchByRegionName.TabIndex = 3;
            this.radioBtnTeamDetailsSearchByRegionName.TabStop = true;
            this.radioBtnTeamDetailsSearchByRegionName.Text = "By Region Name";
            this.radioBtnTeamDetailsSearchByRegionName.UseVisualStyleBackColor = true;
            // 
            // btnPriceUpdateLogSearch
            // 
            this.btnPriceUpdateLogSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPriceUpdateLogSearch.Location = new System.Drawing.Point(184, 45);
            this.btnPriceUpdateLogSearch.Name = "btnPriceUpdateLogSearch";
            this.btnPriceUpdateLogSearch.Size = new System.Drawing.Size(180, 25);
            this.btnPriceUpdateLogSearch.TabIndex = 0;
            this.btnPriceUpdateLogSearch.Text = "Search";
            this.btnPriceUpdateLogSearch.UseVisualStyleBackColor = true;
            // 
            // txtTeamDetailsSearchCriteria
            // 
            this.txtTeamDetailsSearchCriteria.Enabled = false;
            this.txtTeamDetailsSearchCriteria.Location = new System.Drawing.Point(6, 46);
            this.txtTeamDetailsSearchCriteria.Name = "txtTeamDetailsSearchCriteria";
            this.txtTeamDetailsSearchCriteria.Size = new System.Drawing.Size(173, 22);
            this.txtTeamDetailsSearchCriteria.TabIndex = 4;
            // 
            // radioBtnTeamDetailsSearchByDivisionName
            // 
            this.radioBtnTeamDetailsSearchByDivisionName.AutoSize = true;
            this.radioBtnTeamDetailsSearchByDivisionName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioBtnTeamDetailsSearchByDivisionName.Location = new System.Drawing.Point(140, 20);
            this.radioBtnTeamDetailsSearchByDivisionName.Name = "radioBtnTeamDetailsSearchByDivisionName";
            this.radioBtnTeamDetailsSearchByDivisionName.Size = new System.Drawing.Size(133, 20);
            this.radioBtnTeamDetailsSearchByDivisionName.TabIndex = 2;
            this.radioBtnTeamDetailsSearchByDivisionName.TabStop = true;
            this.radioBtnTeamDetailsSearchByDivisionName.Text = "By Division Name";
            this.radioBtnTeamDetailsSearchByDivisionName.UseVisualStyleBackColor = true;
            // 
            // radioBtnTeamDetailsSearchByTeamName
            // 
            this.radioBtnTeamDetailsSearchByTeamName.AutoSize = true;
            this.radioBtnTeamDetailsSearchByTeamName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioBtnTeamDetailsSearchByTeamName.Location = new System.Drawing.Point(6, 20);
            this.radioBtnTeamDetailsSearchByTeamName.Name = "radioBtnTeamDetailsSearchByTeamName";
            this.radioBtnTeamDetailsSearchByTeamName.Size = new System.Drawing.Size(121, 20);
            this.radioBtnTeamDetailsSearchByTeamName.TabIndex = 1;
            this.radioBtnTeamDetailsSearchByTeamName.TabStop = true;
            this.radioBtnTeamDetailsSearchByTeamName.Text = "By Team Name";
            this.radioBtnTeamDetailsSearchByTeamName.UseVisualStyleBackColor = true;
            // 
            // dgvTeamDetails
            // 
            this.dgvTeamDetails.AllowUserToAddRows = false;
            this.dgvTeamDetails.AllowUserToDeleteRows = false;
            this.dgvTeamDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvTeamDetails.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dgvTeamDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTeamDetails.Location = new System.Drawing.Point(6, 86);
            this.dgvTeamDetails.MultiSelect = false;
            this.dgvTeamDetails.Name = "dgvTeamDetails";
            this.dgvTeamDetails.ReadOnly = true;
            this.dgvTeamDetails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvTeamDetails.Size = new System.Drawing.Size(1197, 436);
            this.dgvTeamDetails.TabIndex = 56;
            this.dgvTeamDetails.TabStop = false;
            // 
            // TeamDetailsUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(1209, 526);
            this.Controls.Add(this.dgvTeamDetails);
            this.Controls.Add(this.groupBoxTeamDetailsSearch);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "TeamDetailsUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Team Details";
            this.Load += new System.EventHandler(this.TeamDetailsUI_Load);
            this.groupBoxTeamDetailsSearch.ResumeLayout(false);
            this.groupBoxTeamDetailsSearch.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTeamDetails)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxTeamDetailsSearch;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnTeamDetailsReport;
        private System.Windows.Forms.Button btnRefreshTeamDetails;
        private System.Windows.Forms.RadioButton radioBtnTeamDetailsSearchByRegionName;
        private System.Windows.Forms.Button btnPriceUpdateLogSearch;
        private System.Windows.Forms.TextBox txtTeamDetailsSearchCriteria;
        private System.Windows.Forms.RadioButton radioBtnTeamDetailsSearchByDivisionName;
        private System.Windows.Forms.RadioButton radioBtnTeamDetailsSearchByTeamName;
        private System.Windows.Forms.RadioButton radioBtnTeamDetailsSearchByAreaName;
        private System.Windows.Forms.RadioButton radioBtnTeamDetailsSearchByZoneName;
        private System.Windows.Forms.DataGridView dgvTeamDetails;
    }
}