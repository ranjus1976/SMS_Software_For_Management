﻿namespace SMSapplication.UI
{
    partial class UserReportUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserReportUI));
            this.groupBoxUserReport = new System.Windows.Forms.GroupBox();
            this.radioButtonAllUserForUserReport = new System.Windows.Forms.RadioButton();
            this.btnUserReport = new System.Windows.Forms.Button();
            this.radioButtonNonActiveUserForUserReport = new System.Windows.Forms.RadioButton();
            this.radioButtonActiveUserForUserReport = new System.Windows.Forms.RadioButton();
            this.groupBoxUserReport.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxUserReport
            // 
            this.groupBoxUserReport.Controls.Add(this.radioButtonAllUserForUserReport);
            this.groupBoxUserReport.Controls.Add(this.btnUserReport);
            this.groupBoxUserReport.Controls.Add(this.radioButtonNonActiveUserForUserReport);
            this.groupBoxUserReport.Controls.Add(this.radioButtonActiveUserForUserReport);
            this.groupBoxUserReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxUserReport.Location = new System.Drawing.Point(6, 3);
            this.groupBoxUserReport.Name = "groupBoxUserReport";
            this.groupBoxUserReport.Size = new System.Drawing.Size(360, 130);
            this.groupBoxUserReport.TabIndex = 53;
            this.groupBoxUserReport.TabStop = false;
            this.groupBoxUserReport.Text = "User Report Criteria";
            // 
            // radioButtonAllUserForUserReport
            // 
            this.radioButtonAllUserForUserReport.AutoSize = true;
            this.radioButtonAllUserForUserReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonAllUserForUserReport.Location = new System.Drawing.Point(6, 70);
            this.radioButtonAllUserForUserReport.Name = "radioButtonAllUserForUserReport";
            this.radioButtonAllUserForUserReport.Size = new System.Drawing.Size(81, 20);
            this.radioButtonAllUserForUserReport.TabIndex = 70;
            this.radioButtonAllUserForUserReport.TabStop = true;
            this.radioButtonAllUserForUserReport.Text = "All User";
            this.radioButtonAllUserForUserReport.UseVisualStyleBackColor = true;
            // 
            // btnUserReport
            // 
            this.btnUserReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUserReport.Location = new System.Drawing.Point(6, 100);
            this.btnUserReport.Name = "btnUserReport";
            this.btnUserReport.Size = new System.Drawing.Size(347, 25);
            this.btnUserReport.TabIndex = 73;
            this.btnUserReport.Text = "Report";
            this.btnUserReport.UseVisualStyleBackColor = true;
            this.btnUserReport.Click += new System.EventHandler(this.btnUserReport_Click);
            // 
            // radioButtonNonActiveUserForUserReport
            // 
            this.radioButtonNonActiveUserForUserReport.AutoSize = true;
            this.radioButtonNonActiveUserForUserReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonNonActiveUserForUserReport.Location = new System.Drawing.Point(6, 45);
            this.radioButtonNonActiveUserForUserReport.Name = "radioButtonNonActiveUserForUserReport";
            this.radioButtonNonActiveUserForUserReport.Size = new System.Drawing.Size(138, 20);
            this.radioButtonNonActiveUserForUserReport.TabIndex = 67;
            this.radioButtonNonActiveUserForUserReport.TabStop = true;
            this.radioButtonNonActiveUserForUserReport.Text = "Non Active User";
            this.radioButtonNonActiveUserForUserReport.UseVisualStyleBackColor = true;
            // 
            // radioButtonActiveUserForUserReport
            // 
            this.radioButtonActiveUserForUserReport.AutoSize = true;
            this.radioButtonActiveUserForUserReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonActiveUserForUserReport.Location = new System.Drawing.Point(6, 20);
            this.radioButtonActiveUserForUserReport.Name = "radioButtonActiveUserForUserReport";
            this.radioButtonActiveUserForUserReport.Size = new System.Drawing.Size(106, 20);
            this.radioButtonActiveUserForUserReport.TabIndex = 66;
            this.radioButtonActiveUserForUserReport.TabStop = true;
            this.radioButtonActiveUserForUserReport.Text = "Active User";
            this.radioButtonActiveUserForUserReport.UseVisualStyleBackColor = true;
            // 
            // UserReportUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(372, 137);
            this.Controls.Add(this.groupBoxUserReport);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "UserReportUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "User Report";
            this.groupBoxUserReport.ResumeLayout(false);
            this.groupBoxUserReport.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxUserReport;
        private System.Windows.Forms.RadioButton radioButtonAllUserForUserReport;
        private System.Windows.Forms.Button btnUserReport;
        private System.Windows.Forms.RadioButton radioButtonNonActiveUserForUserReport;
        private System.Windows.Forms.RadioButton radioButtonActiveUserForUserReport;
    }
}