﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Windows.Forms;
using SMSapplication.DAL;
using SMSapplication.DAL.DAO;
using SMSapplication.DAL.Gateway;
using SMSapplication.UI;

namespace SMSapplication.BLL
{
    public class SalesTargerDetailsManager
    {
        public int logInval = 0;
        private SqlDataAdapter da = new SqlDataAdapter();
        private DataTable dt = new DataTable();
        private SqlCommand cmd = new SqlCommand();
        private SqlCommand cmdDelete = new SqlCommand();
        private SqlDataReader dr;

        public DataTable CheckDuplicate(string searchByProductCode)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("select * from tbl_Temp_Target where Product_Code Like '" + '%' + searchByProductCode + '%' + "'", DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

            return dt;
        }

        public DataTable CheckDuplicateInMainTBL(string searchFromDate, string searchToDate, string searchByEmpName, string searchByProductCode, int salesTargetUnit)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("select * from tbl_Target where ('" + searchFromDate + "' between From_Date and To_Date) and ('" + searchToDate + "' between From_Date and To_Date) and Employee_Name = '" + searchByEmpName + "' and Product_Code = '" + searchByProductCode + "' and Target_Unit = " + salesTargetUnit + "", DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

            return dt;
        }
        
        public DataTable ShowAllSalesTarget()
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("select * from tbl_Target order by Employee_ID,From_Date Desc", DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                //DataTable dt = new DataTable();
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

            return dt;
        }

        public DataTable GetAllSalesTarget(string fromDate, string toDate)
        {
            DBConnection.OpenSqlConnection();
            cmdDelete = new SqlCommand("delete tbl_Temp_Target", DBConnection.SqlConnectionObject);
            cmdDelete.ExecuteNonQuery();
            cmd = new SqlCommand("insert into tbl_Temp_Target (From_Date,To_Date,Product_Code,Product_Name,Product_Price,Target_Unit,Target_Amount,Employee_Name,Official_Cell_No,Group_Name,Division_Name)" +
                                     "select From_Date,To_Date,Product_Code,Product_Name,Product_Price,Target_Unit,Target_Amount,Employee_Name,Official_Cell_No,Group_Name,Division_Name from tbl_Target where from_date >= '" + fromDate + "' and To_Date <= '" + toDate + "' order by Employee_Name,Product_Code asc", DBConnection.SqlConnectionObject);
            da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DBConnection.CloseSqlConnection();
            return dt;
        }

        public DataTable GetTempData()
        {
            DBConnection.OpenSqlConnection();
            cmd = new SqlCommand("select * from tbl_Temp_Target", DBConnection.SqlConnectionObject);
            da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DBConnection.CloseSqlConnection();
            return dt;
        }

        public DataTable ShowTempSalesTarget()
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("select * from tbl_Temp_Target order by Product_ID ASC", DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                //DataTable dt = new DataTable();
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

            return dt;
        }

        public void DeleteTempSalesTarget()
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("delete tbl_Temp_Target", DBConnection.SqlConnectionObject);
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        public void InsertSalesTarget_New()
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand(@"insert into tbl_target(From_Date,To_Date,Product_ID,Product_Code,Product_Name,"+
                                    "Product_Price,Target_Unit,Target_Amount,Employee_ID,Employee_Name,Designation,"+
                                    "Official_Cell_No,Group_Name,Division_Name) select From_Date,To_Date,Product_ID,Product_Code,Product_Name,"+
                                    "Product_Price,Target_Unit,Target_Amount,Employee_ID,Employee_Name,Designation,"+
                                    "Official_Cell_No,Group_Name,Division_Name from tbl_Temp_Target", DBConnection.SqlConnectionObject);
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        public void InsertPreviousSalesTargetIntoTemp(string searchFromDate, string searchToDate, string searchByEmpName)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand(@"insert into tbl_Temp_Target(From_Date,To_Date,Product_ID,Product_Code,Product_Name,Product_Price,Target_Unit,Target_Amount,Employee_ID,Employee_Name,Designation, Official_Cell_No,Group_Name)"+
                                       "select From_Date,To_Date,Product_ID,Product_Code,Product_Name,Product_Price,Target_Unit,Target_Amount,Employee_ID,Employee_Name,Designation, Official_Cell_No,Group_Name from tbl_Target where Employee_Name = '" + searchByEmpName + "' and From_Date = '" + searchFromDate + "' and To_Date = '" + searchToDate + "'", DBConnection.SqlConnectionObject);
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        public void InsertSalesTarget(string fromDate, string toDate, int productID, string productCode,
            string productName, decimal productPrice, int salesTargetUnit, decimal salesTargetAmount, int employeeID,
            string employeeName, string empDesignation, string empOfficialCell, string empGroupName)
        {
            {
                string sql = @"insert into tbl_Target(From_Date,To_Date,Product_ID,Product_Code,Product_Name,Product_Price,Target_Unit,Target_Amount,Employee_ID,Employee_Name,Designation,Official_Cell_No,Group_Name) values ( '"+ fromDate + "','" + toDate + "'," + productID + ",'" + productCode + "','" + productName + "'," + productPrice + "," + salesTargetUnit + "," + salesTargetAmount + "," + employeeID + ",'" + employeeName + "','" + empDesignation + "','" + empOfficialCell + "','" + empGroupName + "')"; //," + empMarketID + ",'" + empMarketCode + "','" + empNameOfMarket + "' //'" + empDesiActive + "','" + empDeptActive + "','" + empGroupActive + "',

                string sqlUpdateQuitDate = @"update tbl_Employee_Info set Quit_Date = NULL where Quit_Date = '1/1/1900 12:00:00 AM'".ToString();

                cmd = new SqlCommand(sqlUpdateQuitDate, DBConnection.SqlConnectionObject);

                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
        }

        public void InsertTempSalesTarget(string fromDate, string toDate, int productID, string productCode,
            string productName, decimal productPrice, int salesTargetUnit, decimal salesTargetAmount, int employeeID,
            string employeeName, string empDesignation, string empOfficialCell, string empGroupName, string divisionName)
        {
            {
                string sql = @"insert into tbl_Temp_Target(From_Date,To_Date,Product_ID,Product_Code,Product_Name,Product_Price,Target_Unit,Target_Amount,Employee_ID,Employee_Name,Designation,Official_Cell_No,Group_Name,Division_Name) values ( '" + fromDate + "','" + toDate + "'," + productID + ",'" + productCode + "','" + productName + "'," + productPrice + "," + salesTargetUnit + "," + salesTargetAmount + "," + employeeID + ",'" + employeeName + "','" + empDesignation + "','" + empOfficialCell + "','" + empGroupName + "','" + divisionName + "')"; //," + empMarketID + ",'" + empMarketCode + "','" + empNameOfMarket + "' //'" + empDesiActive + "','" + empDeptActive + "','" + empGroupActive + "',

                //string sqlUpdateQuitDate = @"update tbl_Employee_Info set Quit_Date = NULL where Quit_Date = '1/1/1900 12:00:00 AM'".ToString();

                //cmd = new SqlCommand(sqlUpdateQuitDate, DBConnection.SqlConnectionObject);

                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
        }

        public void UpdateSalesTarget(int salesTargetID, string fromDate, string toDate, int productID, string productCode, string productName,
                    decimal productPrice, int salesTargetUnit, decimal salesTargetAmount, int employeeID, string employeeName, string empDesignation,
                    string empOfficialCell, string empGroupName, string divisionName)
        {
            string sql = @"update tbl_Target set From_Date = '" + fromDate + "'," +
                         "To_Date = '" + toDate + "', " +
                         "Product_ID = " + productID + ", " +
                         "Product_Code = '" + productCode + "', " +
                         "Product_Name = '" + productName + "', " +
                         "Product_Price = " + productPrice + ", " +
                         "Target_Unit = " + salesTargetUnit + ", " +
                         "Target_Amount = " + salesTargetAmount + ", " +
                         "Employee_ID = " + employeeID + ", " +
                         "Employee_Name = '" + employeeName + "', " +
                         "Designation = '" + empDesignation + "', " +
                         "Official_Cell_No = '" + empOfficialCell + "', " +
                         "Group_Name = '" + empGroupName + "', " +
                         "Division_Name = '" + divisionName + "'" +
                         "where Target_ID=" + salesTargetID + "";
            cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
            DBConnection.OpenSqlConnection();
            cmd.ExecuteNonQuery();
            DBConnection.CloseSqlConnection();
        }

        public void UpdateTempSalesTarget(int salesTargetID, string fromDate, string toDate, int productID, string productCode, string productName,
                    decimal productPrice, int salesTargetUnit, decimal salesTargetAmount, int employeeID, string employeeName, string empDesignation,
                    string empOfficialCell, string empGroupName, string divisionName)
        {
            string sql = @"update tbl_Temp_Target set From_Date = '" + fromDate + "'," +
                         "To_Date = '" + toDate + "', " +
                         "Product_ID = " + productID + ", " +
                         "Product_Code = '" + productCode + "', " +
                         "Product_Name = '" + productName + "', " +
                         "Product_Price = " + productPrice + ", " +
                         "Target_Unit = " + salesTargetUnit + ", " +
                         "Target_Amount = " + salesTargetAmount + ", " +
                         "Employee_ID = " + employeeID + ", " +
                         "Employee_Name = '" + employeeName + "', " +
                         "Designation = '" + empDesignation + "', " +
                         "Official_Cell_No = '" + empOfficialCell + "', " +
                         "Group_Name = '" + empGroupName + "', " +
                         "Division_Name = '" + divisionName + "'" +
                         "where Target_ID=" + salesTargetID + "";
            cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
            DBConnection.OpenSqlConnection();
            cmd.ExecuteNonQuery();
            DBConnection.CloseSqlConnection();
        }

        public DataTable SearchTargetByName(string searchFromDate, string searchToDate, string searchByEmpName)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("select * from tbl_Target where ('" + searchFromDate + "' between From_Date and To_Date) and ('" + searchToDate + "' between From_Date and To_Date) and Employee_Name Like '" +'%'+ searchByEmpName +'%'+ "'", DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

            return dt;
        }

        public DataTable SearchTargetByMobile(string searchFromDate, string searchToDate, string searchByEmpMobile)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("select * from tbl_Target where ('" + searchFromDate + "' between From_Date and To_Date) and ('" + searchToDate + "' between From_Date and To_Date) and Official_Cell_No Like '" + '%' + searchByEmpMobile + '%' + "'", DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

            return dt;
        }

        public DataTable SearchTargetByGroupName(string searchFromDate, string searchToDate, string searchByGroupName)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("select * from tbl_Target where ('" + searchFromDate + "' between From_Date and To_Date) and ('" + searchToDate + "' between From_Date and To_Date) and Group_Name Like '" + '%' + searchByGroupName + '%' + "'", DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

            return dt;
        }

        public DataTable SearchTargetByDesignation(string searchFromDate, string searchToDate, string searchByDesignation)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("select * from tbl_Target where ('" + searchFromDate + "' between From_Date and To_Date) and ('" + searchToDate + "' between From_Date and To_Date) and Designation Like '" + '%' + searchByDesignation + '%' + "'", DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

            return dt;
        }

        public DataTable SearchTargetByGroupAndDesignation(string searchFromDate, string searchToDate,string searchByGroupName, string searchByDesignation)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("select * from tbl_Target where ('" + searchFromDate + "' between From_Date and To_Date) and ('" + searchToDate + "' between From_Date and To_Date) and Group_Name Like '" + '%' + searchByGroupName + '%' + "' and Designation Like '" + '%' + searchByDesignation + '%' + "'", DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

            return dt;
        }

        public DataTable SearchTargetByProductCode(string searchFromDate, string searchToDate, string searchByProductCode)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("select * from tbl_Target where ('" + searchFromDate + "' between From_Date and To_Date) and ('" + searchToDate + "' between From_Date and To_Date) and Product_Code Like '" + '%' + searchByProductCode + '%' + "'", DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

            return dt;
        }

        public DataTable ShowAllSalesTargetByDateRange(string searchFromDate, string searchToDate)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("select * from tbl_Target where ('" + searchFromDate + "' between From_Date and To_Date) and ('" + searchToDate + "' between From_Date and To_Date)", DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

            return dt;
        }

        public DataTable ShowAllSpecialItemSalesTarget()
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("select * from tbl_Special_Item_Sale_Target order by Employee_ID,From_Date ASC", DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                //DataTable dt = new DataTable();
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

            return dt;
        }

        public DataTable CheckTarget(string fromDateSearch, string toDateSearch, string ProCodeForSales, string EmpNameForSales)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("select * from tbl_Target where From_Date = '" + fromDateSearch + "' and To_Date = '" + toDateSearch + "' and Employee_Name = '" + EmpNameForSales + "' and Product_Code ='" + ProCodeForSales + "' ", DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

            return dt;
        }
        //CheckTarget(fromDateSearch,toDateSearch,GlobalClass.ProCodeForSales,GlobalClass.EmpNameForSales)
    }
}
