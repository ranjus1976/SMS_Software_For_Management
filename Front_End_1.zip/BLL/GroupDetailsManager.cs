﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Windows.Forms;
using SMSapplication.DAL;
using SMSapplication.DAL.DAO;
using SMSapplication.DAL.Gateway;
using SMSapplication.UI;

namespace SMSapplication.BLL
{
    public class GroupDetailsManager
    {
        public int logInval = 0;
        private GroupDetailsGateway objDetailsGateway = new GroupDetailsGateway();
        private DataTable dt = new DataTable();
        private SqlCommand cmd = new SqlCommand();
        private SqlCommand cmdUpdate = new SqlCommand();
        private SqlCommand cmdUpdateActivityEndDate = new SqlCommand();
        private SqlDataReader dr;
        private string empGroupID;
        private string empTeamID;
        private string empTeamName;
        private string empTeamIDForTeamDetails;
        private string empGroupActiveDetails;
        private SqlDataAdapter da = new SqlDataAdapter();

        public string GetGroupID(string group)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                string CommandText = "select * from tbl_Group where Group_Name='" + group + "'";
                cmd = new SqlCommand(CommandText, DBConnection.SqlConnectionObject);
                //da = new SqlDataAdapter(cmd);
                da.SelectCommand = cmd;
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    dr = cmd.ExecuteReader();
                    dr.Read();
                    empGroupID = dr[0].ToString();
                    cmd.Dispose();
                    DBConnection.CloseSqlConnection();
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            return empGroupID;
        }

        public string GetGroupActiveDetails(int groupID)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                string CommandText = "select * from tbl_Group where Group_ID='" + groupID + "'";
                cmd = new SqlCommand(CommandText, DBConnection.SqlConnectionObject);
                //da = new SqlDataAdapter(cmd);
                da.SelectCommand = cmd;
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    dr = cmd.ExecuteReader();
                    dr.Read();
                    empGroupActiveDetails = dr[3].ToString();
                    cmd.Dispose();
                    DBConnection.CloseSqlConnection();
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            return empGroupActiveDetails;
        }

        public void InsertNewGroup(string groupName, string location, string activateGroup, int MD, int DMD, int DO, int GM, int DGM, int DM, int SM, int ASM, int TSM, int SR)
        {
            try
            {
                string sql = @"insert into tbl_Group(Group_Name, Location, Active, MD, DMD,DO, GM,DGM, DM, SM, ASM, TSM, SR) values ('"
                + groupName + "','" + location + "','" + activateGroup + "'," + MD + "," + DMD + "," + DO + "," + GM + "," + DGM + "," + DM + "," + SM + "," + ASM + "," + TSM + "," + SR + ")";

                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
        }

        public void UpdateGroup(int groupID, string groupName, string location, string activateGroup, int MD, int DMD, int DO, int GM, int DGM, int DM, int SM, int ASM, int TSM, int SR)
        {
            try
            {
                string sql = @"update tbl_Group set Group_Name = '" + groupName + "',Location = '" + location +
                         "', Active = '" + activateGroup + "' , MD =" + MD + ", DMD =" + DMD + ", DO =" + DO + ",GM =" + GM + ",DGM =" + DGM + ",DM =" + DM + ",SM =" + SM + ",ASM =" + ASM + ",TSM =" + TSM + ",SR =" + SR +
                         " where Group_ID=" + groupID + "".ToString();

                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
        }

        public DataTable AllGroupDetails()
        {
            try
            {
                dt = new DataTable();
                dt = objDetailsGateway.ShowAllGroup();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            
            return dt;
        }

        public DataTable LoadGroupCombo()
        {
            try
            {
                dt = new DataTable();
                dt = objDetailsGateway.LoadActiveGroup();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
           return dt;
        }

        public DataTable LoadSelectGroupCombo()
        {
            try
            {
                dt = new DataTable();
                dt = objDetailsGateway.LoadSelectGroupForGroupSetup();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            return dt;
        }

        public void InsertTeam(string teamName, string employeeName, string designationCode, string activityStartDate,string teamActive)
        {
            try
            {
                string sql = @"insert into tbl_Team(Team_Name, Employee_Name, Designation_Code, Activity_Start_Date, Active) values ('"
                + teamName + "','" + employeeName + "','" + designationCode + "','" + activityStartDate + "','" + teamActive + "')";

                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
        }

        public void InsertTeamDetails(string teamName, string employeeName, string designationCode, string activityStartDate, string teamActive)
        {
            try
            {
                empTeamIDForTeamDetails = GetTeamID(teamName);
                if (empTeamIDForTeamDetails != "")
                {
                    string sql = @"insert into tbl_Team_Details(Team_ID, Team_Name, Employee_Name, Designation_Code, Activity_Start_Date, Active) values (" + empTeamIDForTeamDetails + ", '" + teamName + "','" + employeeName + "','" + designationCode + "','" + activityStartDate + "','" + teamActive + "')";

                    cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                    DBConnection.OpenSqlConnection();
                    cmd.ExecuteNonQuery();
                    DBConnection.CloseSqlConnection();
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
        }

        public void UpdateTeamDetails(int teamId, string teamName, string employeeName, string designationCode, string activityStartDate, string activityEndDate, string teamActive)
        {
            try
            {
                empTeamIDForTeamDetails = GetTeamID(teamName);
                if (empTeamIDForTeamDetails != "")
                {
                    //string sql = @"insert into tbl_Team_Details(Team_ID, Team_Name, Employee_Name, Designation_Code, Activity_Start_Date, Active) values (" + empTeamIDForTeamDetails + ", '" + teamName + "','" + employeeName + "','" + designationCode + "','" + activityStartDate + "','" + teamActive + "')";
                    string sql = @"update tbl_Team_Details set Team_Name = '" + teamName + "', Activity_Start_Date = '" + activityStartDate + "',  Activity_End_Date = '" + activityEndDate + "', Active = '" + teamActive + "' where Team_ID = " + empTeamIDForTeamDetails + ""; //, Employee_Name = '" + employeeName + "', Designation_Code = '" + designationCode + "'
                    string sqlUpdate = @"update tbl_Team_Details set Employee_Name = '" + employeeName + "', Designation_Code = '" + designationCode + "' where Team_ID = " + empTeamIDForTeamDetails + " and Division_ID is null and Division_Name is null and Region_ID is null and Region_Name is null and Zone_ID is null and Zone_Name is null and Area_ID is null and Area_Name is null "; //Team_Name = '" + teamName + "', , Activity_Start_Date = '" + activityStartDate + "',  Activity_End_Date = '" + activityEndDate + "', Active = '" + teamActive + "'
                    string sqlUpdateActivityEndDate = @"update tbl_Team_Details set Activity_End_Date = NULL where Activity_End_Date = '1/1/1900 12:00:00 AM'".ToString();
                    cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                    cmdUpdate = new SqlCommand(sqlUpdate, DBConnection.SqlConnectionObject);
                    cmdUpdateActivityEndDate = new SqlCommand(sqlUpdateActivityEndDate, DBConnection.SqlConnectionObject);
                    DBConnection.OpenSqlConnection();
                    cmd.ExecuteNonQuery();
                    cmdUpdate.ExecuteNonQuery();
                    cmdUpdateActivityEndDate.ExecuteNonQuery();
                    DBConnection.CloseSqlConnection();
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
        }

        public void UpdateTeamWithActivateEndDate(int teamId, string teamName, string employeeName, string designationCode, string activityStartDate, string activityEndDate, string teamActive)
        {
            try
            {
                string sql = @"update tbl_Team set Team_Name = '" + teamName + "', Employee_Name = '" + employeeName + "', Designation_Code  = '" + designationCode + "', Activity_Start_Date = '" + activityStartDate + "', Activity_End_Date = '" + activityEndDate + "', Active = '" + teamActive + "' where Team_ID = " + teamId + "".ToString();
                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
        }

        public void UpdateTeamDetailsWithActivateEndDate(int teamId, string teamName, string employeeName, string designationCode, string activityStartDate, string activityEndDate, string teamActive)
        {
            try
            {
                //string sql = @"update tbl_Team_Details set Team_Name = '" + teamName + "', Employee_Name = '" + employeeName + "', Designation_Code  = '" + designationCode + "', Activity_Start_Date = '" + activityStartDate + "', Activity_End_Date = '" + activityEndDate + "', Active = '" + teamActive + "' where Team_ID = " + teamId + "".ToString();
                string sql = @"update tbl_Team_Details set Team_Name = '" + teamName + "' where Team_ID = " + teamId + "".ToString(); //set Team_Name = '" + teamName + "', Activity_Start_Date = '" + activityStartDate + "',
                string sqlUpdate = @"update tbl_Team_Details set Employee_Name = '" + employeeName + "', Designation_Code = '" + designationCode + "' , Activity_End_Date = '" + activityEndDate + "', Active = '" + teamActive + "' where Team_ID = " + teamId + " and Division_ID is null and Division_Name is null and Region_ID is null and Region_Name is null and Zone_ID is null and Zone_Name is null and Area_ID is null and Area_Name is null ";
                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                cmdUpdate = new SqlCommand(sqlUpdate, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                cmdUpdate.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
        }

        public void UpdateTeam(int teamId, string teamName, string employeeName, string designationCode, string activityStartDate, string activityEndDate, string teamActive)
        {
            try
            {
                string sql = @"update tbl_Team set Team_Name = '" + teamName + "', Employee_Name = '" + employeeName + "', Designation_Code  = '" + designationCode + "', Activity_Start_Date = '" + activityStartDate + "', Activity_End_Date = '" + activityEndDate + "', Active = '" + teamActive + "' where Team_ID = " + teamId + "".ToString();
                string sqlUpdateActivityEndDate = @"update tbl_Team set Activity_End_Date = NULL where Activity_End_Date = '1/1/1900 12:00:00 AM'".ToString();
                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                cmdUpdateActivityEndDate = new SqlCommand(sqlUpdateActivityEndDate, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                cmdUpdateActivityEndDate.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
        }

        public DataTable ShowAllTeam()
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("select * from tbl_Team order by team_id asc", DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            return dt;
        }

        public DataTable ShowAllTeamDetails()
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("select * from tbl_Team_Details order by Team_Name,Team_ID,Division_ID,Region_ID,Zone_ID,Area_ID asc", DBConnection.SqlConnectionObject);
                //cmd = new SqlCommand("select * from tbl_Team_Details order by Team_Name,Team_ID,Team_Details_ID asc", DBConnection.SqlConnectionObject);
                //select * from tbl_Team_Details order by Team_Name,Team_ID,Division_ID,Region_ID,Zone_ID,Area_ID asc
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            
            return dt;
        }

        public DataTable LoadTeam()
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("select * from tbl_Team where Active = 'Yes' order by team_id asc", DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            
            return dt;
        }

        public string GetTeamID(string team)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                string CommandText = "select * from tbl_Team where Team_Name='" + team + "'";
                cmd = new SqlCommand(CommandText, DBConnection.SqlConnectionObject);
                //da = new SqlDataAdapter(cmd);
                da.SelectCommand = cmd;
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    dr = cmd.ExecuteReader();
                    dr.Read();
                    empTeamID = dr[0].ToString();
                    cmd.Dispose();
                    DBConnection.CloseSqlConnection();
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            return empTeamID;
        }

        public string GetTeamName(int teamID)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                string CommandText = "select Team_Name from tbl_Team where Team_ID =" + teamID + "";
                cmd = new SqlCommand(CommandText, DBConnection.SqlConnectionObject);
                //da = new SqlDataAdapter(cmd);
                da.SelectCommand = cmd;
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    dr = cmd.ExecuteReader();
                    dr.Read();
                    empTeamName = dr[0].ToString();
                    cmd.Dispose();
                    DBConnection.CloseSqlConnection();
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            return empTeamName;
        }

        public string GetTeamIDFromTeamDivision(int divisionID)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                string CommandText = "select Team_ID from tbl_Team_Division where Division_ID =" + divisionID + " and Active ='Yes'";
                cmd = new SqlCommand(CommandText, DBConnection.SqlConnectionObject);
                //da = new SqlDataAdapter(cmd);
                da.SelectCommand = cmd;
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    dr = cmd.ExecuteReader();
                    dr.Read();
                    empTeamID = dr[0].ToString();
                    cmd.Dispose();
                    DBConnection.CloseSqlConnection();
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            return empTeamID;
        }

        public DataTable GetTeamDetails(string cmbSelectDivisionForRegion)
        {
            try
            {
                //empDesignationCode, empName, regionActivityStartDate
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("select Employee_Name, Designation_Code, Activity_Start_Date from tbl_Team where Team_Name = '" + cmbSelectDivisionForRegion + "'", DBConnection.SqlConnectionObject);
                //cmd = new SqlCommand("select * from tbl_Team_Details order by Team_Name,Team_ID,Team_Details_ID asc", DBConnection.SqlConnectionObject);
                //select * from tbl_Team_Details order by Team_Name,Team_ID,Division_ID,Region_ID,Zone_ID,Area_ID asc
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            
            return dt;
        }

        public DataTable GetDataFromTeamDetails(string zoneName)
        {
            try
            {
                //empDesignationCode, empName, regionActivityStartDate
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("select Team_ID, Team_Name, Division_ID, Division_Name, Region_ID, Region_Name, Zone_ID, Zone_Name from tbl_Team_Details where Zone_Name = '" + zoneName + "'", DBConnection.SqlConnectionObject);
                //cmd = new SqlCommand("select * from tbl_Team_Details order by Team_Name,Team_ID,Team_Details_ID asc", DBConnection.SqlConnectionObject);
                //select * from tbl_Team_Details order by Team_Name,Team_ID,Division_ID,Region_ID,Zone_ID,Area_ID asc
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();

            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }

            return dt;
        }
    }
}
