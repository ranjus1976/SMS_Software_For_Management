﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Windows.Forms;
using SMSapplication.DAL;
using SMSapplication.DAL.DAO;
using SMSapplication.DAL.Gateway;
using SMSapplication.UI;

namespace SMSapplication.BLL
{
    public class ProductDetailsManager
    {
        public int logInval = 0;
        private DataTable dt = new DataTable();
        private SqlCommand cmd = new SqlCommand();
        private SqlDataReader dr;
        private int productIDForUpdatePriceLogTable;
        private int productPriceUpdateLogID;
        private SqlDataAdapter da = new SqlDataAdapter();
        private SqlCommand cmdDelete;

        public DataTable ShowAllProduct()
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("select * from tbl_Product order by Product_ID asc", DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                //DataTable dt = new DataTable();
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            return dt;
        }

        public DataTable ShowUpdateLogForAllProduct()
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("select * from tbl_Product_Price_Update_Log order by Product_ID asc", DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                //DataTable dt = new DataTable();
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            return dt;
        }

        public DataTable GetProductUpdateLogByProductCode(string productCode)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("select * from tbl_Product_Price_Update_Log where Product_Code like '" + '%' + productCode + '%' + "' order by Product_ID asc", DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            return dt;
        }

        public DataTable GetProductDetailsForSales(string proCodeForSales)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("select * from tbl_Product where Product_Code = '" + proCodeForSales + "' and Active = 'Yes'", DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            return dt;
        }

        //GetProductDetailsForSales(GlobalClass.ProCodeForSales);

        public DataTable GetProductUpdateLogByProductName(string productName)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("select * from tbl_Product_Price_Update_Log where Product_Name like '" + '%' + productName + '%' + "' order by Product_ID asc", DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            return dt;
        }
        
        public int GetProductID(string productCode)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                string CommandText = "select Product_ID from tbl_Product where Product_Code='" + productCode + "'";
                cmd = new SqlCommand(CommandText, DBConnection.SqlConnectionObject);
                //da = new SqlDataAdapter(cmd);
                da.SelectCommand = cmd;
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    dr = cmd.ExecuteReader();
                    dr.Read();
                    productIDForUpdatePriceLogTable = Convert.ToInt32(dr[0].ToString());
                    cmd.Dispose();
                    DBConnection.CloseSqlConnection();
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

            return productIDForUpdatePriceLogTable;
        }

        public int GetProductPriceUpdateLogID(int productID)
        {
            DBConnection.OpenSqlConnection();
            string CommandText = "select Product_Price_Update_Log_ID from tbl_Product_Price_Update_Log where Product_ID=" + productID + " and Active ='Yes'";
            cmd = new SqlCommand(CommandText, DBConnection.SqlConnectionObject);
            //da = new SqlDataAdapter(cmd);
            da.SelectCommand = cmd;
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                dr = cmd.ExecuteReader();
                dr.Read();
                productPriceUpdateLogID = Convert.ToInt32(dr[0].ToString());
                cmd.Dispose();
                DBConnection.CloseSqlConnection();
            }
            return productPriceUpdateLogID;
        }
        
        public void InsertProduct(string productCode, string productName, string packSize, decimal unitCostPrice, decimal unitSalePrice, string productActive)
        {
            try
            {
                string sql = @"insert into tbl_Product(Product_Code,Product_Name,Pack_Size,Unit_Cost_Price,Unit_Sale_Price,Active) values ('" + productCode + "','" + productName + "','" + packSize + "'," + unitCostPrice + "," + unitSalePrice + ",'" + productActive + "')";
                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        public void InsertProductPriceUpdateLog(int productIDForProductPriceLog, string productCode, string productName, string packSize, decimal unitCostPrice, decimal unitSalePrice, string today, string productActive)
        {
            try
            {
                string sql = @"insert into tbl_Product_Price_Update_Log(Product_ID,Product_Code,Product_Name,Pack_Size,Unit_Cost_Price,Unit_Sale_Price,Valid_From_Date,Active) values (" + productIDForProductPriceLog + ",'" + productCode + "','" + productName + "','" + packSize + "'," + unitCostPrice + "," + unitSalePrice + ",'" + today + "','" + productActive + "')";
                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }
        
        public void UpdateProductPriceUpdateLog(int productPriceUpdateLogID, string today)
        {
            try
            {
                string sql = @"update tbl_Product_Price_Update_Log set Valid_Upto_Date = '" + today + "', Active = 'No' where Product_Price_Update_Log_ID=" + productPriceUpdateLogID + "".ToString();
                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        public void UpdateProduct(int productID, string productCode, string productName, string packSize, decimal unitCostPrice, decimal unitSalePrice, string productActive)
        {
            try
            {
                string sql = @"update tbl_Product set Product_Code = '" + productCode + "', Product_Name = '" + productName + "', Pack_Size = '" + packSize + "', Unit_Cost_Price = " + unitCostPrice + ", Unit_Sale_Price = " + unitSalePrice + ", Active = '" + productActive + "' where Product_ID=" + productID + "".ToString();
                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        public void UpdateProductPriceUpdateLogData(int productPriceUpdateLogID, int productID, string productCode, string productName, string packSize, decimal unitCostPrice, decimal unitSalePrice, string productActive)
        {
            try
            {
                string sql = @"update tbl_Product_Price_Update_Log set Product_ID = " + productID + ", Product_Code = '" + productCode + "', Product_Name = '" + productName + "', Pack_Size = '" + packSize + "', Unit_Cost_Price = " + unitCostPrice + ", Unit_Sale_Price = " + unitSalePrice + ", Active = '" + productActive + "' where Product_Price_Update_Log_ID =" + productPriceUpdateLogID + "".ToString();
                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        public DataTable SearchProductById(int productID)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("select * from tbl_Product where Product_ID =" + productID + "", DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                //DataTable dt = new DataTable();
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            return dt;
        }

        public DataTable SearchProductByCode(string productCode)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                //cmd = new SqlCommand("select * from tbl_Product where Product_Code ='" + productCode + "'", DBConnection.SqlConnectionObject);
                cmd = new SqlCommand("select * from tbl_Product where Product_Code like '" + '%' + productCode + '%' + "'", DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                //DataTable dt = new DataTable();
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            return dt;
        }

        public DataTable SearchProductByName(string productName)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                //cmd = new SqlCommand("select * from tbl_Product where Product_Name ='" + productName + "'", DBConnection.SqlConnectionObject);
                cmd = new SqlCommand("select * from tbl_Product where Product_Name like '" + '%' + productName + '%' + "'", DBConnection.SqlConnectionObject);
                //like '" + '%' + searchByEmpName + '%' + 
                da = new SqlDataAdapter(cmd);
                //DataTable dt = new DataTable();
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            return dt;
        }

        public DataTable GetActiveProductForProductReport()
        {
            DBConnection.OpenSqlConnection();
            cmdDelete = new SqlCommand("delete tbl_Temp_Product", DBConnection.SqlConnectionObject);
            cmdDelete.ExecuteNonQuery();
            cmd = new SqlCommand("insert into tbl_Temp_Product (Product_Code,Product_Name,Pack_Size,Unit_Cost_Price,Unit_Sale_Price,Active)" +
                                     "select Product_Code,Product_Name,Pack_Size,Unit_Cost_Price,Unit_Sale_Price,Active from tbl_Product where Active = 'Yes'", DBConnection.SqlConnectionObject);
            da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DBConnection.CloseSqlConnection();
            return dt;
        }

        public DataTable GetNonActiveProductForProductReport()
        {
            DBConnection.OpenSqlConnection();
            cmdDelete = new SqlCommand("delete tbl_Temp_Product", DBConnection.SqlConnectionObject);
            cmdDelete.ExecuteNonQuery();
            cmd = new SqlCommand("insert into tbl_Temp_Product (Product_Code,Product_Name,Pack_Size,Unit_Cost_Price,Unit_Sale_Price,Active)" +
                                     "select Product_Code,Product_Name,Pack_Size,Unit_Cost_Price,Unit_Sale_Price,Active from tbl_Product where Active = 'No'", DBConnection.SqlConnectionObject);
            da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DBConnection.CloseSqlConnection();
            return dt;
        }

        public DataTable GetAllProductForProductReport()
        {
            DBConnection.OpenSqlConnection();
            cmdDelete = new SqlCommand("delete tbl_Temp_Product", DBConnection.SqlConnectionObject);
            cmdDelete.ExecuteNonQuery();
            cmd = new SqlCommand("insert into tbl_Temp_Product (Product_Code,Product_Name,Pack_Size,Unit_Cost_Price,Unit_Sale_Price,Active)" +
                                     "select Product_Code,Product_Name,Pack_Size,Unit_Cost_Price,Unit_Sale_Price,Active from tbl_Product", DBConnection.SqlConnectionObject);
            da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DBConnection.CloseSqlConnection();
            return dt;
        }

        public void DeleteTempData()
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("delete tbl_Temp_Product", DBConnection.SqlConnectionObject);
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        public DataTable GetTempData()
        {
            DBConnection.OpenSqlConnection();
            cmd = new SqlCommand("select * from tbl_Temp_Product", DBConnection.SqlConnectionObject);
            da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DBConnection.CloseSqlConnection();
            return dt;
        }
    }
}
