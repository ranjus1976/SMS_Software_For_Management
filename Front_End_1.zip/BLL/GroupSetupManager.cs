﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Windows.Forms;
using SMSapplication.DAL;
using SMSapplication.DAL.DAO;
using SMSapplication.DAL.Gateway;
using SMSapplication.UI;

namespace SMSapplication.BLL
{
    public class GroupSetupManager
    {
        public int logInval = 0;
        private string empDesignationID;
        //private UserDetailsGateway objUserDetails = new UserDetailsGateway();
        //private DepartmentDetailsGateway objDepartmentDetailsGateway = new DepartmentDetailsGateway();
        private DataTable dt = new DataTable();
        private SqlCommand cmd = new SqlCommand();
        private SqlDataReader dr;
        private SqlDataAdapter da = new SqlDataAdapter();

        public DataTable LoadDO()
        {
            DBConnection.OpenSqlConnection();
            cmd = new SqlCommand("select * from tbl_Employee_Info where Designation = 'DO' and Active = 'Yes'", DBConnection.SqlConnectionObject);
            da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DBConnection.CloseSqlConnection();
            return dt;
        }

        public DataTable LoadGM()
        {
            DBConnection.OpenSqlConnection();
            cmd = new SqlCommand("select * from tbl_Employee_Info where Designation = 'GM' and Active = 'Yes' and Designation_Active= 'Yes' and Department_Active = 'Yes' and Group_Active = 'Yes' and Group_Name = '" + GlobalClass.GroupSelectedFromGroupSetup + "' ", DBConnection.SqlConnectionObject);
            da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DBConnection.CloseSqlConnection();
            return dt;
        }

        public DataTable LoadDGM()
        {
            DBConnection.OpenSqlConnection();
            cmd = new SqlCommand("select * from tbl_Employee_Info where Designation = 'DGM' and Active = 'Yes' and Designation_Active= 'Yes' and Department_Active = 'Yes' and Group_Active = 'Yes' and Group_Name = '" + GlobalClass.GroupSelectedFromGroupSetup + "'", DBConnection.SqlConnectionObject);
            da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DBConnection.CloseSqlConnection();
            return dt;
        }

        public DataTable LoadDM()
        {
            DBConnection.OpenSqlConnection();
            cmd = new SqlCommand("select * from tbl_Employee_Info where Designation = 'DM' and Active = 'Yes' and Designation_Active= 'Yes' and Department_Active = 'Yes' and Group_Active = 'Yes' and Group_Name = '" + GlobalClass.GroupSelectedFromGroupSetup + "'", DBConnection.SqlConnectionObject);
            da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DBConnection.CloseSqlConnection();
            return dt;
        }

        public DataTable LoadSM()
        {
            DBConnection.OpenSqlConnection();
            cmd = new SqlCommand("select * from tbl_Employee_Info where Designation = 'SM' and Active = 'Yes' and Designation_Active= 'Yes' and Department_Active = 'Yes' and Group_Active = 'Yes' and Group_Name = '" + GlobalClass.GroupSelectedFromGroupSetup + "'", DBConnection.SqlConnectionObject);
            da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DBConnection.CloseSqlConnection();
            return dt;
        }

        public DataTable LoadASM()
        {
            DBConnection.OpenSqlConnection();
            cmd = new SqlCommand("select * from tbl_Employee_Info where Designation = 'ASM' and Active = 'Yes' and Designation_Active= 'Yes' and Department_Active = 'Yes' and Group_Active = 'Yes' and Group_Name = '" + GlobalClass.GroupSelectedFromGroupSetup + "'", DBConnection.SqlConnectionObject);
            da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DBConnection.CloseSqlConnection();
            return dt;
        }

        public DataTable LoadTSM()
        {
            DBConnection.OpenSqlConnection();
            cmd = new SqlCommand("select * from tbl_Employee_Info where Designation = 'TSM' and Active = 'Yes' and Designation_Active= 'Yes' and Department_Active = 'Yes' and Group_Active = 'Yes' and Group_Name = '" + GlobalClass.GroupSelectedFromGroupSetup + "'", DBConnection.SqlConnectionObject);
            da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DBConnection.CloseSqlConnection();
            return dt;
        }

        public DataTable LoadSR()
        {
            DBConnection.OpenSqlConnection();
            cmd = new SqlCommand("select * from tbl_Employee_Info where Designation = 'SR' and Active = 'Yes' and Designation_Active= 'Yes' and Department_Active = 'Yes' and Group_Active = 'Yes' and Group_Name = '" + GlobalClass.GroupSelectedFromGroupSetup + "'", DBConnection.SqlConnectionObject);
            da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DBConnection.CloseSqlConnection();
            return dt;
        }

        public DataTable LoadAllGroupSetup()
        {
            DBConnection.OpenSqlConnection();
            cmd = new SqlCommand("select * from tbl_Group_Setup order by Group_Setup_ID", DBConnection.SqlConnectionObject);
            da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DBConnection.CloseSqlConnection();
            return dt;
        }

        public void InsertGroupData(string groupName, int DO, int GM, int DGM, int DM, int SM, int ASM, int TSM, int SR, int groupID)
        {
            string sql = @"insert into tbl_Group_Setup(Group_Name,DO,GM,DGM,DM,SM,ASM,TSM,SR,Group_ID) values ('"
                + groupName + "'," + DO + "," + GM + "," + DGM + "," + DM + "," + SM + "," + ASM + "," + TSM + "," + SR + "," + groupID + ")";

            cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
            DBConnection.OpenSqlConnection();
            cmd.ExecuteNonQuery();
            DBConnection.CloseSqlConnection();
        }

        public void UpdateGroupData(int groupSetupID, string groupName, int DO, int GM, int DGM, int DM, int SM, int ASM, int TSM, int SR, int groupID)
        {

            string sql = @"update tbl_Group_Setup set Group_Name = '" + groupName + "',DO =" + DO + ",GM =" + GM + ",DGM =" + DGM + ",DM =" + DM + ",SM =" + SM + ",ASM =" + ASM + ",TSM =" + TSM + ",SR =" + SR + ",Group_ID =" + groupID + 
                         " where Group_Setup_ID =" + groupSetupID + "".ToString();

            cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
            DBConnection.OpenSqlConnection();
            cmd.ExecuteNonQuery();
            DBConnection.CloseSqlConnection();
        }
    }
}
