﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Windows.Forms;
using SMSapplication.DAL;
using SMSapplication.DAL.DAO;
using SMSapplication.DAL.Gateway;
using SMSapplication.UI;

namespace SMSapplication.BLL
{
    class SMSDetailsManager
    {
        public int logInval = 0;
        private GroupDetailsGateway objDetailsGateway = new GroupDetailsGateway();
        private ProductDetailsManager objProductDetailsManager = new ProductDetailsManager();
        private SalesTargerDetailsManager objSalesTargerDetailsManager = new SalesTargerDetailsManager();
        private SalesDetailsManager objSalesDetailsManager = new SalesDetailsManager();
        private DataTable dt = new DataTable();
        private SqlCommand cmd = new SqlCommand();
        private SqlCommand cmdInsertSMSReceivedLog = new SqlCommand();
        private SqlCommand cmdGetEmpDetails = new SqlCommand();
        private SqlCommand cmdGetMarketDetails = new SqlCommand();
        private SqlCommand cmdInsertSalesDetails = new SqlCommand();
        private SqlDataReader dr;
        private SqlDataReader drEmpDetails;
        private SqlDataReader drMarketDetails;
        private SqlDataAdapter da = new SqlDataAdapter();
        private SqlDataAdapter daEmpDetails = new SqlDataAdapter();
        private SqlDataAdapter daMarketDetails = new SqlDataAdapter();
        private DataSet ds = new DataSet();
        public int checkSMSReceivedDBLogFlag;
        private int checkSMSAutoSendDBLogFlag;
        private string fromDateSearch;
        private string toDateSearch;

        public void InsertSMSDetails(string empName, string dateTime, string smsReceived, string smsDetails)
        {
            try
            {
                string sql = @"insert into tbl_SMS_Details(Received_From, Received_Date_Time, Received_From_Cell_Number, SMS_Details) values (
                '" + empName + "','" + dateTime + "','" + smsReceived + "','" + smsDetails + "')";

                string smsReceivedLog = @"insert into tbl_SMS_Received_Log(SMS_Received_Date, SMS_Received_From_Cell_No, SMS_Received_From_Employee_Name) values (
                '" + dateTime + "','" + smsReceived + "','" + empName + "')";

                //04 Apr 2016
                DBConnection.OpenSqlConnection();
                cmdGetEmpDetails =
                    new SqlCommand(
                        "select * from tbl_Employee_Info where Employee_Name = '" + empName +
                        "'  and Official_Cell_No = '" + smsReceived + "'", DBConnection.SqlConnectionObject);
                daEmpDetails.SelectCommand = cmdGetEmpDetails;
                DataSet dsEmpDetails = new DataSet();
                daEmpDetails.Fill(dsEmpDetails);

                if (dsEmpDetails.Tables[0].Rows.Count > 0)
                {
                    drEmpDetails = cmdGetEmpDetails.ExecuteReader();
                    drEmpDetails.Read();
                    GlobalClass.EmpIdForSales = drEmpDetails[0].ToString();
                    GlobalClass.EmpNameForSales = drEmpDetails[1].ToString();
                    GlobalClass.EmpDesignationForSales = drEmpDetails[5].ToString();
                    GlobalClass.EmpCellNoForSales = drEmpDetails[8].ToString();
                    GlobalClass.EmpGroupNameForSales = drEmpDetails[10].ToString();
                    cmdGetEmpDetails.Dispose();
                    DBConnection.CloseSqlConnection();
                }

                ////DBConnection.OpenSqlConnection();
                ////cmdGetMarketDetails =
                ////    new SqlCommand(
                ////        "select * from tbl_Market where Employee_Name = '" + GlobalClass.EmpNameForSales +
                ////        "'  and Official_Cell_No = '" + GlobalClass.EmpCellNoForSales + "' and Employee_ID = " + Convert.ToInt16(GlobalClass.EmpIdForSales) + "", DBConnection.SqlConnectionObject);

                ////daMarketDetails.SelectCommand = cmdGetMarketDetails;
                ////DataSet dsMarket = new DataSet();
                ////daMarketDetails.Fill(dsMarket);
                ////if (dsMarket.Tables[0].Rows.Count > 0)
                ////{
                ////    drMarketDetails = cmdGetMarketDetails.ExecuteReader();
                ////    drMarketDetails.Read();
                ////    GlobalClass.EmpMarketCodeForSales = drMarketDetails[1].ToString();
                ////    GlobalClass.EmpMarketNameForSales = drMarketDetails[2].ToString();
                ////    cmdGetMarketDetails.Dispose();
                ////    DBConnection.CloseSqlConnection();
                ////}


                //////
                ////// 06-June-2016 *** NEED TO CHECK VERY CAREFULLY IN THIS BLOCK
                /////
                
                GlobalClass.SmsDetails = smsDetails;
                char lastChar = GlobalClass.SmsDetails[GlobalClass.SmsDetails.Length - 1];
                if (lastChar != ',')
                {
                    if (lastChar == '.' || lastChar == '#' || !Char.IsDigit(lastChar))
                    {
                        GlobalClass.SmsDetails = GlobalClass.SmsDetails.Replace(lastChar, ',');
                    }
                    else
                    {
                        GlobalClass.SmsDetails = GlobalClass.SmsDetails + ",";
                    }
                }

                //////
                ////// 06-June-2016 *** NEED TO CHECK VERY CAREFULLY IN THIS BLOCK
                /////


                do
                {
                    int index = GlobalClass.SmsDetails.IndexOf(",");
                    if (index > 0)
                    {
                        GlobalClass.SmsCutting = GlobalClass.SmsDetails.Substring(0, index).Trim();
                        GlobalClass.SmsDetails = GlobalClass.SmsDetails.Remove(0, index + 1).Trim();

                        if (!GlobalClass.SmsCutting.Contains(" "))
                        {
                            GlobalClass.MarketCodeOfEmpForSales = GlobalClass.SmsCutting;
                            //GlobalClass.MarketCodeOfEmpForSales = GlobalClass.SmsCutting.Substring(0, GlobalClass.SmsCutting.IndexOf(","));0
                            DBConnection.OpenSqlConnection();
                            cmdGetMarketDetails =
                                new SqlCommand(
                                    "select * from tbl_Market where Market_Code = '" + GlobalClass.MarketCodeOfEmpForSales + "' and Employee_Name = '" + GlobalClass.EmpNameForSales +
                                    "'  and Official_Cell_No = '" + GlobalClass.EmpCellNoForSales + "' and Employee_ID = " + Convert.ToInt16(GlobalClass.EmpIdForSales) + "", DBConnection.SqlConnectionObject);

                            daMarketDetails.SelectCommand = cmdGetMarketDetails;
                            DataSet dsMarket = new DataSet();
                            daMarketDetails.Fill(dsMarket);
                            if (dsMarket.Tables[0].Rows.Count > 0)
                            {
                                drMarketDetails = cmdGetMarketDetails.ExecuteReader();
                                drMarketDetails.Read();
                                GlobalClass.EmpMarketCodeForSales = drMarketDetails[1].ToString();
                                GlobalClass.EmpMarketNameForSales = drMarketDetails[2].ToString();
                                cmdGetMarketDetails.Dispose();
                                DBConnection.CloseSqlConnection();
                            }
                        }

                        if (GlobalClass.SmsCutting.Contains(" "))
                        {
                            GlobalClass.ProCodeForSales = GlobalClass.SmsCutting.Substring(0, GlobalClass.SmsCutting.IndexOf(" "));
                            GlobalClass.ProQuantityForSales = Convert.ToInt16(GlobalClass.SmsCutting.Substring(GlobalClass.SmsCutting.LastIndexOf(" ") + 1));

                            if (GlobalClass.ProCodeForSales.Contains("Memo") ||
                                GlobalClass.ProCodeForSales.Contains("Visit") ||
                                GlobalClass.ProCodeForSales.Contains("Amount") ||
                                GlobalClass.ProCodeForSales.Contains("MemoSaloon") ||
                                GlobalClass.ProCodeForSales.Contains("MemoBeautyParlor") ||
                                GlobalClass.ProCodeForSales.Contains("MemoCosmetics") ||
                                GlobalClass.ProCodeForSales.Contains("MemoPharmacy") ||
                                GlobalClass.ProCodeForSales.Contains("NewOrder")||
                                GlobalClass.ProCodeForSales.Contains("MemoShop"))
                            {
                                //Under Process will done later
                                //if (GlobalClass.ProCodeForSales == "Memo")
                                //{
                                //    //tbl_Other_Sales_Related_Info
                                //    //dobOfEmp = dataGridViewEmployeeList.CurrentRow.Cells[3].Value.ToString();
                                //    //txtDOB.Text = dobOfEmp.Replace("12:00:00 AM", "");
                                //    //txtDOB.Text = txtDOB.Text.Trim();

                                //    //DataTable dtOtherSalesRelatedInfoMemo = new DataTable();
                                //    //dtOtherSalesRelatedInfoMemo = objSalesDetailsManager.CheckOtherInfo()
                                //}
                            }
                            else
                            {
                                GlobalClass.SalesDate = dateTime.ToString();
                                if (GlobalClass.SalesDate.Contains(" ") || GlobalClass.SalesDate.Contains("AM") || GlobalClass.SalesDate.Contains("PM"))
                                {
                                    GlobalClass.SalesDate = GlobalClass.SalesDate.Substring(0,GlobalClass.SalesDate.IndexOf(" "));
                                    //GlobalClass.SalesMonth = GlobalClass.SalesDate.Substring(0,GlobalClass.SalesDate.IndexOf("/")+1);
                                    //GlobalClass.SalesDay = GlobalClass.SalesDate.Substring(0,GlobalClass.SalesDate.IndexOf("/")+1);
                                    //GlobalClass.SalesYear = GlobalClass.SalesDate;

                                    int year = DateTime.Now.Year;
                                    int month = DateTime.Now.Month;
                                    int daysInMonth = Convert.ToInt16(DateTime.DaysInMonth(year, month).ToString());

                                    if (daysInMonth == 28)
                                    {
                                        fromDateSearch = Convert.ToString(month) + "/01/" + Convert.ToString(year);
                                        toDateSearch = Convert.ToString(month) + "/" + Convert.ToString(daysInMonth) + "/" + Convert.ToString(year);
                                    }

                                    else if (daysInMonth == 29)
                                    {
                                        fromDateSearch = Convert.ToString(month) + "/01/" + Convert.ToString(year);
                                        toDateSearch = Convert.ToString(month) + "/" + Convert.ToString(daysInMonth) + "/" + Convert.ToString(year);
                                    }

                                    else if (daysInMonth == 30)
                                    {
                                        fromDateSearch = Convert.ToString(month) + "/01/" + Convert.ToString(year);
                                        toDateSearch = Convert.ToString(month) + "/" + Convert.ToString(daysInMonth) + "/" + Convert.ToString(year);
                                    }

                                    else if (daysInMonth == 31)
                                    {
                                        fromDateSearch = Convert.ToString(month) + "/01/" + Convert.ToString(year);
                                        toDateSearch = Convert.ToString(month) + "/" + Convert.ToString(daysInMonth) + "/" + Convert.ToString(year);
                                    }
                                }
                                
                                DataTable dtProductDetails = new DataTable();
                                dtProductDetails = objProductDetailsManager.GetProductDetailsForSales(GlobalClass.ProCodeForSales);
                                if (dtProductDetails.Rows.Count > 0)
                                {
                                    GlobalClass.ProIdForSales = dtProductDetails.Rows[0][0].ToString();
                                    GlobalClass.ProCodeForSales = dtProductDetails.Rows[0][1].ToString();
                                    GlobalClass.ProNameForSales = dtProductDetails.Rows[0][2].ToString();
                                    GlobalClass.ProCostPriceForSales = Convert.ToDecimal(dtProductDetails.Rows[0][4].ToString());
                                    GlobalClass.ProSalePriceForSales = Convert.ToDecimal(dtProductDetails.Rows[0][5].ToString());
                                    if (GlobalClass.ProQuantityForSales > 0 && GlobalClass.ProSalePriceForSales != null)
                                    {
                                        GlobalClass.ProSaleAmountForSales = (GlobalClass.ProQuantityForSales * GlobalClass.ProSalePriceForSales);
                                    }
                                }

                                DataTable dtCheckProductInTargetTable = new DataTable();
                                dtCheckProductInTargetTable = objSalesTargerDetailsManager.CheckTarget(fromDateSearch, toDateSearch, GlobalClass.ProCodeForSales, GlobalClass.EmpNameForSales);
                                if (dtCheckProductInTargetTable.Rows.Count > 0)
                                {
                                    DataTable dtCheckDuplicate = new DataTable();
                                    dtCheckDuplicate = objSalesDetailsManager.CheckDuplicate(GlobalClass.SalesDate, GlobalClass.ProCodeForSales, GlobalClass.EmpNameForSales);
                                    if (dtCheckDuplicate.Rows.Count > 0)
                                    {
                                        objSalesDetailsManager.DeleteSales(GlobalClass.SalesDate, GlobalClass.ProCodeForSales, GlobalClass.EmpNameForSales);
                                    }
                                        DBConnection.OpenSqlConnection();
                                        //string insertSalesDetails = @"insert into tbl_Sales(Sales_Date,Product_ID,Product_Code,Product_Name,Unit_Cost_Price,Unit_Sale_Price,Sales_Unit,Sales_Amount,Employee_ID, Employee_Name, Designation,Official_Cell_No,Group_Name,Market_Code,Name_Of_Market) values (
                                        //'" + dateTime + "'," + Convert.ToInt16(GlobalClass.ProIdForSales) + ",'" + GlobalClass.ProCodeForSales + "','" + GlobalClass.ProNameForSales + "'," + Convert.ToDecimal(GlobalClass.ProCostPriceForSales) + "," + Convert.ToDecimal(GlobalClass.ProSalePriceForSales) + "," + Convert.ToInt16(GlobalClass.ProQuantityForSales) + "," + Convert.ToDecimal(GlobalClass.ProSaleAmountForSales) + "," + Convert.ToInt16(GlobalClass.EmpIdForSales) + ",'" + GlobalClass.EmpNameForSales + "','" + GlobalClass.EmpDesignationForSales + "','" + GlobalClass.EmpCellNoForSales + "','" + GlobalClass.EmpGroupNameForSales + "','" + GlobalClass.EmpMarketCodeForSales + "','" + GlobalClass.EmpMarketNameForSales + "')";

                                        //string insertSalesDetails = @"insert into tbl_Sales(Sales_Date,Product_ID,Product_Code,Product_Name,Unit_Cost_Price,Unit_Sale_Price,Sales_Unit,Sales_Amount,Employee_ID, Employee_Name, Designation,Official_Cell_No,Group_Name,Market_Code,Name_Of_Market) values (
                                        //'" + dateTime + "'," + Convert.ToInt16(GlobalClass.ProIdForSales) + ",'" + GlobalClass.ProCodeForSales + "','" + GlobalClass.ProNameForSales + "'," + Convert.ToDecimal(GlobalClass.ProCostPriceForSales) + "," + Convert.ToDecimal(GlobalClass.ProSalePriceForSales) + "," + Convert.ToInt16(GlobalClass.ProQuantityForSales) + "," + Convert.ToDecimal(GlobalClass.ProSaleAmountForSales) + "," + Convert.ToInt16(GlobalClass.EmpIdForSales) + ",'" + GlobalClass.EmpNameForSales + "','" + GlobalClass.EmpDesignationForSales + "','" + GlobalClass.EmpCellNoForSales + "','" + GlobalClass.EmpGroupNameForSales + "','" + GlobalClass.MarketCodeOfEmpForSales + "','" + GlobalClass.EmpMarketNameForSales + "')";

                                        string insertSalesDetails = @"insert into tbl_Sales(Sales_Date,Product_ID,Product_Code,Product_Name,Unit_Cost_Price,Unit_Sale_Price,Sales_Unit,Sales_Amount,Employee_ID, Employee_Name, Designation,Official_Cell_No,Group_Name,Market_Code,Name_Of_Market,SMS_Received_Date) values (
                                        '" + GlobalClass.SalesDate + "'," + Convert.ToInt16(GlobalClass.ProIdForSales) + ",'" + GlobalClass.ProCodeForSales + "','" + GlobalClass.ProNameForSales + "'," + Convert.ToDecimal(GlobalClass.ProCostPriceForSales) + "," + Convert.ToDecimal(GlobalClass.ProSalePriceForSales) + "," + Convert.ToInt16(GlobalClass.ProQuantityForSales) + "," + Convert.ToDecimal(GlobalClass.ProSaleAmountForSales) + "," + Convert.ToInt16(GlobalClass.EmpIdForSales) + ",'" + GlobalClass.EmpNameForSales + "','" + GlobalClass.EmpDesignationForSales + "','" + GlobalClass.EmpCellNoForSales + "','" + GlobalClass.EmpGroupNameForSales + "','" + GlobalClass.MarketCodeOfEmpForSales + "','" + GlobalClass.EmpMarketNameForSales + "','" + dateTime + "')";
                                        //GlobalClass.SalesDate
                                        cmdInsertSalesDetails = new SqlCommand(insertSalesDetails, DBConnection.SqlConnectionObject);
                                        cmdInsertSalesDetails.ExecuteNonQuery();
                                        DBConnection.CloseSqlConnection();                                        
                                }
                                else
                                {
                                    DataTable dtCheckDuplicateInSalesTargetExclude = new DataTable();
                                    dtCheckDuplicateInSalesTargetExclude = objSalesDetailsManager.CheckDuplicateInSalesTargetExclude(GlobalClass.SalesDate, GlobalClass.ProCodeForSales, GlobalClass.EmpNameForSales);
                                    if (dtCheckDuplicateInSalesTargetExclude.Rows.Count > 0)
                                    {
                                        objSalesDetailsManager.DeleteSalesInSalesTargetExclude(GlobalClass.SalesDate, GlobalClass.ProCodeForSales, GlobalClass.EmpNameForSales);
                                    }
                                        DBConnection.OpenSqlConnection();
                                        //string insertSalesDetails = @"insert into tbl_Sales(Sales_Date,Product_ID,Product_Code,Product_Name,Unit_Cost_Price,Unit_Sale_Price,Sales_Unit,Sales_Amount,Employee_ID, Employee_Name, Designation,Official_Cell_No,Group_Name,Market_Code,Name_Of_Market) values (
                                        //'" + dateTime + "'," + Convert.ToInt16(GlobalClass.ProIdForSales) + ",'" + GlobalClass.ProCodeForSales + "','" + GlobalClass.ProNameForSales + "'," + Convert.ToDecimal(GlobalClass.ProCostPriceForSales) + "," + Convert.ToDecimal(GlobalClass.ProSalePriceForSales) + "," + Convert.ToInt16(GlobalClass.ProQuantityForSales) + "," + Convert.ToDecimal(GlobalClass.ProSaleAmountForSales) + "," + Convert.ToInt16(GlobalClass.EmpIdForSales) + ",'" + GlobalClass.EmpNameForSales + "','" + GlobalClass.EmpDesignationForSales + "','" + GlobalClass.EmpCellNoForSales + "','" + GlobalClass.EmpGroupNameForSales + "','" + GlobalClass.EmpMarketCodeForSales + "','" + GlobalClass.EmpMarketNameForSales + "')";

                                        //string insertSalesDetails = @"insert into tbl_Sales(Sales_Date,Product_ID,Product_Code,Product_Name,Unit_Cost_Price,Unit_Sale_Price,Sales_Unit,Sales_Amount,Employee_ID, Employee_Name, Designation,Official_Cell_No,Group_Name,Market_Code,Name_Of_Market) values (
                                        //'" + dateTime + "'," + Convert.ToInt16(GlobalClass.ProIdForSales) + ",'" + GlobalClass.ProCodeForSales + "','" + GlobalClass.ProNameForSales + "'," + Convert.ToDecimal(GlobalClass.ProCostPriceForSales) + "," + Convert.ToDecimal(GlobalClass.ProSalePriceForSales) + "," + Convert.ToInt16(GlobalClass.ProQuantityForSales) + "," + Convert.ToDecimal(GlobalClass.ProSaleAmountForSales) + "," + Convert.ToInt16(GlobalClass.EmpIdForSales) + ",'" + GlobalClass.EmpNameForSales + "','" + GlobalClass.EmpDesignationForSales + "','" + GlobalClass.EmpCellNoForSales + "','" + GlobalClass.EmpGroupNameForSales + "','" + GlobalClass.MarketCodeOfEmpForSales + "','" + GlobalClass.EmpMarketNameForSales + "')";

                                        //string insertSalesDetails = @"insert into tbl_Sales_Exclude_Target(Sales_Date,Product_ID,Product_Code,Product_Name,Unit_Cost_Price,Unit_Sale_Price,Sales_Unit,Sales_Amount,Employee_ID, Employee_Name, Designation,Official_Cell_No,Group_Name,Market_Code,Name_Of_Market) values (
                                        //'" + GlobalClass.SalesDate + "'," + Convert.ToInt16(GlobalClass.ProIdForSales) + ",'" + GlobalClass.ProCodeForSales + "','" + GlobalClass.ProNameForSales + "'," + Convert.ToDecimal(GlobalClass.ProCostPriceForSales) + "," + Convert.ToDecimal(GlobalClass.ProSalePriceForSales) + "," + Convert.ToInt16(GlobalClass.ProQuantityForSales) + "," + Convert.ToDecimal(GlobalClass.ProSaleAmountForSales) + "," + Convert.ToInt16(GlobalClass.EmpIdForSales) + ",'" + GlobalClass.EmpNameForSales + "','" + GlobalClass.EmpDesignationForSales + "','" + GlobalClass.EmpCellNoForSales + "','" + GlobalClass.EmpGroupNameForSales + "','" + GlobalClass.MarketCodeOfEmpForSales + "','" + GlobalClass.EmpMarketNameForSales + "')";

                                        string insertSalesDetails = @"insert into tbl_Sales_Exclude_Target(Sales_Date,Product_ID,Product_Code,Product_Name,Unit_Cost_Price,Unit_Sale_Price,Sales_Unit,Sales_Amount,Employee_ID, Employee_Name, Designation,Official_Cell_No,Group_Name,Market_Code,Name_Of_Market,SMS_Received_Date) values (
                                        '" + GlobalClass.SalesDate + "'," + Convert.ToInt16(GlobalClass.ProIdForSales) + ",'" + GlobalClass.ProCodeForSales + "','" + GlobalClass.ProNameForSales + "'," + Convert.ToDecimal(GlobalClass.ProCostPriceForSales) + "," + Convert.ToDecimal(GlobalClass.ProSalePriceForSales) + "," + Convert.ToInt16(GlobalClass.ProQuantityForSales) + "," + Convert.ToDecimal(GlobalClass.ProSaleAmountForSales) + "," + Convert.ToInt16(GlobalClass.EmpIdForSales) + ",'" + GlobalClass.EmpNameForSales + "','" + GlobalClass.EmpDesignationForSales + "','" + GlobalClass.EmpCellNoForSales + "','" + GlobalClass.EmpGroupNameForSales + "','" + GlobalClass.MarketCodeOfEmpForSales + "','" + GlobalClass.EmpMarketNameForSales + "','" + dateTime + "')";
                                        //SMS_Received_Date
                                        //GlobalClass.SalesDate
                                        cmdInsertSalesDetails = new SqlCommand(insertSalesDetails, DBConnection.SqlConnectionObject);
                                        cmdInsertSalesDetails.ExecuteNonQuery();
                                        DBConnection.CloseSqlConnection();                                        
                                }
                            }
                        }
                    }
                    else if (index <= 0)
                    {
                        MessageBox.Show("Nothing left for CUT.....");
                    }
                } while (GlobalClass.SmsDetails.Contains(","));



                // Need to complete 04 Apr 2016 cut product code and qty from sms details (0 to ",") then next then next
                //GlobalClass.SmsDetails = smsDetails;

                //GlobalClass.SmsDetails = "CP 50, CPO 100, CPPN 100, EPMG 100";

                //if (GlobalClass.SmsDetails.Contains(","))
                //{
                //    int index = GlobalClass.SmsDetails.IndexOf(",");
                //    GlobalClass.SmsCutting = GlobalClass.SmsDetails.Substring(0, index);
                //}

                // End of Need to complete 04 Apr 2016


                //End of 04 Apr 2016

                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                cmdInsertSMSReceivedLog = new SqlCommand(smsReceivedLog, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                cmdInsertSMSReceivedLog.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public int checkSMSReceivedDBLog(string receivedDate, string empOfficialCell)
        {
            DBConnection.OpenSqlConnection();
            string CommandText = "select * from tbl_SMS_Received_Log where SMS_Received_Date ='" + receivedDate + "' and SMS_Received_From_Cell_No='" + empOfficialCell + "'";
            cmd = new SqlCommand(CommandText, DBConnection.SqlConnectionObject);
            //cmd.ExecuteNonQuery();
            da.SelectCommand = cmd;
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                checkSMSReceivedDBLogFlag = 1;
            }
            else
            {
                checkSMSReceivedDBLogFlag = 0;
            }

            return checkSMSReceivedDBLogFlag;
        }

        public int checkAutoSendLogDB(string sendDate, string empOfficialCellNo)
        {
            DBConnection.OpenSqlConnection();
            string CommandText = "select * from tbl_SMS_Auto_Send_Log where Send_Date ='" + sendDate + "' and Send_To_Cell_No='" + empOfficialCellNo + "'";
            cmd = new SqlCommand(CommandText, DBConnection.SqlConnectionObject);
            //cmd.ExecuteNonQuery();
            da.SelectCommand = cmd;
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                checkSMSAutoSendDBLogFlag = 1;
            }
            else
            {
                checkSMSAutoSendDBLogFlag = 0;
            }

            return checkSMSAutoSendDBLogFlag;
        }

        public void insertAutoSendLog(string currentDate, string empCellNo)
        {
            string sql = @"insert into tbl_SMS_Auto_Send_Log(Send_Date, Send_To_Cell_No) values ('" + currentDate + "','" + empCellNo + "')";

            cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
            DBConnection.OpenSqlConnection();
            cmd.ExecuteNonQuery();
            DBConnection.CloseSqlConnection();
        }
    }
}
