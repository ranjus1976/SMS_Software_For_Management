﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Windows.Forms;
using SMSapplication.DAL;
using SMSapplication.DAL.DAO;
using SMSapplication.DAL.Gateway;
using SMSapplication.UI;

namespace SMSapplication.BLL
{
    public class UserDetailsManager
    {
        public int logInval = 0;
        private UserDetailsGateway objUserDetails = new UserDetailsGateway();
        private DataTable dt = new DataTable();
        private SqlCommand cmd = new SqlCommand();
        private SqlDataReader dr;

        public int userLogInCheck(UserDetails objUserLogin)
        {
            objUserDetails.UserLogIn(objUserLogin);
            if (objUserDetails.flag == 1)
            {
                logInval = 1;
                return logInval;
            }
            else
            {
                logInval = 0;
                return logInval;
            }
        }

        public DataTable com_UserType_Display()
        {
            dt = objUserDetails.combobox_UserType_Display();
            return dt;
        }

        public DataTable AllUserDetails()
        {
            DataTable dt = new DataTable();
            dt = objUserDetails.ShowAllUser();
            return dt;
        }

        public void InsertNewUser(string userName, string password, int userRoleId, string userRoleName, string activate)
        {
            try
            {
                string sql = @"insert into tbl_User_Details(User_Name, Password, User_Role_ID, User_Role,Active) values ('"
                             + userName + "','" + password + "',"
                             + userRoleId + ",'" + userRoleName + "','" + activate + "')";

                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                DBConnection.CloseSqlConnection();
            }
        }

        public void UpdateUser(int userID, string userName, string password, int userRoleId, string userRoleName, string activate)
        {
            try
            {
                string sql = @"update tbl_User_Details set User_Name = '" + userName + "',Password = '" + password +
                         "',User_Role_ID = " + userRoleId + ",User_Role = '" + userRoleName + "', Active = '" + activate +
                         "' where User_ID = " + userID + "";

                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                DBConnection.CloseSqlConnection();
            }
            
        }

        
    }
}
