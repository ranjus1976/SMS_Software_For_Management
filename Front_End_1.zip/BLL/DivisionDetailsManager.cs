﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Windows.Forms;
using SMSapplication.DAL;
using SMSapplication.DAL.DAO;
using SMSapplication.DAL.Gateway;
using SMSapplication.UI;

namespace SMSapplication.BLL
{
    public class DivisionDetailsManager
    {
        public int logInval = 0;
        private string empDesignationID;
        private string empDesignationActiveDetails;
        private string getEmpDivName;
        private string empTeamName;
        private int divisionID;
        private string empDivisionID;
        //private UserDetailsGateway objUserDetails = new UserDetailsGateway();
        //private DepartmentDetailsGateway objDepartmentDetailsGateway = new DepartmentDetailsGateway();
        private DataTable dt = new DataTable();
        private SqlCommand cmd = new SqlCommand();
        private SqlCommand cmdSqlUpdate = new SqlCommand();
        private SqlCommand cmdUpdateActivityEndDate = new SqlCommand();
        private SqlCommand cmdDelete = new SqlCommand();
        private SqlCommand cmdUpdateMarket = new SqlCommand();
        private SqlCommand cmdUpdateTeam = new SqlCommand();
        private SqlDataReader dr;
        private SqlDataAdapter da = new SqlDataAdapter();
        private SqlCommand cmdUpdateTeamDivision = new SqlCommand();
        private SqlCommand cmdUpdateTeamDetails = new SqlCommand();
        private SqlCommand cmdUpdateTeamDivisionActivityEndDate = new SqlCommand();
        private SqlCommand cmdUpdateTeamDetailsActivityEndDate = new SqlCommand();
        GroupDetailsManager objGroupDetailsManager = new GroupDetailsManager();
        private string divisionIDForZone;
        
        public DataTable ShowAllDivision()
        {
            try
            {
                DBConnection.OpenSqlConnection();
                //cmd = new SqlCommand("select distinct(Division_Name),Group_ID from tbl_Division order by Group_ID ASC", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC

                // closed on 20 July 2016
                //cmd = new SqlCommand("select * from tbl_Division order by Division_ID ASC", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
                // closed on 20 July 2016

                cmd = new SqlCommand("select d.Division_ID, d.Division_Name, d.Employee_Name, d.Designation_Code,d.Activity_Start_Date, d.Activity_End_Date, d.Active, " +
                "t.Team_Name, t.Team_ID " +
                "from tbl_Division d " +
                "inner join tbl_Team_Division td " +
                "on d.Division_ID = td.Division_ID " +
                "inner join tbl_Team t " +
                "on td.Team_ID = t.Team_ID " +
                "order by d.Division_Name asc", DBConnection.SqlConnectionObject);

                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            
            return dt;
        }

        public DataTable ShowAllDivisionForReport()
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmdDelete = new SqlCommand("delete tbl_Temp_Division", DBConnection.SqlConnectionObject);
                cmdDelete.ExecuteNonQuery();
                //cmd = new SqlCommand("select distinct(Division_Name),Group_ID from tbl_Division order by Group_ID ASC", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
                cmd = new SqlCommand("insert into tbl_Temp_Division (Division_Name,Group_Name,Group_ID,Employee_Name,Designation,Active)" +
                             "select Division_Name,Group_Name,Group_ID,Employee_Name,Designation,Active from tbl_Division", DBConnection.SqlConnectionObject);

                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            
            return dt;
        }

        public DataTable ShowSelectedDivisionForReport(string divisionName)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmdDelete = new SqlCommand("delete tbl_Temp_Division", DBConnection.SqlConnectionObject);
                cmdDelete.ExecuteNonQuery();
                //cmd = new SqlCommand("select distinct(Division_Name),Group_ID from tbl_Division order by Group_ID ASC", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
                cmd = new SqlCommand("insert into tbl_Temp_Division (Division_Name,Group_Name,Group_ID,Employee_Name,Designation,Active)" +
                             "select Division_Name,Group_Name,Group_ID,Employee_Name,Designation,Active from tbl_Division where Division_Name = '" + divisionName + "'", DBConnection.SqlConnectionObject);

                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            
            return dt;
        }

        public DataTable GetTempData()
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("select * from tbl_Temp_Division ORDER BY division_name asc, designation", DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            
            return dt;
        }

        public DataTable LoadDivisionByDivisionName(string divisionName)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                //cmd = new SqlCommand("select distinct(Division_Name),Group_ID from tbl_Division order by Group_ID ASC", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
                cmd = new SqlCommand("select * from tbl_Division where Division_Name ='" + divisionName + "' order by Designation, Group_ID ASC", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            
            return dt;
        }

        public DataTable ShowDistinctDivision()
        {
            try
            {
                DBConnection.OpenSqlConnection();
                //cmd = new SqlCommand("select distinct(Division_Name),Group_ID, Active from tbl_Division order by Division_Name ASC", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
                cmd = new SqlCommand("select distinct(Division_Name), Group_Name, Active from tbl_Division order by Group_Name ASC", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
                //cmd = new SqlCommand("select * from tbl_Division order by Division_ID, Group_ID ASC", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            
            return dt;
        }

        public DataTable LoadDistinctGroup(string cmbSelectDivisionForEnableOrDisable)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                //cmd = new SqlCommand("select distinct(Division_Name),Group_ID, Active from tbl_Division order by Division_Name ASC", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
                cmd = new SqlCommand("select distinct(Group_Name) from tbl_Division where Division_Name ='" + cmbSelectDivisionForEnableOrDisable + "' ", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
                //cmd = new SqlCommand("select * from tbl_Division order by Division_ID, Group_ID ASC", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            
            return dt;
        }

        public DataTable LoadDistinctDisabledDivision()
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("select distinct(Division_Name),Active from tbl_Division where Active = 'No' order by Division_Name ASC", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
                //cmd = new SqlCommand("select distinct(Division_Name),Group_ID, Active from tbl_Division where Active = 'No' order by Group_ID ASC", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
                //cmd = new SqlCommand("select * from tbl_Division order by Division_ID, Group_ID ASC", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            
            return dt;
        }

        public DataTable LoadDistinctEnabledDivision()
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("select distinct(Division_Name), Active from tbl_Division where Active = 'Yes' order by Division_Name ASC", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
                //cmd = new SqlCommand("select distinct(Division_Name),Group_ID, Active from tbl_Division where Active = 'Yes' order by Group_ID ASC", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
                //cmd = new SqlCommand("select * from tbl_Division order by Division_ID, Group_ID ASC", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            
            return dt;
        }

        public void DisableDivision(string selectedDivisionName, string slecetedGroupName)
        {
            try
            {
                string sql = @"update tbl_Division set Active = 'No' where Division_Name ='" + selectedDivisionName + "' and Group_name ='" + slecetedGroupName + "'".ToString();
                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);

                string sqlUpdateMarket = @"update tbl_Market set Active = 'No' where DivisionName ='" + selectedDivisionName + "' and Group_name ='" + slecetedGroupName + "'".ToString();
                cmdUpdateMarket = new SqlCommand(sqlUpdateMarket, DBConnection.SqlConnectionObject);

                //string sqlUpdateTeam = @"update tbl_Group set Active = 'No' where Group_Name ='" + selectedDivisionName + "'".ToString();
                //cmdUpdateTeam = new SqlCommand(sqlUpdateTeam, DBConnection.SqlConnectionObject);

                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                cmdUpdateMarket.ExecuteNonQuery();

                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        public void EnableDivision(string selectedDivisionName, string slecetedGroupName)
        {
            try
            {
                string sql = @"update tbl_Division set Active = 'Yes' where Division_Name ='" + selectedDivisionName + "' and Group_name ='" + slecetedGroupName + "'".ToString();
                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);

                string sqlUpdateMarket = @"update tbl_Market set Active = 'Yes' where DivisionName ='" + selectedDivisionName + "' and Group_name ='" + slecetedGroupName + "'".ToString();
                cmdUpdateMarket = new SqlCommand(sqlUpdateMarket, DBConnection.SqlConnectionObject);

                //string sqlUpdateTeam = @"update tbl_Group set Active = 'Yes' where Group_Name ='" + selectedDivisionName + "'".ToString();
                //cmdUpdateTeam = new SqlCommand(sqlUpdateTeam, DBConnection.SqlConnectionObject);

                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                cmdUpdateMarket.ExecuteNonQuery();
                //cmdUpdateTeam.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }
        
        public void DeleteTempDivision()
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("delete tbl_Temp_Division", DBConnection.SqlConnectionObject);
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        public void InsertTempDivision(string tmpDivisionName, string tmpGroupName, int tmpGroupID, string tmpEmpName, string tmpEmpDesignation, string tmpDivisionActive)
        {
            try
            {
                string sql = @"insert into tbl_Temp_Division(Division_Name, Group_Name, Group_ID, Employee_Name, Designation,Active) values ('"
                + tmpDivisionName + "','" + tmpGroupName + "'," + tmpGroupID + ",'" + tmpEmpName + "','" + tmpEmpDesignation + "','" + tmpDivisionActive + "')";

                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            
        }

        public DataTable ShowTempDivision()
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("select * from tbl_Temp_Division order by Division_ID, Group_ID ASC", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            
            return dt;
        }

        public void InsertDivision_New()
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand(@"insert into tbl_Division(Division_Name, Group_Name, Group_ID, Employee_Name, Designation,Active)" +
                                    "select Division_Name, Group_Name, Group_ID, Employee_Name, Designation,Active from tbl_Temp_Division", DBConnection.SqlConnectionObject);
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        public DataTable LoadSelectDivision()
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("select distinct(Division_Name) from tbl_Division", DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            
            return dt;
        }

        public DataTable LoadDivisionBySelectedGroup(string GroupName)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                //cmd = new SqlCommand("select distinct(Division_Name) from tbl_Division", DBConnection.SqlConnectionObject);
                cmd = new SqlCommand("select distinct(Division_Name) from tbl_Division where Group_Name ='" + GroupName + "'", DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            
            return dt;
        }

        public void UpdateDivision(int tmpDivisionID ,string tmpDivisionName ,string tmpGroupName ,int tmpGroupID , string tmpEmpName ,string tmpEmpDesig ,string tmpDivisionActive )
        {
            try
            {
                string sql = @"update tbl_Division set Division_Name = '" + tmpDivisionName + "', Group_Name = '" + tmpGroupName + "', Group_ID = " + tmpGroupID + ", Employee_Name = '" + tmpEmpName + "', Designation = '" + tmpEmpDesig + "', Active = '" + tmpDivisionActive + "' where Division_ID=" + tmpDivisionID + "".ToString();
                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            
        }

        public DataTable GetDivisionInfo(string cmbSelectDivisionForUpdate)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                //cmd = new SqlCommand("select distinct(Division_Name),Group_ID from tbl_Division order by Group_ID ASC", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
                cmd = new SqlCommand("select distinct(Division_Name), Group_Name, Group_ID, Active from tbl_Division where Division_Name ='" + cmbSelectDivisionForUpdate + "'", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            
            return dt;
        }

        public string GetDivisionID(string division)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                string CommandText = "select Division_ID from tbl_Division where Division_Name = '" + division + "'";
                cmd = new SqlCommand(CommandText, DBConnection.SqlConnectionObject);
                //da = new SqlDataAdapter(cmd);
                da.SelectCommand = cmd;
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    dr = cmd.ExecuteReader();
                    dr.Read();
                    empDivisionID = dr[0].ToString();
                    cmd.Dispose();
                    DBConnection.CloseSqlConnection();
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            return empDivisionID;
        }

        public DataTable GetPrevAddedEmpList(string cmbSelectDivisionForUpdate)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                //cmd = new SqlCommand("select distinct(Division_Name),Group_ID from tbl_Division order by Group_ID ASC", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
                cmd = new SqlCommand("select * from tbl_Division where Division_Name ='" + cmbSelectDivisionForUpdate + "' order by designation", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            
            return dt;
        }

        public DataTable CheckEmpExist(string empName, string cmbSelectDivisionForUpdate)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                //cmd = new SqlCommand("select distinct(Division_Name),Group_ID from tbl_Division order by Group_ID ASC", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
                cmd = new SqlCommand("select employee_name from tbl_Division where employee_name = '" + empName + "' and Division_Name ='" + cmbSelectDivisionForUpdate + "'", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            
            return dt;
        }

        public DataTable GetTeamNameAndTeamID(string cmbSelectDivisionForMarket)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                //cmd = new SqlCommand("select distinct(Division_Name),Group_ID from tbl_Division order by Group_ID ASC", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
                cmd = new SqlCommand("select distinct(Division_Name), Group_Name, Group_ID, Active from tbl_Division where Division_Name ='" + cmbSelectDivisionForMarket + "'", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            
            return dt;
        }

        public DataTable LoadEmployeeBySelectedDivision(string divisionName)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                //cmd = new SqlCommand("select distinct(Division_Name),Group_ID from tbl_Division order by Group_ID ASC", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
                //cmd = new SqlCommand("select Employee_Name from tbl_Division where Division_Name ='" + divisionName + "' order by Designation asc", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
                cmd = new SqlCommand("select Employee_Name from tbl_Division where Division_Name ='" + divisionName + "' and Designation ='SR'", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            
            return dt;
        }

        public string GetDivisionNameBySelectedTeamAndEmplyoyee(string cmbSelectGroupForSalesTarget, string cmbSelectEmployeeForSalesTarget)
        {

            try
            {
                DBConnection.OpenSqlConnection();
                string CommandText = "select distinct(Division_Name) from tbl_Division where Group_Name ='" + cmbSelectGroupForSalesTarget + "' and Employee_Name ='" + cmbSelectEmployeeForSalesTarget + "'";
                cmd = new SqlCommand(CommandText, DBConnection.SqlConnectionObject);
                //da = new SqlDataAdapter(cmd);
                da.SelectCommand = cmd;
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    dr = cmd.ExecuteReader();
                    dr.Read();
                    getEmpDivName = dr[0].ToString();
                    cmd.Dispose();
                    DBConnection.CloseSqlConnection();
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

            return getEmpDivName;
            
            //DBConnection.OpenSqlConnection();
            ////cmd = new SqlCommand("select distinct(Division_Name),Group_ID from tbl_Division order by Group_ID ASC", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
            //cmd = new SqlCommand("select distinct(Division_Name) from tbl_Division where Group_Name ='" + cmbSelectGroupForSalesTarget + "' and Employee_Name ='" + cmbSelectEmployeeForSalesTarget + "'", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
            //da = new SqlDataAdapter(cmd);
            //DataTable dt = new DataTable();
            //da.Fill(dt);
            //DBConnection.CloseSqlConnection();
            //return dt;
        }

        // closed on 20 July 2016
        //public void InsertDivision(string divisionName, string empDesignationCode, string empName, string divisionActivityStartDate, string divisionActive, string teamNameForDivision, int teamIdForDivision)
        //{
        //    string sql = @"insert into tbl_Division(Division_Name, Employee_Name, Designation_Code, Activity_Start_Date, Active, Team_Name, Team_ID) values ('"
        //        + divisionName + "','" + empName + "','" + empDesignationCode + "','" + divisionActivityStartDate + "','" + divisionActive + "','" + teamNameForDivision + "'," + teamIdForDivision + ")";

        //    cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
        //    DBConnection.OpenSqlConnection();
        //    cmd.ExecuteNonQuery();
        //    DBConnection.CloseSqlConnection();
        //}
        // closed on 20 July 2016

        public void InsertDivision(string divisionName, string empDesignationCode, string empName, string divisionActivityStartDate, string divisionActive, int teamIdForDivision)
        {
            try
            {
                string sql = @"insert into tbl_Division(Division_Name, Employee_Name, Designation_Code, Activity_Start_Date, Active) values ('"
                                + divisionName + "','" + empName + "','" + empDesignationCode + "','" + divisionActivityStartDate + "','" + divisionActive + "')";

                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();

                string cmdGetDivisionID = "select Division_ID from tbl_Division where Division_Name='" + divisionName + "'";
                cmd = new SqlCommand(cmdGetDivisionID, DBConnection.SqlConnectionObject);
                da.SelectCommand = cmd;
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    dr = cmd.ExecuteReader();
                    dr.Read();
                    divisionID = Convert.ToInt16(dr[0].ToString());
                    GlobalClass.DivisionIdForUpdateDivision = divisionID;
                    cmd.Dispose();
                }
                DBConnection.CloseSqlConnection();
                DBConnection.OpenSqlConnection();
                string sqlInsertTeamDivision = @"insert into tbl_Team_Division(Team_ID, Division_ID, Created_On, Active) values (" + teamIdForDivision + "," + divisionID + ",'" + divisionActivityStartDate + "','" + divisionActive + "')";
                cmd = new SqlCommand(sqlInsertTeamDivision, DBConnection.SqlConnectionObject);
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();

                empTeamName = objGroupDetailsManager.GetTeamName(teamIdForDivision);
                if (empTeamName != "")
                {
                    DBConnection.OpenSqlConnection();
                    string sqlInsertTeamDetails = @"insert into tbl_Team_Details(Team_ID, Team_Name, Division_ID, Division_Name, Employee_Name, Designation_Code, Activity_Start_Date, Active) values (" + teamIdForDivision + ", '" + empTeamName + "', " + divisionID + ", '" + divisionName + "', '" + empName + "', '" + empDesignationCode + "', '" + divisionActivityStartDate + "','" + divisionActive + "')";
                    cmd = new SqlCommand(sqlInsertTeamDetails, DBConnection.SqlConnectionObject);
                    cmd.ExecuteNonQuery();
                    DBConnection.CloseSqlConnection();
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            
        }

        //public void UpdateDivisionWithEndDate(int divisionId, string divisionName, string empDesignationCode, string empName, string divisionActivityStartDate, string divisionActivityEndDate, string divisionActive, string teamNameForDivision, int teamIdForDivision)
        //{
        //    string sql = @"update tbl_Division set Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Activity_End_Date = '" + divisionActivityEndDate + "', Active = '" + divisionActive + "', Team_Name = '" + teamNameForDivision + "', Team_ID = " + teamIdForDivision + " where Division_ID = " + divisionId + "".ToString();
        //    cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
        //    DBConnection.OpenSqlConnection();
        //    cmd.ExecuteNonQuery();
        //    DBConnection.CloseSqlConnection();
        //}

        public void UpdateDivisionWithEndDate(int divisionId, string divisionName, string empDesignationCode, string empName, string divisionActivityStartDate, string divisionActivityEndDate, string divisionActive, string teamNameForDivision, int teamIdForDivision)
        {
            try
            {
                string sql = @"update tbl_Division set Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Activity_End_Date = '" + divisionActivityEndDate + "', Active = '" + divisionActive + "' where Division_ID = " + divisionId + "".ToString(); //, Team_Name = '" + teamNameForDivision + "', Team_ID = " + teamIdForDivision + "
                //string sqlUpdateTeamDivision = @"update tbl_Team_Division set Modified_On = '" + divisionActivityEndDate + "', Active = '" + divisionActive + "' where Division_ID = " + divisionId + " and Team_ID = " + teamIdForDivision + " ".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "',
                //string sqlUpdateTeamDetails = @"update tbl_Team_Details set Activity_End_Date = '" + divisionActivityEndDate + "', Active = '" + divisionActive + "' where Division_ID = " + divisionId + " and Team_ID = " + teamIdForDivision + " ".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "',
                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                //cmdUpdateTeamDivision = new SqlCommand(sqlUpdateTeamDivision, DBConnection.SqlConnectionObject);
                //cmdUpdateTeamDetails = new SqlCommand(sqlUpdateTeamDetails, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                //cmdUpdateTeamDivision.ExecuteNonQuery();
                //cmdUpdateTeamDetails.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            
        }

        public void UpdateDivision(int divisionId, string divisionName, string empDesignationCode, string empName, string divisionActivityStartDate, string divisionActivityEndDate, string divisionActive, string teamNameForDivision, int teamIdForDivision)
        {
            try
            {
                string sql = @"update tbl_Division set Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Activity_End_Date = '" + divisionActivityEndDate + "', Active = '" + divisionActive + "' where Division_ID = " + divisionId + "".ToString(); //, Team_Name = '" + teamNameForDivision + "', Team_ID = " + teamIdForDivision + "
                string sqlUpdateActivityEndDate = @"update tbl_Division set Activity_End_Date = NULL where Activity_End_Date = '1/1/1900 12:00:00 AM'".ToString();
                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                cmdUpdateActivityEndDate = new SqlCommand(sqlUpdateActivityEndDate, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                cmdUpdateActivityEndDate.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            
        }

        public void UpdateTeamDetails(int divisionId, string divisionName, string empDesignationCode, string empName, string divisionActivityStartDate, string divisionActivityEndDate, string divisionActive, string teamNameForDivision, int teamIdForDivision)
        {
            try
            {
                string sqlUpdateTeamDetails = @"update tbl_Team_Details set Division_Name = '" + divisionName + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Activity_End_Date = '" + divisionActivityEndDate + "', Active = '" + divisionActive + "' where Division_ID = " + divisionId + "".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Team_Name = '" + teamNameForDivision + "', Team_ID = " + teamIdForDivision + ", Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "',
                //string sqlUpdate = @"update tbl_Team_Details set Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Team_Name = '" + teamNameForDivision + "', Team_ID = " + teamIdForDivision + " where Division_ID = " + divisionId + " and Region_ID is null and Region_Name is null and Zone_ID is null and Zone_Name is null and Area_ID is null and Area_Name is null".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Team_Name = '" + teamNameForDivision + "', Team_ID = " + teamIdForDivision + ", Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Division_Name = '" + divisionName + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Activity_End_Date = '" + divisionActivityEndDate + "', Active = '" + divisionActive + "'
                string sqlUpdate = @"update tbl_Team_Details set Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "' where Division_ID = " + divisionId + " and Region_ID is null and Region_Name is null and Zone_ID is null and Zone_Name is null and Area_ID is null and Area_Name is null".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Team_Name = '" + teamNameForDivision + "', Team_ID = " + teamIdForDivision + ", Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Division_Name = '" + divisionName + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Activity_End_Date = '" + divisionActivityEndDate + "', Active = '" + divisionActive + "'
                string sqlUpdateTeamDetailsActivityEndDate = @"update tbl_Team_Details set Activity_End_Date = NULL where Activity_End_Date = '1/1/1900 12:00:00 AM'".ToString();
                cmdUpdateTeamDetails = new SqlCommand(sqlUpdateTeamDetails, DBConnection.SqlConnectionObject);
                cmdSqlUpdate = new SqlCommand(sqlUpdate, DBConnection.SqlConnectionObject);
                cmdUpdateTeamDetailsActivityEndDate = new SqlCommand(sqlUpdateTeamDetailsActivityEndDate, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmdUpdateTeamDetails.ExecuteNonQuery();
                cmdSqlUpdate.ExecuteNonQuery();
                cmdUpdateTeamDetailsActivityEndDate.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
        }

        public void UpdateTeamDetailsByUpdateTeamName(int divisionId, string divisionName, string empDesignationCode, string empName, string divisionActivityStartDate, string divisionActivityEndDate, string divisionActive, string teamNameForDivision, int teamIdForDivision)
        {
            try
            {
                string sqlUpdateTeamDetails = @"update tbl_Team_Details set Division_Name = '" + divisionName + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Activity_End_Date = '" + divisionActivityEndDate + "', Active = '" + divisionActive + "' where Division_ID = " + divisionId + "".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Team_Name = '" + teamNameForDivision + "', Team_ID = " + teamIdForDivision + ", Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "',
                string sqlUpdate = @"update tbl_Team_Details set Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "' where Division_ID = " + divisionId + " and Region_ID is null and Region_Name is null and Zone_ID is null and Zone_Name is null and Area_ID is null and Area_Name is null".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Team_Name = '" + teamNameForDivision + "', Team_ID = " + teamIdForDivision + ", Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Division_Name = '" + divisionName + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Activity_End_Date = '" + divisionActivityEndDate + "', Active = '" + divisionActive + "',and Region_ID is null and Region_Name is null and Zone_ID is null and Zone_Name is null and Area_ID is null and Area_Name is null
                string sqlUpdateTeam = @"update tbl_Team_Details set Team_Name = '" + teamNameForDivision + "', Team_ID = " + teamIdForDivision + " where Division_ID = " + divisionId + "".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Team_Name = '" + teamNameForDivision + "', Team_ID = " + teamIdForDivision + ", Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Division_Name = '" + divisionName + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Activity_End_Date = '" + divisionActivityEndDate + "', Active = '" + divisionActive + "',and Region_ID is null and Region_Name is null and Zone_ID is null and Zone_Name is null and Area_ID is null and Area_Name is null
                //string sqlUpdate = @"update tbl_Team_Details set Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "' where Division_ID = " + divisionId + " and Region_ID is null and Region_Name is null and Zone_ID is null and Zone_Name is null and Area_ID is null and Area_Name is null".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Team_Name = '" + teamNameForDivision + "', Team_ID = " + teamIdForDivision + ", Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Division_Name = '" + divisionName + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Activity_End_Date = '" + divisionActivityEndDate + "', Active = '" + divisionActive + "'
                string sqlUpdateTeamDetailsActivityEndDate = @"update tbl_Team_Details set Activity_End_Date = NULL where Activity_End_Date = '1/1/1900 12:00:00 AM'".ToString();
                cmdUpdateTeamDetails = new SqlCommand(sqlUpdateTeamDetails, DBConnection.SqlConnectionObject);
                cmdSqlUpdate = new SqlCommand(sqlUpdate, DBConnection.SqlConnectionObject);
                cmdUpdateTeam = new SqlCommand(sqlUpdateTeam, DBConnection.SqlConnectionObject);
                cmdUpdateTeamDetailsActivityEndDate = new SqlCommand(sqlUpdateTeamDetailsActivityEndDate, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmdUpdateTeamDetails.ExecuteNonQuery();
                cmdSqlUpdate.ExecuteNonQuery();
                cmdUpdateTeam.ExecuteNonQuery();
                cmdUpdateTeamDetailsActivityEndDate.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
        }

        public void UpdateTeamDetailsWithEndDate(int divisionId, string divisionName, string empDesignationCode, string empName, string divisionActivityStartDate, string divisionActivityEndDate, string divisionActive, string teamNameForDivision, int teamIdForDivision)
        {
            try
            {
                string sqlUpdateTeamDetails = @"update tbl_Team_Details set Division_Name = '" + divisionName + "' where Division_ID = " + divisionId + "".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Team_Name = '" + teamNameForDivision + "', Team_ID = " + teamIdForDivision + ", Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "',, Activity_Start_Date = '" + divisionActivityStartDate + "', Activity_End_Date = '" + divisionActivityEndDate + "', Active = '" + divisionActive + "'
                string sqlUpdate = @"update tbl_Team_Details set  Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_End_Date = '" + divisionActivityEndDate + "', Active = '" + divisionActive + "' where Division_ID = " + divisionId + " and Team_ID = " + teamIdForDivision + " and Region_ID is null and Region_Name is null and Zone_ID is null and Zone_Name is null and Area_ID is null and Area_Name is null ".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "',
                cmdUpdateTeamDetails = new SqlCommand(sqlUpdateTeamDetails, DBConnection.SqlConnectionObject);
                cmdSqlUpdate = new SqlCommand(sqlUpdate, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmdUpdateTeamDetails.ExecuteNonQuery();
                cmdSqlUpdate.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
        }

        public void UpdateTeamDivision(int divisionId, string divisionName, string empDesignationCode, string empName, string divisionActivityStartDate, string divisionActivityEndDate, string divisionActive, string teamNameForDivision, int teamIdForDivision)
        {
            try
            {
                string sqlUpdateTeamDivision = @"update tbl_Team_Division set Team_ID = " + teamIdForDivision + ", Active = '" + divisionActive + "', Modified_On = '" + divisionActivityEndDate + "' where Division_ID = " + divisionId + "".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "',
                string sqlUpdateTeamDivisionActivityEndDate = @"update tbl_Team_Division set Modified_On = NULL where Modified_On = '1/1/1900 12:00:00 AM'".ToString();
                cmdUpdateTeamDivision = new SqlCommand(sqlUpdateTeamDivision, DBConnection.SqlConnectionObject);
                cmdUpdateTeamDivisionActivityEndDate = new SqlCommand(sqlUpdateTeamDivisionActivityEndDate, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmdUpdateTeamDivision.ExecuteNonQuery();
                cmdUpdateTeamDivisionActivityEndDate.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
        }

        public string GetDivisionIDFromDivisionRegion(int regionID)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                string CommandText = "select Division_ID from tbl_Division_Region where Region_ID =" + regionID + " and Active ='Yes'";
                cmd = new SqlCommand(CommandText, DBConnection.SqlConnectionObject);
                //da = new SqlDataAdapter(cmd);
                da.SelectCommand = cmd;
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    dr = cmd.ExecuteReader();
                    dr.Read();
                    divisionIDForZone = dr[0].ToString();
                    cmd.Dispose();
                    DBConnection.CloseSqlConnection();
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            return divisionIDForZone;
        }

        public string GetDivisionName(int divisionID)
        {

            try
            {
                DBConnection.OpenSqlConnection();
                string CommandText = "select distinct(Division_Name) from tbl_Division where Division_ID =" + divisionID + "";
                cmd = new SqlCommand(CommandText, DBConnection.SqlConnectionObject);
                //da = new SqlDataAdapter(cmd);
                da.SelectCommand = cmd;
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    dr = cmd.ExecuteReader();
                    dr.Read();
                    getEmpDivName = dr[0].ToString();
                    cmd.Dispose();
                    DBConnection.CloseSqlConnection();
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

            return getEmpDivName;

            //DBConnection.OpenSqlConnection();
            ////cmd = new SqlCommand("select distinct(Division_Name),Group_ID from tbl_Division order by Group_ID ASC", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
            //cmd = new SqlCommand("select distinct(Division_Name) from tbl_Division where Group_Name ='" + cmbSelectGroupForSalesTarget + "' and Employee_Name ='" + cmbSelectEmployeeForSalesTarget + "'", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
            //da = new SqlDataAdapter(cmd);
            //DataTable dt = new DataTable();
            //da.Fill(dt);
            //DBConnection.CloseSqlConnection();
            //return dt;
        }

        public DataTable GetDivisionDetails(string cmbSelectDivisionForRegion)
        {
            try
            {
                //empDesignationCode, empName, regionActivityStartDate
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("select Employee_Name, Designation_Code, Activity_Start_Date, Division_Name from tbl_Division where Division_Name = '" + cmbSelectDivisionForRegion + "'", DBConnection.SqlConnectionObject);
                //cmd = new SqlCommand("select * from tbl_Team_Details order by Team_Name,Team_ID,Team_Details_ID asc", DBConnection.SqlConnectionObject);
                //select * from tbl_Team_Details order by Team_Name,Team_ID,Division_ID,Region_ID,Zone_ID,Area_ID asc
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }

            return dt;
        }

        public DataTable GetTeamDetails(int regionIdForZone)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                //cmd = new SqlCommand("select distinct(Division_Name),Group_ID from tbl_Division order by Group_ID ASC", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
                cmd = new SqlCommand("select team_id,team_name from tbl_team where team_id = (select team_id from tbl_team_division where Division_ID = "+ regionIdForZone +")", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }

            return dt;
        }

        //public void UpdateDivision(int divisionId, string divisionName, string empDesignationCode, string empName, string divisionActivityStartDate, string divisionActivityEndDate, string divisionActive, string teamNameForDivision, int teamIdForDivision)
        //{
        //    string sql = @"update tbl_Division set Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Activity_End_Date = '" + divisionActivityEndDate + "', Active = '" + divisionActive + "', Team_Name = '" + teamNameForDivision + "', Team_ID = " + teamIdForDivision + " where Division_ID = " + divisionId + "".ToString();
        //    string sqlUpdateActivityEndDate = @"update tbl_Division set Activity_End_Date = NULL where Activity_End_Date = '1/1/1900 12:00:00 AM'".ToString();
        //    cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
        //    cmdUpdateActivityEndDate = new SqlCommand(sqlUpdateActivityEndDate, DBConnection.SqlConnectionObject);
        //    DBConnection.OpenSqlConnection();
        //    cmd.ExecuteNonQuery();
        //    cmdUpdateActivityEndDate.ExecuteNonQuery();
        //    DBConnection.CloseSqlConnection();
        //}
    }
}
