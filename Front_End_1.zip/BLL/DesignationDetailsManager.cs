﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Windows.Forms;
using SMSapplication.DAL;
using SMSapplication.DAL.DAO;
using SMSapplication.DAL.Gateway;
using SMSapplication.UI;

namespace SMSapplication.BLL
{
    public class DesignationDetailsManager
    {
        public int logInval = 0;
        private string empDesignationID;
        private string empDesignationActiveDetails;
        //private UserDetailsGateway objUserDetails = new UserDetailsGateway();
        //private DepartmentDetailsGateway objDepartmentDetailsGateway = new DepartmentDetailsGateway();
        private DataTable dt = new DataTable();
        private SqlCommand cmd = new SqlCommand();
        private SqlDataReader dr;
        private SqlDataAdapter da = new SqlDataAdapter();

        public string GetDesignationID(string designation)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                string CommandText = "select * from tbl_Designation where Designation_Code='" + designation + "'";
                cmd = new SqlCommand(CommandText, DBConnection.SqlConnectionObject);
                //da = new SqlDataAdapter(cmd);
                da.SelectCommand = cmd;
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    dr = cmd.ExecuteReader();
                    dr.Read();
                    empDesignationID = dr[0].ToString();
                    cmd.Dispose();
                    DBConnection.CloseSqlConnection();
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            return empDesignationID;
        }

        public string GetDesignationActiveDetails(int designationID)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                string CommandText = "select * from tbl_Designation where Designation_ID='" + designationID + "'";
                cmd = new SqlCommand(CommandText, DBConnection.SqlConnectionObject);
                //da = new SqlDataAdapter(cmd);
                da.SelectCommand = cmd;
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    dr = cmd.ExecuteReader();
                    dr.Read();
                    empDesignationActiveDetails = dr[3].ToString();
                    cmd.Dispose();
                    DBConnection.CloseSqlConnection();
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            return empDesignationActiveDetails;
        }

        public DataTable ShowAllDesignation()
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("select * from tbl_Designation where Designation_Code != 'MD' and Designation_Code != 'DMD' order by Designation_ID ASC", DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            return dt;
        }

        public DataTable LoadDesignationCombo()
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("select * from tbl_Designation where Active = 'Yes' and Designation_Code != 'MD' and Designation_Code != 'DMD' order by Designation_ID ASC", DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            return dt;
        }

        public void InsertDesignation(string designation, string designationDetails, string activeDesignation)
        {
            try
            {
                string sql = @"insert into tbl_Designation(Designation_Code,Designation_Details,Active) values ('"
                    + designation + "','" + designationDetails + "','" + activeDesignation + "')";

                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
        }

        public void UpdateDesignation(int designationID, string designation, string designationDetails, string activeDesignation)
        {
            try
            {
                string sql = @"update tbl_Designation set Designation_Code = '" + designation + "', Designation_Details = '" + designationDetails + "', Active = '" + activeDesignation +
                         "' where Designation_ID=" + designationID + "".ToString();

                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
        }
    }
}
