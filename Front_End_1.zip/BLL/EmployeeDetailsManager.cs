﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Windows.Forms;
using SMSapplication.DAL;
using SMSapplication.DAL.DAO;
using SMSapplication.DAL.Gateway;
using SMSapplication.UI;


namespace SMSapplication.BLL
{
    public class EmployeeDetailsManager
    {
        public int logInval = 0;
        private SqlDataAdapter da = new SqlDataAdapter();
        private DataTable dt = new DataTable();
        private SqlCommand cmd = new SqlCommand();
        private SqlDataReader dr;
        private string employeeName;
        private string getEmpIdForSalesTarget;
        private string getEmpCellNoForSalesTarget;
        List<EmployeeDetails> listOfEmployee = new List<EmployeeDetails>();
        
        public DataTable ShowAllEmployee()
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("select * from tbl_Employee_Info order by Employee_ID ASC", DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                //DataTable dt = new DataTable();
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

            return dt;
        }

        public string GetEmployeeName(string cellNumber)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                string CommandText = "select * from tbl_Employee_Info where Official_Cell_No='" + cellNumber + "'";
                cmd = new SqlCommand(CommandText, DBConnection.SqlConnectionObject);
                //da = new SqlDataAdapter(cmd);
                da.SelectCommand = cmd;
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    dr = cmd.ExecuteReader();
                    dr.Read();
                    employeeName = dr[1].ToString();
                    cmd.Dispose();
                    DBConnection.CloseSqlConnection();
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            
            return employeeName;
        }

        public DataTable SearchEmployeeByName(string searchByEmpName)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                //string CommandText = "select * from tbl_Employee_Info where Employee_Name ='" + searchByEmpName + "'";
                string CommandText = "select * from tbl_Employee_Info where Employee_Name like '" + '%' + searchByEmpName + '%' + "' order by Employee_ID ASC";
                cmd = new SqlCommand(CommandText, DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                //DataTable dt = new DataTable();
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            
            return dt;
        }

        //LoadEmployeeBySelectedGroupAndDesignation(cmbSelectGroupForSalesTarget.Text.ToString(), cmbSelectDesignationForSalesTarget.Text.ToString())
        public DataTable LoadEmployeeBySelectedGroupAndDesignation(string groupName, string designation)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                //string CommandText = "select * from tbl_Employee_Info where Official_Cell_No='" + searchByMobile + "'";
                string CommandText = "select * from tbl_Employee_Info where Group_Name = '" + groupName + "' and Designation = '" + designation + "' order by Employee_ID ASC";
                cmd = new SqlCommand(CommandText, DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                //DataTable dt = new DataTable();
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

            return dt;
        }

        public DataTable LoadEmployeeForDivisionBySelectedGroupAndDesignation(string groupName, string designation)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                //string CommandText = "select * from tbl_Employee_Info where Official_Cell_No='" + searchByMobile + "'";
                string CommandText = "select * from tbl_Employee_Info where Group_Name = '" + groupName + "' and Designation = '" + designation + "'";
                cmd = new SqlCommand(CommandText, DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                //DataTable dt = new DataTable();
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

            return dt;
        }

        public DataTable SearchEmployeeByMobile(string searchByMobile)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                //string CommandText = "select * from tbl_Employee_Info where Official_Cell_No='" + searchByMobile + "'";
                string CommandText = "select * from tbl_Employee_Info where Official_Cell_No like '" + '%' + searchByMobile + '%' + "' order by Employee_ID ASC";
                cmd = new SqlCommand(CommandText, DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                //DataTable dt = new DataTable();
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

            return dt;
        }

        public DataTable SearchEmployeeByGroup(string searchByGroup)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                //string CommandText = "select * from tbl_Employee_Info where Official_Cell_No='" + searchByMobile + "'";
                string CommandText = "select * from tbl_Employee_Info where Group_Name like '" + '%' + searchByGroup + '%' + "' and Group_Name !='All Group' order by Employee_ID ASC";
                cmd = new SqlCommand(CommandText, DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                //DataTable dt = new DataTable();
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

            return dt;
        }

        //SearchEmployeeByGroupNameAndDesignation(txtSearchCriteriaForEmployee.Text.ToString(), cmbSearchCriteriaForEmployeeByDesignation.Text.ToString());
        public DataTable SearchEmployeeByGroupNameAndDesignation(string groupName, string designation)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                //string CommandText = "select * from tbl_Employee_Info where Official_Cell_No='" + searchByMobile + "'";
                string CommandText = "select * from tbl_Employee_Info where Group_Name like '" + '%' + groupName + '%' + "' and Designation like '" + '%' + designation + '%' + "' order by Employee_ID ASC";
                cmd = new SqlCommand(CommandText, DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                //DataTable dt = new DataTable();
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

            return dt;
        }

        public DataTable SearchEmployeeDesignation(string designation)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                //string CommandText = "select * from tbl_Employee_Info where Official_Cell_No='" + searchByMobile + "'";
                string CommandText = "select * from tbl_Employee_Info where Designation_Code like '" + '%' + designation + '%' + "' order by Employee_ID ASC";
                cmd = new SqlCommand(CommandText, DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                //DataTable dt = new DataTable();
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

            return dt;
        }

        //SearchEmployeeDesignation(cmbSearchCriteriaForEmployeeByDesignation.Text.ToString())

        public List<EmployeeDetails> GetEmployeeDetails()
        {
            try
            {
                DBConnection.OpenSqlConnection();
                string CommandText = "select * from tbl_Employee_Info where Designation='SR' and Active ='Yes' order by Employee_ID ASC";
                cmd = new SqlCommand(CommandText, DBConnection.SqlConnectionObject);
                //da = new SqlDataAdapter(cmd);
                //da.SelectCommand = cmd;
                //DataSet ds = new DataSet();
                //da.Fill(ds);
                //if (ds.Tables[0].Rows.Count > 0)
                //{
                //    dr = cmd.ExecuteReader();
                //    dr.Read();
                //    employeeName = dr[1].ToString();
                //    cmd.Dispose();
                //    DBConnection.CloseSqlConnection();
                //}
                cmd.ExecuteNonQuery();
                dr = cmd.ExecuteReader();
                listOfEmployee = new List<EmployeeDetails>();
                while (dr.Read())
                {
                    EmployeeDetails objEmployeeDetails = new EmployeeDetails();
                    objEmployeeDetails.EmpOfficialCellNo = dr[8].ToString();
                    listOfEmployee.Add(objEmployeeDetails);
                }
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            
            return listOfEmployee;
        }

        public void InsertEmployeePrev(string empName, string empAdd, string empDOB, int empDesiID, string empDesi, int empDeptID, string empDept, string empCell, int empGroupID, string empGroup, string empActive, string empDesiActive, string empDeptActive, string empGroupActive, string empQuitDate) //, int empMarketID, string empMarketCode, string empNameOfMarket //, string empDesiActive, string empDeptActive, string empGroupActive
        {
            try
            {
                string sql = @"insert into tbl_Employee_Info(Employee_Name, Address, DOB,Designation_ID,Designation,Department_ID,Department_Name,Official_Cell_No,Group_ID,Group_Name,Active,Designation_Active,Department_Active,Group_Active,Quit_Date) values ('" //,Designation_Active,Department_Active,Group_Active,Market_ID,Market_Code,Name_Of_Market
                    + empName + "','" + empAdd + "','" + empDOB + "'," + empDesiID + ",'" + empDesi + "'," + empDeptID + ",'" + empDept + "','" + empCell + "'," + empGroupID + ",'" + empGroup + "','" + empActive + "','" + empDesiActive + "','" + empDeptActive + "','" + empGroupActive + "','" + empQuitDate + "')"; //," + empMarketID + ",'" + empMarketCode + "','" + empNameOfMarket + "' //'" + empDesiActive + "','" + empDeptActive + "','" + empGroupActive + "',

                string sqlUpdateQuitDate = @"update tbl_Employee_Info set Quit_Date = NULL where Quit_Date = '1/1/1900 12:00:00 AM'".ToString();

                cmd = new SqlCommand(sqlUpdateQuitDate, DBConnection.SqlConnectionObject);

                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        public void InsertEmployee(string empName, string empAdd, string empDOB, string empDesi, string empDept, string empCell, string empActive, string empQuitDate) //, int empMarketID, string empMarketCode, string empNameOfMarket //, string empDesiActive, string empDeptActive, string empGroupActive
        {
            try
            {
                string sql = @"insert into tbl_Employee_Info(Employee_Name, Address, DOB, Designation_Code, Department_Name, Contact_No, Active, Quit_Date) values ('" //,Designation_Active,Department_Active,Group_Active,Market_ID,Market_Code,Name_Of_Market
                    + empName + "','" + empAdd + "','" + empDOB + "','" + empDesi + "','" + empDept + "','" + empCell + "','" + empActive + "','" + empQuitDate + "')"; //," + empMarketID + ",'" + empMarketCode + "','" + empNameOfMarket + "' //'" + empDesiActive + "','" + empDeptActive + "','" + empGroupActive + "',

                string sqlUpdateQuitDate = @"update tbl_Employee_Info set Quit_Date = NULL where Quit_Date = '1/1/1900 12:00:00 AM'".ToString();

                cmd = new SqlCommand(sqlUpdateQuitDate, DBConnection.SqlConnectionObject);

                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        public void UpdateEmployeePrev(int empID, string empName, string empAdd, string empDOB, int empDesiID, string empDesi, int empDeptID, string empDept, string empCell, int empGroupID, string empGroup, string empActive, string empQuitDate) //, string empDesiActive, string empDeptActive, string empGroupActive // , int empMarketID, string empMarketCode, string empNameOfMarket //string empDesiActive, string empDeptActive, string empGroupActive, 
        {
            try
            {
                string sql = @"update tbl_Employee_Info set Employee_Name = '" + empName + "'," +
                                                        "Address = '" + empAdd + "', " +
                                                        "DOB = '" + empDOB + "', " +
                                                        "Designation_ID = " + empDesiID + ", " +
                                                        "Designation = '" + empDesi + "', " +
                                                        "Department_ID = " + empDeptID + ", " +
                                                        "Department_Name = '" + empDept + "', " +
                                                        "Official_Cell_No = '" + empCell + "', " +
                                                        "Group_ID = " + empGroupID + ", " +
                                                        "Group_Name = '" + empGroup + "', " +
                                                        "Active = '" + empActive + "', " +
                                                        "Quit_Date = '" + empQuitDate + "' " +
                                                        "where Employee_ID=" + empID + "";
                //, " +
                //                                            "Market_ID = " + empMarketID + ", " +
                //                                            "Market_Code = '" + empMarketCode + "', " +
                //                                            "Name_Of_Market = '" + empNameOfMarket + "'

                //                                          "Designation_Active = '" + empDesiActive + "', " +
                //                                          "Department_Active = '" + empDeptActive + "', " +
                //                                          "Group_Active = '" + empGroupActive + "', " +


                //Market_ID,Market_Code,Name_Of_Market,Quit_Date
                //, int empMarketID, string empMarketCode, string empNameOfMarket, string empQuitDate

                //string sqlUpdateMarketID = @"exec updateMarketID 0";
                //string sqlUpdateMarketID = @"update tbl_Employee_Info set Market_ID = null where Employee_ID = " + empID + "";

                //update tbl_Employee_Info set market_id = NULL where market_id = 0
                //"Quit_Date = NULL " +
                //and Quit_Date = '1/1/1900 12:00:00 AM'

                string sqlUpdateQuitDate = @"update tbl_Employee_Info set Quit_Date = NULL where Quit_Date = '1/1/1900 12:00:00 AM'".ToString();
                //"Quit_Date = NULL " +
                //and Quit_Date = '1/1/1900 12:00:00 AM'

                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                //cmd = new SqlCommand(sqlUpdateMarketID, DBConnection.SqlConnectionObject);
                //cmd = new SqlCommand(sqlUpdateQuitDate, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();

                cmd = new SqlCommand(sqlUpdateQuitDate, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        public void UpdateEmployee(int empID, string empName, string empAdd, string empDOB, string empDesi, string empDept, string empCell, string empActive, string empQuitDate) //, string empDesiActive, string empDeptActive, string empGroupActive // , int empMarketID, string empMarketCode, string empNameOfMarket //string empDesiActive, string empDeptActive, string empGroupActive, 
        {
            try
            {
                string sql = @"update tbl_Employee_Info set Employee_Name = '" + empName + "'," +
                                                                        "Address = '" + empAdd + "', " +
                                                                        "DOB = '" + empDOB + "', " +
                                                                        "Designation_Code = '" + empDesi + "', " +
                                                                        "Department_Name = '" + empDept + "', " +
                                                                        "Contact_No = '" + empCell + "', " +
                                                                        "Active = '" + empActive + "', " +
                                                                        "Quit_Date = '" + empQuitDate + "' " +
                                                                        "where Employee_ID=" + empID + "";
                //, " +
                //                                            "Market_ID = " + empMarketID + ", " +
                //                                            "Market_Code = '" + empMarketCode + "', " +
                //                                            "Name_Of_Market = '" + empNameOfMarket + "'

                //                                          "Designation_Active = '" + empDesiActive + "', " +
                //                                          "Department_Active = '" + empDeptActive + "', " +
                //                                          "Group_Active = '" + empGroupActive + "', " +


                //Market_ID,Market_Code,Name_Of_Market,Quit_Date
                //, int empMarketID, string empMarketCode, string empNameOfMarket, string empQuitDate

                //string sqlUpdateMarketID = @"exec updateMarketID 0";
                //string sqlUpdateMarketID = @"update tbl_Employee_Info set Market_ID = null where Employee_ID = " + empID + "";

                //update tbl_Employee_Info set market_id = NULL where market_id = 0
                //"Quit_Date = NULL " +
                //and Quit_Date = '1/1/1900 12:00:00 AM'

                string sqlUpdateQuitDate = @"update tbl_Employee_Info set Quit_Date = NULL where Quit_Date = '1/1/1900 12:00:00 AM'".ToString();
                //"Quit_Date = NULL " +
                //and Quit_Date = '1/1/1900 12:00:00 AM'

                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                //cmd = new SqlCommand(sqlUpdateMarketID, DBConnection.SqlConnectionObject);
                //cmd = new SqlCommand(sqlUpdateQuitDate, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();

                cmd = new SqlCommand(sqlUpdateQuitDate, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }      
        }

        public void UpdateGroupActiveLogInEmpInfo(int groupID, string activeGroup)
        {
            try
            {
                string sql = @"update tbl_Employee_Info set Group_Active = '" + activeGroup + "'" +
                                                            "where Group_ID=" + groupID + "".ToString();

                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }
        
        //UpdateDesignationActiveLogInEmpInfo(designationID, activeDesignation);
        public void UpdateDesignationActiveLogInEmpInfo(int designationID, string activeDesignation)
        {
            try
            {
                string sql = @"update tbl_Employee_Info set Designation_Active = '" + activeDesignation + "'" +
                                                        "where Designation_ID=" + designationID + "".ToString();

                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        public void UpdateDepartmentActiveLogInEmpInfo(int deptID, string activeDepartment)
        {
            try
            {
                string sql = @"update tbl_Employee_Info set Department_Active = '" + activeDepartment + "'" +
                                                        "where Department_ID=" + deptID + "".ToString();

                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        public DataTable LoadEmployeeBySelectedGroup(string selectedGroup)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("select * from tbl_Employee_Info where Designation ='SR' and Group_Name = '" + selectedGroup + "' and Active ='Yes' and Designation_Active ='Yes' and Department_Active ='Yes' and Group_Active ='Yes' order by Employee_ID ASC", DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            return dt;
        }

        public DataTable GetEmployeeDetailsForMarket(string empNameSelectForMarket)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("select * from tbl_Employee_Info where Designation ='SR' and Employee_Name = '" + empNameSelectForMarket + "' and Active ='Yes' and Designation_Active ='Yes' and Department_Active ='Yes' and Group_Active ='Yes'", DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            
            return dt;
        }

        //txtEmployeeIDForSalesTarget.Text =
        //        objEmployeeDetailsManager.GetEmployeeID(cmbSelectEmployeeForSalesTarget.Text);
        //    txtEmpMobileNoForSalesTarget.Text = GetEmployeeMobileNo(cmbSelectEmployeeForSalesTarget.Text);

        public string GetEmployeeID(string empName)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                string CommandText = "select * from tbl_Employee_Info where Employee_Name ='" + empName + "'";
                cmd = new SqlCommand(CommandText, DBConnection.SqlConnectionObject);
                //da = new SqlDataAdapter(cmd);
                da.SelectCommand = cmd;
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    dr = cmd.ExecuteReader();
                    dr.Read();
                    getEmpIdForSalesTarget = dr[0].ToString();
                    cmd.Dispose();
                    DBConnection.CloseSqlConnection();
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

            return getEmpIdForSalesTarget;
        }

        public string GetEmployeeMobileNo(string empName)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                string CommandText = "select * from tbl_Employee_Info where Employee_Name ='" + empName + "'";
                cmd = new SqlCommand(CommandText, DBConnection.SqlConnectionObject);
                //da = new SqlDataAdapter(cmd);
                da.SelectCommand = cmd;
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    dr = cmd.ExecuteReader();
                    dr.Read();
                    getEmpCellNoForSalesTarget = dr[8].ToString();
                    cmd.Dispose();
                    DBConnection.CloseSqlConnection();
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

            return getEmpCellNoForSalesTarget;
        }

        //LoadDO(cmbSelectTeam.Text)
        public DataTable LoadDO(string cmbSelectTeam)
        {
            try
            {
                cmbSelectTeam = "All Group";
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("select * from tbl_Employee_Info where Designation ='DO' and Group_Name = '" + cmbSelectTeam + "' and Active ='Yes' and Designation_Active ='Yes' and Department_Active ='Yes' and Group_Active ='Yes' order by Employee_ID ASC", DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            
            return dt;
        }

        public DataTable GetEmpList(string groupName)
        {
            try
            {
                //cmd = new SqlCommand("select * from tbl_Employee_Info where Designation ='DO' and Group_Name = '" + cmbSelectTeam + "' and Active ='Yes' and Designation_Active ='Yes' and Department_Active ='Yes' and Group_Active ='Yes' order by Employee_ID ASC", DBConnection.SqlConnectionObject);
                cmd = new SqlCommand("select * from tbl_Employee_Info where group_name ='" + groupName + "' or group_name ='All Group' order by designation_id asc", DBConnection.SqlConnectionObject);
                //select * from tbl_employee_info where group_name ='Ranesh Chandra Das Gupta' or group_name ='All Group' order by designation_id asc
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            
            return dt;
        }

        public DataTable GetEmpNameFromList(string groupName)
        {
            try
            {
                //cmd = new SqlCommand("select * from tbl_Employee_Info where Designation ='DO' and Group_Name = '" + cmbSelectTeam + "' and Active ='Yes' and Designation_Active ='Yes' and Department_Active ='Yes' and Group_Active ='Yes' order by Employee_ID ASC", DBConnection.SqlConnectionObject);
                cmd = new SqlCommand("select employee_name from tbl_Employee_Info where group_name ='" + groupName + "' or group_name ='All Group' order by designation_id asc", DBConnection.SqlConnectionObject);
                //select * from tbl_employee_info where group_name ='Ranesh Chandra Das Gupta' or group_name ='All Group' order by designation_id asc
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            
            return dt;
        }
        
        public DataTable GetDistinctActiveDesignation()
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("select distinct(e.designation),e.designation_id from tbl_Designation d, tbl_employee_info e where d.Active = 'Yes' and d.Designation != 'MD' and d.Designation != 'DMD' and d.designation = e.designation order by e.Designation_ID ASC", DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                //DataTable dt = new DataTable();
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

            return dt;
        }

        public DataTable EmpExist(string empName)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("select * from tbl_Employee_Info where Employee_Name = '" + empName + "'", DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                //DataTable dt = new DataTable();
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

            return dt;
        }

        public DataTable GetEmployeeDetailsForMarketSetup(string cmbSelectEmployeeForMarketSetup)
        {
            try
            {
                //cmd = new SqlCommand("select * from tbl_Employee_Info where Designation ='DO' and Group_Name = '" + cmbSelectTeam + "' and Active ='Yes' and Designation_Active ='Yes' and Department_Active ='Yes' and Group_Active ='Yes' order by Employee_ID ASC", DBConnection.SqlConnectionObject);
                cmd = new SqlCommand("select Employee_ID,Designation,Official_Cell_No from tbl_Employee_Info where Employee_Name ='" + cmbSelectEmployeeForMarketSetup + "'", DBConnection.SqlConnectionObject);
                //select * from tbl_employee_info where group_name ='Ranesh Chandra Das Gupta' or group_name ='All Group' order by designation_id asc
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            
            return dt;
        }
        
    }
}
