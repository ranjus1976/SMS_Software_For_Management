﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Windows.Forms;
using SMSapplication.DAL;
using SMSapplication.DAL.DAO;
using SMSapplication.DAL.Gateway;
using SMSapplication.UI;

namespace SMSapplication.BLL
{
    class ZoneDetailsManager
    {
        GroupDetailsManager objGroupDetailsManager = new GroupDetailsManager();
        DivisionDetailsManager objDivisionDetailsManager = new DivisionDetailsManager();
        private DataTable dt = new DataTable();
        private SqlCommand cmd = new SqlCommand();
        private SqlCommand cmdSqlUpdate = new SqlCommand();
        private SqlCommand cmdUpdateActivityEndDate = new SqlCommand();
        private SqlCommand cmdUpdateTeamDetailsActivityEndDate = new SqlCommand();
        private SqlCommand cmdUpdateTeamDetails = new SqlCommand();
        private SqlCommand cmdUpdateTeamDetailsByUpdatingDivision = new SqlCommand();
        private SqlCommand cmdUpdateTeamDivision = new SqlCommand();
        private SqlCommand cmdUpdateTeamDivisionActivityEndDate = new SqlCommand();
        private SqlDataReader dr;
        private SqlDataAdapter da = new SqlDataAdapter();
        private int zoneID;
        private int divisionID;
        private string divisionName;
        private int teamID;
        private string teamName;
        private string empZoneID;

        
        public DataTable ShowAllZone()
        {
            DBConnection.OpenSqlConnection();

            //cmd = new SqlCommand("select distinct(Division_Name),Group_ID from tbl_Division order by Group_ID ASC", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
            // closed on 20 July 2016
            //cmd = new SqlCommand("select * from tbl_Division order by Division_ID ASC", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
            // closed on 20 July 2016

            cmd = new SqlCommand("select z.Zone_ID, z.Zone_Name, z.Employee_Name, z.Designation_Code, z.Activity_Start_Date, z.Activity_End_Date, z.Active, " +
            "r.Region_Name, r.Region_ID " +
            "from tbl_Zone z " +
            "inner join tbl_Region_Zone rz " +
            "on z.Zone_ID = rz.Zone_ID " +
            "inner join tbl_Region r " +
            "on rz.Region_ID = r.Region_ID " +
            "order by z.Zone_Name asc", DBConnection.SqlConnectionObject);

            da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DBConnection.CloseSqlConnection();
            return dt;
        }

        public void InsertZone(string zoneName, string empDesignationCode, string empName, string zoneActivityStartDate, string zoneActive, int regionIdForZone, string regionNameForZone)
        {
            string sql = @"insert into tbl_Zone(Zone_Name, Employee_Name, Designation_Code, Activity_Start_Date, Active) values ('"
                + zoneName + "','" + empName + "','" + empDesignationCode + "','" + zoneActivityStartDate + "','" + zoneActive + "')";

            cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
            DBConnection.OpenSqlConnection();
            cmd.ExecuteNonQuery();

            string cmdGetZoneID = "select Zone_ID from tbl_Zone where Zone_Name='" + zoneName + "'";
            cmd = new SqlCommand(cmdGetZoneID, DBConnection.SqlConnectionObject);
            da.SelectCommand = cmd;
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                dr = cmd.ExecuteReader();
                dr.Read();
                zoneID = Convert.ToInt16(dr[0].ToString());
                cmd.Dispose();
            }
            DBConnection.CloseSqlConnection();

            DBConnection.OpenSqlConnection();
            string sqlInsertRegionZone = @"insert into tbl_Region_Zone(Region_ID, Zone_ID, Created_On, Active) values (" + regionIdForZone + "," + zoneID + ",'" + zoneActivityStartDate + "','" + zoneActive + "')";
            cmd = new SqlCommand(sqlInsertRegionZone, DBConnection.SqlConnectionObject);
            cmd.ExecuteNonQuery();
            DBConnection.CloseSqlConnection();

            divisionID = Convert.ToInt16(objDivisionDetailsManager.GetDivisionIDFromDivisionRegion(regionIdForZone));
            if (divisionID != 0)
            {
                divisionName = objDivisionDetailsManager.GetDivisionName(divisionID);
            }

            teamID = Convert.ToInt16(objGroupDetailsManager.GetTeamIDFromTeamDivision(divisionID));

            teamName = objGroupDetailsManager.GetTeamName(teamID);
            if (teamName != "")
            {
                DBConnection.OpenSqlConnection();
                string sqlInsertTeamDetails = @"insert into tbl_Team_Details(Team_ID, Team_Name, Division_ID, Division_Name, Region_ID, Region_Name, Zone_ID, Zone_Name, Employee_Name, Designation_Code, Activity_Start_Date, Active) values (" + teamID + ", '" + teamName + "', " + divisionID + ", '" + divisionName + "', " + regionIdForZone + ", '" + regionNameForZone + "', " + zoneID + ", '" + zoneName + "','" + empName + "', '" + empDesignationCode + "', '" + zoneActivityStartDate + "','" + zoneActive + "')";
                cmd = new SqlCommand(sqlInsertTeamDetails, DBConnection.SqlConnectionObject);
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
        }

        public void UpdateZoneWithEndDate(int zoneId, string zoneName, string empDesignationCode, string empName, string zoneActivityStartDate, string zoneActivityEndDate, string zoneActive, string regionNameForZone, int regionIdForZone)
        {
            string sql = @"update tbl_Zone set Zone_Name = '" + zoneName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + zoneActivityStartDate + "', Activity_End_Date = '" + zoneActivityEndDate + "', Active = '" + zoneActive + "' where Zone_ID = " + zoneId + "".ToString(); //, Team_Name = '" + teamNameForDivision + "', Team_ID = " + teamIdForDivision + "
            //string sqlUpdateTeamDivision = @"update tbl_Team_Division set Modified_On = '" + divisionActivityEndDate + "', Active = '" + divisionActive + "' where Division_ID = " + divisionId + " and Team_ID = " + teamIdForDivision + " ".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "',
            //string sqlUpdateTeamDetails = @"update tbl_Team_Details set Activity_End_Date = '" + divisionActivityEndDate + "', Active = '" + divisionActive + "' where Division_ID = " + divisionId + " and Team_ID = " + teamIdForDivision + " ".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "',
            cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
            //cmdUpdateTeamDivision = new SqlCommand(sqlUpdateTeamDivision, DBConnection.SqlConnectionObject);
            //cmdUpdateTeamDetails = new SqlCommand(sqlUpdateTeamDetails, DBConnection.SqlConnectionObject);
            DBConnection.OpenSqlConnection();
            cmd.ExecuteNonQuery();
            //cmdUpdateTeamDivision.ExecuteNonQuery();
            //cmdUpdateTeamDetails.ExecuteNonQuery();
            DBConnection.CloseSqlConnection();
        }

        public void UpdateTeamDetailsWithEndDate(int zoneId, string zoneName, string empDesignationCode, string empName, string zoneActivityStartDate, string zoneActivityEndDate, string zoneActive, string regionNameForZone, int regionIdForZone)
        {
            string sqlUpdateTeamDetails = @"update tbl_Team_Details set Zone_Name = '" + zoneName + "' where Zone_ID = " + zoneId + "".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Team_Name = '" + teamNameForDivision + "', Team_ID = " + teamIdForDivision + ", Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "',, Activity_Start_Date = '" + divisionActivityStartDate + "', Activity_End_Date = '" + divisionActivityEndDate + "', Active = '" + divisionActive + "'
            string sqlUpdate = @"update tbl_Team_Details set  Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_End_Date = '" + zoneActivityEndDate + "', Active = '" + zoneActive + "' where Zone_ID = " + zoneId + " and Region_ID = " + regionIdForZone + " and Area_ID is null and Area_Name is null ".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "',
            cmdUpdateTeamDetails = new SqlCommand(sqlUpdateTeamDetails, DBConnection.SqlConnectionObject);
            cmdSqlUpdate = new SqlCommand(sqlUpdate, DBConnection.SqlConnectionObject);
            DBConnection.OpenSqlConnection();
            cmdUpdateTeamDetails.ExecuteNonQuery();
            cmdSqlUpdate.ExecuteNonQuery();
            DBConnection.CloseSqlConnection();
        }

        public void UpdateRegionZone(int zoneId, string zoneName, string empDesignationCode, string empName, string zoneActivityStartDate, string zoneActivityEndDate, string zoneActive, string regionNameForZone, int regionIdForZone)
        {
            string sqlUpdateDivisionRegion = @"update tbl_Region_Zone set Region_ID = " + regionIdForZone + ", Active = '" + zoneActive + "', Modified_On = '" + zoneActivityEndDate + "' where Zone_ID = " + zoneId + "".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "',
            string sqlUpdatesqlUpdateDivisionRegionActivityEndDate = @"update tbl_Region_Zone set Modified_On = NULL where Modified_On = '1/1/1900 12:00:00 AM'".ToString();
            cmdUpdateTeamDivision = new SqlCommand(sqlUpdateDivisionRegion, DBConnection.SqlConnectionObject);
            cmdUpdateTeamDivisionActivityEndDate = new SqlCommand(sqlUpdatesqlUpdateDivisionRegionActivityEndDate, DBConnection.SqlConnectionObject);
            DBConnection.OpenSqlConnection();
            cmdUpdateTeamDivision.ExecuteNonQuery();
            cmdUpdateTeamDivisionActivityEndDate.ExecuteNonQuery();
            DBConnection.CloseSqlConnection();
        }

        public void UpdateZone(int zoneId, string zoneName, string empDesignationCode, string empName, string zoneActivityStartDate, string zoneActivityEndDate, string zoneActive, string regionNameForZone, int regionIdForZone)
        {
            string sql = @"update tbl_Zone set Zone_Name = '" + zoneName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + zoneActivityStartDate + "', Activity_End_Date = '" + zoneActivityEndDate + "', Active = '" + zoneActive + "' where Zone_ID = " + zoneId + "".ToString(); //, Team_Name = '" + teamNameForDivision + "', Team_ID = " + teamIdForDivision + "
            string sqlUpdateActivityEndDate = @"update tbl_Zone set Activity_End_Date = NULL where Activity_End_Date = '1/1/1900 12:00:00 AM'".ToString();
            cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
            cmdUpdateActivityEndDate = new SqlCommand(sqlUpdateActivityEndDate, DBConnection.SqlConnectionObject);
            DBConnection.OpenSqlConnection();
            cmd.ExecuteNonQuery();
            cmdUpdateActivityEndDate.ExecuteNonQuery();
            DBConnection.CloseSqlConnection();
        }

        public void UpdateTeamDetails(int zoneId, string zoneName, string empDesignationCode, string empName, string zoneActivityStartDate, string zoneActivityEndDate, string zoneActive, string regionNameForZone, int regionIdForZone)
        {
            string sqlUpdateTeamDetails = @"update tbl_Team_Details set Zone_Name = '" + zoneName + "', Activity_Start_Date = '" + zoneActivityStartDate + "', Activity_End_Date = '" + zoneActivityEndDate + "', Active = '" + zoneActive + "' where Zone_ID = " + zoneId + "".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Team_Name = '" + teamNameForDivision + "', Team_ID = " + teamIdForDivision + ", Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "',
            string sqlUpdate = @"update tbl_Team_Details set Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "' where Zone_ID = " + zoneId + " and Area_ID is null and Area_Name is null".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Team_Name = '" + teamNameForDivision + "', Team_ID = " + teamIdForDivision + ", Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Division_Name = '" + divisionName + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Activity_End_Date = '" + divisionActivityEndDate + "', Active = '" + divisionActive + "' and Region_ID is null and Region_Name is null
            string sqlUpdateTeamDetailsActivityEndDate = @"update tbl_Team_Details set Activity_End_Date = NULL where Activity_End_Date = '1/1/1900 12:00:00 AM'".ToString();
            cmdUpdateTeamDetails = new SqlCommand(sqlUpdateTeamDetails, DBConnection.SqlConnectionObject);
            cmdSqlUpdate = new SqlCommand(sqlUpdate, DBConnection.SqlConnectionObject);
            cmdUpdateTeamDetailsActivityEndDate = new SqlCommand(sqlUpdateTeamDetailsActivityEndDate, DBConnection.SqlConnectionObject);
            DBConnection.OpenSqlConnection();
            cmdUpdateTeamDetails.ExecuteNonQuery();
            cmdSqlUpdate.ExecuteNonQuery();
            cmdUpdateTeamDetailsActivityEndDate.ExecuteNonQuery();
            DBConnection.CloseSqlConnection();
        }

        public void UpdateTeamDetailsByUpdateRegionName(int zoneId, string zoneName, string empDesignationCode, string empName, string zoneActivityStartDate, string zoneActivityEndDate, string zoneActive, string regionNameForZone, int regionIdForZone)
        {
            string sqlUpdateTeamDetails = @"update tbl_Team_Details set Zone_Name = '" + zoneName + "', Activity_Start_Date = '" + zoneActivityStartDate + "', Activity_End_Date = '" + zoneActivityEndDate + "', Active = '" + zoneActive + "' where Zone_ID = " + zoneId + "".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Team_Name = '" + teamNameForDivision + "', Team_ID = " + teamIdForDivision + ", Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "',
            string sqlUpdate = @"update tbl_Team_Details set Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "' where Zone_ID = " + zoneId + " and Area_ID is null and Area_Name is null".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Team_Name = '" + teamNameForDivision + "', Team_ID = " + teamIdForDivision + ", Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Division_Name = '" + divisionName + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Activity_End_Date = '" + divisionActivityEndDate + "', Active = '" + divisionActive + "' and Region_ID is null and Region_Name is null // and Zone_ID is null and Zone_Name is null and Area_ID is null and Area_Name is null
            string sqlUpdateTeam = @"update tbl_Team_Details set Region_Name = '" + regionNameForZone + "', Region_ID = " + regionIdForZone + " where Zone_ID = " + zoneId + "".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Team_Name = '" + teamNameForDivision + "', Team_ID = " + teamIdForDivision + ", Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Division_Name = '" + divisionName + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Activity_End_Date = '" + divisionActivityEndDate + "', Active = '" + divisionActive + "',and Region_ID is null and Region_Name is null and Zone_ID is null and Zone_Name is null and Area_ID is null and Area_Name is null
            string sqlUpdateTeamDetailsActivityEndDate = @"update tbl_Team_Details set Activity_End_Date = NULL where Activity_End_Date = '1/1/1900 12:00:00 AM'".ToString();
            cmdUpdateTeamDetails = new SqlCommand(sqlUpdateTeamDetails, DBConnection.SqlConnectionObject);
            cmdSqlUpdate = new SqlCommand(sqlUpdate, DBConnection.SqlConnectionObject);
            cmdUpdateTeamDetailsByUpdatingDivision = new SqlCommand(sqlUpdateTeam, DBConnection.SqlConnectionObject);
            cmdUpdateTeamDetailsActivityEndDate = new SqlCommand(sqlUpdateTeamDetailsActivityEndDate, DBConnection.SqlConnectionObject);
            DBConnection.OpenSqlConnection();
            cmdUpdateTeamDetails.ExecuteNonQuery();
            cmdSqlUpdate.ExecuteNonQuery();
            cmdUpdateTeamDetailsByUpdatingDivision.ExecuteNonQuery();
            cmdUpdateTeamDetailsActivityEndDate.ExecuteNonQuery();
            DBConnection.CloseSqlConnection();
        }

        public DataTable LoadDistinctEnabledZone()
        {
            DBConnection.OpenSqlConnection();
            cmd = new SqlCommand("select distinct(Zone_Name), Active from tbl_Zone where Active = 'Yes' order by Zone_Name ASC", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
            //cmd = new SqlCommand("select distinct(Division_Name),Group_ID, Active from tbl_Division where Active = 'Yes' order by Group_ID ASC", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
            //cmd = new SqlCommand("select * from tbl_Division order by Division_ID, Group_ID ASC", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
            da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DBConnection.CloseSqlConnection();
            return dt;
        }

        public string GetZoneID(string zone)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                string CommandText = "select Zone_ID from tbl_Zone where Zone_Name = '" + zone + "'";
                cmd = new SqlCommand(CommandText, DBConnection.SqlConnectionObject);
                //da = new SqlDataAdapter(cmd);
                da.SelectCommand = cmd;
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    dr = cmd.ExecuteReader();
                    dr.Read();
                    empZoneID = dr[0].ToString();
                    cmd.Dispose();
                    DBConnection.CloseSqlConnection();
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            return empZoneID;
        }
    }
}
