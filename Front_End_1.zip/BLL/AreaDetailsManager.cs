﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Windows.Forms;
using SMSapplication.DAL;
using SMSapplication.DAL.DAO;
using SMSapplication.DAL.Gateway;
using SMSapplication.UI;

namespace SMSapplication.BLL
{
    class AreaDetailsManager
    {
        GroupDetailsManager objGroupDetailsManager = new GroupDetailsManager();
        DivisionDetailsManager objDivisionDetailsManager = new DivisionDetailsManager();
        private SqlCommand cmd = new SqlCommand();
        private SqlDataAdapter da = new SqlDataAdapter();
        private SqlCommand cmdSqlUpdate = new SqlCommand();
        private SqlCommand cmdUpdateActivityEndDate = new SqlCommand();
        private SqlCommand cmdUpdateTeamDetailsActivityEndDate = new SqlCommand();
        private SqlCommand cmdUpdateTeamDetails = new SqlCommand();
        private SqlCommand cmdUpdateTeamDetailsByUpdatingDivision = new SqlCommand();
        private SqlCommand cmdUpdateTeamDivision = new SqlCommand();
        private SqlCommand cmdUpdateTeamDivisionActivityEndDate = new SqlCommand();
        private DataTable dt = new DataTable();
        private SqlDataReader dr;
        private int areaID;
        private int divisionID;
        private string divisionName;
        private int teamID;
        private string teamName;
        private int regionID;
        private string regionName;
        private string empNameForAreaForRestrictDuplicateFetch;
        int val;

        public DataTable ShowAllArea()
        {
            try
            {
                DBConnection.OpenSqlConnection();
                //cmd = new SqlCommand("select distinct(Division_Name),Group_ID from tbl_Division order by Group_ID ASC", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
                // closed on 20 July 2016
                //cmd = new SqlCommand("select * from tbl_Division order by Division_ID ASC", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
                // closed on 20 July 2016

                cmd = new SqlCommand("select a.Area_ID, a.Area_Name, a.Employee_Name, a.Designation_Code, a.Official_Cell_No, a.Activity_Start_Date, a.Activity_End_Date, a.Active, " +
                "z.Zone_Name, z.Zone_ID " +
                "from tbl_Area a " +
                "inner join tbl_Zone_Area za " +
                "on a.Area_ID = za.Area_ID " +
                "inner join tbl_Zone z " +
                "on za.Zone_ID = z.Zone_ID " +
                "order by a.Area_Name asc", DBConnection.SqlConnectionObject);

                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            
            return dt;
        }

        public void InsertArea(string areaName, string empDesignationCode, string empName, string officialCellno,string areaActivityStartDate, string areaActive, int zoneIdForArea, string zoneNameForArea)
        {
            try
            {
                string sql = @"insert into tbl_Area(Area_Name, Employee_Name, Designation_Code, Official_Cell_No, Activity_Start_Date, Active) values ('"
                                + areaName + "','" + empName + "','" + empDesignationCode + "','" + officialCellno + "','" + areaActivityStartDate + "','" + areaActive + "')";

                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();

                string cmdGetAreaID = "select Area_ID from tbl_Area where Area_Name ='" + areaName + "'";
                cmd = new SqlCommand(cmdGetAreaID, DBConnection.SqlConnectionObject);
                da.SelectCommand = cmd;
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    dr = cmd.ExecuteReader();
                    dr.Read();
                    areaID = Convert.ToInt16(dr[0].ToString());
                    //empNameForAreaForRestrictDuplicateFetch = dr[1].ToString();
                    cmd.Dispose();
                }
                DBConnection.CloseSqlConnection();

                DBConnection.OpenSqlConnection();
                string sqlInsertZoneArea = @"insert into tbl_Zone_Area(Zone_ID, Area_ID, Created_On, Active) values (" + zoneIdForArea + "," + areaID + ",'" + areaActivityStartDate + "','" + areaActive + "')";
                cmd = new SqlCommand(sqlInsertZoneArea, DBConnection.SqlConnectionObject);
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();

                DBConnection.OpenSqlConnection();
                if (areaID != 0 && zoneIdForArea != 0)
                {
                    //string cmdGetDataForTeamDetails = "select Team_ID,Team_Name,Division_ID,Division_Name,Region_ID,Region_Name from tbl_Team_Details where Zone_ID = " + zoneIdForArea + " and Area_ID = " + areaID + " and Employee_Name = '" + empName + "'";
                    string cmdGetDataForTeamDetails = "select Team_ID,Team_Name,Division_ID,Division_Name,Region_ID,Region_Name from tbl_Team_Details where Zone_ID = " + zoneIdForArea + "";
                    cmd = new SqlCommand(cmdGetDataForTeamDetails, DBConnection.SqlConnectionObject);
                    da.SelectCommand = cmd;
                    DataSet dsGetDataForTeamDetails = new DataSet();
                    da.Fill(dsGetDataForTeamDetails);
                    if (dsGetDataForTeamDetails.Tables[0].Rows.Count > 0)
                    {
                        dr = cmd.ExecuteReader();
                        dr.Read();
                        teamID = Convert.ToInt16(dr[0].ToString());
                        teamName = dr[1].ToString();
                        divisionID = Convert.ToInt16(dr[2].ToString());
                        divisionName = dr[3].ToString();
                        regionID = Convert.ToInt16(dr[4].ToString());
                        regionName = dr[5].ToString();
                        cmd.Dispose();
                    }
                    DBConnection.CloseSqlConnection();

                    DBConnection.OpenSqlConnection();
                    string sqlInsertTeamDetails = @"insert into tbl_Team_Details(Team_ID, Team_Name, Division_ID, Division_Name, Region_ID, Region_Name, Zone_ID, Zone_Name, Area_ID, Area_Name, Employee_Name, Designation_Code, Activity_Start_Date, Active) values (" + teamID + ", '" + teamName + "', " + divisionID + ", '" + divisionName + "', " + regionID + ", '" + regionName + "', " + zoneIdForArea + ", '" + zoneNameForArea + "', " + areaID + ", '" + areaName + "','" + empName + "', '" + empDesignationCode + "', '" + areaActivityStartDate + "','" + areaActive + "')";
                    cmd = new SqlCommand(sqlInsertTeamDetails, DBConnection.SqlConnectionObject);
                    cmd.ExecuteNonQuery();
                    DBConnection.CloseSqlConnection();
                }

                //divisionID = Convert.ToInt16(objDivisionDetailsManager.GetDivisionIDFromDivisionRegion(regionIdForZone));
                //if (divisionID != 0)
                //{
                //    divisionName = objDivisionDetailsManager.GetDivisionName(divisionID);
                //}

                //teamID = Convert.ToInt16(objGroupDetailsManager.GetTeamIDFromTeamDivision(divisionID));

                //teamName = objGroupDetailsManager.GetTeamName(teamID);
                //if (teamName != "")
                //{
                //    DBConnection.OpenSqlConnection();
                //    string sqlInsertTeamDetails = @"insert into tbl_Team_Details(Team_ID, Team_Name, Division_ID, Division_Name, Region_ID, Region_Name, Zone_ID, Zone_Name, Employee_Name, Designation_Code, Activity_Start_Date, Active) values (" + teamID + ", '" + teamName + "', " + divisionID + ", '" + divisionName + "', " + regionIdForZone + ", '" + regionNameForZone + "', " + zoneID + ", '" + zoneName + "','" + empName + "', '" + empDesignationCode + "', '" + zoneActivityStartDate + "','" + zoneActive + "')";
                //    cmd = new SqlCommand(sqlInsertTeamDetails, DBConnection.SqlConnectionObject);
                //    cmd.ExecuteNonQuery();
                //    DBConnection.CloseSqlConnection();
                //}
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
        }

        public void UpdateAreaWithEndDate(int areaId, string areaName, string empDesignationCode, string empName, string areaActivityStartDate, string areaActivityEndDate, string areaActive, string zoneNameForArea, int zoneIdForArea, string cellNo)
        {
            try
            {
                string sql = @"update tbl_Area set Area_Name = '" + areaName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + areaActivityStartDate + "', Activity_End_Date = '" + areaActivityEndDate + "', Active = '" + areaActive + "', Official_Cell_No = '" + cellNo + "'  where Area_ID = " + areaId + "".ToString(); //, Team_Name = '" + teamNameForDivision + "', Team_ID = " + teamIdForDivision + "
                //string sqlUpdateTeamDivision = @"update tbl_Team_Division set Modified_On = '" + divisionActivityEndDate + "', Active = '" + divisionActive + "' where Division_ID = " + divisionId + " and Team_ID = " + teamIdForDivision + " ".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "',
                //string sqlUpdateTeamDetails = @"update tbl_Team_Details set Activity_End_Date = '" + divisionActivityEndDate + "', Active = '" + divisionActive + "' where Division_ID = " + divisionId + " and Team_ID = " + teamIdForDivision + " ".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "',
                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                //cmdUpdateTeamDivision = new SqlCommand(sqlUpdateTeamDivision, DBConnection.SqlConnectionObject);
                //cmdUpdateTeamDetails = new SqlCommand(sqlUpdateTeamDetails, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                //cmdUpdateTeamDivision.ExecuteNonQuery();
                //cmdUpdateTeamDetails.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
        }

        public void UpdateTeamDetailsWithEndDate(int areaId, string areaName, string empDesignationCode, string empName, string areaActivityStartDate, string areaActivityEndDate, string areaActive, string zoneNameForArea, int zoneIdForArea)
        {
            try
            {
                string sqlUpdateTeamDetails = @"update tbl_Team_Details set Area_Name = '" + areaName + "' where Area_ID = " + areaId + "".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Team_Name = '" + teamNameForDivision + "', Team_ID = " + teamIdForDivision + ", Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "',, Activity_Start_Date = '" + divisionActivityStartDate + "', Activity_End_Date = '" + divisionActivityEndDate + "', Active = '" + divisionActive + "'
                string sqlUpdate = @"update tbl_Team_Details set  Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_End_Date = '" + areaActivityEndDate + "', Active = '" + areaActive + "' where Area_ID = " + areaId + " and Zone_ID = " + zoneIdForArea + " and Area_Name is not null and Zone_Name is not null".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "',
                cmdUpdateTeamDetails = new SqlCommand(sqlUpdateTeamDetails, DBConnection.SqlConnectionObject);
                cmdSqlUpdate = new SqlCommand(sqlUpdate, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmdUpdateTeamDetails.ExecuteNonQuery();
                cmdSqlUpdate.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
        }

        public void UpdateZoneArea(int areaId, string areaName, string empDesignationCode, string empName, string areaActivityStartDate, string areaActivityEndDate, string areaActive, string zoneNameForArea, int zoneIdForArea)
        {
            try
            {
                string sqlUpdateZoneArea = @"update tbl_Zone_Area set Zone_ID = " + zoneIdForArea + ", Active = '" + areaActive + "', Modified_On = '" + areaActivityEndDate + "' where Area_ID = " + areaId + "".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "',
                string sqlUpdateZoneAreaActivityEndDate = @"update tbl_Zone_Area set Modified_On = NULL where Modified_On = '1/1/1900 12:00:00 AM'".ToString();
                cmdUpdateTeamDivision = new SqlCommand(sqlUpdateZoneArea, DBConnection.SqlConnectionObject);
                cmdUpdateTeamDivisionActivityEndDate = new SqlCommand(sqlUpdateZoneAreaActivityEndDate, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmdUpdateTeamDivision.ExecuteNonQuery();
                cmdUpdateTeamDivisionActivityEndDate.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
        }

        public void UpdateArea(int areaId, string areaName, string empDesignationCode, string empName, string areaActivityStartDate, string areaActivityEndDate, string areaActive, string zoneNameForArea, int zoneIdForArea, string cellNo)
        {
            try
            {
                string sql = @"update tbl_Area set Area_Name = '" + areaName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + areaActivityStartDate + "', Activity_End_Date = '" + areaActivityEndDate + "', Active = '" + areaActive + "' where Area_ID = " + areaId + "".ToString(); //, Team_Name = '" + teamNameForDivision + "', Team_ID = " + teamIdForDivision + "
                string sqlUpdateActivityEndDate = @"update tbl_Area set Activity_End_Date = NULL where Activity_End_Date = '1/1/1900 12:00:00 AM'".ToString();
                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                cmdUpdateActivityEndDate = new SqlCommand(sqlUpdateActivityEndDate, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                cmdUpdateActivityEndDate.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
        }

        public void UpdateTeamDetails(int areaId, string areaName, string empDesignationCode, string empName, string areaActivityStartDate, string areaActivityEndDate, string areaActive, string zoneNameForArea, int zoneIdForArea)
        {
            try
            {
                string sqlUpdateTeamDetails = @"update tbl_Team_Details set Area_Name = '" + areaName + "', Activity_Start_Date = '" + areaActivityStartDate + "', Activity_End_Date = '" + areaActivityEndDate + "', Active = '" + areaActive + "' where Area_ID = " + areaId + "".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Team_Name = '" + teamNameForDivision + "', Team_ID = " + teamIdForDivision + ", Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "',
                string sqlUpdate = @"update tbl_Team_Details set Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "' where Area_ID = " + areaId + "".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Team_Name = '" + teamNameForDivision + "', Team_ID = " + teamIdForDivision + ", Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Division_Name = '" + divisionName + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Activity_End_Date = '" + divisionActivityEndDate + "', Active = '" + divisionActive + "' and Region_ID is null and Region_Name is null
                string sqlUpdateTeamDetailsActivityEndDate = @"update tbl_Team_Details set Activity_End_Date = NULL where Activity_End_Date = '1/1/1900 12:00:00 AM'".ToString();
                cmdUpdateTeamDetails = new SqlCommand(sqlUpdateTeamDetails, DBConnection.SqlConnectionObject);
                cmdSqlUpdate = new SqlCommand(sqlUpdate, DBConnection.SqlConnectionObject);
                cmdUpdateTeamDetailsActivityEndDate = new SqlCommand(sqlUpdateTeamDetailsActivityEndDate, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmdUpdateTeamDetails.ExecuteNonQuery();
                cmdSqlUpdate.ExecuteNonQuery();
                cmdUpdateTeamDetailsActivityEndDate.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
        }

        public void UpdateTeamDetailsByUpdateZoneName(int areaId, string areaName, string empDesignationCode, string empName, string areaActivityStartDate, string areaActivityEndDate, string areaActive, string zoneNameForArea, int zoneIdForArea)
        {
            try
            {
                string sqlUpdateTeamDetails = @"update tbl_Team_Details set Area_Name = '" + areaName + "', Activity_Start_Date = '" + areaActivityStartDate + "', Activity_End_Date = '" + areaActivityEndDate + "', Active = '" + areaActive + "' where Area_ID = " + areaId + "".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Team_Name = '" + teamNameForDivision + "', Team_ID = " + teamIdForDivision + ", Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "',
                string sqlUpdate = @"update tbl_Team_Details set Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "' where Area_ID = " + areaId + "".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Team_Name = '" + teamNameForDivision + "', Team_ID = " + teamIdForDivision + ", Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Division_Name = '" + divisionName + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Activity_End_Date = '" + divisionActivityEndDate + "', Active = '" + divisionActive + "' and Region_ID is null and Region_Name is null // and Zone_ID is null and Zone_Name is null and Area_ID is null and Area_Name is null
                string sqlUpdateTeam = @"update tbl_Team_Details set Zone_Name = '" + zoneNameForArea + "', Zone_ID = " + zoneIdForArea + " where Area_ID = " + areaId + "".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Team_Name = '" + teamNameForDivision + "', Team_ID = " + teamIdForDivision + ", Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Division_Name = '" + divisionName + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Activity_End_Date = '" + divisionActivityEndDate + "', Active = '" + divisionActive + "',and Region_ID is null and Region_Name is null and Zone_ID is null and Zone_Name is null and Area_ID is null and Area_Name is null
                string sqlUpdateTeamDetailsActivityEndDate = @"update tbl_Team_Details set Activity_End_Date = NULL where Activity_End_Date = '1/1/1900 12:00:00 AM'".ToString();
                cmdUpdateTeamDetails = new SqlCommand(sqlUpdateTeamDetails, DBConnection.SqlConnectionObject);
                cmdSqlUpdate = new SqlCommand(sqlUpdate, DBConnection.SqlConnectionObject);
                cmdUpdateTeamDetailsByUpdatingDivision = new SqlCommand(sqlUpdateTeam, DBConnection.SqlConnectionObject);
                cmdUpdateTeamDetailsActivityEndDate = new SqlCommand(sqlUpdateTeamDetailsActivityEndDate, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmdUpdateTeamDetails.ExecuteNonQuery();
                cmdSqlUpdate.ExecuteNonQuery();
                cmdUpdateTeamDetailsByUpdatingDivision.ExecuteNonQuery();
                cmdUpdateTeamDetailsActivityEndDate.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
        }

        public int checkDuplicateCellNoForInsertArea(string cellNoForArea)
        {
            try
            {
                string checkDuplicateCellNo = "select * from tbl_Area where Official_Cell_No = '" + cellNoForArea + "'";
                cmd = new SqlCommand(checkDuplicateCellNo, DBConnection.SqlConnectionObject);
                //da = new SqlDataAdapter(cmd);
                da.SelectCommand = cmd;
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    val = 1;
                }
                else
                {
                    val = 0;
                }
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            
            return val;
        }
    }
}
