﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Windows.Forms;
using SMSapplication.DAL;
using SMSapplication.DAL.DAO;
using SMSapplication.DAL.Gateway;
using SMSapplication.UI;

namespace SMSapplication.BLL
{
    class RegionDetailsManager
    {
        GroupDetailsManager objGroupDetailsManager = new GroupDetailsManager();
        private DataTable dt = new DataTable();
        private SqlCommand cmd = new SqlCommand();
        private SqlCommand cmdSqlUpdate = new SqlCommand();
        private SqlCommand cmdUpdateActivityEndDate = new SqlCommand();
        private SqlCommand cmdUpdateTeamDetailsActivityEndDate = new SqlCommand();
        private SqlCommand cmdUpdateTeamDetails = new SqlCommand();
        private SqlCommand cmdUpdateTeamDetailsByUpdatingDivision = new SqlCommand();
        private SqlCommand cmdUpdateTeamDivision = new SqlCommand();
        private SqlCommand cmdUpdateTeamDivisionActivityEndDate = new SqlCommand();
        private SqlDataReader dr;
        private SqlDataAdapter da = new SqlDataAdapter();
        private int regionID;
        private int teamID;
        private string empTeamName;
        private string empRegionID;

        public DataTable ShowAllRegion()
        {
            try
            {
                DBConnection.OpenSqlConnection();

                //cmd = new SqlCommand("select distinct(Division_Name),Group_ID from tbl_Division order by Group_ID ASC", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
                // closed on 20 July 2016
                //cmd = new SqlCommand("select * from tbl_Division order by Division_ID ASC", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
                // closed on 20 July 2016

                cmd = new SqlCommand("select r.Region_ID, r.Region_Name, r.Employee_Name, r.Designation_Code, r.Activity_Start_Date, r.Activity_End_Date, r.Active, " +
                "d.Division_Name, d.Division_ID " +
                "from tbl_Region r " +
                "inner join tbl_Division_Region dr " +
                "on r.Region_ID = dr.Region_ID " +
                "inner join tbl_Division d " +
                "on dr.Division_ID = d.Division_ID " +
                "order by r.Region_Name asc", DBConnection.SqlConnectionObject);

                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            
            return dt;
        }

        public string GetRegionID(string region)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                string CommandText = "select Region_ID from tbl_Region where Region_Name = '" + region + "'";
                cmd = new SqlCommand(CommandText, DBConnection.SqlConnectionObject);
                //da = new SqlDataAdapter(cmd);
                da.SelectCommand = cmd;
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    dr = cmd.ExecuteReader();
                    dr.Read();
                    empRegionID = dr[0].ToString();
                    cmd.Dispose();
                    DBConnection.CloseSqlConnection();
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            return empRegionID;
        }

        public DataTable LoadDistinctEnabledRegion()
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("select distinct(Region_Name), Active from tbl_Region where Active = 'Yes' order by Region_Name ASC", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
                //cmd = new SqlCommand("select distinct(Division_Name),Group_ID, Active from tbl_Division where Active = 'Yes' order by Group_ID ASC", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
                //cmd = new SqlCommand("select * from tbl_Division order by Division_ID, Group_ID ASC", DBConnection.SqlConnectionObject);//order by Employee_ID,From_Date ASC
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
                //return dt;
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            return dt;
        }

        public void InsertRegion(string regionName, string empDesignationCode, string empName, string regionActivityStartDate, string regionActive, int divisionIdForRegion, string divisionNameForRegion)
        {
            try
            {
                string sql = @"insert into tbl_Region(Region_Name, Employee_Name, Designation_Code, Activity_Start_Date, Active) values ('"
                + regionName + "','" + empName + "','" + empDesignationCode + "','" + regionActivityStartDate + "','" + regionActive + "')";

                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();

                string cmdGetRegionID = "select Region_ID from tbl_Region where Region_Name='" + regionName + "'";
                cmd = new SqlCommand(cmdGetRegionID, DBConnection.SqlConnectionObject);
                da.SelectCommand = cmd;
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    dr = cmd.ExecuteReader();
                    dr.Read();
                    regionID = Convert.ToInt16(dr[0].ToString());
                    cmd.Dispose();
                }
                DBConnection.CloseSqlConnection();

                DBConnection.OpenSqlConnection();
                string sqlInsertDivisionRegion = @"insert into tbl_Division_Region(Division_ID, Region_ID, Created_On, Active) values (" + divisionIdForRegion + "," + regionID + ",'" + regionActivityStartDate + "','" + regionActive + "')";
                cmd = new SqlCommand(sqlInsertDivisionRegion, DBConnection.SqlConnectionObject);
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();

                teamID = Convert.ToInt16(objGroupDetailsManager.GetTeamIDFromTeamDivision(divisionIdForRegion));

                empTeamName = objGroupDetailsManager.GetTeamName(teamID);
                if (empTeamName != "")
                {
                    DBConnection.OpenSqlConnection();
                    string sqlInsertTeamDetails = @"insert into tbl_Team_Details(Team_ID, Team_Name, Division_ID, Division_Name, Region_ID, Region_Name, Employee_Name, Designation_Code, Activity_Start_Date, Active) values (" + teamID + ", '" + empTeamName + "', " + divisionIdForRegion + ", '" + divisionNameForRegion + "', " + regionID + ", '" + regionName + "', '" + empName + "', '" + empDesignationCode + "', '" + regionActivityStartDate + "','" + regionActive + "')";
                    cmd = new SqlCommand(sqlInsertTeamDetails, DBConnection.SqlConnectionObject);
                    cmd.ExecuteNonQuery();
                    DBConnection.CloseSqlConnection();
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
        }

        public void UpdateRegionWithEndDate(int regionId, string regionName, string empDesignationCode, string empName, string regionActivityStartDate, string regionActivityEndDate, string regionActive, string divisionNameForRegion, int divisionIdForRegion)
        {
            try
            {
                string sql = @"update tbl_Region set Region_Name = '" + regionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + regionActivityStartDate + "', Activity_End_Date = '" + regionActivityEndDate + "', Active = '" + regionActive + "' where Region_ID = " + regionId + "".ToString(); //, Team_Name = '" + teamNameForDivision + "', Team_ID = " + teamIdForDivision + "
                //string sqlUpdateTeamDivision = @"update tbl_Team_Division set Modified_On = '" + divisionActivityEndDate + "', Active = '" + divisionActive + "' where Division_ID = " + divisionId + " and Team_ID = " + teamIdForDivision + " ".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "',
                //string sqlUpdateTeamDetails = @"update tbl_Team_Details set Activity_End_Date = '" + divisionActivityEndDate + "', Active = '" + divisionActive + "' where Division_ID = " + divisionId + " and Team_ID = " + teamIdForDivision + " ".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "',
                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                //cmdUpdateTeamDivision = new SqlCommand(sqlUpdateTeamDivision, DBConnection.SqlConnectionObject);
                //cmdUpdateTeamDetails = new SqlCommand(sqlUpdateTeamDetails, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                //cmdUpdateTeamDivision.ExecuteNonQuery();
                //cmdUpdateTeamDetails.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
        }

        public void UpdateTeamDetailsWithEndDate(int regionId, string regionName, string empDesignationCode, string empName, string regionActivityStartDate, string regionActivityEndDate, string regionActive, string divisionNameForRegion, int divisionIdForRegion)
        {
            try
            {
                string sqlUpdateTeamDetails = @"update tbl_Team_Details set Region_Name = '" + regionName + "' where Region_ID = " + regionId + "".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Team_Name = '" + teamNameForDivision + "', Team_ID = " + teamIdForDivision + ", Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "',, Activity_Start_Date = '" + divisionActivityStartDate + "', Activity_End_Date = '" + divisionActivityEndDate + "', Active = '" + divisionActive + "'
                string sqlUpdate = @"update tbl_Team_Details set  Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_End_Date = '" + regionActivityEndDate + "', Active = '" + regionActive + "' where Region_ID = " + regionId + " and Division_ID = " + divisionIdForRegion + " and Zone_ID is null and Zone_Name is null and Area_ID is null and Area_Name is null ".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "',
                cmdUpdateTeamDetails = new SqlCommand(sqlUpdateTeamDetails, DBConnection.SqlConnectionObject);
                cmdSqlUpdate = new SqlCommand(sqlUpdate, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmdUpdateTeamDetails.ExecuteNonQuery();
                cmdSqlUpdate.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
        }

        public void UpdateDivisionRegion(int regionId, string regionName, string empDesignationCode, string empName, string regionActivityStartDate, string regionActivityEndDate, string regionActive, string divisionNameForRegion, int divisionIdForRegion)
        {
            try
            {
                string sqlUpdateDivisionRegion = @"update tbl_Division_Region set Division_ID = " + divisionIdForRegion + ", Active = '" + regionActive + "', Modified_On = '" + regionActivityEndDate + "' where Region_ID = " + regionId + "".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "',
                string sqlUpdatesqlUpdateDivisionRegionActivityEndDate = @"update tbl_Division_Region set Modified_On = NULL where Modified_On = '1/1/1900 12:00:00 AM'".ToString();
                cmdUpdateTeamDivision = new SqlCommand(sqlUpdateDivisionRegion, DBConnection.SqlConnectionObject);
                cmdUpdateTeamDivisionActivityEndDate = new SqlCommand(sqlUpdatesqlUpdateDivisionRegionActivityEndDate, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmdUpdateTeamDivision.ExecuteNonQuery();
                cmdUpdateTeamDivisionActivityEndDate.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
        }

        public void UpdateRegion(int regionId, string regionName, string empDesignationCode, string empName, string regionActivityStartDate, string regionActivityEndDate, string regionActive, string divisionNameForRegion, int divisionIdForRegion)
        {
            try
            {
                string sql = @"update tbl_Region set Region_Name = '" + regionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + regionActivityStartDate + "', Activity_End_Date = '" + regionActivityEndDate + "', Active = '" + regionActive + "' where Region_ID = " + regionId + "".ToString(); //, Team_Name = '" + teamNameForDivision + "', Team_ID = " + teamIdForDivision + "
                string sqlUpdateActivityEndDate = @"update tbl_Region set Activity_End_Date = NULL where Activity_End_Date = '1/1/1900 12:00:00 AM'".ToString();
                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                cmdUpdateActivityEndDate = new SqlCommand(sqlUpdateActivityEndDate, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                cmdUpdateActivityEndDate.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
        }

        public void UpdateTeamDetails(int regionId, string regionName, string empDesignationCode, string empName, string regionActivityStartDate, string regionActivityEndDate, string regionActive, string divisionNameForRegion, int divisionIdForRegion)
        {
            try
            {
                string sqlUpdateTeamDetails = @"update tbl_Team_Details set Region_Name = '" + regionName + "', Activity_Start_Date = '" + regionActivityStartDate + "', Activity_End_Date = '" + regionActivityEndDate + "', Active = '" + regionActive + "' where Region_ID = " + regionId + "".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Team_Name = '" + teamNameForDivision + "', Team_ID = " + teamIdForDivision + ", Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "',
                string sqlUpdate = @"update tbl_Team_Details set Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "' where Region_ID = " + regionId + " and Zone_ID is null and Zone_Name is null and Area_ID is null and Area_Name is null".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Team_Name = '" + teamNameForDivision + "', Team_ID = " + teamIdForDivision + ", Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Division_Name = '" + divisionName + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Activity_End_Date = '" + divisionActivityEndDate + "', Active = '" + divisionActive + "' and Region_ID is null and Region_Name is null
                string sqlUpdateTeamDetailsActivityEndDate = @"update tbl_Team_Details set Activity_End_Date = NULL where Activity_End_Date = '1/1/1900 12:00:00 AM'".ToString();
                cmdUpdateTeamDetails = new SqlCommand(sqlUpdateTeamDetails, DBConnection.SqlConnectionObject);
                cmdSqlUpdate = new SqlCommand(sqlUpdate, DBConnection.SqlConnectionObject);
                cmdUpdateTeamDetailsActivityEndDate = new SqlCommand(sqlUpdateTeamDetailsActivityEndDate, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmdUpdateTeamDetails.ExecuteNonQuery();
                cmdSqlUpdate.ExecuteNonQuery();
                cmdUpdateTeamDetailsActivityEndDate.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
        }

        public void UpdateTeamDetailsForCheck(int regionId, string regionName, string empDesignationCode, string empName, string regionActivityStartDate, string regionActivityEndDate, string regionActive, string divisionNameForRegion, int divisionIdForRegion, int teamID, string teamName)
        {
            try
            {
                string sqlUpdateTeamDetails = @"update tbl_Team_Details set Team_ID = " + teamID + ", Team_Name =  '" + teamName + "', Division_ID = " + divisionIdForRegion + ", Division_Name =  '" + divisionNameForRegion + "',Region_Name = '" + regionName + "', Activity_Start_Date = '" + regionActivityStartDate + "', Activity_End_Date = '" + regionActivityEndDate + "', Active = '" + regionActive + "' where Region_ID = " + regionId + "".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Team_Name = '" + teamNameForDivision + "', Team_ID = " + teamIdForDivision + ", Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "',
                string sqlUpdate = @"update tbl_Team_Details set Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "' where Region_ID = " + regionId + " ".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Team_Name = '" + teamNameForDivision + "', Team_ID = " + teamIdForDivision + ", Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Division_Name = '" + divisionName + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Activity_End_Date = '" + divisionActivityEndDate + "', Active = '" + divisionActive + "' and Region_ID is null and Region_Name is null
                string sqlUpdateTeamDetailsActivityEndDate = @"update tbl_Team_Details set Activity_End_Date = NULL where Activity_End_Date = '1/1/1900 12:00:00 AM'".ToString();
                cmdUpdateTeamDetails = new SqlCommand(sqlUpdateTeamDetails, DBConnection.SqlConnectionObject);
                cmdSqlUpdate = new SqlCommand(sqlUpdate, DBConnection.SqlConnectionObject);
                cmdUpdateTeamDetailsActivityEndDate = new SqlCommand(sqlUpdateTeamDetailsActivityEndDate, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmdUpdateTeamDetails.ExecuteNonQuery();
                cmdSqlUpdate.ExecuteNonQuery();
                cmdUpdateTeamDetailsActivityEndDate.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
        }

        public void UpdateTeamDetailsByUpdateDivisionName(int regionId, string regionName, string empDesignationCode, string empName, string regionActivityStartDate, string regionActivityEndDate, string regionActive, string divisionNameForRegion, int divisionIdForRegion)
        {
            try
            {
                string sqlUpdateTeamDetails = @"update tbl_Team_Details set Region_Name = '" + regionName + "', Activity_Start_Date = '" + regionActivityStartDate + "', Activity_End_Date = '" + regionActivityEndDate + "', Active = '" + regionActive + "' where Region_ID = " + regionId + "".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Team_Name = '" + teamNameForDivision + "', Team_ID = " + teamIdForDivision + ", Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "',
                string sqlUpdate = @"update tbl_Team_Details set Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "' where Region_ID = " + regionId + " and Zone_ID is null and Zone_Name is null and Area_ID is null and Area_Name is null".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Team_Name = '" + teamNameForDivision + "', Team_ID = " + teamIdForDivision + ", Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Division_Name = '" + divisionName + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Activity_End_Date = '" + divisionActivityEndDate + "', Active = '" + divisionActive + "' and Region_ID is null and Region_Name is null // and Zone_ID is null and Zone_Name is null and Area_ID is null and Area_Name is null
                string sqlUpdateTeam = @"update tbl_Team_Details set Division_Name = '" + divisionNameForRegion + "', Division_ID = " + divisionIdForRegion + " where Region_ID = " + regionId + "".ToString(); //Division_Name = '" + divisionName + "', Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Team_Name = '" + teamNameForDivision + "', Team_ID = " + teamIdForDivision + ", Employee_Name = '" + empName + "', Designation_Code = '" + empDesignationCode + "', Division_Name = '" + divisionName + "', Activity_Start_Date = '" + divisionActivityStartDate + "', Activity_End_Date = '" + divisionActivityEndDate + "', Active = '" + divisionActive + "',and Region_ID is null and Region_Name is null and Zone_ID is null and Zone_Name is null and Area_ID is null and Area_Name is null
                string sqlUpdateTeamDetailsActivityEndDate = @"update tbl_Team_Details set Activity_End_Date = NULL where Activity_End_Date = '1/1/1900 12:00:00 AM'".ToString();
                cmdUpdateTeamDetails = new SqlCommand(sqlUpdateTeamDetails, DBConnection.SqlConnectionObject);
                cmdSqlUpdate = new SqlCommand(sqlUpdate, DBConnection.SqlConnectionObject);
                cmdUpdateTeamDetailsByUpdatingDivision = new SqlCommand(sqlUpdateTeam, DBConnection.SqlConnectionObject);
                cmdUpdateTeamDetailsActivityEndDate = new SqlCommand(sqlUpdateTeamDetailsActivityEndDate, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmdUpdateTeamDetails.ExecuteNonQuery();
                cmdSqlUpdate.ExecuteNonQuery();
                cmdUpdateTeamDetailsByUpdatingDivision.ExecuteNonQuery();
                cmdUpdateTeamDetailsActivityEndDate.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
        }
    }
}
