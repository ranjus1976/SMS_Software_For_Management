﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Windows.Forms;
using SMSapplication.DAL;
using SMSapplication.DAL.DAO;
using SMSapplication.DAL.Gateway;
using SMSapplication.UI;

namespace SMSapplication.BLL
{
    public class SalesDetailsManager
    {
        public int logInval = 0;
        private SqlDataAdapter da = new SqlDataAdapter();
        private DataTable dt = new DataTable();
        private SqlCommand cmd = new SqlCommand();
        private SqlDataReader dr;

        public DataTable ShowAllSales()
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd = new SqlCommand("select * from tbl_Sales order by Sales_Date,Employee_ID ASC",
                    DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                //DataTable dt = new DataTable();
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

            return dt;
        }

        public DataTable CheckDuplicate(string SalesDate, string ProCodeForSales, string EmpNameForSales)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd =
                    new SqlCommand(
                        "select * from tbl_Sales where Sales_Date = '" + SalesDate + "' and Product_Code = '" +
                        ProCodeForSales + "' and Employee_Name = '" + EmpNameForSales + "'",
                        DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                //DataTable dt = new DataTable();
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

            return dt;
        }

        public void DeleteSales(string SalesDate, string ProCodeForSales, string EmpNameForSales)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd =
                    new SqlCommand("delete tbl_Sales where Sales_Date = '" + SalesDate + "' and Product_Code = '" +
                                   ProCodeForSales + "' and Employee_Name = '" + EmpNameForSales + "'", DBConnection.SqlConnectionObject);
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        public DataTable CheckDuplicateInSalesTargetExclude(string SalesDate, string ProCodeForSales, string EmpNameForSales)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd =
                    new SqlCommand(
                        "select * from tbl_Sales_Exclude_Target where Sales_Date = '" + SalesDate + "' and Product_Code = '" +
                        ProCodeForSales + "' and Employee_Name = '" + EmpNameForSales + "'",
                        DBConnection.SqlConnectionObject);
                da = new SqlDataAdapter(cmd);
                //DataTable dt = new DataTable();
                dt = new DataTable();
                da.Fill(dt);
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

            return dt;
        }

        public void DeleteSalesInSalesTargetExclude(string SalesDate, string ProCodeForSales, string EmpNameForSales)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                cmd =
                    new SqlCommand("delete tbl_Sales_Exclude_Target where Sales_Date = '" + SalesDate + "' and Product_Code = '" +
                                   ProCodeForSales + "' and Employee_Name = '" + EmpNameForSales + "'", DBConnection.SqlConnectionObject);
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }
    }
}

