﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Windows.Forms;
using SMSapplication.DAL;
using SMSapplication.DAL.DAO;
using SMSapplication.DAL.Gateway;
using SMSapplication.UI;

namespace SMSapplication.BLL
{
    public class UserRoleDetailsManager
    {
        private string userRoleID;
        UserRoleDetailsGateway objUserRoleDetailsGateway = new UserRoleDetailsGateway();

        public string GetUserRoleID(string userRoleName)
        {
            try
            {
                userRoleID = objUserRoleDetailsGateway.GetUserRoleID(userRoleName);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            return userRoleID;
        }
    }
}
