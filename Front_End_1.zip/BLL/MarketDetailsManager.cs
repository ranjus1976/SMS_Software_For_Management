﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Windows.Forms;
using SMSapplication.DAL;
using SMSapplication.DAL.DAO;
using SMSapplication.DAL.Gateway;
using SMSapplication.UI;

namespace SMSapplication.BLL
{
    public class MarketDetailsManager
    {
        public int logInval = 0;
        private DataTable dt = new DataTable();
        private SqlCommand cmd = new SqlCommand();
        private SqlDataReader dr;
        private SqlDataAdapter da = new SqlDataAdapter();

        //closed on 17 May 2016
        //public void InsertMarket(string marketCode, string marketName, int noOfParty, int target, int monthlyNoOfVisit, string marketActive, int empIdForMarket, string empNameForMarket, string empOfficialCellForMarket, string empDesignationForMarketint, int groupIdForMarket, string groupNameForMarket)
        //{
        //    try
        //    {
        //        string sql = @"insert into tbl_Market(Market_Code,Name_Of_Market,Total_No_Of_Party,Target,Monthly_No_Of_Visit,Active,Employee_ID,Employee_Name,Official_Cell_No,Employee_Designation,Group_ID,Group_Name) values ('"
        //        + marketCode + "','" + marketName + "'," + noOfParty + "," + target + "," + monthlyNoOfVisit + ",'" + marketActive + "'," + empIdForMarket + ", '" + empNameForMarket + "','" + empOfficialCellForMarket + "','" + empDesignationForMarketint + "'," + groupIdForMarket + ", '" + groupNameForMarket + "')";
        //        cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
        //        DBConnection.OpenSqlConnection();
        //        cmd.ExecuteNonQuery();
        //        DBConnection.CloseSqlConnection();
        //    }
        //    catch (Exception e)
        //    {
        //        MessageBox.Show(e.Message);
        //    }
        //}
        //end closed on 17 May 2016

        //new on 17 May 2016
        public void InsertMarket(string marketCode, string marketName, int noOfParty, int target, int monthlyNoOfVisit, int groupID, string  groupName, string divisionName, string marketActive)
        {
            try
            {
                string sql = @"insert into tbl_Market(Market_Code,Name_Of_Market,Total_No_Of_Party,Target,Monthly_No_Of_Visit,Group_ID,Group_Name,DivisionName,Active) values ('" + marketCode + "','" + marketName + "'," + noOfParty + "," + target + "," + monthlyNoOfVisit + "," + groupID + ",'" + groupName + "','" + divisionName + "','" + marketActive + "')";
                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }
        //end of new on 17 May 2016


        //public void UpdateMarket(int marketID, string marketCode, string marketName, int noOfParty, int target, int monthlyNoOfVisit, string marketActive, int empIdForMarket, string empNameForMarket, string empOfficialCellForMarket, string empDesignationForMarketint, int groupIdForMarket, string groupNameForMarket)
        //{
        //    try
        //    {
        //        string sql = @"update tbl_Market set Market_Code = '" + marketCode + "', Name_Of_Market = '" + marketName + "', Total_No_Of_Party = " + noOfParty + ",  Target = " + target + ",  Monthly_No_Of_Visit = " + monthlyNoOfVisit + ",  Active = '" + marketActive +
        //        "',  Employee_ID = " + empIdForMarket + ",  Employee_Name = '" + empNameForMarket + "',  Official_Cell_No = '" + empOfficialCellForMarket + "', Employee_Designation = '" + empDesignationForMarketint + "', Group_ID = " + groupIdForMarket + ",  Group_Name = '" + groupNameForMarket + "' where Market_ID=" + marketID + "".ToString();
        //        cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
        //        DBConnection.OpenSqlConnection();
        //        cmd.ExecuteNonQuery();
        //        DBConnection.CloseSqlConnection();
        //    }
        //    catch (Exception e)
        //    {
        //        MessageBox.Show(e.Message);
        //        throw;
        //    }
        //}


        //new on 17 May 2016
        public void UpdateMarket(int marketID, string marketCode, string marketName, int noOfParty, int target, int monthlyNoOfVisit, int groupID, string groupName, string divisionName, string marketActive)
        {
            try
            {
                string sql = @"update tbl_Market set Market_Code = '" + marketCode + "', Name_Of_Market = '" + marketName + "', Total_No_Of_Party = " + noOfParty + ",  Target = " + target + ",  Monthly_No_Of_Visit = " + monthlyNoOfVisit + ", Group_ID =" + groupID + " ,Group_Name ='" + groupName + "' , DivisionName = '" + divisionName + "',  Active = '" + marketActive + "' where Market_ID=" + marketID + "".ToString();
                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                throw;
            }
        }
        //end of new on 17 May 2016

        public void UpdateMarketSetup(string marketCode, string empName, Int16 empID, string empDesignation, string empCell)
        {
            try
            {
                string sql = @"update tbl_Market set Employee_Name = '" + empName + "', Employee_ID = " + empID + ", Employee_Designation = '" + empDesignation + "',  Official_Cell_No = '" + empCell + "' where Market_Code = '" + marketCode + "'".ToString();
                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                throw;
            }
        }

        public void UpdateMarketSetupNew(string marketCode, string groupName, Int16 groupID, string division, string empName, Int16 empID, string empDesignation, string empCell)
        {
            try
            {
                string sql = @"update tbl_Market set Group_Name = '" + groupName + "', Group_ID = " + groupID + ", DivisionName = '" + division + "', Employee_Name = '" + empName + "', Employee_ID = " + empID + ", Employee_Designation = '" + empDesignation + "',  Official_Cell_No = '" + empCell + "' where Market_Code = '" + marketCode + "'".ToString();
                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                throw;
            }
        }

        //UpdateMarketSetup(marketCode, empName, empID, empDesignation, empCell)

        public DataTable AllMarketDetails()
        {
            DBConnection.OpenSqlConnection();
            cmd = new SqlCommand("select * from tbl_Market", DBConnection.SqlConnectionObject);
            da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DBConnection.CloseSqlConnection();
            return dt;            
        }

        public DataTable LoadAllMarket()
        {
            DBConnection.OpenSqlConnection();
            cmd = new SqlCommand("select Distinct(Market_Code) from tbl_Market", DBConnection.SqlConnectionObject);
            da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DBConnection.CloseSqlConnection();
            return dt;
        }

        public void UpdateMarketByChangingDivision(string tmpEmpName, int tmpGroupID, string tmpGroupName, string tmpDivisionName, string tmpDivisionActive)
        {
            try
            {
                string sql = @"update tbl_Market set Group_Name = '" + tmpGroupName + "', Group_ID = " + tmpGroupID + ", DivisionName = '" + tmpDivisionName + "', Active = '" + tmpDivisionActive + "' where Employee_Name = '" + tmpEmpName + "'".ToString();
                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                throw;
            }
        }

        //UpdateMarketByChangingDivision(tmpEmpName,tmpGroupID,tmpGroupName,tmpDivisionName,tmpDivisionActive);

        public DataTable LoadMarketBySelectedDivision(string divisionName)
        {
            DBConnection.OpenSqlConnection();
            cmd = new SqlCommand("select Distinct(Market_Code),Name_Of_Market from tbl_Market where DivisionName = '" + divisionName +"'", DBConnection.SqlConnectionObject);
            da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DBConnection.CloseSqlConnection();
            return dt;
        }
    }
}
