﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Windows.Forms;
using SMSapplication.DAL;
using SMSapplication.DAL.DAO;
using SMSapplication.DAL.Gateway;
using SMSapplication.UI;

namespace SMSapplication.BLL
{
    public class DepartmentDetailsManager
    {
        public int logInval = 0;
        //private UserDetailsGateway objUserDetails = new UserDetailsGateway();
        private DepartmentDetailsGateway objDepartmentDetailsGateway = new DepartmentDetailsGateway();
        private DataTable dt = new DataTable();
        private SqlCommand cmd = new SqlCommand();
        private SqlDataReader dr;
        private string empDepartmentID;
        private string empDepartmentActiveDetails;
        private SqlDataAdapter da = new SqlDataAdapter();

        public string GetDepartmentID(string department)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                string CommandText = "select * from tbl_Department where Department_Name='" + department + "'";
                cmd = new SqlCommand(CommandText, DBConnection.SqlConnectionObject);
                //da = new SqlDataAdapter(cmd);
                da.SelectCommand = cmd;
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    dr = cmd.ExecuteReader();
                    dr.Read();
                    empDepartmentID = dr[0].ToString();
                    cmd.Dispose();
                    DBConnection.CloseSqlConnection();
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            return empDepartmentID;
        }

        public string GetDepartmentActiveDetails(int departmentID)
        {
            try
            {
                DBConnection.OpenSqlConnection();
                string CommandText = "select * from tbl_Department where Department_ID='" + departmentID + "'";
                cmd = new SqlCommand(CommandText, DBConnection.SqlConnectionObject);
                //da = new SqlDataAdapter(cmd);
                da.SelectCommand = cmd;
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    dr = cmd.ExecuteReader();
                    dr.Read();
                    empDepartmentActiveDetails = dr[2].ToString();
                    cmd.Dispose();
                    DBConnection.CloseSqlConnection();
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "No connection to Database........");
            }
            return empDepartmentActiveDetails;
        }

        public DataTable AllDepartmentDetails()
        {
            try
            {
                //DataTable dt = new DataTable();
                dt = new DataTable();
                dt = objDepartmentDetailsGateway.ShowAllDepartment();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            return dt;
        }

        public DataTable LoadDepartmentCombo()
        {
            try
            {
                //DataTable dt = new DataTable();
                dt = new DataTable();
                dt = objDepartmentDetailsGateway.LoadAllActiveDepartment();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            return dt;
        }

        public void InsertNewDepartment(string deptName, string deptActivate)
        {
            try
            {
                string sql = @"insert into tbl_Department(Department_Name,Active) values ('"+ deptName + "','" + deptActivate + "')";
                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        public void UpdateDepartment(int deptID, string deptName, string deptActivate)
        {
            try
            {
                string sql = @"update tbl_Department set Department_Name = '" + deptName + "', Active = '" + deptActivate + "' where Department_ID=" + deptID + "".ToString();
                cmd = new SqlCommand(sql, DBConnection.SqlConnectionObject);
                DBConnection.OpenSqlConnection();
                cmd.ExecuteNonQuery();
                DBConnection.CloseSqlConnection();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }
    }
}
