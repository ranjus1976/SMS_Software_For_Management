using System;
using System.Collections.Generic;
using System.Windows.Forms;
using SMSapplication.UI;

namespace SMSapplication
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            //Application.Run(new AppSMS());
            Application.Run(new LoginUI());
            //Application.Run(new SMSapplication());
        }
    }
}